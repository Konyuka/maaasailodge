import { onMounted, onUpdated, useSSRContext, mergeProps, unref, withCtx, createVNode } from "vue";
import { ssrRenderAttrs, ssrRenderSlot, ssrRenderStyle, ssrRenderAttr, ssrRenderComponent } from "vue/server-renderer";
import WOW from "wow.js";
import { Head } from "@inertiajs/vue3";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.js";
import "locomotive-scroll";
/*! jQuery v3.3.1 | (c) JS Foundation and other contributors | jquery.org/license */
!function(e, t) {
  "object" == typeof module && "object" == typeof module.exports ? module.exports = e.document ? t(e, true) : function(e2) {
    if (!e2.document)
      throw new Error("jQuery requires a window with a document");
    return t(e2);
  } : t(e);
}("undefined" != typeof window ? window : globalThis, function(e, t) {
  var n = [], r = e.document, i = Object.getPrototypeOf, o = n.slice, a = n.concat, s = n.push, u = n.indexOf, l = {}, c = l.toString, f = l.hasOwnProperty, p = f.toString, d = p.call(Object), h = {}, g = function e2(t2) {
    return "function" == typeof t2 && "number" != typeof t2.nodeType;
  }, y = function e2(t2) {
    return null != t2 && t2 === t2.window;
  }, v = { type: true, src: true, noModule: true };
  function m(e2, t2, n2) {
    var i2, o2 = (t2 = t2 || r).createElement("script");
    if (o2.text = e2, n2)
      for (i2 in v)
        n2[i2] && (o2[i2] = n2[i2]);
    t2.head.appendChild(o2).parentNode.removeChild(o2);
  }
  function x(e2) {
    return null == e2 ? e2 + "" : "object" == typeof e2 || "function" == typeof e2 ? l[c.call(e2)] || "object" : typeof e2;
  }
  var w = function(e2, t2) {
    return new w.fn.init(e2, t2);
  }, T = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
  w.fn = w.prototype = { jquery: "3.3.1", constructor: w, length: 0, toArray: function() {
    return o.call(this);
  }, get: function(e2) {
    return null == e2 ? o.call(this) : e2 < 0 ? this[e2 + this.length] : this[e2];
  }, pushStack: function(e2) {
    var t2 = w.merge(this.constructor(), e2);
    return t2.prevObject = this, t2;
  }, each: function(e2) {
    return w.each(this, e2);
  }, map: function(e2) {
    return this.pushStack(w.map(this, function(t2, n2) {
      return e2.call(t2, n2, t2);
    }));
  }, slice: function() {
    return this.pushStack(o.apply(this, arguments));
  }, first: function() {
    return this.eq(0);
  }, last: function() {
    return this.eq(-1);
  }, eq: function(e2) {
    var t2 = this.length, n2 = +e2 + (e2 < 0 ? t2 : 0);
    return this.pushStack(n2 >= 0 && n2 < t2 ? [this[n2]] : []);
  }, end: function() {
    return this.prevObject || this.constructor();
  }, push: s, sort: n.sort, splice: n.splice }, w.extend = w.fn.extend = function() {
    var e2, t2, n2, r2, i2, o2, a2 = arguments[0] || {}, s2 = 1, u2 = arguments.length, l2 = false;
    for ("boolean" == typeof a2 && (l2 = a2, a2 = arguments[s2] || {}, s2++), "object" == typeof a2 || g(a2) || (a2 = {}), s2 === u2 && (a2 = this, s2--); s2 < u2; s2++)
      if (null != (e2 = arguments[s2]))
        for (t2 in e2)
          n2 = a2[t2], a2 !== (r2 = e2[t2]) && (l2 && r2 && (w.isPlainObject(r2) || (i2 = Array.isArray(r2))) ? (i2 ? (i2 = false, o2 = n2 && Array.isArray(n2) ? n2 : []) : o2 = n2 && w.isPlainObject(n2) ? n2 : {}, a2[t2] = w.extend(l2, o2, r2)) : void 0 !== r2 && (a2[t2] = r2));
    return a2;
  }, w.extend({ expando: "jQuery" + ("3.3.1" + Math.random()).replace(/\D/g, ""), isReady: true, error: function(e2) {
    throw new Error(e2);
  }, noop: function() {
  }, isPlainObject: function(e2) {
    var t2, n2;
    return !(!e2 || "[object Object]" !== c.call(e2)) && (!(t2 = i(e2)) || "function" == typeof (n2 = f.call(t2, "constructor") && t2.constructor) && p.call(n2) === d);
  }, isEmptyObject: function(e2) {
    var t2;
    for (t2 in e2)
      return false;
    return true;
  }, globalEval: function(e2) {
    m(e2);
  }, each: function(e2, t2) {
    var n2, r2 = 0;
    if (C(e2)) {
      for (n2 = e2.length; r2 < n2; r2++)
        if (false === t2.call(e2[r2], r2, e2[r2]))
          break;
    } else
      for (r2 in e2)
        if (false === t2.call(e2[r2], r2, e2[r2]))
          break;
    return e2;
  }, trim: function(e2) {
    return null == e2 ? "" : (e2 + "").replace(T, "");
  }, makeArray: function(e2, t2) {
    var n2 = t2 || [];
    return null != e2 && (C(Object(e2)) ? w.merge(n2, "string" == typeof e2 ? [e2] : e2) : s.call(n2, e2)), n2;
  }, inArray: function(e2, t2, n2) {
    return null == t2 ? -1 : u.call(t2, e2, n2);
  }, merge: function(e2, t2) {
    for (var n2 = +t2.length, r2 = 0, i2 = e2.length; r2 < n2; r2++)
      e2[i2++] = t2[r2];
    return e2.length = i2, e2;
  }, grep: function(e2, t2, n2) {
    for (var r2, i2 = [], o2 = 0, a2 = e2.length, s2 = !n2; o2 < a2; o2++)
      (r2 = !t2(e2[o2], o2)) !== s2 && i2.push(e2[o2]);
    return i2;
  }, map: function(e2, t2, n2) {
    var r2, i2, o2 = 0, s2 = [];
    if (C(e2))
      for (r2 = e2.length; o2 < r2; o2++)
        null != (i2 = t2(e2[o2], o2, n2)) && s2.push(i2);
    else
      for (o2 in e2)
        null != (i2 = t2(e2[o2], o2, n2)) && s2.push(i2);
    return a.apply([], s2);
  }, guid: 1, support: h }), "function" == typeof Symbol && (w.fn[Symbol.iterator] = n[Symbol.iterator]), w.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function(e2, t2) {
    l["[object " + t2 + "]"] = t2.toLowerCase();
  });
  function C(e2) {
    var t2 = !!e2 && "length" in e2 && e2.length, n2 = x(e2);
    return !g(e2) && !y(e2) && ("array" === n2 || 0 === t2 || "number" == typeof t2 && t2 > 0 && t2 - 1 in e2);
  }
  var E = function(e2) {
    var t2, n2, r2, i2, o2, a2, s2, u2, l2, c2, f2, p2, d2, h2, g2, y2, v2, m2, x2, b = "sizzle" + 1 * /* @__PURE__ */ new Date(), w2 = e2.document, T2 = 0, C2 = 0, E2 = ae2(), k2 = ae2(), S2 = ae2(), D2 = function(e3, t3) {
      return e3 === t3 && (f2 = true), 0;
    }, N2 = {}.hasOwnProperty, A2 = [], j2 = A2.pop, q2 = A2.push, L2 = A2.push, H2 = A2.slice, O2 = function(e3, t3) {
      for (var n3 = 0, r3 = e3.length; n3 < r3; n3++)
        if (e3[n3] === t3)
          return n3;
      return -1;
    }, P2 = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped", M2 = "[\\x20\\t\\r\\n\\f]", R2 = "(?:\\\\.|[\\w-]|[^\0-\\xa0])+", I2 = "\\[" + M2 + "*(" + R2 + ")(?:" + M2 + "*([*^$|!~]?=)" + M2 + `*(?:'((?:\\\\.|[^\\\\'])*)'|"((?:\\\\.|[^\\\\"])*)"|(` + R2 + "))|)" + M2 + "*\\]", W2 = ":(" + R2 + `)(?:\\((('((?:\\\\.|[^\\\\'])*)'|"((?:\\\\.|[^\\\\"])*)")|((?:\\\\.|[^\\\\()[\\]]|` + I2 + ")*)|.*)\\)|)", $2 = new RegExp(M2 + "+", "g"), B2 = new RegExp("^" + M2 + "+|((?:^|[^\\\\])(?:\\\\.)*)" + M2 + "+$", "g"), F2 = new RegExp("^" + M2 + "*," + M2 + "*"), _2 = new RegExp("^" + M2 + "*([>+~]|" + M2 + ")" + M2 + "*"), z2 = new RegExp("=" + M2 + `*([^\\]'"]*?)` + M2 + "*\\]", "g"), X2 = new RegExp(W2), U2 = new RegExp("^" + R2 + "$"), V2 = { ID: new RegExp("^#(" + R2 + ")"), CLASS: new RegExp("^\\.(" + R2 + ")"), TAG: new RegExp("^(" + R2 + "|[*])"), ATTR: new RegExp("^" + I2), PSEUDO: new RegExp("^" + W2), CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + M2 + "*(even|odd|(([+-]|)(\\d*)n|)" + M2 + "*(?:([+-]|)" + M2 + "*(\\d+)|))" + M2 + "*\\)|)", "i"), bool: new RegExp("^(?:" + P2 + ")$", "i"), needsContext: new RegExp("^" + M2 + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + M2 + "*((?:-\\d)?\\d*)" + M2 + "*\\)|)(?=[^-]|$)", "i") }, G2 = /^(?:input|select|textarea|button)$/i, Y2 = /^h\d$/i, Q2 = /^[^{]+\{\s*\[native \w/, J2 = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/, K2 = /[+~]/, Z2 = new RegExp("\\\\([\\da-f]{1,6}" + M2 + "?|(" + M2 + ")|.)", "ig"), ee2 = function(e3, t3, n3) {
      var r3 = "0x" + t3 - 65536;
      return r3 !== r3 || n3 ? t3 : r3 < 0 ? String.fromCharCode(r3 + 65536) : String.fromCharCode(r3 >> 10 | 55296, 1023 & r3 | 56320);
    }, te2 = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g, ne2 = function(e3, t3) {
      return t3 ? "\0" === e3 ? "�" : e3.slice(0, -1) + "\\" + e3.charCodeAt(e3.length - 1).toString(16) + " " : "\\" + e3;
    }, re2 = function() {
      p2();
    }, ie2 = me2(function(e3) {
      return true === e3.disabled && ("form" in e3 || "label" in e3);
    }, { dir: "parentNode", next: "legend" });
    try {
      L2.apply(A2 = H2.call(w2.childNodes), w2.childNodes), A2[w2.childNodes.length].nodeType;
    } catch (e3) {
      L2 = { apply: A2.length ? function(e4, t3) {
        q2.apply(e4, H2.call(t3));
      } : function(e4, t3) {
        var n3 = e4.length, r3 = 0;
        while (e4[n3++] = t3[r3++])
          ;
        e4.length = n3 - 1;
      } };
    }
    function oe2(e3, t3, r3, i3) {
      var o3, s3, l3, c3, f3, h3, v3, m3 = t3 && t3.ownerDocument, T3 = t3 ? t3.nodeType : 9;
      if (r3 = r3 || [], "string" != typeof e3 || !e3 || 1 !== T3 && 9 !== T3 && 11 !== T3)
        return r3;
      if (!i3 && ((t3 ? t3.ownerDocument || t3 : w2) !== d2 && p2(t3), t3 = t3 || d2, g2)) {
        if (11 !== T3 && (f3 = J2.exec(e3)))
          if (o3 = f3[1]) {
            if (9 === T3) {
              if (!(l3 = t3.getElementById(o3)))
                return r3;
              if (l3.id === o3)
                return r3.push(l3), r3;
            } else if (m3 && (l3 = m3.getElementById(o3)) && x2(t3, l3) && l3.id === o3)
              return r3.push(l3), r3;
          } else {
            if (f3[2])
              return L2.apply(r3, t3.getElementsByTagName(e3)), r3;
            if ((o3 = f3[3]) && n2.getElementsByClassName && t3.getElementsByClassName)
              return L2.apply(r3, t3.getElementsByClassName(o3)), r3;
          }
        if (n2.qsa && !S2[e3 + " "] && (!y2 || !y2.test(e3))) {
          if (1 !== T3)
            m3 = t3, v3 = e3;
          else if ("object" !== t3.nodeName.toLowerCase()) {
            (c3 = t3.getAttribute("id")) ? c3 = c3.replace(te2, ne2) : t3.setAttribute("id", c3 = b), s3 = (h3 = a2(e3)).length;
            while (s3--)
              h3[s3] = "#" + c3 + " " + ve2(h3[s3]);
            v3 = h3.join(","), m3 = K2.test(e3) && ge2(t3.parentNode) || t3;
          }
          if (v3)
            try {
              return L2.apply(r3, m3.querySelectorAll(v3)), r3;
            } catch (e4) {
            } finally {
              c3 === b && t3.removeAttribute("id");
            }
        }
      }
      return u2(e3.replace(B2, "$1"), t3, r3, i3);
    }
    function ae2() {
      var e3 = [];
      function t3(n3, i3) {
        return e3.push(n3 + " ") > r2.cacheLength && delete t3[e3.shift()], t3[n3 + " "] = i3;
      }
      return t3;
    }
    function se2(e3) {
      return e3[b] = true, e3;
    }
    function ue2(e3) {
      var t3 = d2.createElement("fieldset");
      try {
        return !!e3(t3);
      } catch (e4) {
        return false;
      } finally {
        t3.parentNode && t3.parentNode.removeChild(t3), t3 = null;
      }
    }
    function le2(e3, t3) {
      var n3 = e3.split("|"), i3 = n3.length;
      while (i3--)
        r2.attrHandle[n3[i3]] = t3;
    }
    function ce2(e3, t3) {
      var n3 = t3 && e3, r3 = n3 && 1 === e3.nodeType && 1 === t3.nodeType && e3.sourceIndex - t3.sourceIndex;
      if (r3)
        return r3;
      if (n3) {
        while (n3 = n3.nextSibling)
          if (n3 === t3)
            return -1;
      }
      return e3 ? 1 : -1;
    }
    function fe2(e3) {
      return function(t3) {
        return "input" === t3.nodeName.toLowerCase() && t3.type === e3;
      };
    }
    function pe2(e3) {
      return function(t3) {
        var n3 = t3.nodeName.toLowerCase();
        return ("input" === n3 || "button" === n3) && t3.type === e3;
      };
    }
    function de2(e3) {
      return function(t3) {
        return "form" in t3 ? t3.parentNode && false === t3.disabled ? "label" in t3 ? "label" in t3.parentNode ? t3.parentNode.disabled === e3 : t3.disabled === e3 : t3.isDisabled === e3 || t3.isDisabled !== !e3 && ie2(t3) === e3 : t3.disabled === e3 : "label" in t3 && t3.disabled === e3;
      };
    }
    function he2(e3) {
      return se2(function(t3) {
        return t3 = +t3, se2(function(n3, r3) {
          var i3, o3 = e3([], n3.length, t3), a3 = o3.length;
          while (a3--)
            n3[i3 = o3[a3]] && (n3[i3] = !(r3[i3] = n3[i3]));
        });
      });
    }
    function ge2(e3) {
      return e3 && "undefined" != typeof e3.getElementsByTagName && e3;
    }
    n2 = oe2.support = {}, o2 = oe2.isXML = function(e3) {
      var t3 = e3 && (e3.ownerDocument || e3).documentElement;
      return !!t3 && "HTML" !== t3.nodeName;
    }, p2 = oe2.setDocument = function(e3) {
      var t3, i3, a3 = e3 ? e3.ownerDocument || e3 : w2;
      return a3 !== d2 && 9 === a3.nodeType && a3.documentElement ? (d2 = a3, h2 = d2.documentElement, g2 = !o2(d2), w2 !== d2 && (i3 = d2.defaultView) && i3.top !== i3 && (i3.addEventListener ? i3.addEventListener("unload", re2, false) : i3.attachEvent && i3.attachEvent("onunload", re2)), n2.attributes = ue2(function(e4) {
        return e4.className = "i", !e4.getAttribute("className");
      }), n2.getElementsByTagName = ue2(function(e4) {
        return e4.appendChild(d2.createComment("")), !e4.getElementsByTagName("*").length;
      }), n2.getElementsByClassName = Q2.test(d2.getElementsByClassName), n2.getById = ue2(function(e4) {
        return h2.appendChild(e4).id = b, !d2.getElementsByName || !d2.getElementsByName(b).length;
      }), n2.getById ? (r2.filter.ID = function(e4) {
        var t4 = e4.replace(Z2, ee2);
        return function(e5) {
          return e5.getAttribute("id") === t4;
        };
      }, r2.find.ID = function(e4, t4) {
        if ("undefined" != typeof t4.getElementById && g2) {
          var n3 = t4.getElementById(e4);
          return n3 ? [n3] : [];
        }
      }) : (r2.filter.ID = function(e4) {
        var t4 = e4.replace(Z2, ee2);
        return function(e5) {
          var n3 = "undefined" != typeof e5.getAttributeNode && e5.getAttributeNode("id");
          return n3 && n3.value === t4;
        };
      }, r2.find.ID = function(e4, t4) {
        if ("undefined" != typeof t4.getElementById && g2) {
          var n3, r3, i4, o3 = t4.getElementById(e4);
          if (o3) {
            if ((n3 = o3.getAttributeNode("id")) && n3.value === e4)
              return [o3];
            i4 = t4.getElementsByName(e4), r3 = 0;
            while (o3 = i4[r3++])
              if ((n3 = o3.getAttributeNode("id")) && n3.value === e4)
                return [o3];
          }
          return [];
        }
      }), r2.find.TAG = n2.getElementsByTagName ? function(e4, t4) {
        return "undefined" != typeof t4.getElementsByTagName ? t4.getElementsByTagName(e4) : n2.qsa ? t4.querySelectorAll(e4) : void 0;
      } : function(e4, t4) {
        var n3, r3 = [], i4 = 0, o3 = t4.getElementsByTagName(e4);
        if ("*" === e4) {
          while (n3 = o3[i4++])
            1 === n3.nodeType && r3.push(n3);
          return r3;
        }
        return o3;
      }, r2.find.CLASS = n2.getElementsByClassName && function(e4, t4) {
        if ("undefined" != typeof t4.getElementsByClassName && g2)
          return t4.getElementsByClassName(e4);
      }, v2 = [], y2 = [], (n2.qsa = Q2.test(d2.querySelectorAll)) && (ue2(function(e4) {
        h2.appendChild(e4).innerHTML = "<a id='" + b + "'></a><select id='" + b + "-\r\\' msallowcapture=''><option selected=''></option></select>", e4.querySelectorAll("[msallowcapture^='']").length && y2.push("[*^$]=" + M2 + `*(?:''|"")`), e4.querySelectorAll("[selected]").length || y2.push("\\[" + M2 + "*(?:value|" + P2 + ")"), e4.querySelectorAll("[id~=" + b + "-]").length || y2.push("~="), e4.querySelectorAll(":checked").length || y2.push(":checked"), e4.querySelectorAll("a#" + b + "+*").length || y2.push(".#.+[+~]");
      }), ue2(function(e4) {
        e4.innerHTML = "<a href='' disabled='disabled'></a><select disabled='disabled'><option/></select>";
        var t4 = d2.createElement("input");
        t4.setAttribute("type", "hidden"), e4.appendChild(t4).setAttribute("name", "D"), e4.querySelectorAll("[name=d]").length && y2.push("name" + M2 + "*[*^$|!~]?="), 2 !== e4.querySelectorAll(":enabled").length && y2.push(":enabled", ":disabled"), h2.appendChild(e4).disabled = true, 2 !== e4.querySelectorAll(":disabled").length && y2.push(":enabled", ":disabled"), e4.querySelectorAll("*,:x"), y2.push(",.*:");
      })), (n2.matchesSelector = Q2.test(m2 = h2.matches || h2.webkitMatchesSelector || h2.mozMatchesSelector || h2.oMatchesSelector || h2.msMatchesSelector)) && ue2(function(e4) {
        n2.disconnectedMatch = m2.call(e4, "*"), m2.call(e4, "[s!='']:x"), v2.push("!=", W2);
      }), y2 = y2.length && new RegExp(y2.join("|")), v2 = v2.length && new RegExp(v2.join("|")), t3 = Q2.test(h2.compareDocumentPosition), x2 = t3 || Q2.test(h2.contains) ? function(e4, t4) {
        var n3 = 9 === e4.nodeType ? e4.documentElement : e4, r3 = t4 && t4.parentNode;
        return e4 === r3 || !(!r3 || 1 !== r3.nodeType || !(n3.contains ? n3.contains(r3) : e4.compareDocumentPosition && 16 & e4.compareDocumentPosition(r3)));
      } : function(e4, t4) {
        if (t4) {
          while (t4 = t4.parentNode)
            if (t4 === e4)
              return true;
        }
        return false;
      }, D2 = t3 ? function(e4, t4) {
        if (e4 === t4)
          return f2 = true, 0;
        var r3 = !e4.compareDocumentPosition - !t4.compareDocumentPosition;
        return r3 || (1 & (r3 = (e4.ownerDocument || e4) === (t4.ownerDocument || t4) ? e4.compareDocumentPosition(t4) : 1) || !n2.sortDetached && t4.compareDocumentPosition(e4) === r3 ? e4 === d2 || e4.ownerDocument === w2 && x2(w2, e4) ? -1 : t4 === d2 || t4.ownerDocument === w2 && x2(w2, t4) ? 1 : c2 ? O2(c2, e4) - O2(c2, t4) : 0 : 4 & r3 ? -1 : 1);
      } : function(e4, t4) {
        if (e4 === t4)
          return f2 = true, 0;
        var n3, r3 = 0, i4 = e4.parentNode, o3 = t4.parentNode, a4 = [e4], s3 = [t4];
        if (!i4 || !o3)
          return e4 === d2 ? -1 : t4 === d2 ? 1 : i4 ? -1 : o3 ? 1 : c2 ? O2(c2, e4) - O2(c2, t4) : 0;
        if (i4 === o3)
          return ce2(e4, t4);
        n3 = e4;
        while (n3 = n3.parentNode)
          a4.unshift(n3);
        n3 = t4;
        while (n3 = n3.parentNode)
          s3.unshift(n3);
        while (a4[r3] === s3[r3])
          r3++;
        return r3 ? ce2(a4[r3], s3[r3]) : a4[r3] === w2 ? -1 : s3[r3] === w2 ? 1 : 0;
      }, d2) : d2;
    }, oe2.matches = function(e3, t3) {
      return oe2(e3, null, null, t3);
    }, oe2.matchesSelector = function(e3, t3) {
      if ((e3.ownerDocument || e3) !== d2 && p2(e3), t3 = t3.replace(z2, "='$1']"), n2.matchesSelector && g2 && !S2[t3 + " "] && (!v2 || !v2.test(t3)) && (!y2 || !y2.test(t3)))
        try {
          var r3 = m2.call(e3, t3);
          if (r3 || n2.disconnectedMatch || e3.document && 11 !== e3.document.nodeType)
            return r3;
        } catch (e4) {
        }
      return oe2(t3, d2, null, [e3]).length > 0;
    }, oe2.contains = function(e3, t3) {
      return (e3.ownerDocument || e3) !== d2 && p2(e3), x2(e3, t3);
    }, oe2.attr = function(e3, t3) {
      (e3.ownerDocument || e3) !== d2 && p2(e3);
      var i3 = r2.attrHandle[t3.toLowerCase()], o3 = i3 && N2.call(r2.attrHandle, t3.toLowerCase()) ? i3(e3, t3, !g2) : void 0;
      return void 0 !== o3 ? o3 : n2.attributes || !g2 ? e3.getAttribute(t3) : (o3 = e3.getAttributeNode(t3)) && o3.specified ? o3.value : null;
    }, oe2.escape = function(e3) {
      return (e3 + "").replace(te2, ne2);
    }, oe2.error = function(e3) {
      throw new Error("Syntax error, unrecognized expression: " + e3);
    }, oe2.uniqueSort = function(e3) {
      var t3, r3 = [], i3 = 0, o3 = 0;
      if (f2 = !n2.detectDuplicates, c2 = !n2.sortStable && e3.slice(0), e3.sort(D2), f2) {
        while (t3 = e3[o3++])
          t3 === e3[o3] && (i3 = r3.push(o3));
        while (i3--)
          e3.splice(r3[i3], 1);
      }
      return c2 = null, e3;
    }, i2 = oe2.getText = function(e3) {
      var t3, n3 = "", r3 = 0, o3 = e3.nodeType;
      if (o3) {
        if (1 === o3 || 9 === o3 || 11 === o3) {
          if ("string" == typeof e3.textContent)
            return e3.textContent;
          for (e3 = e3.firstChild; e3; e3 = e3.nextSibling)
            n3 += i2(e3);
        } else if (3 === o3 || 4 === o3)
          return e3.nodeValue;
      } else
        while (t3 = e3[r3++])
          n3 += i2(t3);
      return n3;
    }, (r2 = oe2.selectors = { cacheLength: 50, createPseudo: se2, match: V2, attrHandle: {}, find: {}, relative: { ">": { dir: "parentNode", first: true }, " ": { dir: "parentNode" }, "+": { dir: "previousSibling", first: true }, "~": { dir: "previousSibling" } }, preFilter: { ATTR: function(e3) {
      return e3[1] = e3[1].replace(Z2, ee2), e3[3] = (e3[3] || e3[4] || e3[5] || "").replace(Z2, ee2), "~=" === e3[2] && (e3[3] = " " + e3[3] + " "), e3.slice(0, 4);
    }, CHILD: function(e3) {
      return e3[1] = e3[1].toLowerCase(), "nth" === e3[1].slice(0, 3) ? (e3[3] || oe2.error(e3[0]), e3[4] = +(e3[4] ? e3[5] + (e3[6] || 1) : 2 * ("even" === e3[3] || "odd" === e3[3])), e3[5] = +(e3[7] + e3[8] || "odd" === e3[3])) : e3[3] && oe2.error(e3[0]), e3;
    }, PSEUDO: function(e3) {
      var t3, n3 = !e3[6] && e3[2];
      return V2.CHILD.test(e3[0]) ? null : (e3[3] ? e3[2] = e3[4] || e3[5] || "" : n3 && X2.test(n3) && (t3 = a2(n3, true)) && (t3 = n3.indexOf(")", n3.length - t3) - n3.length) && (e3[0] = e3[0].slice(0, t3), e3[2] = n3.slice(0, t3)), e3.slice(0, 3));
    } }, filter: { TAG: function(e3) {
      var t3 = e3.replace(Z2, ee2).toLowerCase();
      return "*" === e3 ? function() {
        return true;
      } : function(e4) {
        return e4.nodeName && e4.nodeName.toLowerCase() === t3;
      };
    }, CLASS: function(e3) {
      var t3 = E2[e3 + " "];
      return t3 || (t3 = new RegExp("(^|" + M2 + ")" + e3 + "(" + M2 + "|$)")) && E2(e3, function(e4) {
        return t3.test("string" == typeof e4.className && e4.className || "undefined" != typeof e4.getAttribute && e4.getAttribute("class") || "");
      });
    }, ATTR: function(e3, t3, n3) {
      return function(r3) {
        var i3 = oe2.attr(r3, e3);
        return null == i3 ? "!=" === t3 : !t3 || (i3 += "", "=" === t3 ? i3 === n3 : "!=" === t3 ? i3 !== n3 : "^=" === t3 ? n3 && 0 === i3.indexOf(n3) : "*=" === t3 ? n3 && i3.indexOf(n3) > -1 : "$=" === t3 ? n3 && i3.slice(-n3.length) === n3 : "~=" === t3 ? (" " + i3.replace($2, " ") + " ").indexOf(n3) > -1 : "|=" === t3 && (i3 === n3 || i3.slice(0, n3.length + 1) === n3 + "-"));
      };
    }, CHILD: function(e3, t3, n3, r3, i3) {
      var o3 = "nth" !== e3.slice(0, 3), a3 = "last" !== e3.slice(-4), s3 = "of-type" === t3;
      return 1 === r3 && 0 === i3 ? function(e4) {
        return !!e4.parentNode;
      } : function(t4, n4, u3) {
        var l3, c3, f3, p3, d3, h3, g3 = o3 !== a3 ? "nextSibling" : "previousSibling", y3 = t4.parentNode, v3 = s3 && t4.nodeName.toLowerCase(), m3 = !u3 && !s3, x3 = false;
        if (y3) {
          if (o3) {
            while (g3) {
              p3 = t4;
              while (p3 = p3[g3])
                if (s3 ? p3.nodeName.toLowerCase() === v3 : 1 === p3.nodeType)
                  return false;
              h3 = g3 = "only" === e3 && !h3 && "nextSibling";
            }
            return true;
          }
          if (h3 = [a3 ? y3.firstChild : y3.lastChild], a3 && m3) {
            x3 = (d3 = (l3 = (c3 = (f3 = (p3 = y3)[b] || (p3[b] = {}))[p3.uniqueID] || (f3[p3.uniqueID] = {}))[e3] || [])[0] === T2 && l3[1]) && l3[2], p3 = d3 && y3.childNodes[d3];
            while (p3 = ++d3 && p3 && p3[g3] || (x3 = d3 = 0) || h3.pop())
              if (1 === p3.nodeType && ++x3 && p3 === t4) {
                c3[e3] = [T2, d3, x3];
                break;
              }
          } else if (m3 && (x3 = d3 = (l3 = (c3 = (f3 = (p3 = t4)[b] || (p3[b] = {}))[p3.uniqueID] || (f3[p3.uniqueID] = {}))[e3] || [])[0] === T2 && l3[1]), false === x3) {
            while (p3 = ++d3 && p3 && p3[g3] || (x3 = d3 = 0) || h3.pop())
              if ((s3 ? p3.nodeName.toLowerCase() === v3 : 1 === p3.nodeType) && ++x3 && (m3 && ((c3 = (f3 = p3[b] || (p3[b] = {}))[p3.uniqueID] || (f3[p3.uniqueID] = {}))[e3] = [T2, x3]), p3 === t4))
                break;
          }
          return (x3 -= i3) === r3 || x3 % r3 == 0 && x3 / r3 >= 0;
        }
      };
    }, PSEUDO: function(e3, t3) {
      var n3, i3 = r2.pseudos[e3] || r2.setFilters[e3.toLowerCase()] || oe2.error("unsupported pseudo: " + e3);
      return i3[b] ? i3(t3) : i3.length > 1 ? (n3 = [e3, e3, "", t3], r2.setFilters.hasOwnProperty(e3.toLowerCase()) ? se2(function(e4, n4) {
        var r3, o3 = i3(e4, t3), a3 = o3.length;
        while (a3--)
          e4[r3 = O2(e4, o3[a3])] = !(n4[r3] = o3[a3]);
      }) : function(e4) {
        return i3(e4, 0, n3);
      }) : i3;
    } }, pseudos: { not: se2(function(e3) {
      var t3 = [], n3 = [], r3 = s2(e3.replace(B2, "$1"));
      return r3[b] ? se2(function(e4, t4, n4, i3) {
        var o3, a3 = r3(e4, null, i3, []), s3 = e4.length;
        while (s3--)
          (o3 = a3[s3]) && (e4[s3] = !(t4[s3] = o3));
      }) : function(e4, i3, o3) {
        return t3[0] = e4, r3(t3, null, o3, n3), t3[0] = null, !n3.pop();
      };
    }), has: se2(function(e3) {
      return function(t3) {
        return oe2(e3, t3).length > 0;
      };
    }), contains: se2(function(e3) {
      return e3 = e3.replace(Z2, ee2), function(t3) {
        return (t3.textContent || t3.innerText || i2(t3)).indexOf(e3) > -1;
      };
    }), lang: se2(function(e3) {
      return U2.test(e3 || "") || oe2.error("unsupported lang: " + e3), e3 = e3.replace(Z2, ee2).toLowerCase(), function(t3) {
        var n3;
        do {
          if (n3 = g2 ? t3.lang : t3.getAttribute("xml:lang") || t3.getAttribute("lang"))
            return (n3 = n3.toLowerCase()) === e3 || 0 === n3.indexOf(e3 + "-");
        } while ((t3 = t3.parentNode) && 1 === t3.nodeType);
        return false;
      };
    }), target: function(t3) {
      var n3 = e2.location && e2.location.hash;
      return n3 && n3.slice(1) === t3.id;
    }, root: function(e3) {
      return e3 === h2;
    }, focus: function(e3) {
      return e3 === d2.activeElement && (!d2.hasFocus || d2.hasFocus()) && !!(e3.type || e3.href || ~e3.tabIndex);
    }, enabled: de2(false), disabled: de2(true), checked: function(e3) {
      var t3 = e3.nodeName.toLowerCase();
      return "input" === t3 && !!e3.checked || "option" === t3 && !!e3.selected;
    }, selected: function(e3) {
      return e3.parentNode && e3.parentNode.selectedIndex, true === e3.selected;
    }, empty: function(e3) {
      for (e3 = e3.firstChild; e3; e3 = e3.nextSibling)
        if (e3.nodeType < 6)
          return false;
      return true;
    }, parent: function(e3) {
      return !r2.pseudos.empty(e3);
    }, header: function(e3) {
      return Y2.test(e3.nodeName);
    }, input: function(e3) {
      return G2.test(e3.nodeName);
    }, button: function(e3) {
      var t3 = e3.nodeName.toLowerCase();
      return "input" === t3 && "button" === e3.type || "button" === t3;
    }, text: function(e3) {
      var t3;
      return "input" === e3.nodeName.toLowerCase() && "text" === e3.type && (null == (t3 = e3.getAttribute("type")) || "text" === t3.toLowerCase());
    }, first: he2(function() {
      return [0];
    }), last: he2(function(e3, t3) {
      return [t3 - 1];
    }), eq: he2(function(e3, t3, n3) {
      return [n3 < 0 ? n3 + t3 : n3];
    }), even: he2(function(e3, t3) {
      for (var n3 = 0; n3 < t3; n3 += 2)
        e3.push(n3);
      return e3;
    }), odd: he2(function(e3, t3) {
      for (var n3 = 1; n3 < t3; n3 += 2)
        e3.push(n3);
      return e3;
    }), lt: he2(function(e3, t3, n3) {
      for (var r3 = n3 < 0 ? n3 + t3 : n3; --r3 >= 0; )
        e3.push(r3);
      return e3;
    }), gt: he2(function(e3, t3, n3) {
      for (var r3 = n3 < 0 ? n3 + t3 : n3; ++r3 < t3; )
        e3.push(r3);
      return e3;
    }) } }).pseudos.nth = r2.pseudos.eq;
    for (t2 in { radio: true, checkbox: true, file: true, password: true, image: true })
      r2.pseudos[t2] = fe2(t2);
    for (t2 in { submit: true, reset: true })
      r2.pseudos[t2] = pe2(t2);
    function ye2() {
    }
    ye2.prototype = r2.filters = r2.pseudos, r2.setFilters = new ye2(), a2 = oe2.tokenize = function(e3, t3) {
      var n3, i3, o3, a3, s3, u3, l3, c3 = k2[e3 + " "];
      if (c3)
        return t3 ? 0 : c3.slice(0);
      s3 = e3, u3 = [], l3 = r2.preFilter;
      while (s3) {
        n3 && !(i3 = F2.exec(s3)) || (i3 && (s3 = s3.slice(i3[0].length) || s3), u3.push(o3 = [])), n3 = false, (i3 = _2.exec(s3)) && (n3 = i3.shift(), o3.push({ value: n3, type: i3[0].replace(B2, " ") }), s3 = s3.slice(n3.length));
        for (a3 in r2.filter)
          !(i3 = V2[a3].exec(s3)) || l3[a3] && !(i3 = l3[a3](i3)) || (n3 = i3.shift(), o3.push({ value: n3, type: a3, matches: i3 }), s3 = s3.slice(n3.length));
        if (!n3)
          break;
      }
      return t3 ? s3.length : s3 ? oe2.error(e3) : k2(e3, u3).slice(0);
    };
    function ve2(e3) {
      for (var t3 = 0, n3 = e3.length, r3 = ""; t3 < n3; t3++)
        r3 += e3[t3].value;
      return r3;
    }
    function me2(e3, t3, n3) {
      var r3 = t3.dir, i3 = t3.next, o3 = i3 || r3, a3 = n3 && "parentNode" === o3, s3 = C2++;
      return t3.first ? function(t4, n4, i4) {
        while (t4 = t4[r3])
          if (1 === t4.nodeType || a3)
            return e3(t4, n4, i4);
        return false;
      } : function(t4, n4, u3) {
        var l3, c3, f3, p3 = [T2, s3];
        if (u3) {
          while (t4 = t4[r3])
            if ((1 === t4.nodeType || a3) && e3(t4, n4, u3))
              return true;
        } else
          while (t4 = t4[r3])
            if (1 === t4.nodeType || a3)
              if (f3 = t4[b] || (t4[b] = {}), c3 = f3[t4.uniqueID] || (f3[t4.uniqueID] = {}), i3 && i3 === t4.nodeName.toLowerCase())
                t4 = t4[r3] || t4;
              else {
                if ((l3 = c3[o3]) && l3[0] === T2 && l3[1] === s3)
                  return p3[2] = l3[2];
                if (c3[o3] = p3, p3[2] = e3(t4, n4, u3))
                  return true;
              }
        return false;
      };
    }
    function xe2(e3) {
      return e3.length > 1 ? function(t3, n3, r3) {
        var i3 = e3.length;
        while (i3--)
          if (!e3[i3](t3, n3, r3))
            return false;
        return true;
      } : e3[0];
    }
    function be2(e3, t3, n3) {
      for (var r3 = 0, i3 = t3.length; r3 < i3; r3++)
        oe2(e3, t3[r3], n3);
      return n3;
    }
    function we2(e3, t3, n3, r3, i3) {
      for (var o3, a3 = [], s3 = 0, u3 = e3.length, l3 = null != t3; s3 < u3; s3++)
        (o3 = e3[s3]) && (n3 && !n3(o3, r3, i3) || (a3.push(o3), l3 && t3.push(s3)));
      return a3;
    }
    function Te2(e3, t3, n3, r3, i3, o3) {
      return r3 && !r3[b] && (r3 = Te2(r3)), i3 && !i3[b] && (i3 = Te2(i3, o3)), se2(function(o4, a3, s3, u3) {
        var l3, c3, f3, p3 = [], d3 = [], h3 = a3.length, g3 = o4 || be2(t3 || "*", s3.nodeType ? [s3] : s3, []), y3 = !e3 || !o4 && t3 ? g3 : we2(g3, p3, e3, s3, u3), v3 = n3 ? i3 || (o4 ? e3 : h3 || r3) ? [] : a3 : y3;
        if (n3 && n3(y3, v3, s3, u3), r3) {
          l3 = we2(v3, d3), r3(l3, [], s3, u3), c3 = l3.length;
          while (c3--)
            (f3 = l3[c3]) && (v3[d3[c3]] = !(y3[d3[c3]] = f3));
        }
        if (o4) {
          if (i3 || e3) {
            if (i3) {
              l3 = [], c3 = v3.length;
              while (c3--)
                (f3 = v3[c3]) && l3.push(y3[c3] = f3);
              i3(null, v3 = [], l3, u3);
            }
            c3 = v3.length;
            while (c3--)
              (f3 = v3[c3]) && (l3 = i3 ? O2(o4, f3) : p3[c3]) > -1 && (o4[l3] = !(a3[l3] = f3));
          }
        } else
          v3 = we2(v3 === a3 ? v3.splice(h3, v3.length) : v3), i3 ? i3(null, a3, v3, u3) : L2.apply(a3, v3);
      });
    }
    function Ce2(e3) {
      for (var t3, n3, i3, o3 = e3.length, a3 = r2.relative[e3[0].type], s3 = a3 || r2.relative[" "], u3 = a3 ? 1 : 0, c3 = me2(function(e4) {
        return e4 === t3;
      }, s3, true), f3 = me2(function(e4) {
        return O2(t3, e4) > -1;
      }, s3, true), p3 = [function(e4, n4, r3) {
        var i4 = !a3 && (r3 || n4 !== l2) || ((t3 = n4).nodeType ? c3(e4, n4, r3) : f3(e4, n4, r3));
        return t3 = null, i4;
      }]; u3 < o3; u3++)
        if (n3 = r2.relative[e3[u3].type])
          p3 = [me2(xe2(p3), n3)];
        else {
          if ((n3 = r2.filter[e3[u3].type].apply(null, e3[u3].matches))[b]) {
            for (i3 = ++u3; i3 < o3; i3++)
              if (r2.relative[e3[i3].type])
                break;
            return Te2(u3 > 1 && xe2(p3), u3 > 1 && ve2(e3.slice(0, u3 - 1).concat({ value: " " === e3[u3 - 2].type ? "*" : "" })).replace(B2, "$1"), n3, u3 < i3 && Ce2(e3.slice(u3, i3)), i3 < o3 && Ce2(e3 = e3.slice(i3)), i3 < o3 && ve2(e3));
          }
          p3.push(n3);
        }
      return xe2(p3);
    }
    function Ee2(e3, t3) {
      var n3 = t3.length > 0, i3 = e3.length > 0, o3 = function(o4, a3, s3, u3, c3) {
        var f3, h3, y3, v3 = 0, m3 = "0", x3 = o4 && [], b2 = [], w3 = l2, C3 = o4 || i3 && r2.find.TAG("*", c3), E3 = T2 += null == w3 ? 1 : Math.random() || 0.1, k3 = C3.length;
        for (c3 && (l2 = a3 === d2 || a3 || c3); m3 !== k3 && null != (f3 = C3[m3]); m3++) {
          if (i3 && f3) {
            h3 = 0, a3 || f3.ownerDocument === d2 || (p2(f3), s3 = !g2);
            while (y3 = e3[h3++])
              if (y3(f3, a3 || d2, s3)) {
                u3.push(f3);
                break;
              }
            c3 && (T2 = E3);
          }
          n3 && ((f3 = !y3 && f3) && v3--, o4 && x3.push(f3));
        }
        if (v3 += m3, n3 && m3 !== v3) {
          h3 = 0;
          while (y3 = t3[h3++])
            y3(x3, b2, a3, s3);
          if (o4) {
            if (v3 > 0)
              while (m3--)
                x3[m3] || b2[m3] || (b2[m3] = j2.call(u3));
            b2 = we2(b2);
          }
          L2.apply(u3, b2), c3 && !o4 && b2.length > 0 && v3 + t3.length > 1 && oe2.uniqueSort(u3);
        }
        return c3 && (T2 = E3, l2 = w3), x3;
      };
      return n3 ? se2(o3) : o3;
    }
    return s2 = oe2.compile = function(e3, t3) {
      var n3, r3 = [], i3 = [], o3 = S2[e3 + " "];
      if (!o3) {
        t3 || (t3 = a2(e3)), n3 = t3.length;
        while (n3--)
          (o3 = Ce2(t3[n3]))[b] ? r3.push(o3) : i3.push(o3);
        (o3 = S2(e3, Ee2(i3, r3))).selector = e3;
      }
      return o3;
    }, u2 = oe2.select = function(e3, t3, n3, i3) {
      var o3, u3, l3, c3, f3, p3 = "function" == typeof e3 && e3, d3 = !i3 && a2(e3 = p3.selector || e3);
      if (n3 = n3 || [], 1 === d3.length) {
        if ((u3 = d3[0] = d3[0].slice(0)).length > 2 && "ID" === (l3 = u3[0]).type && 9 === t3.nodeType && g2 && r2.relative[u3[1].type]) {
          if (!(t3 = (r2.find.ID(l3.matches[0].replace(Z2, ee2), t3) || [])[0]))
            return n3;
          p3 && (t3 = t3.parentNode), e3 = e3.slice(u3.shift().value.length);
        }
        o3 = V2.needsContext.test(e3) ? 0 : u3.length;
        while (o3--) {
          if (l3 = u3[o3], r2.relative[c3 = l3.type])
            break;
          if ((f3 = r2.find[c3]) && (i3 = f3(l3.matches[0].replace(Z2, ee2), K2.test(u3[0].type) && ge2(t3.parentNode) || t3))) {
            if (u3.splice(o3, 1), !(e3 = i3.length && ve2(u3)))
              return L2.apply(n3, i3), n3;
            break;
          }
        }
      }
      return (p3 || s2(e3, d3))(i3, t3, !g2, n3, !t3 || K2.test(e3) && ge2(t3.parentNode) || t3), n3;
    }, n2.sortStable = b.split("").sort(D2).join("") === b, n2.detectDuplicates = !!f2, p2(), n2.sortDetached = ue2(function(e3) {
      return 1 & e3.compareDocumentPosition(d2.createElement("fieldset"));
    }), ue2(function(e3) {
      return e3.innerHTML = "<a href='#'></a>", "#" === e3.firstChild.getAttribute("href");
    }) || le2("type|href|height|width", function(e3, t3, n3) {
      if (!n3)
        return e3.getAttribute(t3, "type" === t3.toLowerCase() ? 1 : 2);
    }), n2.attributes && ue2(function(e3) {
      return e3.innerHTML = "<input/>", e3.firstChild.setAttribute("value", ""), "" === e3.firstChild.getAttribute("value");
    }) || le2("value", function(e3, t3, n3) {
      if (!n3 && "input" === e3.nodeName.toLowerCase())
        return e3.defaultValue;
    }), ue2(function(e3) {
      return null == e3.getAttribute("disabled");
    }) || le2(P2, function(e3, t3, n3) {
      var r3;
      if (!n3)
        return true === e3[t3] ? t3.toLowerCase() : (r3 = e3.getAttributeNode(t3)) && r3.specified ? r3.value : null;
    }), oe2;
  }(e);
  w.find = E, w.expr = E.selectors, w.expr[":"] = w.expr.pseudos, w.uniqueSort = w.unique = E.uniqueSort, w.text = E.getText, w.isXMLDoc = E.isXML, w.contains = E.contains, w.escapeSelector = E.escape;
  var k = function(e2, t2, n2) {
    var r2 = [], i2 = void 0 !== n2;
    while ((e2 = e2[t2]) && 9 !== e2.nodeType)
      if (1 === e2.nodeType) {
        if (i2 && w(e2).is(n2))
          break;
        r2.push(e2);
      }
    return r2;
  }, S = function(e2, t2) {
    for (var n2 = []; e2; e2 = e2.nextSibling)
      1 === e2.nodeType && e2 !== t2 && n2.push(e2);
    return n2;
  }, D = w.expr.match.needsContext;
  function N(e2, t2) {
    return e2.nodeName && e2.nodeName.toLowerCase() === t2.toLowerCase();
  }
  var A = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;
  function j(e2, t2, n2) {
    return g(t2) ? w.grep(e2, function(e3, r2) {
      return !!t2.call(e3, r2, e3) !== n2;
    }) : t2.nodeType ? w.grep(e2, function(e3) {
      return e3 === t2 !== n2;
    }) : "string" != typeof t2 ? w.grep(e2, function(e3) {
      return u.call(t2, e3) > -1 !== n2;
    }) : w.filter(t2, e2, n2);
  }
  w.filter = function(e2, t2, n2) {
    var r2 = t2[0];
    return n2 && (e2 = ":not(" + e2 + ")"), 1 === t2.length && 1 === r2.nodeType ? w.find.matchesSelector(r2, e2) ? [r2] : [] : w.find.matches(e2, w.grep(t2, function(e3) {
      return 1 === e3.nodeType;
    }));
  }, w.fn.extend({ find: function(e2) {
    var t2, n2, r2 = this.length, i2 = this;
    if ("string" != typeof e2)
      return this.pushStack(w(e2).filter(function() {
        for (t2 = 0; t2 < r2; t2++)
          if (w.contains(i2[t2], this))
            return true;
      }));
    for (n2 = this.pushStack([]), t2 = 0; t2 < r2; t2++)
      w.find(e2, i2[t2], n2);
    return r2 > 1 ? w.uniqueSort(n2) : n2;
  }, filter: function(e2) {
    return this.pushStack(j(this, e2 || [], false));
  }, not: function(e2) {
    return this.pushStack(j(this, e2 || [], true));
  }, is: function(e2) {
    return !!j(this, "string" == typeof e2 && D.test(e2) ? w(e2) : e2 || [], false).length;
  } });
  var q, L = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;
  (w.fn.init = function(e2, t2, n2) {
    var i2, o2;
    if (!e2)
      return this;
    if (n2 = n2 || q, "string" == typeof e2) {
      if (!(i2 = "<" === e2[0] && ">" === e2[e2.length - 1] && e2.length >= 3 ? [null, e2, null] : L.exec(e2)) || !i2[1] && t2)
        return !t2 || t2.jquery ? (t2 || n2).find(e2) : this.constructor(t2).find(e2);
      if (i2[1]) {
        if (t2 = t2 instanceof w ? t2[0] : t2, w.merge(this, w.parseHTML(i2[1], t2 && t2.nodeType ? t2.ownerDocument || t2 : r, true)), A.test(i2[1]) && w.isPlainObject(t2))
          for (i2 in t2)
            g(this[i2]) ? this[i2](t2[i2]) : this.attr(i2, t2[i2]);
        return this;
      }
      return (o2 = r.getElementById(i2[2])) && (this[0] = o2, this.length = 1), this;
    }
    return e2.nodeType ? (this[0] = e2, this.length = 1, this) : g(e2) ? void 0 !== n2.ready ? n2.ready(e2) : e2(w) : w.makeArray(e2, this);
  }).prototype = w.fn, q = w(r);
  var H = /^(?:parents|prev(?:Until|All))/, O = { children: true, contents: true, next: true, prev: true };
  w.fn.extend({ has: function(e2) {
    var t2 = w(e2, this), n2 = t2.length;
    return this.filter(function() {
      for (var e3 = 0; e3 < n2; e3++)
        if (w.contains(this, t2[e3]))
          return true;
    });
  }, closest: function(e2, t2) {
    var n2, r2 = 0, i2 = this.length, o2 = [], a2 = "string" != typeof e2 && w(e2);
    if (!D.test(e2)) {
      for (; r2 < i2; r2++)
        for (n2 = this[r2]; n2 && n2 !== t2; n2 = n2.parentNode)
          if (n2.nodeType < 11 && (a2 ? a2.index(n2) > -1 : 1 === n2.nodeType && w.find.matchesSelector(n2, e2))) {
            o2.push(n2);
            break;
          }
    }
    return this.pushStack(o2.length > 1 ? w.uniqueSort(o2) : o2);
  }, index: function(e2) {
    return e2 ? "string" == typeof e2 ? u.call(w(e2), this[0]) : u.call(this, e2.jquery ? e2[0] : e2) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1;
  }, add: function(e2, t2) {
    return this.pushStack(w.uniqueSort(w.merge(this.get(), w(e2, t2))));
  }, addBack: function(e2) {
    return this.add(null == e2 ? this.prevObject : this.prevObject.filter(e2));
  } });
  function P(e2, t2) {
    while ((e2 = e2[t2]) && 1 !== e2.nodeType)
      ;
    return e2;
  }
  w.each({ parent: function(e2) {
    var t2 = e2.parentNode;
    return t2 && 11 !== t2.nodeType ? t2 : null;
  }, parents: function(e2) {
    return k(e2, "parentNode");
  }, parentsUntil: function(e2, t2, n2) {
    return k(e2, "parentNode", n2);
  }, next: function(e2) {
    return P(e2, "nextSibling");
  }, prev: function(e2) {
    return P(e2, "previousSibling");
  }, nextAll: function(e2) {
    return k(e2, "nextSibling");
  }, prevAll: function(e2) {
    return k(e2, "previousSibling");
  }, nextUntil: function(e2, t2, n2) {
    return k(e2, "nextSibling", n2);
  }, prevUntil: function(e2, t2, n2) {
    return k(e2, "previousSibling", n2);
  }, siblings: function(e2) {
    return S((e2.parentNode || {}).firstChild, e2);
  }, children: function(e2) {
    return S(e2.firstChild);
  }, contents: function(e2) {
    return N(e2, "iframe") ? e2.contentDocument : (N(e2, "template") && (e2 = e2.content || e2), w.merge([], e2.childNodes));
  } }, function(e2, t2) {
    w.fn[e2] = function(n2, r2) {
      var i2 = w.map(this, t2, n2);
      return "Until" !== e2.slice(-5) && (r2 = n2), r2 && "string" == typeof r2 && (i2 = w.filter(r2, i2)), this.length > 1 && (O[e2] || w.uniqueSort(i2), H.test(e2) && i2.reverse()), this.pushStack(i2);
    };
  });
  var M = /[^\x20\t\r\n\f]+/g;
  function R(e2) {
    var t2 = {};
    return w.each(e2.match(M) || [], function(e3, n2) {
      t2[n2] = true;
    }), t2;
  }
  w.Callbacks = function(e2) {
    e2 = "string" == typeof e2 ? R(e2) : w.extend({}, e2);
    var t2, n2, r2, i2, o2 = [], a2 = [], s2 = -1, u2 = function() {
      for (i2 = i2 || e2.once, r2 = t2 = true; a2.length; s2 = -1) {
        n2 = a2.shift();
        while (++s2 < o2.length)
          false === o2[s2].apply(n2[0], n2[1]) && e2.stopOnFalse && (s2 = o2.length, n2 = false);
      }
      e2.memory || (n2 = false), t2 = false, i2 && (o2 = n2 ? [] : "");
    }, l2 = { add: function() {
      return o2 && (n2 && !t2 && (s2 = o2.length - 1, a2.push(n2)), function t3(n3) {
        w.each(n3, function(n4, r3) {
          g(r3) ? e2.unique && l2.has(r3) || o2.push(r3) : r3 && r3.length && "string" !== x(r3) && t3(r3);
        });
      }(arguments), n2 && !t2 && u2()), this;
    }, remove: function() {
      return w.each(arguments, function(e3, t3) {
        var n3;
        while ((n3 = w.inArray(t3, o2, n3)) > -1)
          o2.splice(n3, 1), n3 <= s2 && s2--;
      }), this;
    }, has: function(e3) {
      return e3 ? w.inArray(e3, o2) > -1 : o2.length > 0;
    }, empty: function() {
      return o2 && (o2 = []), this;
    }, disable: function() {
      return i2 = a2 = [], o2 = n2 = "", this;
    }, disabled: function() {
      return !o2;
    }, lock: function() {
      return i2 = a2 = [], n2 || t2 || (o2 = n2 = ""), this;
    }, locked: function() {
      return !!i2;
    }, fireWith: function(e3, n3) {
      return i2 || (n3 = [e3, (n3 = n3 || []).slice ? n3.slice() : n3], a2.push(n3), t2 || u2()), this;
    }, fire: function() {
      return l2.fireWith(this, arguments), this;
    }, fired: function() {
      return !!r2;
    } };
    return l2;
  };
  function I(e2) {
    return e2;
  }
  function W(e2) {
    throw e2;
  }
  function $(e2, t2, n2, r2) {
    var i2;
    try {
      e2 && g(i2 = e2.promise) ? i2.call(e2).done(t2).fail(n2) : e2 && g(i2 = e2.then) ? i2.call(e2, t2, n2) : t2.apply(void 0, [e2].slice(r2));
    } catch (e3) {
      n2.apply(void 0, [e3]);
    }
  }
  w.extend({ Deferred: function(t2) {
    var n2 = [["notify", "progress", w.Callbacks("memory"), w.Callbacks("memory"), 2], ["resolve", "done", w.Callbacks("once memory"), w.Callbacks("once memory"), 0, "resolved"], ["reject", "fail", w.Callbacks("once memory"), w.Callbacks("once memory"), 1, "rejected"]], r2 = "pending", i2 = { state: function() {
      return r2;
    }, always: function() {
      return o2.done(arguments).fail(arguments), this;
    }, "catch": function(e2) {
      return i2.then(null, e2);
    }, pipe: function() {
      var e2 = arguments;
      return w.Deferred(function(t3) {
        w.each(n2, function(n3, r3) {
          var i3 = g(e2[r3[4]]) && e2[r3[4]];
          o2[r3[1]](function() {
            var e3 = i3 && i3.apply(this, arguments);
            e3 && g(e3.promise) ? e3.promise().progress(t3.notify).done(t3.resolve).fail(t3.reject) : t3[r3[0] + "With"](this, i3 ? [e3] : arguments);
          });
        }), e2 = null;
      }).promise();
    }, then: function(t3, r3, i3) {
      var o3 = 0;
      function a2(t4, n3, r4, i4) {
        return function() {
          var s2 = this, u2 = arguments, l2 = function() {
            var e2, l3;
            if (!(t4 < o3)) {
              if ((e2 = r4.apply(s2, u2)) === n3.promise())
                throw new TypeError("Thenable self-resolution");
              l3 = e2 && ("object" == typeof e2 || "function" == typeof e2) && e2.then, g(l3) ? i4 ? l3.call(e2, a2(o3, n3, I, i4), a2(o3, n3, W, i4)) : (o3++, l3.call(e2, a2(o3, n3, I, i4), a2(o3, n3, W, i4), a2(o3, n3, I, n3.notifyWith))) : (r4 !== I && (s2 = void 0, u2 = [e2]), (i4 || n3.resolveWith)(s2, u2));
            }
          }, c2 = i4 ? l2 : function() {
            try {
              l2();
            } catch (e2) {
              w.Deferred.exceptionHook && w.Deferred.exceptionHook(e2, c2.stackTrace), t4 + 1 >= o3 && (r4 !== W && (s2 = void 0, u2 = [e2]), n3.rejectWith(s2, u2));
            }
          };
          t4 ? c2() : (w.Deferred.getStackHook && (c2.stackTrace = w.Deferred.getStackHook()), e.setTimeout(c2));
        };
      }
      return w.Deferred(function(e2) {
        n2[0][3].add(a2(0, e2, g(i3) ? i3 : I, e2.notifyWith)), n2[1][3].add(a2(0, e2, g(t3) ? t3 : I)), n2[2][3].add(a2(0, e2, g(r3) ? r3 : W));
      }).promise();
    }, promise: function(e2) {
      return null != e2 ? w.extend(e2, i2) : i2;
    } }, o2 = {};
    return w.each(n2, function(e2, t3) {
      var a2 = t3[2], s2 = t3[5];
      i2[t3[1]] = a2.add, s2 && a2.add(function() {
        r2 = s2;
      }, n2[3 - e2][2].disable, n2[3 - e2][3].disable, n2[0][2].lock, n2[0][3].lock), a2.add(t3[3].fire), o2[t3[0]] = function() {
        return o2[t3[0] + "With"](this === o2 ? void 0 : this, arguments), this;
      }, o2[t3[0] + "With"] = a2.fireWith;
    }), i2.promise(o2), t2 && t2.call(o2, o2), o2;
  }, when: function(e2) {
    var t2 = arguments.length, n2 = t2, r2 = Array(n2), i2 = o.call(arguments), a2 = w.Deferred(), s2 = function(e3) {
      return function(n3) {
        r2[e3] = this, i2[e3] = arguments.length > 1 ? o.call(arguments) : n3, --t2 || a2.resolveWith(r2, i2);
      };
    };
    if (t2 <= 1 && ($(e2, a2.done(s2(n2)).resolve, a2.reject, !t2), "pending" === a2.state() || g(i2[n2] && i2[n2].then)))
      return a2.then();
    while (n2--)
      $(i2[n2], s2(n2), a2.reject);
    return a2.promise();
  } });
  var B = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
  w.Deferred.exceptionHook = function(t2, n2) {
    e.console && e.console.warn && t2 && B.test(t2.name) && e.console.warn("jQuery.Deferred exception: " + t2.message, t2.stack, n2);
  }, w.readyException = function(t2) {
    e.setTimeout(function() {
      throw t2;
    });
  };
  var F = w.Deferred();
  w.fn.ready = function(e2) {
    return F.then(e2)["catch"](function(e3) {
      w.readyException(e3);
    }), this;
  }, w.extend({ isReady: false, readyWait: 1, ready: function(e2) {
    (true === e2 ? --w.readyWait : w.isReady) || (w.isReady = true, true !== e2 && --w.readyWait > 0 || F.resolveWith(r, [w]));
  } }), w.ready.then = F.then;
  function _() {
    r.removeEventListener("DOMContentLoaded", _), e.removeEventListener("load", _), w.ready();
  }
  "complete" === r.readyState || "loading" !== r.readyState && !r.documentElement.doScroll ? e.setTimeout(w.ready) : (r.addEventListener("DOMContentLoaded", _), e.addEventListener("load", _));
  var z = function(e2, t2, n2, r2, i2, o2, a2) {
    var s2 = 0, u2 = e2.length, l2 = null == n2;
    if ("object" === x(n2)) {
      i2 = true;
      for (s2 in n2)
        z(e2, t2, s2, n2[s2], true, o2, a2);
    } else if (void 0 !== r2 && (i2 = true, g(r2) || (a2 = true), l2 && (a2 ? (t2.call(e2, r2), t2 = null) : (l2 = t2, t2 = function(e3, t3, n3) {
      return l2.call(w(e3), n3);
    })), t2))
      for (; s2 < u2; s2++)
        t2(e2[s2], n2, a2 ? r2 : r2.call(e2[s2], s2, t2(e2[s2], n2)));
    return i2 ? e2 : l2 ? t2.call(e2) : u2 ? t2(e2[0], n2) : o2;
  }, X = /^-ms-/, U = /-([a-z])/g;
  function V(e2, t2) {
    return t2.toUpperCase();
  }
  function G(e2) {
    return e2.replace(X, "ms-").replace(U, V);
  }
  var Y = function(e2) {
    return 1 === e2.nodeType || 9 === e2.nodeType || !+e2.nodeType;
  };
  function Q() {
    this.expando = w.expando + Q.uid++;
  }
  Q.uid = 1, Q.prototype = { cache: function(e2) {
    var t2 = e2[this.expando];
    return t2 || (t2 = {}, Y(e2) && (e2.nodeType ? e2[this.expando] = t2 : Object.defineProperty(e2, this.expando, { value: t2, configurable: true }))), t2;
  }, set: function(e2, t2, n2) {
    var r2, i2 = this.cache(e2);
    if ("string" == typeof t2)
      i2[G(t2)] = n2;
    else
      for (r2 in t2)
        i2[G(r2)] = t2[r2];
    return i2;
  }, get: function(e2, t2) {
    return void 0 === t2 ? this.cache(e2) : e2[this.expando] && e2[this.expando][G(t2)];
  }, access: function(e2, t2, n2) {
    return void 0 === t2 || t2 && "string" == typeof t2 && void 0 === n2 ? this.get(e2, t2) : (this.set(e2, t2, n2), void 0 !== n2 ? n2 : t2);
  }, remove: function(e2, t2) {
    var n2, r2 = e2[this.expando];
    if (void 0 !== r2) {
      if (void 0 !== t2) {
        n2 = (t2 = Array.isArray(t2) ? t2.map(G) : (t2 = G(t2)) in r2 ? [t2] : t2.match(M) || []).length;
        while (n2--)
          delete r2[t2[n2]];
      }
      (void 0 === t2 || w.isEmptyObject(r2)) && (e2.nodeType ? e2[this.expando] = void 0 : delete e2[this.expando]);
    }
  }, hasData: function(e2) {
    var t2 = e2[this.expando];
    return void 0 !== t2 && !w.isEmptyObject(t2);
  } };
  var J = new Q(), K = new Q(), Z = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/, ee = /[A-Z]/g;
  function te(e2) {
    return "true" === e2 || "false" !== e2 && ("null" === e2 ? null : e2 === +e2 + "" ? +e2 : Z.test(e2) ? JSON.parse(e2) : e2);
  }
  function ne(e2, t2, n2) {
    var r2;
    if (void 0 === n2 && 1 === e2.nodeType)
      if (r2 = "data-" + t2.replace(ee, "-$&").toLowerCase(), "string" == typeof (n2 = e2.getAttribute(r2))) {
        try {
          n2 = te(n2);
        } catch (e3) {
        }
        K.set(e2, t2, n2);
      } else
        n2 = void 0;
    return n2;
  }
  w.extend({ hasData: function(e2) {
    return K.hasData(e2) || J.hasData(e2);
  }, data: function(e2, t2, n2) {
    return K.access(e2, t2, n2);
  }, removeData: function(e2, t2) {
    K.remove(e2, t2);
  }, _data: function(e2, t2, n2) {
    return J.access(e2, t2, n2);
  }, _removeData: function(e2, t2) {
    J.remove(e2, t2);
  } }), w.fn.extend({ data: function(e2, t2) {
    var n2, r2, i2, o2 = this[0], a2 = o2 && o2.attributes;
    if (void 0 === e2) {
      if (this.length && (i2 = K.get(o2), 1 === o2.nodeType && !J.get(o2, "hasDataAttrs"))) {
        n2 = a2.length;
        while (n2--)
          a2[n2] && 0 === (r2 = a2[n2].name).indexOf("data-") && (r2 = G(r2.slice(5)), ne(o2, r2, i2[r2]));
        J.set(o2, "hasDataAttrs", true);
      }
      return i2;
    }
    return "object" == typeof e2 ? this.each(function() {
      K.set(this, e2);
    }) : z(this, function(t3) {
      var n3;
      if (o2 && void 0 === t3) {
        if (void 0 !== (n3 = K.get(o2, e2)))
          return n3;
        if (void 0 !== (n3 = ne(o2, e2)))
          return n3;
      } else
        this.each(function() {
          K.set(this, e2, t3);
        });
    }, null, t2, arguments.length > 1, null, true);
  }, removeData: function(e2) {
    return this.each(function() {
      K.remove(this, e2);
    });
  } }), w.extend({ queue: function(e2, t2, n2) {
    var r2;
    if (e2)
      return t2 = (t2 || "fx") + "queue", r2 = J.get(e2, t2), n2 && (!r2 || Array.isArray(n2) ? r2 = J.access(e2, t2, w.makeArray(n2)) : r2.push(n2)), r2 || [];
  }, dequeue: function(e2, t2) {
    t2 = t2 || "fx";
    var n2 = w.queue(e2, t2), r2 = n2.length, i2 = n2.shift(), o2 = w._queueHooks(e2, t2), a2 = function() {
      w.dequeue(e2, t2);
    };
    "inprogress" === i2 && (i2 = n2.shift(), r2--), i2 && ("fx" === t2 && n2.unshift("inprogress"), delete o2.stop, i2.call(e2, a2, o2)), !r2 && o2 && o2.empty.fire();
  }, _queueHooks: function(e2, t2) {
    var n2 = t2 + "queueHooks";
    return J.get(e2, n2) || J.access(e2, n2, { empty: w.Callbacks("once memory").add(function() {
      J.remove(e2, [t2 + "queue", n2]);
    }) });
  } }), w.fn.extend({ queue: function(e2, t2) {
    var n2 = 2;
    return "string" != typeof e2 && (t2 = e2, e2 = "fx", n2--), arguments.length < n2 ? w.queue(this[0], e2) : void 0 === t2 ? this : this.each(function() {
      var n3 = w.queue(this, e2, t2);
      w._queueHooks(this, e2), "fx" === e2 && "inprogress" !== n3[0] && w.dequeue(this, e2);
    });
  }, dequeue: function(e2) {
    return this.each(function() {
      w.dequeue(this, e2);
    });
  }, clearQueue: function(e2) {
    return this.queue(e2 || "fx", []);
  }, promise: function(e2, t2) {
    var n2, r2 = 1, i2 = w.Deferred(), o2 = this, a2 = this.length, s2 = function() {
      --r2 || i2.resolveWith(o2, [o2]);
    };
    "string" != typeof e2 && (t2 = e2, e2 = void 0), e2 = e2 || "fx";
    while (a2--)
      (n2 = J.get(o2[a2], e2 + "queueHooks")) && n2.empty && (r2++, n2.empty.add(s2));
    return s2(), i2.promise(t2);
  } });
  var re = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source, ie = new RegExp("^(?:([+-])=|)(" + re + ")([a-z%]*)$", "i"), oe = ["Top", "Right", "Bottom", "Left"], ae = function(e2, t2) {
    return "none" === (e2 = t2 || e2).style.display || "" === e2.style.display && w.contains(e2.ownerDocument, e2) && "none" === w.css(e2, "display");
  }, se = function(e2, t2, n2, r2) {
    var i2, o2, a2 = {};
    for (o2 in t2)
      a2[o2] = e2.style[o2], e2.style[o2] = t2[o2];
    i2 = n2.apply(e2, r2 || []);
    for (o2 in t2)
      e2.style[o2] = a2[o2];
    return i2;
  };
  function ue(e2, t2, n2, r2) {
    var i2, o2, a2 = 20, s2 = r2 ? function() {
      return r2.cur();
    } : function() {
      return w.css(e2, t2, "");
    }, u2 = s2(), l2 = n2 && n2[3] || (w.cssNumber[t2] ? "" : "px"), c2 = (w.cssNumber[t2] || "px" !== l2 && +u2) && ie.exec(w.css(e2, t2));
    if (c2 && c2[3] !== l2) {
      u2 /= 2, l2 = l2 || c2[3], c2 = +u2 || 1;
      while (a2--)
        w.style(e2, t2, c2 + l2), (1 - o2) * (1 - (o2 = s2() / u2 || 0.5)) <= 0 && (a2 = 0), c2 /= o2;
      c2 *= 2, w.style(e2, t2, c2 + l2), n2 = n2 || [];
    }
    return n2 && (c2 = +c2 || +u2 || 0, i2 = n2[1] ? c2 + (n2[1] + 1) * n2[2] : +n2[2], r2 && (r2.unit = l2, r2.start = c2, r2.end = i2)), i2;
  }
  var le = {};
  function ce(e2) {
    var t2, n2 = e2.ownerDocument, r2 = e2.nodeName, i2 = le[r2];
    return i2 || (t2 = n2.body.appendChild(n2.createElement(r2)), i2 = w.css(t2, "display"), t2.parentNode.removeChild(t2), "none" === i2 && (i2 = "block"), le[r2] = i2, i2);
  }
  function fe(e2, t2) {
    for (var n2, r2, i2 = [], o2 = 0, a2 = e2.length; o2 < a2; o2++)
      (r2 = e2[o2]).style && (n2 = r2.style.display, t2 ? ("none" === n2 && (i2[o2] = J.get(r2, "display") || null, i2[o2] || (r2.style.display = "")), "" === r2.style.display && ae(r2) && (i2[o2] = ce(r2))) : "none" !== n2 && (i2[o2] = "none", J.set(r2, "display", n2)));
    for (o2 = 0; o2 < a2; o2++)
      null != i2[o2] && (e2[o2].style.display = i2[o2]);
    return e2;
  }
  w.fn.extend({ show: function() {
    return fe(this, true);
  }, hide: function() {
    return fe(this);
  }, toggle: function(e2) {
    return "boolean" == typeof e2 ? e2 ? this.show() : this.hide() : this.each(function() {
      ae(this) ? w(this).show() : w(this).hide();
    });
  } });
  var pe = /^(?:checkbox|radio)$/i, de = /<([a-z][^\/\0>\x20\t\r\n\f]+)/i, he = /^$|^module$|\/(?:java|ecma)script/i, ge = { option: [1, "<select multiple='multiple'>", "</select>"], thead: [1, "<table>", "</table>"], col: [2, "<table><colgroup>", "</colgroup></table>"], tr: [2, "<table><tbody>", "</tbody></table>"], td: [3, "<table><tbody><tr>", "</tr></tbody></table>"], _default: [0, "", ""] };
  ge.optgroup = ge.option, ge.tbody = ge.tfoot = ge.colgroup = ge.caption = ge.thead, ge.th = ge.td;
  function ye(e2, t2) {
    var n2;
    return n2 = "undefined" != typeof e2.getElementsByTagName ? e2.getElementsByTagName(t2 || "*") : "undefined" != typeof e2.querySelectorAll ? e2.querySelectorAll(t2 || "*") : [], void 0 === t2 || t2 && N(e2, t2) ? w.merge([e2], n2) : n2;
  }
  function ve(e2, t2) {
    for (var n2 = 0, r2 = e2.length; n2 < r2; n2++)
      J.set(e2[n2], "globalEval", !t2 || J.get(t2[n2], "globalEval"));
  }
  var me = /<|&#?\w+;/;
  function xe(e2, t2, n2, r2, i2) {
    for (var o2, a2, s2, u2, l2, c2, f2 = t2.createDocumentFragment(), p2 = [], d2 = 0, h2 = e2.length; d2 < h2; d2++)
      if ((o2 = e2[d2]) || 0 === o2)
        if ("object" === x(o2))
          w.merge(p2, o2.nodeType ? [o2] : o2);
        else if (me.test(o2)) {
          a2 = a2 || f2.appendChild(t2.createElement("div")), s2 = (de.exec(o2) || ["", ""])[1].toLowerCase(), u2 = ge[s2] || ge._default, a2.innerHTML = u2[1] + w.htmlPrefilter(o2) + u2[2], c2 = u2[0];
          while (c2--)
            a2 = a2.lastChild;
          w.merge(p2, a2.childNodes), (a2 = f2.firstChild).textContent = "";
        } else
          p2.push(t2.createTextNode(o2));
    f2.textContent = "", d2 = 0;
    while (o2 = p2[d2++])
      if (r2 && w.inArray(o2, r2) > -1)
        i2 && i2.push(o2);
      else if (l2 = w.contains(o2.ownerDocument, o2), a2 = ye(f2.appendChild(o2), "script"), l2 && ve(a2), n2) {
        c2 = 0;
        while (o2 = a2[c2++])
          he.test(o2.type || "") && n2.push(o2);
      }
    return f2;
  }
  !function() {
    var e2 = r.createDocumentFragment().appendChild(r.createElement("div")), t2 = r.createElement("input");
    t2.setAttribute("type", "radio"), t2.setAttribute("checked", "checked"), t2.setAttribute("name", "t"), e2.appendChild(t2), h.checkClone = e2.cloneNode(true).cloneNode(true).lastChild.checked, e2.innerHTML = "<textarea>x</textarea>", h.noCloneChecked = !!e2.cloneNode(true).lastChild.defaultValue;
  }();
  var be = r.documentElement, we = /^key/, Te = /^(?:mouse|pointer|contextmenu|drag|drop)|click/, Ce = /^([^.]*)(?:\.(.+)|)/;
  function Ee() {
    return true;
  }
  function ke() {
    return false;
  }
  function Se() {
    try {
      return r.activeElement;
    } catch (e2) {
    }
  }
  function De(e2, t2, n2, r2, i2, o2) {
    var a2, s2;
    if ("object" == typeof t2) {
      "string" != typeof n2 && (r2 = r2 || n2, n2 = void 0);
      for (s2 in t2)
        De(e2, s2, n2, r2, t2[s2], o2);
      return e2;
    }
    if (null == r2 && null == i2 ? (i2 = n2, r2 = n2 = void 0) : null == i2 && ("string" == typeof n2 ? (i2 = r2, r2 = void 0) : (i2 = r2, r2 = n2, n2 = void 0)), false === i2)
      i2 = ke;
    else if (!i2)
      return e2;
    return 1 === o2 && (a2 = i2, (i2 = function(e3) {
      return w().off(e3), a2.apply(this, arguments);
    }).guid = a2.guid || (a2.guid = w.guid++)), e2.each(function() {
      w.event.add(this, t2, i2, r2, n2);
    });
  }
  w.event = { global: {}, add: function(e2, t2, n2, r2, i2) {
    var o2, a2, s2, u2, l2, c2, f2, p2, d2, h2, g2, y2 = J.get(e2);
    if (y2) {
      n2.handler && (n2 = (o2 = n2).handler, i2 = o2.selector), i2 && w.find.matchesSelector(be, i2), n2.guid || (n2.guid = w.guid++), (u2 = y2.events) || (u2 = y2.events = {}), (a2 = y2.handle) || (a2 = y2.handle = function(t3) {
        return "undefined" != typeof w && w.event.triggered !== t3.type ? w.event.dispatch.apply(e2, arguments) : void 0;
      }), l2 = (t2 = (t2 || "").match(M) || [""]).length;
      while (l2--)
        d2 = g2 = (s2 = Ce.exec(t2[l2]) || [])[1], h2 = (s2[2] || "").split(".").sort(), d2 && (f2 = w.event.special[d2] || {}, d2 = (i2 ? f2.delegateType : f2.bindType) || d2, f2 = w.event.special[d2] || {}, c2 = w.extend({ type: d2, origType: g2, data: r2, handler: n2, guid: n2.guid, selector: i2, needsContext: i2 && w.expr.match.needsContext.test(i2), namespace: h2.join(".") }, o2), (p2 = u2[d2]) || ((p2 = u2[d2] = []).delegateCount = 0, f2.setup && false !== f2.setup.call(e2, r2, h2, a2) || e2.addEventListener && e2.addEventListener(d2, a2)), f2.add && (f2.add.call(e2, c2), c2.handler.guid || (c2.handler.guid = n2.guid)), i2 ? p2.splice(p2.delegateCount++, 0, c2) : p2.push(c2), w.event.global[d2] = true);
    }
  }, remove: function(e2, t2, n2, r2, i2) {
    var o2, a2, s2, u2, l2, c2, f2, p2, d2, h2, g2, y2 = J.hasData(e2) && J.get(e2);
    if (y2 && (u2 = y2.events)) {
      l2 = (t2 = (t2 || "").match(M) || [""]).length;
      while (l2--)
        if (s2 = Ce.exec(t2[l2]) || [], d2 = g2 = s2[1], h2 = (s2[2] || "").split(".").sort(), d2) {
          f2 = w.event.special[d2] || {}, p2 = u2[d2 = (r2 ? f2.delegateType : f2.bindType) || d2] || [], s2 = s2[2] && new RegExp("(^|\\.)" + h2.join("\\.(?:.*\\.|)") + "(\\.|$)"), a2 = o2 = p2.length;
          while (o2--)
            c2 = p2[o2], !i2 && g2 !== c2.origType || n2 && n2.guid !== c2.guid || s2 && !s2.test(c2.namespace) || r2 && r2 !== c2.selector && ("**" !== r2 || !c2.selector) || (p2.splice(o2, 1), c2.selector && p2.delegateCount--, f2.remove && f2.remove.call(e2, c2));
          a2 && !p2.length && (f2.teardown && false !== f2.teardown.call(e2, h2, y2.handle) || w.removeEvent(e2, d2, y2.handle), delete u2[d2]);
        } else
          for (d2 in u2)
            w.event.remove(e2, d2 + t2[l2], n2, r2, true);
      w.isEmptyObject(u2) && J.remove(e2, "handle events");
    }
  }, dispatch: function(e2) {
    var t2 = w.event.fix(e2), n2, r2, i2, o2, a2, s2, u2 = new Array(arguments.length), l2 = (J.get(this, "events") || {})[t2.type] || [], c2 = w.event.special[t2.type] || {};
    for (u2[0] = t2, n2 = 1; n2 < arguments.length; n2++)
      u2[n2] = arguments[n2];
    if (t2.delegateTarget = this, !c2.preDispatch || false !== c2.preDispatch.call(this, t2)) {
      s2 = w.event.handlers.call(this, t2, l2), n2 = 0;
      while ((o2 = s2[n2++]) && !t2.isPropagationStopped()) {
        t2.currentTarget = o2.elem, r2 = 0;
        while ((a2 = o2.handlers[r2++]) && !t2.isImmediatePropagationStopped())
          t2.rnamespace && !t2.rnamespace.test(a2.namespace) || (t2.handleObj = a2, t2.data = a2.data, void 0 !== (i2 = ((w.event.special[a2.origType] || {}).handle || a2.handler).apply(o2.elem, u2)) && false === (t2.result = i2) && (t2.preventDefault(), t2.stopPropagation()));
      }
      return c2.postDispatch && c2.postDispatch.call(this, t2), t2.result;
    }
  }, handlers: function(e2, t2) {
    var n2, r2, i2, o2, a2, s2 = [], u2 = t2.delegateCount, l2 = e2.target;
    if (u2 && l2.nodeType && !("click" === e2.type && e2.button >= 1)) {
      for (; l2 !== this; l2 = l2.parentNode || this)
        if (1 === l2.nodeType && ("click" !== e2.type || true !== l2.disabled)) {
          for (o2 = [], a2 = {}, n2 = 0; n2 < u2; n2++)
            void 0 === a2[i2 = (r2 = t2[n2]).selector + " "] && (a2[i2] = r2.needsContext ? w(i2, this).index(l2) > -1 : w.find(i2, this, null, [l2]).length), a2[i2] && o2.push(r2);
          o2.length && s2.push({ elem: l2, handlers: o2 });
        }
    }
    return l2 = this, u2 < t2.length && s2.push({ elem: l2, handlers: t2.slice(u2) }), s2;
  }, addProp: function(e2, t2) {
    Object.defineProperty(w.Event.prototype, e2, { enumerable: true, configurable: true, get: g(t2) ? function() {
      if (this.originalEvent)
        return t2(this.originalEvent);
    } : function() {
      if (this.originalEvent)
        return this.originalEvent[e2];
    }, set: function(t3) {
      Object.defineProperty(this, e2, { enumerable: true, configurable: true, writable: true, value: t3 });
    } });
  }, fix: function(e2) {
    return e2[w.expando] ? e2 : new w.Event(e2);
  }, special: { load: { noBubble: true }, focus: { trigger: function() {
    if (this !== Se() && this.focus)
      return this.focus(), false;
  }, delegateType: "focusin" }, blur: { trigger: function() {
    if (this === Se() && this.blur)
      return this.blur(), false;
  }, delegateType: "focusout" }, click: { trigger: function() {
    if ("checkbox" === this.type && this.click && N(this, "input"))
      return this.click(), false;
  }, _default: function(e2) {
    return N(e2.target, "a");
  } }, beforeunload: { postDispatch: function(e2) {
    void 0 !== e2.result && e2.originalEvent && (e2.originalEvent.returnValue = e2.result);
  } } } }, w.removeEvent = function(e2, t2, n2) {
    e2.removeEventListener && e2.removeEventListener(t2, n2);
  }, w.Event = function(e2, t2) {
    if (!(this instanceof w.Event))
      return new w.Event(e2, t2);
    e2 && e2.type ? (this.originalEvent = e2, this.type = e2.type, this.isDefaultPrevented = e2.defaultPrevented || void 0 === e2.defaultPrevented && false === e2.returnValue ? Ee : ke, this.target = e2.target && 3 === e2.target.nodeType ? e2.target.parentNode : e2.target, this.currentTarget = e2.currentTarget, this.relatedTarget = e2.relatedTarget) : this.type = e2, t2 && w.extend(this, t2), this.timeStamp = e2 && e2.timeStamp || Date.now(), this[w.expando] = true;
  }, w.Event.prototype = { constructor: w.Event, isDefaultPrevented: ke, isPropagationStopped: ke, isImmediatePropagationStopped: ke, isSimulated: false, preventDefault: function() {
    var e2 = this.originalEvent;
    this.isDefaultPrevented = Ee, e2 && !this.isSimulated && e2.preventDefault();
  }, stopPropagation: function() {
    var e2 = this.originalEvent;
    this.isPropagationStopped = Ee, e2 && !this.isSimulated && e2.stopPropagation();
  }, stopImmediatePropagation: function() {
    var e2 = this.originalEvent;
    this.isImmediatePropagationStopped = Ee, e2 && !this.isSimulated && e2.stopImmediatePropagation(), this.stopPropagation();
  } }, w.each({ altKey: true, bubbles: true, cancelable: true, changedTouches: true, ctrlKey: true, detail: true, eventPhase: true, metaKey: true, pageX: true, pageY: true, shiftKey: true, view: true, "char": true, charCode: true, key: true, keyCode: true, button: true, buttons: true, clientX: true, clientY: true, offsetX: true, offsetY: true, pointerId: true, pointerType: true, screenX: true, screenY: true, targetTouches: true, toElement: true, touches: true, which: function(e2) {
    var t2 = e2.button;
    return null == e2.which && we.test(e2.type) ? null != e2.charCode ? e2.charCode : e2.keyCode : !e2.which && void 0 !== t2 && Te.test(e2.type) ? 1 & t2 ? 1 : 2 & t2 ? 3 : 4 & t2 ? 2 : 0 : e2.which;
  } }, w.event.addProp), w.each({ mouseenter: "mouseover", mouseleave: "mouseout", pointerenter: "pointerover", pointerleave: "pointerout" }, function(e2, t2) {
    w.event.special[e2] = { delegateType: t2, bindType: t2, handle: function(e3) {
      var n2, r2 = this, i2 = e3.relatedTarget, o2 = e3.handleObj;
      return i2 && (i2 === r2 || w.contains(r2, i2)) || (e3.type = o2.origType, n2 = o2.handler.apply(this, arguments), e3.type = t2), n2;
    } };
  }), w.fn.extend({ on: function(e2, t2, n2, r2) {
    return De(this, e2, t2, n2, r2);
  }, one: function(e2, t2, n2, r2) {
    return De(this, e2, t2, n2, r2, 1);
  }, off: function(e2, t2, n2) {
    var r2, i2;
    if (e2 && e2.preventDefault && e2.handleObj)
      return r2 = e2.handleObj, w(e2.delegateTarget).off(r2.namespace ? r2.origType + "." + r2.namespace : r2.origType, r2.selector, r2.handler), this;
    if ("object" == typeof e2) {
      for (i2 in e2)
        this.off(i2, t2, e2[i2]);
      return this;
    }
    return false !== t2 && "function" != typeof t2 || (n2 = t2, t2 = void 0), false === n2 && (n2 = ke), this.each(function() {
      w.event.remove(this, e2, n2, t2);
    });
  } });
  var Ne = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi, Ae = /<script|<style|<link/i, je = /checked\s*(?:[^=]|=\s*.checked.)/i, qe = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;
  function Le(e2, t2) {
    return N(e2, "table") && N(11 !== t2.nodeType ? t2 : t2.firstChild, "tr") ? w(e2).children("tbody")[0] || e2 : e2;
  }
  function He(e2) {
    return e2.type = (null !== e2.getAttribute("type")) + "/" + e2.type, e2;
  }
  function Oe(e2) {
    return "true/" === (e2.type || "").slice(0, 5) ? e2.type = e2.type.slice(5) : e2.removeAttribute("type"), e2;
  }
  function Pe(e2, t2) {
    var n2, r2, i2, o2, a2, s2, u2, l2;
    if (1 === t2.nodeType) {
      if (J.hasData(e2) && (o2 = J.access(e2), a2 = J.set(t2, o2), l2 = o2.events)) {
        delete a2.handle, a2.events = {};
        for (i2 in l2)
          for (n2 = 0, r2 = l2[i2].length; n2 < r2; n2++)
            w.event.add(t2, i2, l2[i2][n2]);
      }
      K.hasData(e2) && (s2 = K.access(e2), u2 = w.extend({}, s2), K.set(t2, u2));
    }
  }
  function Me(e2, t2) {
    var n2 = t2.nodeName.toLowerCase();
    "input" === n2 && pe.test(e2.type) ? t2.checked = e2.checked : "input" !== n2 && "textarea" !== n2 || (t2.defaultValue = e2.defaultValue);
  }
  function Re(e2, t2, n2, r2) {
    t2 = a.apply([], t2);
    var i2, o2, s2, u2, l2, c2, f2 = 0, p2 = e2.length, d2 = p2 - 1, y2 = t2[0], v2 = g(y2);
    if (v2 || p2 > 1 && "string" == typeof y2 && !h.checkClone && je.test(y2))
      return e2.each(function(i3) {
        var o3 = e2.eq(i3);
        v2 && (t2[0] = y2.call(this, i3, o3.html())), Re(o3, t2, n2, r2);
      });
    if (p2 && (i2 = xe(t2, e2[0].ownerDocument, false, e2, r2), o2 = i2.firstChild, 1 === i2.childNodes.length && (i2 = o2), o2 || r2)) {
      for (u2 = (s2 = w.map(ye(i2, "script"), He)).length; f2 < p2; f2++)
        l2 = i2, f2 !== d2 && (l2 = w.clone(l2, true, true), u2 && w.merge(s2, ye(l2, "script"))), n2.call(e2[f2], l2, f2);
      if (u2)
        for (c2 = s2[s2.length - 1].ownerDocument, w.map(s2, Oe), f2 = 0; f2 < u2; f2++)
          l2 = s2[f2], he.test(l2.type || "") && !J.access(l2, "globalEval") && w.contains(c2, l2) && (l2.src && "module" !== (l2.type || "").toLowerCase() ? w._evalUrl && w._evalUrl(l2.src) : m(l2.textContent.replace(qe, ""), c2, l2));
    }
    return e2;
  }
  function Ie(e2, t2, n2) {
    for (var r2, i2 = t2 ? w.filter(t2, e2) : e2, o2 = 0; null != (r2 = i2[o2]); o2++)
      n2 || 1 !== r2.nodeType || w.cleanData(ye(r2)), r2.parentNode && (n2 && w.contains(r2.ownerDocument, r2) && ve(ye(r2, "script")), r2.parentNode.removeChild(r2));
    return e2;
  }
  w.extend({ htmlPrefilter: function(e2) {
    return e2.replace(Ne, "<$1></$2>");
  }, clone: function(e2, t2, n2) {
    var r2, i2, o2, a2, s2 = e2.cloneNode(true), u2 = w.contains(e2.ownerDocument, e2);
    if (!(h.noCloneChecked || 1 !== e2.nodeType && 11 !== e2.nodeType || w.isXMLDoc(e2)))
      for (a2 = ye(s2), r2 = 0, i2 = (o2 = ye(e2)).length; r2 < i2; r2++)
        Me(o2[r2], a2[r2]);
    if (t2)
      if (n2)
        for (o2 = o2 || ye(e2), a2 = a2 || ye(s2), r2 = 0, i2 = o2.length; r2 < i2; r2++)
          Pe(o2[r2], a2[r2]);
      else
        Pe(e2, s2);
    return (a2 = ye(s2, "script")).length > 0 && ve(a2, !u2 && ye(e2, "script")), s2;
  }, cleanData: function(e2) {
    for (var t2, n2, r2, i2 = w.event.special, o2 = 0; void 0 !== (n2 = e2[o2]); o2++)
      if (Y(n2)) {
        if (t2 = n2[J.expando]) {
          if (t2.events)
            for (r2 in t2.events)
              i2[r2] ? w.event.remove(n2, r2) : w.removeEvent(n2, r2, t2.handle);
          n2[J.expando] = void 0;
        }
        n2[K.expando] && (n2[K.expando] = void 0);
      }
  } }), w.fn.extend({ detach: function(e2) {
    return Ie(this, e2, true);
  }, remove: function(e2) {
    return Ie(this, e2);
  }, text: function(e2) {
    return z(this, function(e3) {
      return void 0 === e3 ? w.text(this) : this.empty().each(function() {
        1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || (this.textContent = e3);
      });
    }, null, e2, arguments.length);
  }, append: function() {
    return Re(this, arguments, function(e2) {
      1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || Le(this, e2).appendChild(e2);
    });
  }, prepend: function() {
    return Re(this, arguments, function(e2) {
      if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
        var t2 = Le(this, e2);
        t2.insertBefore(e2, t2.firstChild);
      }
    });
  }, before: function() {
    return Re(this, arguments, function(e2) {
      this.parentNode && this.parentNode.insertBefore(e2, this);
    });
  }, after: function() {
    return Re(this, arguments, function(e2) {
      this.parentNode && this.parentNode.insertBefore(e2, this.nextSibling);
    });
  }, empty: function() {
    for (var e2, t2 = 0; null != (e2 = this[t2]); t2++)
      1 === e2.nodeType && (w.cleanData(ye(e2, false)), e2.textContent = "");
    return this;
  }, clone: function(e2, t2) {
    return e2 = null != e2 && e2, t2 = null == t2 ? e2 : t2, this.map(function() {
      return w.clone(this, e2, t2);
    });
  }, html: function(e2) {
    return z(this, function(e3) {
      var t2 = this[0] || {}, n2 = 0, r2 = this.length;
      if (void 0 === e3 && 1 === t2.nodeType)
        return t2.innerHTML;
      if ("string" == typeof e3 && !Ae.test(e3) && !ge[(de.exec(e3) || ["", ""])[1].toLowerCase()]) {
        e3 = w.htmlPrefilter(e3);
        try {
          for (; n2 < r2; n2++)
            1 === (t2 = this[n2] || {}).nodeType && (w.cleanData(ye(t2, false)), t2.innerHTML = e3);
          t2 = 0;
        } catch (e4) {
        }
      }
      t2 && this.empty().append(e3);
    }, null, e2, arguments.length);
  }, replaceWith: function() {
    var e2 = [];
    return Re(this, arguments, function(t2) {
      var n2 = this.parentNode;
      w.inArray(this, e2) < 0 && (w.cleanData(ye(this)), n2 && n2.replaceChild(t2, this));
    }, e2);
  } }), w.each({ appendTo: "append", prependTo: "prepend", insertBefore: "before", insertAfter: "after", replaceAll: "replaceWith" }, function(e2, t2) {
    w.fn[e2] = function(e3) {
      for (var n2, r2 = [], i2 = w(e3), o2 = i2.length - 1, a2 = 0; a2 <= o2; a2++)
        n2 = a2 === o2 ? this : this.clone(true), w(i2[a2])[t2](n2), s.apply(r2, n2.get());
      return this.pushStack(r2);
    };
  });
  var We = new RegExp("^(" + re + ")(?!px)[a-z%]+$", "i"), $e = function(t2) {
    var n2 = t2.ownerDocument.defaultView;
    return n2 && n2.opener || (n2 = e), n2.getComputedStyle(t2);
  }, Be = new RegExp(oe.join("|"), "i");
  !function() {
    function t2() {
      if (c2) {
        l2.style.cssText = "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0", c2.style.cssText = "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%", be.appendChild(l2).appendChild(c2);
        var t3 = e.getComputedStyle(c2);
        i2 = "1%" !== t3.top, u2 = 12 === n2(t3.marginLeft), c2.style.right = "60%", s2 = 36 === n2(t3.right), o2 = 36 === n2(t3.width), c2.style.position = "absolute", a2 = 36 === c2.offsetWidth || "absolute", be.removeChild(l2), c2 = null;
      }
    }
    function n2(e2) {
      return Math.round(parseFloat(e2));
    }
    var i2, o2, a2, s2, u2, l2 = r.createElement("div"), c2 = r.createElement("div");
    c2.style && (c2.style.backgroundClip = "content-box", c2.cloneNode(true).style.backgroundClip = "", h.clearCloneStyle = "content-box" === c2.style.backgroundClip, w.extend(h, { boxSizingReliable: function() {
      return t2(), o2;
    }, pixelBoxStyles: function() {
      return t2(), s2;
    }, pixelPosition: function() {
      return t2(), i2;
    }, reliableMarginLeft: function() {
      return t2(), u2;
    }, scrollboxSize: function() {
      return t2(), a2;
    } }));
  }();
  function Fe(e2, t2, n2) {
    var r2, i2, o2, a2, s2 = e2.style;
    return (n2 = n2 || $e(e2)) && ("" !== (a2 = n2.getPropertyValue(t2) || n2[t2]) || w.contains(e2.ownerDocument, e2) || (a2 = w.style(e2, t2)), !h.pixelBoxStyles() && We.test(a2) && Be.test(t2) && (r2 = s2.width, i2 = s2.minWidth, o2 = s2.maxWidth, s2.minWidth = s2.maxWidth = s2.width = a2, a2 = n2.width, s2.width = r2, s2.minWidth = i2, s2.maxWidth = o2)), void 0 !== a2 ? a2 + "" : a2;
  }
  function _e(e2, t2) {
    return { get: function() {
      if (!e2())
        return (this.get = t2).apply(this, arguments);
      delete this.get;
    } };
  }
  var ze = /^(none|table(?!-c[ea]).+)/, Xe = /^--/, Ue = { position: "absolute", visibility: "hidden", display: "block" }, Ve = { letterSpacing: "0", fontWeight: "400" }, Ge = ["Webkit", "Moz", "ms"], Ye = r.createElement("div").style;
  function Qe(e2) {
    if (e2 in Ye)
      return e2;
    var t2 = e2[0].toUpperCase() + e2.slice(1), n2 = Ge.length;
    while (n2--)
      if ((e2 = Ge[n2] + t2) in Ye)
        return e2;
  }
  function Je(e2) {
    var t2 = w.cssProps[e2];
    return t2 || (t2 = w.cssProps[e2] = Qe(e2) || e2), t2;
  }
  function Ke(e2, t2, n2) {
    var r2 = ie.exec(t2);
    return r2 ? Math.max(0, r2[2] - (n2 || 0)) + (r2[3] || "px") : t2;
  }
  function Ze(e2, t2, n2, r2, i2, o2) {
    var a2 = "width" === t2 ? 1 : 0, s2 = 0, u2 = 0;
    if (n2 === (r2 ? "border" : "content"))
      return 0;
    for (; a2 < 4; a2 += 2)
      "margin" === n2 && (u2 += w.css(e2, n2 + oe[a2], true, i2)), r2 ? ("content" === n2 && (u2 -= w.css(e2, "padding" + oe[a2], true, i2)), "margin" !== n2 && (u2 -= w.css(e2, "border" + oe[a2] + "Width", true, i2))) : (u2 += w.css(e2, "padding" + oe[a2], true, i2), "padding" !== n2 ? u2 += w.css(e2, "border" + oe[a2] + "Width", true, i2) : s2 += w.css(e2, "border" + oe[a2] + "Width", true, i2));
    return !r2 && o2 >= 0 && (u2 += Math.max(0, Math.ceil(e2["offset" + t2[0].toUpperCase() + t2.slice(1)] - o2 - u2 - s2 - 0.5))), u2;
  }
  function et(e2, t2, n2) {
    var r2 = $e(e2), i2 = Fe(e2, t2, r2), o2 = "border-box" === w.css(e2, "boxSizing", false, r2), a2 = o2;
    if (We.test(i2)) {
      if (!n2)
        return i2;
      i2 = "auto";
    }
    return a2 = a2 && (h.boxSizingReliable() || i2 === e2.style[t2]), ("auto" === i2 || !parseFloat(i2) && "inline" === w.css(e2, "display", false, r2)) && (i2 = e2["offset" + t2[0].toUpperCase() + t2.slice(1)], a2 = true), (i2 = parseFloat(i2) || 0) + Ze(e2, t2, n2 || (o2 ? "border" : "content"), a2, r2, i2) + "px";
  }
  w.extend({ cssHooks: { opacity: { get: function(e2, t2) {
    if (t2) {
      var n2 = Fe(e2, "opacity");
      return "" === n2 ? "1" : n2;
    }
  } } }, cssNumber: { animationIterationCount: true, columnCount: true, fillOpacity: true, flexGrow: true, flexShrink: true, fontWeight: true, lineHeight: true, opacity: true, order: true, orphans: true, widows: true, zIndex: true, zoom: true }, cssProps: {}, style: function(e2, t2, n2, r2) {
    if (e2 && 3 !== e2.nodeType && 8 !== e2.nodeType && e2.style) {
      var i2, o2, a2, s2 = G(t2), u2 = Xe.test(t2), l2 = e2.style;
      if (u2 || (t2 = Je(s2)), a2 = w.cssHooks[t2] || w.cssHooks[s2], void 0 === n2)
        return a2 && "get" in a2 && void 0 !== (i2 = a2.get(e2, false, r2)) ? i2 : l2[t2];
      "string" == (o2 = typeof n2) && (i2 = ie.exec(n2)) && i2[1] && (n2 = ue(e2, t2, i2), o2 = "number"), null != n2 && n2 === n2 && ("number" === o2 && (n2 += i2 && i2[3] || (w.cssNumber[s2] ? "" : "px")), h.clearCloneStyle || "" !== n2 || 0 !== t2.indexOf("background") || (l2[t2] = "inherit"), a2 && "set" in a2 && void 0 === (n2 = a2.set(e2, n2, r2)) || (u2 ? l2.setProperty(t2, n2) : l2[t2] = n2));
    }
  }, css: function(e2, t2, n2, r2) {
    var i2, o2, a2, s2 = G(t2);
    return Xe.test(t2) || (t2 = Je(s2)), (a2 = w.cssHooks[t2] || w.cssHooks[s2]) && "get" in a2 && (i2 = a2.get(e2, true, n2)), void 0 === i2 && (i2 = Fe(e2, t2, r2)), "normal" === i2 && t2 in Ve && (i2 = Ve[t2]), "" === n2 || n2 ? (o2 = parseFloat(i2), true === n2 || isFinite(o2) ? o2 || 0 : i2) : i2;
  } }), w.each(["height", "width"], function(e2, t2) {
    w.cssHooks[t2] = { get: function(e3, n2, r2) {
      if (n2)
        return !ze.test(w.css(e3, "display")) || e3.getClientRects().length && e3.getBoundingClientRect().width ? et(e3, t2, r2) : se(e3, Ue, function() {
          return et(e3, t2, r2);
        });
    }, set: function(e3, n2, r2) {
      var i2, o2 = $e(e3), a2 = "border-box" === w.css(e3, "boxSizing", false, o2), s2 = r2 && Ze(e3, t2, r2, a2, o2);
      return a2 && h.scrollboxSize() === o2.position && (s2 -= Math.ceil(e3["offset" + t2[0].toUpperCase() + t2.slice(1)] - parseFloat(o2[t2]) - Ze(e3, t2, "border", false, o2) - 0.5)), s2 && (i2 = ie.exec(n2)) && "px" !== (i2[3] || "px") && (e3.style[t2] = n2, n2 = w.css(e3, t2)), Ke(e3, n2, s2);
    } };
  }), w.cssHooks.marginLeft = _e(h.reliableMarginLeft, function(e2, t2) {
    if (t2)
      return (parseFloat(Fe(e2, "marginLeft")) || e2.getBoundingClientRect().left - se(e2, { marginLeft: 0 }, function() {
        return e2.getBoundingClientRect().left;
      })) + "px";
  }), w.each({ margin: "", padding: "", border: "Width" }, function(e2, t2) {
    w.cssHooks[e2 + t2] = { expand: function(n2) {
      for (var r2 = 0, i2 = {}, o2 = "string" == typeof n2 ? n2.split(" ") : [n2]; r2 < 4; r2++)
        i2[e2 + oe[r2] + t2] = o2[r2] || o2[r2 - 2] || o2[0];
      return i2;
    } }, "margin" !== e2 && (w.cssHooks[e2 + t2].set = Ke);
  }), w.fn.extend({ css: function(e2, t2) {
    return z(this, function(e3, t3, n2) {
      var r2, i2, o2 = {}, a2 = 0;
      if (Array.isArray(t3)) {
        for (r2 = $e(e3), i2 = t3.length; a2 < i2; a2++)
          o2[t3[a2]] = w.css(e3, t3[a2], false, r2);
        return o2;
      }
      return void 0 !== n2 ? w.style(e3, t3, n2) : w.css(e3, t3);
    }, e2, t2, arguments.length > 1);
  } });
  function tt(e2, t2, n2, r2, i2) {
    return new tt.prototype.init(e2, t2, n2, r2, i2);
  }
  w.Tween = tt, tt.prototype = { constructor: tt, init: function(e2, t2, n2, r2, i2, o2) {
    this.elem = e2, this.prop = n2, this.easing = i2 || w.easing._default, this.options = t2, this.start = this.now = this.cur(), this.end = r2, this.unit = o2 || (w.cssNumber[n2] ? "" : "px");
  }, cur: function() {
    var e2 = tt.propHooks[this.prop];
    return e2 && e2.get ? e2.get(this) : tt.propHooks._default.get(this);
  }, run: function(e2) {
    var t2, n2 = tt.propHooks[this.prop];
    return this.options.duration ? this.pos = t2 = w.easing[this.easing](e2, this.options.duration * e2, 0, 1, this.options.duration) : this.pos = t2 = e2, this.now = (this.end - this.start) * t2 + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n2 && n2.set ? n2.set(this) : tt.propHooks._default.set(this), this;
  } }, tt.prototype.init.prototype = tt.prototype, tt.propHooks = { _default: { get: function(e2) {
    var t2;
    return 1 !== e2.elem.nodeType || null != e2.elem[e2.prop] && null == e2.elem.style[e2.prop] ? e2.elem[e2.prop] : (t2 = w.css(e2.elem, e2.prop, "")) && "auto" !== t2 ? t2 : 0;
  }, set: function(e2) {
    w.fx.step[e2.prop] ? w.fx.step[e2.prop](e2) : 1 !== e2.elem.nodeType || null == e2.elem.style[w.cssProps[e2.prop]] && !w.cssHooks[e2.prop] ? e2.elem[e2.prop] = e2.now : w.style(e2.elem, e2.prop, e2.now + e2.unit);
  } } }, tt.propHooks.scrollTop = tt.propHooks.scrollLeft = { set: function(e2) {
    e2.elem.nodeType && e2.elem.parentNode && (e2.elem[e2.prop] = e2.now);
  } }, w.easing = { linear: function(e2) {
    return e2;
  }, swing: function(e2) {
    return 0.5 - Math.cos(e2 * Math.PI) / 2;
  }, _default: "swing" }, w.fx = tt.prototype.init, w.fx.step = {};
  var nt, rt, it = /^(?:toggle|show|hide)$/, ot = /queueHooks$/;
  function at() {
    rt && (false === r.hidden && e.requestAnimationFrame ? e.requestAnimationFrame(at) : e.setTimeout(at, w.fx.interval), w.fx.tick());
  }
  function st() {
    return e.setTimeout(function() {
      nt = void 0;
    }), nt = Date.now();
  }
  function ut(e2, t2) {
    var n2, r2 = 0, i2 = { height: e2 };
    for (t2 = t2 ? 1 : 0; r2 < 4; r2 += 2 - t2)
      i2["margin" + (n2 = oe[r2])] = i2["padding" + n2] = e2;
    return t2 && (i2.opacity = i2.width = e2), i2;
  }
  function lt(e2, t2, n2) {
    for (var r2, i2 = (pt.tweeners[t2] || []).concat(pt.tweeners["*"]), o2 = 0, a2 = i2.length; o2 < a2; o2++)
      if (r2 = i2[o2].call(n2, t2, e2))
        return r2;
  }
  function ct(e2, t2, n2) {
    var r2, i2, o2, a2, s2, u2, l2, c2, f2 = "width" in t2 || "height" in t2, p2 = this, d2 = {}, h2 = e2.style, g2 = e2.nodeType && ae(e2), y2 = J.get(e2, "fxshow");
    n2.queue || (null == (a2 = w._queueHooks(e2, "fx")).unqueued && (a2.unqueued = 0, s2 = a2.empty.fire, a2.empty.fire = function() {
      a2.unqueued || s2();
    }), a2.unqueued++, p2.always(function() {
      p2.always(function() {
        a2.unqueued--, w.queue(e2, "fx").length || a2.empty.fire();
      });
    }));
    for (r2 in t2)
      if (i2 = t2[r2], it.test(i2)) {
        if (delete t2[r2], o2 = o2 || "toggle" === i2, i2 === (g2 ? "hide" : "show")) {
          if ("show" !== i2 || !y2 || void 0 === y2[r2])
            continue;
          g2 = true;
        }
        d2[r2] = y2 && y2[r2] || w.style(e2, r2);
      }
    if ((u2 = !w.isEmptyObject(t2)) || !w.isEmptyObject(d2)) {
      f2 && 1 === e2.nodeType && (n2.overflow = [h2.overflow, h2.overflowX, h2.overflowY], null == (l2 = y2 && y2.display) && (l2 = J.get(e2, "display")), "none" === (c2 = w.css(e2, "display")) && (l2 ? c2 = l2 : (fe([e2], true), l2 = e2.style.display || l2, c2 = w.css(e2, "display"), fe([e2]))), ("inline" === c2 || "inline-block" === c2 && null != l2) && "none" === w.css(e2, "float") && (u2 || (p2.done(function() {
        h2.display = l2;
      }), null == l2 && (c2 = h2.display, l2 = "none" === c2 ? "" : c2)), h2.display = "inline-block")), n2.overflow && (h2.overflow = "hidden", p2.always(function() {
        h2.overflow = n2.overflow[0], h2.overflowX = n2.overflow[1], h2.overflowY = n2.overflow[2];
      })), u2 = false;
      for (r2 in d2)
        u2 || (y2 ? "hidden" in y2 && (g2 = y2.hidden) : y2 = J.access(e2, "fxshow", { display: l2 }), o2 && (y2.hidden = !g2), g2 && fe([e2], true), p2.done(function() {
          g2 || fe([e2]), J.remove(e2, "fxshow");
          for (r2 in d2)
            w.style(e2, r2, d2[r2]);
        })), u2 = lt(g2 ? y2[r2] : 0, r2, p2), r2 in y2 || (y2[r2] = u2.start, g2 && (u2.end = u2.start, u2.start = 0));
    }
  }
  function ft(e2, t2) {
    var n2, r2, i2, o2, a2;
    for (n2 in e2)
      if (r2 = G(n2), i2 = t2[r2], o2 = e2[n2], Array.isArray(o2) && (i2 = o2[1], o2 = e2[n2] = o2[0]), n2 !== r2 && (e2[r2] = o2, delete e2[n2]), (a2 = w.cssHooks[r2]) && "expand" in a2) {
        o2 = a2.expand(o2), delete e2[r2];
        for (n2 in o2)
          n2 in e2 || (e2[n2] = o2[n2], t2[n2] = i2);
      } else
        t2[r2] = i2;
  }
  function pt(e2, t2, n2) {
    var r2, i2, o2 = 0, a2 = pt.prefilters.length, s2 = w.Deferred().always(function() {
      delete u2.elem;
    }), u2 = function() {
      if (i2)
        return false;
      for (var t3 = nt || st(), n3 = Math.max(0, l2.startTime + l2.duration - t3), r3 = 1 - (n3 / l2.duration || 0), o3 = 0, a3 = l2.tweens.length; o3 < a3; o3++)
        l2.tweens[o3].run(r3);
      return s2.notifyWith(e2, [l2, r3, n3]), r3 < 1 && a3 ? n3 : (a3 || s2.notifyWith(e2, [l2, 1, 0]), s2.resolveWith(e2, [l2]), false);
    }, l2 = s2.promise({ elem: e2, props: w.extend({}, t2), opts: w.extend(true, { specialEasing: {}, easing: w.easing._default }, n2), originalProperties: t2, originalOptions: n2, startTime: nt || st(), duration: n2.duration, tweens: [], createTween: function(t3, n3) {
      var r3 = w.Tween(e2, l2.opts, t3, n3, l2.opts.specialEasing[t3] || l2.opts.easing);
      return l2.tweens.push(r3), r3;
    }, stop: function(t3) {
      var n3 = 0, r3 = t3 ? l2.tweens.length : 0;
      if (i2)
        return this;
      for (i2 = true; n3 < r3; n3++)
        l2.tweens[n3].run(1);
      return t3 ? (s2.notifyWith(e2, [l2, 1, 0]), s2.resolveWith(e2, [l2, t3])) : s2.rejectWith(e2, [l2, t3]), this;
    } }), c2 = l2.props;
    for (ft(c2, l2.opts.specialEasing); o2 < a2; o2++)
      if (r2 = pt.prefilters[o2].call(l2, e2, c2, l2.opts))
        return g(r2.stop) && (w._queueHooks(l2.elem, l2.opts.queue).stop = r2.stop.bind(r2)), r2;
    return w.map(c2, lt, l2), g(l2.opts.start) && l2.opts.start.call(e2, l2), l2.progress(l2.opts.progress).done(l2.opts.done, l2.opts.complete).fail(l2.opts.fail).always(l2.opts.always), w.fx.timer(w.extend(u2, { elem: e2, anim: l2, queue: l2.opts.queue })), l2;
  }
  w.Animation = w.extend(pt, { tweeners: { "*": [function(e2, t2) {
    var n2 = this.createTween(e2, t2);
    return ue(n2.elem, e2, ie.exec(t2), n2), n2;
  }] }, tweener: function(e2, t2) {
    g(e2) ? (t2 = e2, e2 = ["*"]) : e2 = e2.match(M);
    for (var n2, r2 = 0, i2 = e2.length; r2 < i2; r2++)
      n2 = e2[r2], pt.tweeners[n2] = pt.tweeners[n2] || [], pt.tweeners[n2].unshift(t2);
  }, prefilters: [ct], prefilter: function(e2, t2) {
    t2 ? pt.prefilters.unshift(e2) : pt.prefilters.push(e2);
  } }), w.speed = function(e2, t2, n2) {
    var r2 = e2 && "object" == typeof e2 ? w.extend({}, e2) : { complete: n2 || !n2 && t2 || g(e2) && e2, duration: e2, easing: n2 && t2 || t2 && !g(t2) && t2 };
    return w.fx.off ? r2.duration = 0 : "number" != typeof r2.duration && (r2.duration in w.fx.speeds ? r2.duration = w.fx.speeds[r2.duration] : r2.duration = w.fx.speeds._default), null != r2.queue && true !== r2.queue || (r2.queue = "fx"), r2.old = r2.complete, r2.complete = function() {
      g(r2.old) && r2.old.call(this), r2.queue && w.dequeue(this, r2.queue);
    }, r2;
  }, w.fn.extend({ fadeTo: function(e2, t2, n2, r2) {
    return this.filter(ae).css("opacity", 0).show().end().animate({ opacity: t2 }, e2, n2, r2);
  }, animate: function(e2, t2, n2, r2) {
    var i2 = w.isEmptyObject(e2), o2 = w.speed(t2, n2, r2), a2 = function() {
      var t3 = pt(this, w.extend({}, e2), o2);
      (i2 || J.get(this, "finish")) && t3.stop(true);
    };
    return a2.finish = a2, i2 || false === o2.queue ? this.each(a2) : this.queue(o2.queue, a2);
  }, stop: function(e2, t2, n2) {
    var r2 = function(e3) {
      var t3 = e3.stop;
      delete e3.stop, t3(n2);
    };
    return "string" != typeof e2 && (n2 = t2, t2 = e2, e2 = void 0), t2 && false !== e2 && this.queue(e2 || "fx", []), this.each(function() {
      var t3 = true, i2 = null != e2 && e2 + "queueHooks", o2 = w.timers, a2 = J.get(this);
      if (i2)
        a2[i2] && a2[i2].stop && r2(a2[i2]);
      else
        for (i2 in a2)
          a2[i2] && a2[i2].stop && ot.test(i2) && r2(a2[i2]);
      for (i2 = o2.length; i2--; )
        o2[i2].elem !== this || null != e2 && o2[i2].queue !== e2 || (o2[i2].anim.stop(n2), t3 = false, o2.splice(i2, 1));
      !t3 && n2 || w.dequeue(this, e2);
    });
  }, finish: function(e2) {
    return false !== e2 && (e2 = e2 || "fx"), this.each(function() {
      var t2, n2 = J.get(this), r2 = n2[e2 + "queue"], i2 = n2[e2 + "queueHooks"], o2 = w.timers, a2 = r2 ? r2.length : 0;
      for (n2.finish = true, w.queue(this, e2, []), i2 && i2.stop && i2.stop.call(this, true), t2 = o2.length; t2--; )
        o2[t2].elem === this && o2[t2].queue === e2 && (o2[t2].anim.stop(true), o2.splice(t2, 1));
      for (t2 = 0; t2 < a2; t2++)
        r2[t2] && r2[t2].finish && r2[t2].finish.call(this);
      delete n2.finish;
    });
  } }), w.each(["toggle", "show", "hide"], function(e2, t2) {
    var n2 = w.fn[t2];
    w.fn[t2] = function(e3, r2, i2) {
      return null == e3 || "boolean" == typeof e3 ? n2.apply(this, arguments) : this.animate(ut(t2, true), e3, r2, i2);
    };
  }), w.each({ slideDown: ut("show"), slideUp: ut("hide"), slideToggle: ut("toggle"), fadeIn: { opacity: "show" }, fadeOut: { opacity: "hide" }, fadeToggle: { opacity: "toggle" } }, function(e2, t2) {
    w.fn[e2] = function(e3, n2, r2) {
      return this.animate(t2, e3, n2, r2);
    };
  }), w.timers = [], w.fx.tick = function() {
    var e2, t2 = 0, n2 = w.timers;
    for (nt = Date.now(); t2 < n2.length; t2++)
      (e2 = n2[t2])() || n2[t2] !== e2 || n2.splice(t2--, 1);
    n2.length || w.fx.stop(), nt = void 0;
  }, w.fx.timer = function(e2) {
    w.timers.push(e2), w.fx.start();
  }, w.fx.interval = 13, w.fx.start = function() {
    rt || (rt = true, at());
  }, w.fx.stop = function() {
    rt = null;
  }, w.fx.speeds = { slow: 600, fast: 200, _default: 400 }, w.fn.delay = function(t2, n2) {
    return t2 = w.fx ? w.fx.speeds[t2] || t2 : t2, n2 = n2 || "fx", this.queue(n2, function(n3, r2) {
      var i2 = e.setTimeout(n3, t2);
      r2.stop = function() {
        e.clearTimeout(i2);
      };
    });
  }, function() {
    var e2 = r.createElement("input"), t2 = r.createElement("select").appendChild(r.createElement("option"));
    e2.type = "checkbox", h.checkOn = "" !== e2.value, h.optSelected = t2.selected, (e2 = r.createElement("input")).value = "t", e2.type = "radio", h.radioValue = "t" === e2.value;
  }();
  var dt, ht = w.expr.attrHandle;
  w.fn.extend({ attr: function(e2, t2) {
    return z(this, w.attr, e2, t2, arguments.length > 1);
  }, removeAttr: function(e2) {
    return this.each(function() {
      w.removeAttr(this, e2);
    });
  } }), w.extend({ attr: function(e2, t2, n2) {
    var r2, i2, o2 = e2.nodeType;
    if (3 !== o2 && 8 !== o2 && 2 !== o2)
      return "undefined" == typeof e2.getAttribute ? w.prop(e2, t2, n2) : (1 === o2 && w.isXMLDoc(e2) || (i2 = w.attrHooks[t2.toLowerCase()] || (w.expr.match.bool.test(t2) ? dt : void 0)), void 0 !== n2 ? null === n2 ? void w.removeAttr(e2, t2) : i2 && "set" in i2 && void 0 !== (r2 = i2.set(e2, n2, t2)) ? r2 : (e2.setAttribute(t2, n2 + ""), n2) : i2 && "get" in i2 && null !== (r2 = i2.get(e2, t2)) ? r2 : null == (r2 = w.find.attr(e2, t2)) ? void 0 : r2);
  }, attrHooks: { type: { set: function(e2, t2) {
    if (!h.radioValue && "radio" === t2 && N(e2, "input")) {
      var n2 = e2.value;
      return e2.setAttribute("type", t2), n2 && (e2.value = n2), t2;
    }
  } } }, removeAttr: function(e2, t2) {
    var n2, r2 = 0, i2 = t2 && t2.match(M);
    if (i2 && 1 === e2.nodeType)
      while (n2 = i2[r2++])
        e2.removeAttribute(n2);
  } }), dt = { set: function(e2, t2, n2) {
    return false === t2 ? w.removeAttr(e2, n2) : e2.setAttribute(n2, n2), n2;
  } }, w.each(w.expr.match.bool.source.match(/\w+/g), function(e2, t2) {
    var n2 = ht[t2] || w.find.attr;
    ht[t2] = function(e3, t3, r2) {
      var i2, o2, a2 = t3.toLowerCase();
      return r2 || (o2 = ht[a2], ht[a2] = i2, i2 = null != n2(e3, t3, r2) ? a2 : null, ht[a2] = o2), i2;
    };
  });
  var gt = /^(?:input|select|textarea|button)$/i, yt = /^(?:a|area)$/i;
  w.fn.extend({ prop: function(e2, t2) {
    return z(this, w.prop, e2, t2, arguments.length > 1);
  }, removeProp: function(e2) {
    return this.each(function() {
      delete this[w.propFix[e2] || e2];
    });
  } }), w.extend({ prop: function(e2, t2, n2) {
    var r2, i2, o2 = e2.nodeType;
    if (3 !== o2 && 8 !== o2 && 2 !== o2)
      return 1 === o2 && w.isXMLDoc(e2) || (t2 = w.propFix[t2] || t2, i2 = w.propHooks[t2]), void 0 !== n2 ? i2 && "set" in i2 && void 0 !== (r2 = i2.set(e2, n2, t2)) ? r2 : e2[t2] = n2 : i2 && "get" in i2 && null !== (r2 = i2.get(e2, t2)) ? r2 : e2[t2];
  }, propHooks: { tabIndex: { get: function(e2) {
    var t2 = w.find.attr(e2, "tabindex");
    return t2 ? parseInt(t2, 10) : gt.test(e2.nodeName) || yt.test(e2.nodeName) && e2.href ? 0 : -1;
  } } }, propFix: { "for": "htmlFor", "class": "className" } }), h.optSelected || (w.propHooks.selected = { get: function(e2) {
    var t2 = e2.parentNode;
    return t2 && t2.parentNode && t2.parentNode.selectedIndex, null;
  }, set: function(e2) {
    var t2 = e2.parentNode;
    t2 && (t2.selectedIndex, t2.parentNode && t2.parentNode.selectedIndex);
  } }), w.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
    w.propFix[this.toLowerCase()] = this;
  });
  function vt(e2) {
    return (e2.match(M) || []).join(" ");
  }
  function mt(e2) {
    return e2.getAttribute && e2.getAttribute("class") || "";
  }
  function xt(e2) {
    return Array.isArray(e2) ? e2 : "string" == typeof e2 ? e2.match(M) || [] : [];
  }
  w.fn.extend({ addClass: function(e2) {
    var t2, n2, r2, i2, o2, a2, s2, u2 = 0;
    if (g(e2))
      return this.each(function(t3) {
        w(this).addClass(e2.call(this, t3, mt(this)));
      });
    if ((t2 = xt(e2)).length) {
      while (n2 = this[u2++])
        if (i2 = mt(n2), r2 = 1 === n2.nodeType && " " + vt(i2) + " ") {
          a2 = 0;
          while (o2 = t2[a2++])
            r2.indexOf(" " + o2 + " ") < 0 && (r2 += o2 + " ");
          i2 !== (s2 = vt(r2)) && n2.setAttribute("class", s2);
        }
    }
    return this;
  }, removeClass: function(e2) {
    var t2, n2, r2, i2, o2, a2, s2, u2 = 0;
    if (g(e2))
      return this.each(function(t3) {
        w(this).removeClass(e2.call(this, t3, mt(this)));
      });
    if (!arguments.length)
      return this.attr("class", "");
    if ((t2 = xt(e2)).length) {
      while (n2 = this[u2++])
        if (i2 = mt(n2), r2 = 1 === n2.nodeType && " " + vt(i2) + " ") {
          a2 = 0;
          while (o2 = t2[a2++])
            while (r2.indexOf(" " + o2 + " ") > -1)
              r2 = r2.replace(" " + o2 + " ", " ");
          i2 !== (s2 = vt(r2)) && n2.setAttribute("class", s2);
        }
    }
    return this;
  }, toggleClass: function(e2, t2) {
    var n2 = typeof e2, r2 = "string" === n2 || Array.isArray(e2);
    return "boolean" == typeof t2 && r2 ? t2 ? this.addClass(e2) : this.removeClass(e2) : g(e2) ? this.each(function(n3) {
      w(this).toggleClass(e2.call(this, n3, mt(this), t2), t2);
    }) : this.each(function() {
      var t3, i2, o2, a2;
      if (r2) {
        i2 = 0, o2 = w(this), a2 = xt(e2);
        while (t3 = a2[i2++])
          o2.hasClass(t3) ? o2.removeClass(t3) : o2.addClass(t3);
      } else
        void 0 !== e2 && "boolean" !== n2 || ((t3 = mt(this)) && J.set(this, "__className__", t3), this.setAttribute && this.setAttribute("class", t3 || false === e2 ? "" : J.get(this, "__className__") || ""));
    });
  }, hasClass: function(e2) {
    var t2, n2, r2 = 0;
    t2 = " " + e2 + " ";
    while (n2 = this[r2++])
      if (1 === n2.nodeType && (" " + vt(mt(n2)) + " ").indexOf(t2) > -1)
        return true;
    return false;
  } });
  var bt = /\r/g;
  w.fn.extend({ val: function(e2) {
    var t2, n2, r2, i2 = this[0];
    {
      if (arguments.length)
        return r2 = g(e2), this.each(function(n3) {
          var i3;
          1 === this.nodeType && (null == (i3 = r2 ? e2.call(this, n3, w(this).val()) : e2) ? i3 = "" : "number" == typeof i3 ? i3 += "" : Array.isArray(i3) && (i3 = w.map(i3, function(e3) {
            return null == e3 ? "" : e3 + "";
          })), (t2 = w.valHooks[this.type] || w.valHooks[this.nodeName.toLowerCase()]) && "set" in t2 && void 0 !== t2.set(this, i3, "value") || (this.value = i3));
        });
      if (i2)
        return (t2 = w.valHooks[i2.type] || w.valHooks[i2.nodeName.toLowerCase()]) && "get" in t2 && void 0 !== (n2 = t2.get(i2, "value")) ? n2 : "string" == typeof (n2 = i2.value) ? n2.replace(bt, "") : null == n2 ? "" : n2;
    }
  } }), w.extend({ valHooks: { option: { get: function(e2) {
    var t2 = w.find.attr(e2, "value");
    return null != t2 ? t2 : vt(w.text(e2));
  } }, select: { get: function(e2) {
    var t2, n2, r2, i2 = e2.options, o2 = e2.selectedIndex, a2 = "select-one" === e2.type, s2 = a2 ? null : [], u2 = a2 ? o2 + 1 : i2.length;
    for (r2 = o2 < 0 ? u2 : a2 ? o2 : 0; r2 < u2; r2++)
      if (((n2 = i2[r2]).selected || r2 === o2) && !n2.disabled && (!n2.parentNode.disabled || !N(n2.parentNode, "optgroup"))) {
        if (t2 = w(n2).val(), a2)
          return t2;
        s2.push(t2);
      }
    return s2;
  }, set: function(e2, t2) {
    var n2, r2, i2 = e2.options, o2 = w.makeArray(t2), a2 = i2.length;
    while (a2--)
      ((r2 = i2[a2]).selected = w.inArray(w.valHooks.option.get(r2), o2) > -1) && (n2 = true);
    return n2 || (e2.selectedIndex = -1), o2;
  } } } }), w.each(["radio", "checkbox"], function() {
    w.valHooks[this] = { set: function(e2, t2) {
      if (Array.isArray(t2))
        return e2.checked = w.inArray(w(e2).val(), t2) > -1;
    } }, h.checkOn || (w.valHooks[this].get = function(e2) {
      return null === e2.getAttribute("value") ? "on" : e2.value;
    });
  }), h.focusin = "onfocusin" in e;
  var wt = /^(?:focusinfocus|focusoutblur)$/, Tt = function(e2) {
    e2.stopPropagation();
  };
  w.extend(w.event, { trigger: function(t2, n2, i2, o2) {
    var a2, s2, u2, l2, c2, p2, d2, h2, v2 = [i2 || r], m2 = f.call(t2, "type") ? t2.type : t2, x2 = f.call(t2, "namespace") ? t2.namespace.split(".") : [];
    if (s2 = h2 = u2 = i2 = i2 || r, 3 !== i2.nodeType && 8 !== i2.nodeType && !wt.test(m2 + w.event.triggered) && (m2.indexOf(".") > -1 && (m2 = (x2 = m2.split(".")).shift(), x2.sort()), c2 = m2.indexOf(":") < 0 && "on" + m2, t2 = t2[w.expando] ? t2 : new w.Event(m2, "object" == typeof t2 && t2), t2.isTrigger = o2 ? 2 : 3, t2.namespace = x2.join("."), t2.rnamespace = t2.namespace ? new RegExp("(^|\\.)" + x2.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, t2.result = void 0, t2.target || (t2.target = i2), n2 = null == n2 ? [t2] : w.makeArray(n2, [t2]), d2 = w.event.special[m2] || {}, o2 || !d2.trigger || false !== d2.trigger.apply(i2, n2))) {
      if (!o2 && !d2.noBubble && !y(i2)) {
        for (l2 = d2.delegateType || m2, wt.test(l2 + m2) || (s2 = s2.parentNode); s2; s2 = s2.parentNode)
          v2.push(s2), u2 = s2;
        u2 === (i2.ownerDocument || r) && v2.push(u2.defaultView || u2.parentWindow || e);
      }
      a2 = 0;
      while ((s2 = v2[a2++]) && !t2.isPropagationStopped())
        h2 = s2, t2.type = a2 > 1 ? l2 : d2.bindType || m2, (p2 = (J.get(s2, "events") || {})[t2.type] && J.get(s2, "handle")) && p2.apply(s2, n2), (p2 = c2 && s2[c2]) && p2.apply && Y(s2) && (t2.result = p2.apply(s2, n2), false === t2.result && t2.preventDefault());
      return t2.type = m2, o2 || t2.isDefaultPrevented() || d2._default && false !== d2._default.apply(v2.pop(), n2) || !Y(i2) || c2 && g(i2[m2]) && !y(i2) && ((u2 = i2[c2]) && (i2[c2] = null), w.event.triggered = m2, t2.isPropagationStopped() && h2.addEventListener(m2, Tt), i2[m2](), t2.isPropagationStopped() && h2.removeEventListener(m2, Tt), w.event.triggered = void 0, u2 && (i2[c2] = u2)), t2.result;
    }
  }, simulate: function(e2, t2, n2) {
    var r2 = w.extend(new w.Event(), n2, { type: e2, isSimulated: true });
    w.event.trigger(r2, null, t2);
  } }), w.fn.extend({ trigger: function(e2, t2) {
    return this.each(function() {
      w.event.trigger(e2, t2, this);
    });
  }, triggerHandler: function(e2, t2) {
    var n2 = this[0];
    if (n2)
      return w.event.trigger(e2, t2, n2, true);
  } }), h.focusin || w.each({ focus: "focusin", blur: "focusout" }, function(e2, t2) {
    var n2 = function(e3) {
      w.event.simulate(t2, e3.target, w.event.fix(e3));
    };
    w.event.special[t2] = { setup: function() {
      var r2 = this.ownerDocument || this, i2 = J.access(r2, t2);
      i2 || r2.addEventListener(e2, n2, true), J.access(r2, t2, (i2 || 0) + 1);
    }, teardown: function() {
      var r2 = this.ownerDocument || this, i2 = J.access(r2, t2) - 1;
      i2 ? J.access(r2, t2, i2) : (r2.removeEventListener(e2, n2, true), J.remove(r2, t2));
    } };
  });
  var Ct = e.location, Et = Date.now(), kt = /\?/;
  w.parseXML = function(t2) {
    var n2;
    if (!t2 || "string" != typeof t2)
      return null;
    try {
      n2 = new e.DOMParser().parseFromString(t2, "text/xml");
    } catch (e2) {
      n2 = void 0;
    }
    return n2 && !n2.getElementsByTagName("parsererror").length || w.error("Invalid XML: " + t2), n2;
  };
  var St = /\[\]$/, Dt = /\r?\n/g, Nt = /^(?:submit|button|image|reset|file)$/i, At = /^(?:input|select|textarea|keygen)/i;
  function jt(e2, t2, n2, r2) {
    var i2;
    if (Array.isArray(t2))
      w.each(t2, function(t3, i3) {
        n2 || St.test(e2) ? r2(e2, i3) : jt(e2 + "[" + ("object" == typeof i3 && null != i3 ? t3 : "") + "]", i3, n2, r2);
      });
    else if (n2 || "object" !== x(t2))
      r2(e2, t2);
    else
      for (i2 in t2)
        jt(e2 + "[" + i2 + "]", t2[i2], n2, r2);
  }
  w.param = function(e2, t2) {
    var n2, r2 = [], i2 = function(e3, t3) {
      var n3 = g(t3) ? t3() : t3;
      r2[r2.length] = encodeURIComponent(e3) + "=" + encodeURIComponent(null == n3 ? "" : n3);
    };
    if (Array.isArray(e2) || e2.jquery && !w.isPlainObject(e2))
      w.each(e2, function() {
        i2(this.name, this.value);
      });
    else
      for (n2 in e2)
        jt(n2, e2[n2], t2, i2);
    return r2.join("&");
  }, w.fn.extend({ serialize: function() {
    return w.param(this.serializeArray());
  }, serializeArray: function() {
    return this.map(function() {
      var e2 = w.prop(this, "elements");
      return e2 ? w.makeArray(e2) : this;
    }).filter(function() {
      var e2 = this.type;
      return this.name && !w(this).is(":disabled") && At.test(this.nodeName) && !Nt.test(e2) && (this.checked || !pe.test(e2));
    }).map(function(e2, t2) {
      var n2 = w(this).val();
      return null == n2 ? null : Array.isArray(n2) ? w.map(n2, function(e3) {
        return { name: t2.name, value: e3.replace(Dt, "\r\n") };
      }) : { name: t2.name, value: n2.replace(Dt, "\r\n") };
    }).get();
  } });
  var qt = /%20/g, Lt = /#.*$/, Ht = /([?&])_=[^&]*/, Ot = /^(.*?):[ \t]*([^\r\n]*)$/gm, Pt = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/, Mt = /^(?:GET|HEAD)$/, Rt = /^\/\//, It = {}, Wt = {}, $t = "*/".concat("*"), Bt = r.createElement("a");
  Bt.href = Ct.href;
  function Ft(e2) {
    return function(t2, n2) {
      "string" != typeof t2 && (n2 = t2, t2 = "*");
      var r2, i2 = 0, o2 = t2.toLowerCase().match(M) || [];
      if (g(n2))
        while (r2 = o2[i2++])
          "+" === r2[0] ? (r2 = r2.slice(1) || "*", (e2[r2] = e2[r2] || []).unshift(n2)) : (e2[r2] = e2[r2] || []).push(n2);
    };
  }
  function _t(e2, t2, n2, r2) {
    var i2 = {}, o2 = e2 === Wt;
    function a2(s2) {
      var u2;
      return i2[s2] = true, w.each(e2[s2] || [], function(e3, s3) {
        var l2 = s3(t2, n2, r2);
        return "string" != typeof l2 || o2 || i2[l2] ? o2 ? !(u2 = l2) : void 0 : (t2.dataTypes.unshift(l2), a2(l2), false);
      }), u2;
    }
    return a2(t2.dataTypes[0]) || !i2["*"] && a2("*");
  }
  function zt(e2, t2) {
    var n2, r2, i2 = w.ajaxSettings.flatOptions || {};
    for (n2 in t2)
      void 0 !== t2[n2] && ((i2[n2] ? e2 : r2 || (r2 = {}))[n2] = t2[n2]);
    return r2 && w.extend(true, e2, r2), e2;
  }
  function Xt(e2, t2, n2) {
    var r2, i2, o2, a2, s2 = e2.contents, u2 = e2.dataTypes;
    while ("*" === u2[0])
      u2.shift(), void 0 === r2 && (r2 = e2.mimeType || t2.getResponseHeader("Content-Type"));
    if (r2) {
      for (i2 in s2)
        if (s2[i2] && s2[i2].test(r2)) {
          u2.unshift(i2);
          break;
        }
    }
    if (u2[0] in n2)
      o2 = u2[0];
    else {
      for (i2 in n2) {
        if (!u2[0] || e2.converters[i2 + " " + u2[0]]) {
          o2 = i2;
          break;
        }
        a2 || (a2 = i2);
      }
      o2 = o2 || a2;
    }
    if (o2)
      return o2 !== u2[0] && u2.unshift(o2), n2[o2];
  }
  function Ut(e2, t2, n2, r2) {
    var i2, o2, a2, s2, u2, l2 = {}, c2 = e2.dataTypes.slice();
    if (c2[1])
      for (a2 in e2.converters)
        l2[a2.toLowerCase()] = e2.converters[a2];
    o2 = c2.shift();
    while (o2)
      if (e2.responseFields[o2] && (n2[e2.responseFields[o2]] = t2), !u2 && r2 && e2.dataFilter && (t2 = e2.dataFilter(t2, e2.dataType)), u2 = o2, o2 = c2.shift()) {
        if ("*" === o2)
          o2 = u2;
        else if ("*" !== u2 && u2 !== o2) {
          if (!(a2 = l2[u2 + " " + o2] || l2["* " + o2])) {
            for (i2 in l2)
              if ((s2 = i2.split(" "))[1] === o2 && (a2 = l2[u2 + " " + s2[0]] || l2["* " + s2[0]])) {
                true === a2 ? a2 = l2[i2] : true !== l2[i2] && (o2 = s2[0], c2.unshift(s2[1]));
                break;
              }
          }
          if (true !== a2)
            if (a2 && e2["throws"])
              t2 = a2(t2);
            else
              try {
                t2 = a2(t2);
              } catch (e3) {
                return { state: "parsererror", error: a2 ? e3 : "No conversion from " + u2 + " to " + o2 };
              }
        }
      }
    return { state: "success", data: t2 };
  }
  w.extend({ active: 0, lastModified: {}, etag: {}, ajaxSettings: { url: Ct.href, type: "GET", isLocal: Pt.test(Ct.protocol), global: true, processData: true, async: true, contentType: "application/x-www-form-urlencoded; charset=UTF-8", accepts: { "*": $t, text: "text/plain", html: "text/html", xml: "application/xml, text/xml", json: "application/json, text/javascript" }, contents: { xml: /\bxml\b/, html: /\bhtml/, json: /\bjson\b/ }, responseFields: { xml: "responseXML", text: "responseText", json: "responseJSON" }, converters: { "* text": String, "text html": true, "text json": JSON.parse, "text xml": w.parseXML }, flatOptions: { url: true, context: true } }, ajaxSetup: function(e2, t2) {
    return t2 ? zt(zt(e2, w.ajaxSettings), t2) : zt(w.ajaxSettings, e2);
  }, ajaxPrefilter: Ft(It), ajaxTransport: Ft(Wt), ajax: function(t2, n2) {
    "object" == typeof t2 && (n2 = t2, t2 = void 0), n2 = n2 || {};
    var i2, o2, a2, s2, u2, l2, c2, f2, p2, d2, h2 = w.ajaxSetup({}, n2), g2 = h2.context || h2, y2 = h2.context && (g2.nodeType || g2.jquery) ? w(g2) : w.event, v2 = w.Deferred(), m2 = w.Callbacks("once memory"), x2 = h2.statusCode || {}, b = {}, T2 = {}, C2 = "canceled", E2 = { readyState: 0, getResponseHeader: function(e2) {
      var t3;
      if (c2) {
        if (!s2) {
          s2 = {};
          while (t3 = Ot.exec(a2))
            s2[t3[1].toLowerCase()] = t3[2];
        }
        t3 = s2[e2.toLowerCase()];
      }
      return null == t3 ? null : t3;
    }, getAllResponseHeaders: function() {
      return c2 ? a2 : null;
    }, setRequestHeader: function(e2, t3) {
      return null == c2 && (e2 = T2[e2.toLowerCase()] = T2[e2.toLowerCase()] || e2, b[e2] = t3), this;
    }, overrideMimeType: function(e2) {
      return null == c2 && (h2.mimeType = e2), this;
    }, statusCode: function(e2) {
      var t3;
      if (e2)
        if (c2)
          E2.always(e2[E2.status]);
        else
          for (t3 in e2)
            x2[t3] = [x2[t3], e2[t3]];
      return this;
    }, abort: function(e2) {
      var t3 = e2 || C2;
      return i2 && i2.abort(t3), k2(0, t3), this;
    } };
    if (v2.promise(E2), h2.url = ((t2 || h2.url || Ct.href) + "").replace(Rt, Ct.protocol + "//"), h2.type = n2.method || n2.type || h2.method || h2.type, h2.dataTypes = (h2.dataType || "*").toLowerCase().match(M) || [""], null == h2.crossDomain) {
      l2 = r.createElement("a");
      try {
        l2.href = h2.url, l2.href = l2.href, h2.crossDomain = Bt.protocol + "//" + Bt.host != l2.protocol + "//" + l2.host;
      } catch (e2) {
        h2.crossDomain = true;
      }
    }
    if (h2.data && h2.processData && "string" != typeof h2.data && (h2.data = w.param(h2.data, h2.traditional)), _t(It, h2, n2, E2), c2)
      return E2;
    (f2 = w.event && h2.global) && 0 == w.active++ && w.event.trigger("ajaxStart"), h2.type = h2.type.toUpperCase(), h2.hasContent = !Mt.test(h2.type), o2 = h2.url.replace(Lt, ""), h2.hasContent ? h2.data && h2.processData && 0 === (h2.contentType || "").indexOf("application/x-www-form-urlencoded") && (h2.data = h2.data.replace(qt, "+")) : (d2 = h2.url.slice(o2.length), h2.data && (h2.processData || "string" == typeof h2.data) && (o2 += (kt.test(o2) ? "&" : "?") + h2.data, delete h2.data), false === h2.cache && (o2 = o2.replace(Ht, "$1"), d2 = (kt.test(o2) ? "&" : "?") + "_=" + Et++ + d2), h2.url = o2 + d2), h2.ifModified && (w.lastModified[o2] && E2.setRequestHeader("If-Modified-Since", w.lastModified[o2]), w.etag[o2] && E2.setRequestHeader("If-None-Match", w.etag[o2])), (h2.data && h2.hasContent && false !== h2.contentType || n2.contentType) && E2.setRequestHeader("Content-Type", h2.contentType), E2.setRequestHeader("Accept", h2.dataTypes[0] && h2.accepts[h2.dataTypes[0]] ? h2.accepts[h2.dataTypes[0]] + ("*" !== h2.dataTypes[0] ? ", " + $t + "; q=0.01" : "") : h2.accepts["*"]);
    for (p2 in h2.headers)
      E2.setRequestHeader(p2, h2.headers[p2]);
    if (h2.beforeSend && (false === h2.beforeSend.call(g2, E2, h2) || c2))
      return E2.abort();
    if (C2 = "abort", m2.add(h2.complete), E2.done(h2.success), E2.fail(h2.error), i2 = _t(Wt, h2, n2, E2)) {
      if (E2.readyState = 1, f2 && y2.trigger("ajaxSend", [E2, h2]), c2)
        return E2;
      h2.async && h2.timeout > 0 && (u2 = e.setTimeout(function() {
        E2.abort("timeout");
      }, h2.timeout));
      try {
        c2 = false, i2.send(b, k2);
      } catch (e2) {
        if (c2)
          throw e2;
        k2(-1, e2);
      }
    } else
      k2(-1, "No Transport");
    function k2(t3, n3, r2, s3) {
      var l3, p3, d3, b2, T3, C3 = n3;
      c2 || (c2 = true, u2 && e.clearTimeout(u2), i2 = void 0, a2 = s3 || "", E2.readyState = t3 > 0 ? 4 : 0, l3 = t3 >= 200 && t3 < 300 || 304 === t3, r2 && (b2 = Xt(h2, E2, r2)), b2 = Ut(h2, b2, E2, l3), l3 ? (h2.ifModified && ((T3 = E2.getResponseHeader("Last-Modified")) && (w.lastModified[o2] = T3), (T3 = E2.getResponseHeader("etag")) && (w.etag[o2] = T3)), 204 === t3 || "HEAD" === h2.type ? C3 = "nocontent" : 304 === t3 ? C3 = "notmodified" : (C3 = b2.state, p3 = b2.data, l3 = !(d3 = b2.error))) : (d3 = C3, !t3 && C3 || (C3 = "error", t3 < 0 && (t3 = 0))), E2.status = t3, E2.statusText = (n3 || C3) + "", l3 ? v2.resolveWith(g2, [p3, C3, E2]) : v2.rejectWith(g2, [E2, C3, d3]), E2.statusCode(x2), x2 = void 0, f2 && y2.trigger(l3 ? "ajaxSuccess" : "ajaxError", [E2, h2, l3 ? p3 : d3]), m2.fireWith(g2, [E2, C3]), f2 && (y2.trigger("ajaxComplete", [E2, h2]), --w.active || w.event.trigger("ajaxStop")));
    }
    return E2;
  }, getJSON: function(e2, t2, n2) {
    return w.get(e2, t2, n2, "json");
  }, getScript: function(e2, t2) {
    return w.get(e2, void 0, t2, "script");
  } }), w.each(["get", "post"], function(e2, t2) {
    w[t2] = function(e3, n2, r2, i2) {
      return g(n2) && (i2 = i2 || r2, r2 = n2, n2 = void 0), w.ajax(w.extend({ url: e3, type: t2, dataType: i2, data: n2, success: r2 }, w.isPlainObject(e3) && e3));
    };
  }), w._evalUrl = function(e2) {
    return w.ajax({ url: e2, type: "GET", dataType: "script", cache: true, async: false, global: false, "throws": true });
  }, w.fn.extend({ wrapAll: function(e2) {
    var t2;
    return this[0] && (g(e2) && (e2 = e2.call(this[0])), t2 = w(e2, this[0].ownerDocument).eq(0).clone(true), this[0].parentNode && t2.insertBefore(this[0]), t2.map(function() {
      var e3 = this;
      while (e3.firstElementChild)
        e3 = e3.firstElementChild;
      return e3;
    }).append(this)), this;
  }, wrapInner: function(e2) {
    return g(e2) ? this.each(function(t2) {
      w(this).wrapInner(e2.call(this, t2));
    }) : this.each(function() {
      var t2 = w(this), n2 = t2.contents();
      n2.length ? n2.wrapAll(e2) : t2.append(e2);
    });
  }, wrap: function(e2) {
    var t2 = g(e2);
    return this.each(function(n2) {
      w(this).wrapAll(t2 ? e2.call(this, n2) : e2);
    });
  }, unwrap: function(e2) {
    return this.parent(e2).not("body").each(function() {
      w(this).replaceWith(this.childNodes);
    }), this;
  } }), w.expr.pseudos.hidden = function(e2) {
    return !w.expr.pseudos.visible(e2);
  }, w.expr.pseudos.visible = function(e2) {
    return !!(e2.offsetWidth || e2.offsetHeight || e2.getClientRects().length);
  }, w.ajaxSettings.xhr = function() {
    try {
      return new e.XMLHttpRequest();
    } catch (e2) {
    }
  };
  var Vt = { 0: 200, 1223: 204 }, Gt = w.ajaxSettings.xhr();
  h.cors = !!Gt && "withCredentials" in Gt, h.ajax = Gt = !!Gt, w.ajaxTransport(function(t2) {
    var n2, r2;
    if (h.cors || Gt && !t2.crossDomain)
      return { send: function(i2, o2) {
        var a2, s2 = t2.xhr();
        if (s2.open(t2.type, t2.url, t2.async, t2.username, t2.password), t2.xhrFields)
          for (a2 in t2.xhrFields)
            s2[a2] = t2.xhrFields[a2];
        t2.mimeType && s2.overrideMimeType && s2.overrideMimeType(t2.mimeType), t2.crossDomain || i2["X-Requested-With"] || (i2["X-Requested-With"] = "XMLHttpRequest");
        for (a2 in i2)
          s2.setRequestHeader(a2, i2[a2]);
        n2 = function(e2) {
          return function() {
            n2 && (n2 = r2 = s2.onload = s2.onerror = s2.onabort = s2.ontimeout = s2.onreadystatechange = null, "abort" === e2 ? s2.abort() : "error" === e2 ? "number" != typeof s2.status ? o2(0, "error") : o2(s2.status, s2.statusText) : o2(Vt[s2.status] || s2.status, s2.statusText, "text" !== (s2.responseType || "text") || "string" != typeof s2.responseText ? { binary: s2.response } : { text: s2.responseText }, s2.getAllResponseHeaders()));
          };
        }, s2.onload = n2(), r2 = s2.onerror = s2.ontimeout = n2("error"), void 0 !== s2.onabort ? s2.onabort = r2 : s2.onreadystatechange = function() {
          4 === s2.readyState && e.setTimeout(function() {
            n2 && r2();
          });
        }, n2 = n2("abort");
        try {
          s2.send(t2.hasContent && t2.data || null);
        } catch (e2) {
          if (n2)
            throw e2;
        }
      }, abort: function() {
        n2 && n2();
      } };
  }), w.ajaxPrefilter(function(e2) {
    e2.crossDomain && (e2.contents.script = false);
  }), w.ajaxSetup({ accepts: { script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript" }, contents: { script: /\b(?:java|ecma)script\b/ }, converters: { "text script": function(e2) {
    return w.globalEval(e2), e2;
  } } }), w.ajaxPrefilter("script", function(e2) {
    void 0 === e2.cache && (e2.cache = false), e2.crossDomain && (e2.type = "GET");
  }), w.ajaxTransport("script", function(e2) {
    if (e2.crossDomain) {
      var t2, n2;
      return { send: function(i2, o2) {
        t2 = w("<script>").prop({ charset: e2.scriptCharset, src: e2.url }).on("load error", n2 = function(e3) {
          t2.remove(), n2 = null, e3 && o2("error" === e3.type ? 404 : 200, e3.type);
        }), r.head.appendChild(t2[0]);
      }, abort: function() {
        n2 && n2();
      } };
    }
  });
  var Yt = [], Qt = /(=)\?(?=&|$)|\?\?/;
  w.ajaxSetup({ jsonp: "callback", jsonpCallback: function() {
    var e2 = Yt.pop() || w.expando + "_" + Et++;
    return this[e2] = true, e2;
  } }), w.ajaxPrefilter("json jsonp", function(t2, n2, r2) {
    var i2, o2, a2, s2 = false !== t2.jsonp && (Qt.test(t2.url) ? "url" : "string" == typeof t2.data && 0 === (t2.contentType || "").indexOf("application/x-www-form-urlencoded") && Qt.test(t2.data) && "data");
    if (s2 || "jsonp" === t2.dataTypes[0])
      return i2 = t2.jsonpCallback = g(t2.jsonpCallback) ? t2.jsonpCallback() : t2.jsonpCallback, s2 ? t2[s2] = t2[s2].replace(Qt, "$1" + i2) : false !== t2.jsonp && (t2.url += (kt.test(t2.url) ? "&" : "?") + t2.jsonp + "=" + i2), t2.converters["script json"] = function() {
        return a2 || w.error(i2 + " was not called"), a2[0];
      }, t2.dataTypes[0] = "json", o2 = e[i2], e[i2] = function() {
        a2 = arguments;
      }, r2.always(function() {
        void 0 === o2 ? w(e).removeProp(i2) : e[i2] = o2, t2[i2] && (t2.jsonpCallback = n2.jsonpCallback, Yt.push(i2)), a2 && g(o2) && o2(a2[0]), a2 = o2 = void 0;
      }), "script";
  }), h.createHTMLDocument = function() {
    var e2 = r.implementation.createHTMLDocument("").body;
    return e2.innerHTML = "<form></form><form></form>", 2 === e2.childNodes.length;
  }(), w.parseHTML = function(e2, t2, n2) {
    if ("string" != typeof e2)
      return [];
    "boolean" == typeof t2 && (n2 = t2, t2 = false);
    var i2, o2, a2;
    return t2 || (h.createHTMLDocument ? ((i2 = (t2 = r.implementation.createHTMLDocument("")).createElement("base")).href = r.location.href, t2.head.appendChild(i2)) : t2 = r), o2 = A.exec(e2), a2 = !n2 && [], o2 ? [t2.createElement(o2[1])] : (o2 = xe([e2], t2, a2), a2 && a2.length && w(a2).remove(), w.merge([], o2.childNodes));
  }, w.fn.load = function(e2, t2, n2) {
    var r2, i2, o2, a2 = this, s2 = e2.indexOf(" ");
    return s2 > -1 && (r2 = vt(e2.slice(s2)), e2 = e2.slice(0, s2)), g(t2) ? (n2 = t2, t2 = void 0) : t2 && "object" == typeof t2 && (i2 = "POST"), a2.length > 0 && w.ajax({ url: e2, type: i2 || "GET", dataType: "html", data: t2 }).done(function(e3) {
      o2 = arguments, a2.html(r2 ? w("<div>").append(w.parseHTML(e3)).find(r2) : e3);
    }).always(n2 && function(e3, t3) {
      a2.each(function() {
        n2.apply(this, o2 || [e3.responseText, t3, e3]);
      });
    }), this;
  }, w.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(e2, t2) {
    w.fn[t2] = function(e3) {
      return this.on(t2, e3);
    };
  }), w.expr.pseudos.animated = function(e2) {
    return w.grep(w.timers, function(t2) {
      return e2 === t2.elem;
    }).length;
  }, w.offset = { setOffset: function(e2, t2, n2) {
    var r2, i2, o2, a2, s2, u2, c2 = w.css(e2, "position"), f2 = w(e2), p2 = {};
    "static" === c2 && (e2.style.position = "relative"), s2 = f2.offset(), o2 = w.css(e2, "top"), u2 = w.css(e2, "left"), ("absolute" === c2 || "fixed" === c2) && (o2 + u2).indexOf("auto") > -1 ? (a2 = (r2 = f2.position()).top, i2 = r2.left) : (a2 = parseFloat(o2) || 0, i2 = parseFloat(u2) || 0), g(t2) && (t2 = t2.call(e2, n2, w.extend({}, s2))), null != t2.top && (p2.top = t2.top - s2.top + a2), null != t2.left && (p2.left = t2.left - s2.left + i2), "using" in t2 ? t2.using.call(e2, p2) : f2.css(p2);
  } }, w.fn.extend({ offset: function(e2) {
    if (arguments.length)
      return void 0 === e2 ? this : this.each(function(t3) {
        w.offset.setOffset(this, e2, t3);
      });
    var t2, n2, r2 = this[0];
    if (r2)
      return r2.getClientRects().length ? (t2 = r2.getBoundingClientRect(), n2 = r2.ownerDocument.defaultView, { top: t2.top + n2.pageYOffset, left: t2.left + n2.pageXOffset }) : { top: 0, left: 0 };
  }, position: function() {
    if (this[0]) {
      var e2, t2, n2, r2 = this[0], i2 = { top: 0, left: 0 };
      if ("fixed" === w.css(r2, "position"))
        t2 = r2.getBoundingClientRect();
      else {
        t2 = this.offset(), n2 = r2.ownerDocument, e2 = r2.offsetParent || n2.documentElement;
        while (e2 && (e2 === n2.body || e2 === n2.documentElement) && "static" === w.css(e2, "position"))
          e2 = e2.parentNode;
        e2 && e2 !== r2 && 1 === e2.nodeType && ((i2 = w(e2).offset()).top += w.css(e2, "borderTopWidth", true), i2.left += w.css(e2, "borderLeftWidth", true));
      }
      return { top: t2.top - i2.top - w.css(r2, "marginTop", true), left: t2.left - i2.left - w.css(r2, "marginLeft", true) };
    }
  }, offsetParent: function() {
    return this.map(function() {
      var e2 = this.offsetParent;
      while (e2 && "static" === w.css(e2, "position"))
        e2 = e2.offsetParent;
      return e2 || be;
    });
  } }), w.each({ scrollLeft: "pageXOffset", scrollTop: "pageYOffset" }, function(e2, t2) {
    var n2 = "pageYOffset" === t2;
    w.fn[e2] = function(r2) {
      return z(this, function(e3, r3, i2) {
        var o2;
        if (y(e3) ? o2 = e3 : 9 === e3.nodeType && (o2 = e3.defaultView), void 0 === i2)
          return o2 ? o2[t2] : e3[r3];
        o2 ? o2.scrollTo(n2 ? o2.pageXOffset : i2, n2 ? i2 : o2.pageYOffset) : e3[r3] = i2;
      }, e2, r2, arguments.length);
    };
  }), w.each(["top", "left"], function(e2, t2) {
    w.cssHooks[t2] = _e(h.pixelPosition, function(e3, n2) {
      if (n2)
        return n2 = Fe(e3, t2), We.test(n2) ? w(e3).position()[t2] + "px" : n2;
    });
  }), w.each({ Height: "height", Width: "width" }, function(e2, t2) {
    w.each({ padding: "inner" + e2, content: t2, "": "outer" + e2 }, function(n2, r2) {
      w.fn[r2] = function(i2, o2) {
        var a2 = arguments.length && (n2 || "boolean" != typeof i2), s2 = n2 || (true === i2 || true === o2 ? "margin" : "border");
        return z(this, function(t3, n3, i3) {
          var o3;
          return y(t3) ? 0 === r2.indexOf("outer") ? t3["inner" + e2] : t3.document.documentElement["client" + e2] : 9 === t3.nodeType ? (o3 = t3.documentElement, Math.max(t3.body["scroll" + e2], o3["scroll" + e2], t3.body["offset" + e2], o3["offset" + e2], o3["client" + e2])) : void 0 === i3 ? w.css(t3, n3, s2) : w.style(t3, n3, i3, s2);
        }, t2, a2 ? i2 : void 0, a2);
      };
    });
  }), w.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), function(e2, t2) {
    w.fn[t2] = function(e3, n2) {
      return arguments.length > 0 ? this.on(t2, null, e3, n2) : this.trigger(t2);
    };
  }), w.fn.extend({ hover: function(e2, t2) {
    return this.mouseenter(e2).mouseleave(t2 || e2);
  } }), w.fn.extend({ bind: function(e2, t2, n2) {
    return this.on(e2, null, t2, n2);
  }, unbind: function(e2, t2) {
    return this.off(e2, null, t2);
  }, delegate: function(e2, t2, n2, r2) {
    return this.on(t2, e2, n2, r2);
  }, undelegate: function(e2, t2, n2) {
    return 1 === arguments.length ? this.off(e2, "**") : this.off(t2, e2 || "**", n2);
  } }), w.proxy = function(e2, t2) {
    var n2, r2, i2;
    if ("string" == typeof t2 && (n2 = e2[t2], t2 = e2, e2 = n2), g(e2))
      return r2 = o.call(arguments, 2), i2 = function() {
        return e2.apply(t2 || this, r2.concat(o.call(arguments)));
      }, i2.guid = e2.guid = e2.guid || w.guid++, i2;
  }, w.holdReady = function(e2) {
    e2 ? w.readyWait++ : w.ready(true);
  }, w.isArray = Array.isArray, w.parseJSON = JSON.parse, w.nodeName = N, w.isFunction = g, w.isWindow = y, w.camelCase = G, w.type = x, w.now = Date.now, w.isNumeric = function(e2) {
    var t2 = w.type(e2);
    return ("number" === t2 || "string" === t2) && !isNaN(e2 - parseFloat(e2));
  }, "function" == typeof define && define.amd && define("jquery", [], function() {
    return w;
  });
  var Jt = e.jQuery, Kt = e.$;
  return w.noConflict = function(t2) {
    return e.$ === w && (e.$ = Kt), t2 && e.jQuery === w && (e.jQuery = Jt), w;
  }, t || (e.jQuery = e.$ = w), w;
});
/*!
  * Bootstrap v4.4.1 (https://getbootstrap.com/)
  * Copyright 2011-2019 The Bootstrap Authors (https://github.com/twbs/bootstrap/graphs/contributors)
  * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
  */
!function(t, e) {
  "object" == typeof exports && "undefined" != typeof module ? e(exports, require("jquery"), require("popper.js")) : "function" == typeof define && define.amd ? define(["exports", "jquery", "popper.js"], e) : e((t = t || self).bootstrap = {}, t.jQuery, t.Popper);
}(globalThis, function(t, g, u) {
  function i(t2, e2) {
    for (var n2 = 0; n2 < e2.length; n2++) {
      var i2 = e2[n2];
      i2.enumerable = i2.enumerable || false, i2.configurable = true, "value" in i2 && (i2.writable = true), Object.defineProperty(t2, i2.key, i2);
    }
  }
  function s(t2, e2, n2) {
    return e2 && i(t2.prototype, e2), n2 && i(t2, n2), t2;
  }
  function e(e2, t2) {
    var n2 = Object.keys(e2);
    if (Object.getOwnPropertySymbols) {
      var i2 = Object.getOwnPropertySymbols(e2);
      t2 && (i2 = i2.filter(function(t3) {
        return Object.getOwnPropertyDescriptor(e2, t3).enumerable;
      })), n2.push.apply(n2, i2);
    }
    return n2;
  }
  function l(o2) {
    for (var t2 = 1; t2 < arguments.length; t2++) {
      var r2 = null != arguments[t2] ? arguments[t2] : {};
      t2 % 2 ? e(Object(r2), true).forEach(function(t3) {
        var e2, n2, i2;
        e2 = o2, i2 = r2[n2 = t3], n2 in e2 ? Object.defineProperty(e2, n2, { value: i2, enumerable: true, configurable: true, writable: true }) : e2[n2] = i2;
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(o2, Object.getOwnPropertyDescriptors(r2)) : e(Object(r2)).forEach(function(t3) {
        Object.defineProperty(o2, t3, Object.getOwnPropertyDescriptor(r2, t3));
      });
    }
    return o2;
  }
  g = g && g.hasOwnProperty("default") ? g.default : g, u = u && u.hasOwnProperty("default") ? u.default : u;
  var n = "transitionend";
  function o(t2) {
    var e2 = this, n2 = false;
    return g(this).one(_.TRANSITION_END, function() {
      n2 = true;
    }), setTimeout(function() {
      n2 || _.triggerTransitionEnd(e2);
    }, t2), this;
  }
  var _ = { TRANSITION_END: "bsTransitionEnd", getUID: function(t2) {
    for (; t2 += ~~(1e6 * Math.random()), document.getElementById(t2); )
      ;
    return t2;
  }, getSelectorFromElement: function(t2) {
    var e2 = t2.getAttribute("data-target");
    if (!e2 || "#" === e2) {
      var n2 = t2.getAttribute("href");
      e2 = n2 && "#" !== n2 ? n2.trim() : "";
    }
    try {
      return document.querySelector(e2) ? e2 : null;
    } catch (t3) {
      return null;
    }
  }, getTransitionDurationFromElement: function(t2) {
    if (!t2)
      return 0;
    var e2 = g(t2).css("transition-duration"), n2 = g(t2).css("transition-delay"), i2 = parseFloat(e2), o2 = parseFloat(n2);
    return i2 || o2 ? (e2 = e2.split(",")[0], n2 = n2.split(",")[0], 1e3 * (parseFloat(e2) + parseFloat(n2))) : 0;
  }, reflow: function(t2) {
    return t2.offsetHeight;
  }, triggerTransitionEnd: function(t2) {
    g(t2).trigger(n);
  }, supportsTransitionEnd: function() {
    return Boolean(n);
  }, isElement: function(t2) {
    return (t2[0] || t2).nodeType;
  }, typeCheckConfig: function(t2, e2, n2) {
    for (var i2 in n2)
      if (Object.prototype.hasOwnProperty.call(n2, i2)) {
        var o2 = n2[i2], r2 = e2[i2], s2 = r2 && _.isElement(r2) ? "element" : (a2 = r2, {}.toString.call(a2).match(/\s([a-z]+)/i)[1].toLowerCase());
        if (!new RegExp(o2).test(s2))
          throw new Error(t2.toUpperCase() + ': Option "' + i2 + '" provided type "' + s2 + '" but expected type "' + o2 + '".');
      }
    var a2;
  }, findShadowRoot: function(t2) {
    if (!document.documentElement.attachShadow)
      return null;
    if ("function" != typeof t2.getRootNode)
      return t2 instanceof ShadowRoot ? t2 : t2.parentNode ? _.findShadowRoot(t2.parentNode) : null;
    var e2 = t2.getRootNode();
    return e2 instanceof ShadowRoot ? e2 : null;
  }, jQueryDetection: function() {
    if ("undefined" == typeof g)
      throw new TypeError("Bootstrap's JavaScript requires jQuery. jQuery must be included before Bootstrap's JavaScript.");
    var t2 = g.fn.jquery.split(" ")[0].split(".");
    if (t2[0] < 2 && t2[1] < 9 || 1 === t2[0] && 9 === t2[1] && t2[2] < 1 || 4 <= t2[0])
      throw new Error("Bootstrap's JavaScript requires at least jQuery v1.9.1 but less than v4.0.0");
  } };
  _.jQueryDetection(), g.fn.emulateTransitionEnd = o, g.event.special[_.TRANSITION_END] = { bindType: n, delegateType: n, handle: function(t2) {
    if (g(t2.target).is(this))
      return t2.handleObj.handler.apply(this, arguments);
  } };
  var r = "alert", a = "bs.alert", c = "." + a, h = g.fn[r], f = { CLOSE: "close" + c, CLOSED: "closed" + c, CLICK_DATA_API: "click" + c + ".data-api" }, d = "alert", m = "fade", p = "show", v = function() {
    function i2(t3) {
      this._element = t3;
    }
    var t2 = i2.prototype;
    return t2.close = function(t3) {
      var e2 = this._element;
      t3 && (e2 = this._getRootElement(t3)), this._triggerCloseEvent(e2).isDefaultPrevented() || this._removeElement(e2);
    }, t2.dispose = function() {
      g.removeData(this._element, a), this._element = null;
    }, t2._getRootElement = function(t3) {
      var e2 = _.getSelectorFromElement(t3), n2 = false;
      return e2 && (n2 = document.querySelector(e2)), n2 = n2 || g(t3).closest("." + d)[0];
    }, t2._triggerCloseEvent = function(t3) {
      var e2 = g.Event(f.CLOSE);
      return g(t3).trigger(e2), e2;
    }, t2._removeElement = function(e2) {
      var n2 = this;
      if (g(e2).removeClass(p), g(e2).hasClass(m)) {
        var t3 = _.getTransitionDurationFromElement(e2);
        g(e2).one(_.TRANSITION_END, function(t4) {
          return n2._destroyElement(e2, t4);
        }).emulateTransitionEnd(t3);
      } else
        this._destroyElement(e2);
    }, t2._destroyElement = function(t3) {
      g(t3).detach().trigger(f.CLOSED).remove();
    }, i2._jQueryInterface = function(n2) {
      return this.each(function() {
        var t3 = g(this), e2 = t3.data(a);
        e2 || (e2 = new i2(this), t3.data(a, e2)), "close" === n2 && e2[n2](this);
      });
    }, i2._handleDismiss = function(e2) {
      return function(t3) {
        t3 && t3.preventDefault(), e2.close(this);
      };
    }, s(i2, null, [{ key: "VERSION", get: function() {
      return "4.4.1";
    } }]), i2;
  }();
  g(document).on(f.CLICK_DATA_API, '[data-dismiss="alert"]', v._handleDismiss(new v())), g.fn[r] = v._jQueryInterface, g.fn[r].Constructor = v, g.fn[r].noConflict = function() {
    return g.fn[r] = h, v._jQueryInterface;
  };
  var y = "button", E = "bs.button", C = "." + E, T = ".data-api", b = g.fn[y], S = "active", D = "btn", I = "focus", w = '[data-toggle^="button"]', A = '[data-toggle="buttons"]', N = '[data-toggle="button"]', O = '[data-toggle="buttons"] .btn', k = 'input:not([type="hidden"])', P = ".active", L = ".btn", j = { CLICK_DATA_API: "click" + C + T, FOCUS_BLUR_DATA_API: "focus" + C + T + " blur" + C + T, LOAD_DATA_API: "load" + C + T }, H = function() {
    function n2(t3) {
      this._element = t3;
    }
    var t2 = n2.prototype;
    return t2.toggle = function() {
      var t3 = true, e2 = true, n3 = g(this._element).closest(A)[0];
      if (n3) {
        var i2 = this._element.querySelector(k);
        if (i2) {
          if ("radio" === i2.type)
            if (i2.checked && this._element.classList.contains(S))
              t3 = false;
            else {
              var o2 = n3.querySelector(P);
              o2 && g(o2).removeClass(S);
            }
          else
            "checkbox" === i2.type ? "LABEL" === this._element.tagName && i2.checked === this._element.classList.contains(S) && (t3 = false) : t3 = false;
          t3 && (i2.checked = !this._element.classList.contains(S), g(i2).trigger("change")), i2.focus(), e2 = false;
        }
      }
      this._element.hasAttribute("disabled") || this._element.classList.contains("disabled") || (e2 && this._element.setAttribute("aria-pressed", !this._element.classList.contains(S)), t3 && g(this._element).toggleClass(S));
    }, t2.dispose = function() {
      g.removeData(this._element, E), this._element = null;
    }, n2._jQueryInterface = function(e2) {
      return this.each(function() {
        var t3 = g(this).data(E);
        t3 || (t3 = new n2(this), g(this).data(E, t3)), "toggle" === e2 && t3[e2]();
      });
    }, s(n2, null, [{ key: "VERSION", get: function() {
      return "4.4.1";
    } }]), n2;
  }();
  g(document).on(j.CLICK_DATA_API, w, function(t2) {
    var e2 = t2.target;
    if (g(e2).hasClass(D) || (e2 = g(e2).closest(L)[0]), !e2 || e2.hasAttribute("disabled") || e2.classList.contains("disabled"))
      t2.preventDefault();
    else {
      var n2 = e2.querySelector(k);
      if (n2 && (n2.hasAttribute("disabled") || n2.classList.contains("disabled")))
        return void t2.preventDefault();
      H._jQueryInterface.call(g(e2), "toggle");
    }
  }).on(j.FOCUS_BLUR_DATA_API, w, function(t2) {
    var e2 = g(t2.target).closest(L)[0];
    g(e2).toggleClass(I, /^focus(in)?$/.test(t2.type));
  }), g(window).on(j.LOAD_DATA_API, function() {
    for (var t2 = [].slice.call(document.querySelectorAll(O)), e2 = 0, n2 = t2.length; e2 < n2; e2++) {
      var i2 = t2[e2], o2 = i2.querySelector(k);
      o2.checked || o2.hasAttribute("checked") ? i2.classList.add(S) : i2.classList.remove(S);
    }
    for (var r2 = 0, s2 = (t2 = [].slice.call(document.querySelectorAll(N))).length; r2 < s2; r2++) {
      var a2 = t2[r2];
      "true" === a2.getAttribute("aria-pressed") ? a2.classList.add(S) : a2.classList.remove(S);
    }
  }), g.fn[y] = H._jQueryInterface, g.fn[y].Constructor = H, g.fn[y].noConflict = function() {
    return g.fn[y] = b, H._jQueryInterface;
  };
  var R = "carousel", x = "bs.carousel", F = "." + x, U = ".data-api", W = g.fn[R], q = { interval: 5e3, keyboard: true, slide: false, pause: "hover", wrap: true, touch: true }, M = { interval: "(number|boolean)", keyboard: "boolean", slide: "(boolean|string)", pause: "(string|boolean)", wrap: "boolean", touch: "boolean" }, K = "next", Q = "prev", B = "left", V = "right", Y = { SLIDE: "slide" + F, SLID: "slid" + F, KEYDOWN: "keydown" + F, MOUSEENTER: "mouseenter" + F, MOUSELEAVE: "mouseleave" + F, TOUCHSTART: "touchstart" + F, TOUCHMOVE: "touchmove" + F, TOUCHEND: "touchend" + F, POINTERDOWN: "pointerdown" + F, POINTERUP: "pointerup" + F, DRAG_START: "dragstart" + F, LOAD_DATA_API: "load" + F + U, CLICK_DATA_API: "click" + F + U }, z = "carousel", X = "active", $ = "slide", G = "carousel-item-right", J = "carousel-item-left", Z = "carousel-item-next", tt = "carousel-item-prev", et = "pointer-event", nt = ".active", it = ".active.carousel-item", ot = ".carousel-item", rt = ".carousel-item img", st = ".carousel-item-next, .carousel-item-prev", at = ".carousel-indicators", lt = "[data-slide], [data-slide-to]", ct = '[data-ride="carousel"]', ht = { TOUCH: "touch", PEN: "pen" }, ut = function() {
    function r2(t3, e2) {
      this._items = null, this._interval = null, this._activeElement = null, this._isPaused = false, this._isSliding = false, this.touchTimeout = null, this.touchStartX = 0, this.touchDeltaX = 0, this._config = this._getConfig(e2), this._element = t3, this._indicatorsElement = this._element.querySelector(at), this._touchSupported = "ontouchstart" in document.documentElement || 0 < navigator.maxTouchPoints, this._pointerEvent = Boolean(window.PointerEvent || window.MSPointerEvent), this._addEventListeners();
    }
    var t2 = r2.prototype;
    return t2.next = function() {
      this._isSliding || this._slide(K);
    }, t2.nextWhenVisible = function() {
      !document.hidden && g(this._element).is(":visible") && "hidden" !== g(this._element).css("visibility") && this.next();
    }, t2.prev = function() {
      this._isSliding || this._slide(Q);
    }, t2.pause = function(t3) {
      t3 || (this._isPaused = true), this._element.querySelector(st) && (_.triggerTransitionEnd(this._element), this.cycle(true)), clearInterval(this._interval), this._interval = null;
    }, t2.cycle = function(t3) {
      t3 || (this._isPaused = false), this._interval && (clearInterval(this._interval), this._interval = null), this._config.interval && !this._isPaused && (this._interval = setInterval((document.visibilityState ? this.nextWhenVisible : this.next).bind(this), this._config.interval));
    }, t2.to = function(t3) {
      var e2 = this;
      this._activeElement = this._element.querySelector(it);
      var n2 = this._getItemIndex(this._activeElement);
      if (!(t3 > this._items.length - 1 || t3 < 0))
        if (this._isSliding)
          g(this._element).one(Y.SLID, function() {
            return e2.to(t3);
          });
        else {
          if (n2 === t3)
            return this.pause(), void this.cycle();
          var i2 = n2 < t3 ? K : Q;
          this._slide(i2, this._items[t3]);
        }
    }, t2.dispose = function() {
      g(this._element).off(F), g.removeData(this._element, x), this._items = null, this._config = null, this._element = null, this._interval = null, this._isPaused = null, this._isSliding = null, this._activeElement = null, this._indicatorsElement = null;
    }, t2._getConfig = function(t3) {
      return t3 = l({}, q, {}, t3), _.typeCheckConfig(R, t3, M), t3;
    }, t2._handleSwipe = function() {
      var t3 = Math.abs(this.touchDeltaX);
      if (!(t3 <= 40)) {
        var e2 = t3 / this.touchDeltaX;
        (this.touchDeltaX = 0) < e2 && this.prev(), e2 < 0 && this.next();
      }
    }, t2._addEventListeners = function() {
      var e2 = this;
      this._config.keyboard && g(this._element).on(Y.KEYDOWN, function(t3) {
        return e2._keydown(t3);
      }), "hover" === this._config.pause && g(this._element).on(Y.MOUSEENTER, function(t3) {
        return e2.pause(t3);
      }).on(Y.MOUSELEAVE, function(t3) {
        return e2.cycle(t3);
      }), this._config.touch && this._addTouchEventListeners();
    }, t2._addTouchEventListeners = function() {
      var e2 = this;
      if (this._touchSupported) {
        var n2 = function(t3) {
          e2._pointerEvent && ht[t3.originalEvent.pointerType.toUpperCase()] ? e2.touchStartX = t3.originalEvent.clientX : e2._pointerEvent || (e2.touchStartX = t3.originalEvent.touches[0].clientX);
        }, i2 = function(t3) {
          e2._pointerEvent && ht[t3.originalEvent.pointerType.toUpperCase()] && (e2.touchDeltaX = t3.originalEvent.clientX - e2.touchStartX), e2._handleSwipe(), "hover" === e2._config.pause && (e2.pause(), e2.touchTimeout && clearTimeout(e2.touchTimeout), e2.touchTimeout = setTimeout(function(t4) {
            return e2.cycle(t4);
          }, 500 + e2._config.interval));
        };
        g(this._element.querySelectorAll(rt)).on(Y.DRAG_START, function(t3) {
          return t3.preventDefault();
        }), this._pointerEvent ? (g(this._element).on(Y.POINTERDOWN, function(t3) {
          return n2(t3);
        }), g(this._element).on(Y.POINTERUP, function(t3) {
          return i2(t3);
        }), this._element.classList.add(et)) : (g(this._element).on(Y.TOUCHSTART, function(t3) {
          return n2(t3);
        }), g(this._element).on(Y.TOUCHMOVE, function(t3) {
          return function(t4) {
            t4.originalEvent.touches && 1 < t4.originalEvent.touches.length ? e2.touchDeltaX = 0 : e2.touchDeltaX = t4.originalEvent.touches[0].clientX - e2.touchStartX;
          }(t3);
        }), g(this._element).on(Y.TOUCHEND, function(t3) {
          return i2(t3);
        }));
      }
    }, t2._keydown = function(t3) {
      if (!/input|textarea/i.test(t3.target.tagName))
        switch (t3.which) {
          case 37:
            t3.preventDefault(), this.prev();
            break;
          case 39:
            t3.preventDefault(), this.next();
        }
    }, t2._getItemIndex = function(t3) {
      return this._items = t3 && t3.parentNode ? [].slice.call(t3.parentNode.querySelectorAll(ot)) : [], this._items.indexOf(t3);
    }, t2._getItemByDirection = function(t3, e2) {
      var n2 = t3 === K, i2 = t3 === Q, o2 = this._getItemIndex(e2), r3 = this._items.length - 1;
      if ((i2 && 0 === o2 || n2 && o2 === r3) && !this._config.wrap)
        return e2;
      var s2 = (o2 + (t3 === Q ? -1 : 1)) % this._items.length;
      return -1 == s2 ? this._items[this._items.length - 1] : this._items[s2];
    }, t2._triggerSlideEvent = function(t3, e2) {
      var n2 = this._getItemIndex(t3), i2 = this._getItemIndex(this._element.querySelector(it)), o2 = g.Event(Y.SLIDE, { relatedTarget: t3, direction: e2, from: i2, to: n2 });
      return g(this._element).trigger(o2), o2;
    }, t2._setActiveIndicatorElement = function(t3) {
      if (this._indicatorsElement) {
        var e2 = [].slice.call(this._indicatorsElement.querySelectorAll(nt));
        g(e2).removeClass(X);
        var n2 = this._indicatorsElement.children[this._getItemIndex(t3)];
        n2 && g(n2).addClass(X);
      }
    }, t2._slide = function(t3, e2) {
      var n2, i2, o2, r3 = this, s2 = this._element.querySelector(it), a2 = this._getItemIndex(s2), l2 = e2 || s2 && this._getItemByDirection(t3, s2), c2 = this._getItemIndex(l2), h2 = Boolean(this._interval);
      if (o2 = t3 === K ? (n2 = J, i2 = Z, B) : (n2 = G, i2 = tt, V), l2 && g(l2).hasClass(X))
        this._isSliding = false;
      else if (!this._triggerSlideEvent(l2, o2).isDefaultPrevented() && s2 && l2) {
        this._isSliding = true, h2 && this.pause(), this._setActiveIndicatorElement(l2);
        var u2 = g.Event(Y.SLID, { relatedTarget: l2, direction: o2, from: a2, to: c2 });
        if (g(this._element).hasClass($)) {
          g(l2).addClass(i2), _.reflow(l2), g(s2).addClass(n2), g(l2).addClass(n2);
          var f2 = parseInt(l2.getAttribute("data-interval"), 10);
          f2 ? (this._config.defaultInterval = this._config.defaultInterval || this._config.interval, this._config.interval = f2) : this._config.interval = this._config.defaultInterval || this._config.interval;
          var d2 = _.getTransitionDurationFromElement(s2);
          g(s2).one(_.TRANSITION_END, function() {
            g(l2).removeClass(n2 + " " + i2).addClass(X), g(s2).removeClass(X + " " + i2 + " " + n2), r3._isSliding = false, setTimeout(function() {
              return g(r3._element).trigger(u2);
            }, 0);
          }).emulateTransitionEnd(d2);
        } else
          g(s2).removeClass(X), g(l2).addClass(X), this._isSliding = false, g(this._element).trigger(u2);
        h2 && this.cycle();
      }
    }, r2._jQueryInterface = function(i2) {
      return this.each(function() {
        var t3 = g(this).data(x), e2 = l({}, q, {}, g(this).data());
        "object" == typeof i2 && (e2 = l({}, e2, {}, i2));
        var n2 = "string" == typeof i2 ? i2 : e2.slide;
        if (t3 || (t3 = new r2(this, e2), g(this).data(x, t3)), "number" == typeof i2)
          t3.to(i2);
        else if ("string" == typeof n2) {
          if ("undefined" == typeof t3[n2])
            throw new TypeError('No method named "' + n2 + '"');
          t3[n2]();
        } else
          e2.interval && e2.ride && (t3.pause(), t3.cycle());
      });
    }, r2._dataApiClickHandler = function(t3) {
      var e2 = _.getSelectorFromElement(this);
      if (e2) {
        var n2 = g(e2)[0];
        if (n2 && g(n2).hasClass(z)) {
          var i2 = l({}, g(n2).data(), {}, g(this).data()), o2 = this.getAttribute("data-slide-to");
          o2 && (i2.interval = false), r2._jQueryInterface.call(g(n2), i2), o2 && g(n2).data(x).to(o2), t3.preventDefault();
        }
      }
    }, s(r2, null, [{ key: "VERSION", get: function() {
      return "4.4.1";
    } }, { key: "Default", get: function() {
      return q;
    } }]), r2;
  }();
  g(document).on(Y.CLICK_DATA_API, lt, ut._dataApiClickHandler), g(window).on(Y.LOAD_DATA_API, function() {
    for (var t2 = [].slice.call(document.querySelectorAll(ct)), e2 = 0, n2 = t2.length; e2 < n2; e2++) {
      var i2 = g(t2[e2]);
      ut._jQueryInterface.call(i2, i2.data());
    }
  }), g.fn[R] = ut._jQueryInterface, g.fn[R].Constructor = ut, g.fn[R].noConflict = function() {
    return g.fn[R] = W, ut._jQueryInterface;
  };
  var ft = "collapse", dt = "bs.collapse", gt = "." + dt, _t = g.fn[ft], mt = { toggle: true, parent: "" }, pt = { toggle: "boolean", parent: "(string|element)" }, vt = { SHOW: "show" + gt, SHOWN: "shown" + gt, HIDE: "hide" + gt, HIDDEN: "hidden" + gt, CLICK_DATA_API: "click" + gt + ".data-api" }, yt = "show", Et = "collapse", Ct = "collapsing", Tt = "collapsed", bt = "width", St = "height", Dt = ".show, .collapsing", It = '[data-toggle="collapse"]', wt = function() {
    function a2(e2, t3) {
      this._isTransitioning = false, this._element = e2, this._config = this._getConfig(t3), this._triggerArray = [].slice.call(document.querySelectorAll('[data-toggle="collapse"][href="#' + e2.id + '"],[data-toggle="collapse"][data-target="#' + e2.id + '"]'));
      for (var n2 = [].slice.call(document.querySelectorAll(It)), i2 = 0, o2 = n2.length; i2 < o2; i2++) {
        var r2 = n2[i2], s2 = _.getSelectorFromElement(r2), a3 = [].slice.call(document.querySelectorAll(s2)).filter(function(t4) {
          return t4 === e2;
        });
        null !== s2 && 0 < a3.length && (this._selector = s2, this._triggerArray.push(r2));
      }
      this._parent = this._config.parent ? this._getParent() : null, this._config.parent || this._addAriaAndCollapsedClass(this._element, this._triggerArray), this._config.toggle && this.toggle();
    }
    var t2 = a2.prototype;
    return t2.toggle = function() {
      g(this._element).hasClass(yt) ? this.hide() : this.show();
    }, t2.show = function() {
      var t3, e2, n2 = this;
      if (!this._isTransitioning && !g(this._element).hasClass(yt) && (this._parent && 0 === (t3 = [].slice.call(this._parent.querySelectorAll(Dt)).filter(function(t4) {
        return "string" == typeof n2._config.parent ? t4.getAttribute("data-parent") === n2._config.parent : t4.classList.contains(Et);
      })).length && (t3 = null), !(t3 && (e2 = g(t3).not(this._selector).data(dt)) && e2._isTransitioning))) {
        var i2 = g.Event(vt.SHOW);
        if (g(this._element).trigger(i2), !i2.isDefaultPrevented()) {
          t3 && (a2._jQueryInterface.call(g(t3).not(this._selector), "hide"), e2 || g(t3).data(dt, null));
          var o2 = this._getDimension();
          g(this._element).removeClass(Et).addClass(Ct), this._element.style[o2] = 0, this._triggerArray.length && g(this._triggerArray).removeClass(Tt).attr("aria-expanded", true), this.setTransitioning(true);
          var r2 = "scroll" + (o2[0].toUpperCase() + o2.slice(1)), s2 = _.getTransitionDurationFromElement(this._element);
          g(this._element).one(_.TRANSITION_END, function() {
            g(n2._element).removeClass(Ct).addClass(Et).addClass(yt), n2._element.style[o2] = "", n2.setTransitioning(false), g(n2._element).trigger(vt.SHOWN);
          }).emulateTransitionEnd(s2), this._element.style[o2] = this._element[r2] + "px";
        }
      }
    }, t2.hide = function() {
      var t3 = this;
      if (!this._isTransitioning && g(this._element).hasClass(yt)) {
        var e2 = g.Event(vt.HIDE);
        if (g(this._element).trigger(e2), !e2.isDefaultPrevented()) {
          var n2 = this._getDimension();
          this._element.style[n2] = this._element.getBoundingClientRect()[n2] + "px", _.reflow(this._element), g(this._element).addClass(Ct).removeClass(Et).removeClass(yt);
          var i2 = this._triggerArray.length;
          if (0 < i2)
            for (var o2 = 0; o2 < i2; o2++) {
              var r2 = this._triggerArray[o2], s2 = _.getSelectorFromElement(r2);
              if (null !== s2)
                g([].slice.call(document.querySelectorAll(s2))).hasClass(yt) || g(r2).addClass(Tt).attr("aria-expanded", false);
            }
          this.setTransitioning(true);
          this._element.style[n2] = "";
          var a3 = _.getTransitionDurationFromElement(this._element);
          g(this._element).one(_.TRANSITION_END, function() {
            t3.setTransitioning(false), g(t3._element).removeClass(Ct).addClass(Et).trigger(vt.HIDDEN);
          }).emulateTransitionEnd(a3);
        }
      }
    }, t2.setTransitioning = function(t3) {
      this._isTransitioning = t3;
    }, t2.dispose = function() {
      g.removeData(this._element, dt), this._config = null, this._parent = null, this._element = null, this._triggerArray = null, this._isTransitioning = null;
    }, t2._getConfig = function(t3) {
      return (t3 = l({}, mt, {}, t3)).toggle = Boolean(t3.toggle), _.typeCheckConfig(ft, t3, pt), t3;
    }, t2._getDimension = function() {
      return g(this._element).hasClass(bt) ? bt : St;
    }, t2._getParent = function() {
      var t3, n2 = this;
      _.isElement(this._config.parent) ? (t3 = this._config.parent, "undefined" != typeof this._config.parent.jquery && (t3 = this._config.parent[0])) : t3 = document.querySelector(this._config.parent);
      var e2 = '[data-toggle="collapse"][data-parent="' + this._config.parent + '"]', i2 = [].slice.call(t3.querySelectorAll(e2));
      return g(i2).each(function(t4, e3) {
        n2._addAriaAndCollapsedClass(a2._getTargetFromElement(e3), [e3]);
      }), t3;
    }, t2._addAriaAndCollapsedClass = function(t3, e2) {
      var n2 = g(t3).hasClass(yt);
      e2.length && g(e2).toggleClass(Tt, !n2).attr("aria-expanded", n2);
    }, a2._getTargetFromElement = function(t3) {
      var e2 = _.getSelectorFromElement(t3);
      return e2 ? document.querySelector(e2) : null;
    }, a2._jQueryInterface = function(i2) {
      return this.each(function() {
        var t3 = g(this), e2 = t3.data(dt), n2 = l({}, mt, {}, t3.data(), {}, "object" == typeof i2 && i2 ? i2 : {});
        if (!e2 && n2.toggle && /show|hide/.test(i2) && (n2.toggle = false), e2 || (e2 = new a2(this, n2), t3.data(dt, e2)), "string" == typeof i2) {
          if ("undefined" == typeof e2[i2])
            throw new TypeError('No method named "' + i2 + '"');
          e2[i2]();
        }
      });
    }, s(a2, null, [{ key: "VERSION", get: function() {
      return "4.4.1";
    } }, { key: "Default", get: function() {
      return mt;
    } }]), a2;
  }();
  g(document).on(vt.CLICK_DATA_API, It, function(t2) {
    "A" === t2.currentTarget.tagName && t2.preventDefault();
    var n2 = g(this), e2 = _.getSelectorFromElement(this), i2 = [].slice.call(document.querySelectorAll(e2));
    g(i2).each(function() {
      var t3 = g(this), e3 = t3.data(dt) ? "toggle" : n2.data();
      wt._jQueryInterface.call(t3, e3);
    });
  }), g.fn[ft] = wt._jQueryInterface, g.fn[ft].Constructor = wt, g.fn[ft].noConflict = function() {
    return g.fn[ft] = _t, wt._jQueryInterface;
  };
  var At = "dropdown", Nt = "bs.dropdown", Ot = "." + Nt, kt = ".data-api", Pt = g.fn[At], Lt = new RegExp("38|40|27"), jt = { HIDE: "hide" + Ot, HIDDEN: "hidden" + Ot, SHOW: "show" + Ot, SHOWN: "shown" + Ot, CLICK: "click" + Ot, CLICK_DATA_API: "click" + Ot + kt, KEYDOWN_DATA_API: "keydown" + Ot + kt, KEYUP_DATA_API: "keyup" + Ot + kt }, Ht = "disabled", Rt = "show", xt = "dropup", Ft = "dropright", Ut = "dropleft", Wt = "dropdown-menu-right", qt = "position-static", Mt = '[data-toggle="dropdown"]', Kt = ".dropdown form", Qt = ".dropdown-menu", Bt = ".navbar-nav", Vt = ".dropdown-menu .dropdown-item:not(.disabled):not(:disabled)", Yt = "top-start", zt = "top-end", Xt = "bottom-start", $t = "bottom-end", Gt = "right-start", Jt = "left-start", Zt = { offset: 0, flip: true, boundary: "scrollParent", reference: "toggle", display: "dynamic", popperConfig: null }, te = { offset: "(number|string|function)", flip: "boolean", boundary: "(string|element)", reference: "(string|element)", display: "string", popperConfig: "(null|object)" }, ee = function() {
    function c2(t3, e2) {
      this._element = t3, this._popper = null, this._config = this._getConfig(e2), this._menu = this._getMenuElement(), this._inNavbar = this._detectNavbar(), this._addEventListeners();
    }
    var t2 = c2.prototype;
    return t2.toggle = function() {
      if (!this._element.disabled && !g(this._element).hasClass(Ht)) {
        var t3 = g(this._menu).hasClass(Rt);
        c2._clearMenus(), t3 || this.show(true);
      }
    }, t2.show = function(t3) {
      if (void 0 === t3 && (t3 = false), !(this._element.disabled || g(this._element).hasClass(Ht) || g(this._menu).hasClass(Rt))) {
        var e2 = { relatedTarget: this._element }, n2 = g.Event(jt.SHOW, e2), i2 = c2._getParentFromElement(this._element);
        if (g(i2).trigger(n2), !n2.isDefaultPrevented()) {
          if (!this._inNavbar && t3) {
            if ("undefined" == typeof u)
              throw new TypeError("Bootstrap's dropdowns require Popper.js (https://popper.js.org/)");
            var o2 = this._element;
            "parent" === this._config.reference ? o2 = i2 : _.isElement(this._config.reference) && (o2 = this._config.reference, "undefined" != typeof this._config.reference.jquery && (o2 = this._config.reference[0])), "scrollParent" !== this._config.boundary && g(i2).addClass(qt), this._popper = new u(o2, this._menu, this._getPopperConfig());
          }
          "ontouchstart" in document.documentElement && 0 === g(i2).closest(Bt).length && g(document.body).children().on("mouseover", null, g.noop), this._element.focus(), this._element.setAttribute("aria-expanded", true), g(this._menu).toggleClass(Rt), g(i2).toggleClass(Rt).trigger(g.Event(jt.SHOWN, e2));
        }
      }
    }, t2.hide = function() {
      if (!this._element.disabled && !g(this._element).hasClass(Ht) && g(this._menu).hasClass(Rt)) {
        var t3 = { relatedTarget: this._element }, e2 = g.Event(jt.HIDE, t3), n2 = c2._getParentFromElement(this._element);
        g(n2).trigger(e2), e2.isDefaultPrevented() || (this._popper && this._popper.destroy(), g(this._menu).toggleClass(Rt), g(n2).toggleClass(Rt).trigger(g.Event(jt.HIDDEN, t3)));
      }
    }, t2.dispose = function() {
      g.removeData(this._element, Nt), g(this._element).off(Ot), this._element = null, (this._menu = null) !== this._popper && (this._popper.destroy(), this._popper = null);
    }, t2.update = function() {
      this._inNavbar = this._detectNavbar(), null !== this._popper && this._popper.scheduleUpdate();
    }, t2._addEventListeners = function() {
      var e2 = this;
      g(this._element).on(jt.CLICK, function(t3) {
        t3.preventDefault(), t3.stopPropagation(), e2.toggle();
      });
    }, t2._getConfig = function(t3) {
      return t3 = l({}, this.constructor.Default, {}, g(this._element).data(), {}, t3), _.typeCheckConfig(At, t3, this.constructor.DefaultType), t3;
    }, t2._getMenuElement = function() {
      if (!this._menu) {
        var t3 = c2._getParentFromElement(this._element);
        t3 && (this._menu = t3.querySelector(Qt));
      }
      return this._menu;
    }, t2._getPlacement = function() {
      var t3 = g(this._element.parentNode), e2 = Xt;
      return t3.hasClass(xt) ? (e2 = Yt, g(this._menu).hasClass(Wt) && (e2 = zt)) : t3.hasClass(Ft) ? e2 = Gt : t3.hasClass(Ut) ? e2 = Jt : g(this._menu).hasClass(Wt) && (e2 = $t), e2;
    }, t2._detectNavbar = function() {
      return 0 < g(this._element).closest(".navbar").length;
    }, t2._getOffset = function() {
      var e2 = this, t3 = {};
      return "function" == typeof this._config.offset ? t3.fn = function(t4) {
        return t4.offsets = l({}, t4.offsets, {}, e2._config.offset(t4.offsets, e2._element) || {}), t4;
      } : t3.offset = this._config.offset, t3;
    }, t2._getPopperConfig = function() {
      var t3 = { placement: this._getPlacement(), modifiers: { offset: this._getOffset(), flip: { enabled: this._config.flip }, preventOverflow: { boundariesElement: this._config.boundary } } };
      return "static" === this._config.display && (t3.modifiers.applyStyle = { enabled: false }), l({}, t3, {}, this._config.popperConfig);
    }, c2._jQueryInterface = function(e2) {
      return this.each(function() {
        var t3 = g(this).data(Nt);
        if (t3 || (t3 = new c2(this, "object" == typeof e2 ? e2 : null), g(this).data(Nt, t3)), "string" == typeof e2) {
          if ("undefined" == typeof t3[e2])
            throw new TypeError('No method named "' + e2 + '"');
          t3[e2]();
        }
      });
    }, c2._clearMenus = function(t3) {
      if (!t3 || 3 !== t3.which && ("keyup" !== t3.type || 9 === t3.which))
        for (var e2 = [].slice.call(document.querySelectorAll(Mt)), n2 = 0, i2 = e2.length; n2 < i2; n2++) {
          var o2 = c2._getParentFromElement(e2[n2]), r2 = g(e2[n2]).data(Nt), s2 = { relatedTarget: e2[n2] };
          if (t3 && "click" === t3.type && (s2.clickEvent = t3), r2) {
            var a2 = r2._menu;
            if (g(o2).hasClass(Rt) && !(t3 && ("click" === t3.type && /input|textarea/i.test(t3.target.tagName) || "keyup" === t3.type && 9 === t3.which) && g.contains(o2, t3.target))) {
              var l2 = g.Event(jt.HIDE, s2);
              g(o2).trigger(l2), l2.isDefaultPrevented() || ("ontouchstart" in document.documentElement && g(document.body).children().off("mouseover", null, g.noop), e2[n2].setAttribute("aria-expanded", "false"), r2._popper && r2._popper.destroy(), g(a2).removeClass(Rt), g(o2).removeClass(Rt).trigger(g.Event(jt.HIDDEN, s2)));
            }
          }
        }
    }, c2._getParentFromElement = function(t3) {
      var e2, n2 = _.getSelectorFromElement(t3);
      return n2 && (e2 = document.querySelector(n2)), e2 || t3.parentNode;
    }, c2._dataApiKeydownHandler = function(t3) {
      if ((/input|textarea/i.test(t3.target.tagName) ? !(32 === t3.which || 27 !== t3.which && (40 !== t3.which && 38 !== t3.which || g(t3.target).closest(Qt).length)) : Lt.test(t3.which)) && (t3.preventDefault(), t3.stopPropagation(), !this.disabled && !g(this).hasClass(Ht))) {
        var e2 = c2._getParentFromElement(this), n2 = g(e2).hasClass(Rt);
        if (n2 || 27 !== t3.which)
          if (n2 && (!n2 || 27 !== t3.which && 32 !== t3.which)) {
            var i2 = [].slice.call(e2.querySelectorAll(Vt)).filter(function(t4) {
              return g(t4).is(":visible");
            });
            if (0 !== i2.length) {
              var o2 = i2.indexOf(t3.target);
              38 === t3.which && 0 < o2 && o2--, 40 === t3.which && o2 < i2.length - 1 && o2++, o2 < 0 && (o2 = 0), i2[o2].focus();
            }
          } else {
            if (27 === t3.which) {
              var r2 = e2.querySelector(Mt);
              g(r2).trigger("focus");
            }
            g(this).trigger("click");
          }
      }
    }, s(c2, null, [{ key: "VERSION", get: function() {
      return "4.4.1";
    } }, { key: "Default", get: function() {
      return Zt;
    } }, { key: "DefaultType", get: function() {
      return te;
    } }]), c2;
  }();
  g(document).on(jt.KEYDOWN_DATA_API, Mt, ee._dataApiKeydownHandler).on(jt.KEYDOWN_DATA_API, Qt, ee._dataApiKeydownHandler).on(jt.CLICK_DATA_API + " " + jt.KEYUP_DATA_API, ee._clearMenus).on(jt.CLICK_DATA_API, Mt, function(t2) {
    t2.preventDefault(), t2.stopPropagation(), ee._jQueryInterface.call(g(this), "toggle");
  }).on(jt.CLICK_DATA_API, Kt, function(t2) {
    t2.stopPropagation();
  }), g.fn[At] = ee._jQueryInterface, g.fn[At].Constructor = ee, g.fn[At].noConflict = function() {
    return g.fn[At] = Pt, ee._jQueryInterface;
  };
  var ne = "modal", ie = "bs.modal", oe = "." + ie, re = g.fn[ne], se = { backdrop: true, keyboard: true, focus: true, show: true }, ae = { backdrop: "(boolean|string)", keyboard: "boolean", focus: "boolean", show: "boolean" }, le = { HIDE: "hide" + oe, HIDE_PREVENTED: "hidePrevented" + oe, HIDDEN: "hidden" + oe, SHOW: "show" + oe, SHOWN: "shown" + oe, FOCUSIN: "focusin" + oe, RESIZE: "resize" + oe, CLICK_DISMISS: "click.dismiss" + oe, KEYDOWN_DISMISS: "keydown.dismiss" + oe, MOUSEUP_DISMISS: "mouseup.dismiss" + oe, MOUSEDOWN_DISMISS: "mousedown.dismiss" + oe, CLICK_DATA_API: "click" + oe + ".data-api" }, ce = "modal-dialog-scrollable", he = "modal-scrollbar-measure", ue = "modal-backdrop", fe = "modal-open", de = "fade", ge = "show", _e = "modal-static", me = ".modal-dialog", pe = ".modal-body", ve = '[data-toggle="modal"]', ye = '[data-dismiss="modal"]', Ee = ".fixed-top, .fixed-bottom, .is-fixed, .sticky-top", Ce = ".sticky-top", Te = function() {
    function o2(t3, e2) {
      this._config = this._getConfig(e2), this._element = t3, this._dialog = t3.querySelector(me), this._backdrop = null, this._isShown = false, this._isBodyOverflowing = false, this._ignoreBackdropClick = false, this._isTransitioning = false, this._scrollbarWidth = 0;
    }
    var t2 = o2.prototype;
    return t2.toggle = function(t3) {
      return this._isShown ? this.hide() : this.show(t3);
    }, t2.show = function(t3) {
      var e2 = this;
      if (!this._isShown && !this._isTransitioning) {
        g(this._element).hasClass(de) && (this._isTransitioning = true);
        var n2 = g.Event(le.SHOW, { relatedTarget: t3 });
        g(this._element).trigger(n2), this._isShown || n2.isDefaultPrevented() || (this._isShown = true, this._checkScrollbar(), this._setScrollbar(), this._adjustDialog(), this._setEscapeEvent(), this._setResizeEvent(), g(this._element).on(le.CLICK_DISMISS, ye, function(t4) {
          return e2.hide(t4);
        }), g(this._dialog).on(le.MOUSEDOWN_DISMISS, function() {
          g(e2._element).one(le.MOUSEUP_DISMISS, function(t4) {
            g(t4.target).is(e2._element) && (e2._ignoreBackdropClick = true);
          });
        }), this._showBackdrop(function() {
          return e2._showElement(t3);
        }));
      }
    }, t2.hide = function(t3) {
      var e2 = this;
      if (t3 && t3.preventDefault(), this._isShown && !this._isTransitioning) {
        var n2 = g.Event(le.HIDE);
        if (g(this._element).trigger(n2), this._isShown && !n2.isDefaultPrevented()) {
          this._isShown = false;
          var i2 = g(this._element).hasClass(de);
          if (i2 && (this._isTransitioning = true), this._setEscapeEvent(), this._setResizeEvent(), g(document).off(le.FOCUSIN), g(this._element).removeClass(ge), g(this._element).off(le.CLICK_DISMISS), g(this._dialog).off(le.MOUSEDOWN_DISMISS), i2) {
            var o3 = _.getTransitionDurationFromElement(this._element);
            g(this._element).one(_.TRANSITION_END, function(t4) {
              return e2._hideModal(t4);
            }).emulateTransitionEnd(o3);
          } else
            this._hideModal();
        }
      }
    }, t2.dispose = function() {
      [window, this._element, this._dialog].forEach(function(t3) {
        return g(t3).off(oe);
      }), g(document).off(le.FOCUSIN), g.removeData(this._element, ie), this._config = null, this._element = null, this._dialog = null, this._backdrop = null, this._isShown = null, this._isBodyOverflowing = null, this._ignoreBackdropClick = null, this._isTransitioning = null, this._scrollbarWidth = null;
    }, t2.handleUpdate = function() {
      this._adjustDialog();
    }, t2._getConfig = function(t3) {
      return t3 = l({}, se, {}, t3), _.typeCheckConfig(ne, t3, ae), t3;
    }, t2._triggerBackdropTransition = function() {
      var t3 = this;
      if ("static" === this._config.backdrop) {
        var e2 = g.Event(le.HIDE_PREVENTED);
        if (g(this._element).trigger(e2), e2.defaultPrevented)
          return;
        this._element.classList.add(_e);
        var n2 = _.getTransitionDurationFromElement(this._element);
        g(this._element).one(_.TRANSITION_END, function() {
          t3._element.classList.remove(_e);
        }).emulateTransitionEnd(n2), this._element.focus();
      } else
        this.hide();
    }, t2._showElement = function(t3) {
      var e2 = this, n2 = g(this._element).hasClass(de), i2 = this._dialog ? this._dialog.querySelector(pe) : null;
      this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE || document.body.appendChild(this._element), this._element.style.display = "block", this._element.removeAttribute("aria-hidden"), this._element.setAttribute("aria-modal", true), g(this._dialog).hasClass(ce) && i2 ? i2.scrollTop = 0 : this._element.scrollTop = 0, n2 && _.reflow(this._element), g(this._element).addClass(ge), this._config.focus && this._enforceFocus();
      function o3() {
        e2._config.focus && e2._element.focus(), e2._isTransitioning = false, g(e2._element).trigger(r2);
      }
      var r2 = g.Event(le.SHOWN, { relatedTarget: t3 });
      if (n2) {
        var s2 = _.getTransitionDurationFromElement(this._dialog);
        g(this._dialog).one(_.TRANSITION_END, o3).emulateTransitionEnd(s2);
      } else
        o3();
    }, t2._enforceFocus = function() {
      var e2 = this;
      g(document).off(le.FOCUSIN).on(le.FOCUSIN, function(t3) {
        document !== t3.target && e2._element !== t3.target && 0 === g(e2._element).has(t3.target).length && e2._element.focus();
      });
    }, t2._setEscapeEvent = function() {
      var e2 = this;
      this._isShown && this._config.keyboard ? g(this._element).on(le.KEYDOWN_DISMISS, function(t3) {
        27 === t3.which && e2._triggerBackdropTransition();
      }) : this._isShown || g(this._element).off(le.KEYDOWN_DISMISS);
    }, t2._setResizeEvent = function() {
      var e2 = this;
      this._isShown ? g(window).on(le.RESIZE, function(t3) {
        return e2.handleUpdate(t3);
      }) : g(window).off(le.RESIZE);
    }, t2._hideModal = function() {
      var t3 = this;
      this._element.style.display = "none", this._element.setAttribute("aria-hidden", true), this._element.removeAttribute("aria-modal"), this._isTransitioning = false, this._showBackdrop(function() {
        g(document.body).removeClass(fe), t3._resetAdjustments(), t3._resetScrollbar(), g(t3._element).trigger(le.HIDDEN);
      });
    }, t2._removeBackdrop = function() {
      this._backdrop && (g(this._backdrop).remove(), this._backdrop = null);
    }, t2._showBackdrop = function(t3) {
      var e2 = this, n2 = g(this._element).hasClass(de) ? de : "";
      if (this._isShown && this._config.backdrop) {
        if (this._backdrop = document.createElement("div"), this._backdrop.className = ue, n2 && this._backdrop.classList.add(n2), g(this._backdrop).appendTo(document.body), g(this._element).on(le.CLICK_DISMISS, function(t4) {
          e2._ignoreBackdropClick ? e2._ignoreBackdropClick = false : t4.target === t4.currentTarget && e2._triggerBackdropTransition();
        }), n2 && _.reflow(this._backdrop), g(this._backdrop).addClass(ge), !t3)
          return;
        if (!n2)
          return void t3();
        var i2 = _.getTransitionDurationFromElement(this._backdrop);
        g(this._backdrop).one(_.TRANSITION_END, t3).emulateTransitionEnd(i2);
      } else if (!this._isShown && this._backdrop) {
        g(this._backdrop).removeClass(ge);
        var o3 = function() {
          e2._removeBackdrop(), t3 && t3();
        };
        if (g(this._element).hasClass(de)) {
          var r2 = _.getTransitionDurationFromElement(this._backdrop);
          g(this._backdrop).one(_.TRANSITION_END, o3).emulateTransitionEnd(r2);
        } else
          o3();
      } else
        t3 && t3();
    }, t2._adjustDialog = function() {
      var t3 = this._element.scrollHeight > document.documentElement.clientHeight;
      !this._isBodyOverflowing && t3 && (this._element.style.paddingLeft = this._scrollbarWidth + "px"), this._isBodyOverflowing && !t3 && (this._element.style.paddingRight = this._scrollbarWidth + "px");
    }, t2._resetAdjustments = function() {
      this._element.style.paddingLeft = "", this._element.style.paddingRight = "";
    }, t2._checkScrollbar = function() {
      var t3 = document.body.getBoundingClientRect();
      this._isBodyOverflowing = t3.left + t3.right < window.innerWidth, this._scrollbarWidth = this._getScrollbarWidth();
    }, t2._setScrollbar = function() {
      var o3 = this;
      if (this._isBodyOverflowing) {
        var t3 = [].slice.call(document.querySelectorAll(Ee)), e2 = [].slice.call(document.querySelectorAll(Ce));
        g(t3).each(function(t4, e3) {
          var n3 = e3.style.paddingRight, i3 = g(e3).css("padding-right");
          g(e3).data("padding-right", n3).css("padding-right", parseFloat(i3) + o3._scrollbarWidth + "px");
        }), g(e2).each(function(t4, e3) {
          var n3 = e3.style.marginRight, i3 = g(e3).css("margin-right");
          g(e3).data("margin-right", n3).css("margin-right", parseFloat(i3) - o3._scrollbarWidth + "px");
        });
        var n2 = document.body.style.paddingRight, i2 = g(document.body).css("padding-right");
        g(document.body).data("padding-right", n2).css("padding-right", parseFloat(i2) + this._scrollbarWidth + "px");
      }
      g(document.body).addClass(fe);
    }, t2._resetScrollbar = function() {
      var t3 = [].slice.call(document.querySelectorAll(Ee));
      g(t3).each(function(t4, e3) {
        var n3 = g(e3).data("padding-right");
        g(e3).removeData("padding-right"), e3.style.paddingRight = n3 || "";
      });
      var e2 = [].slice.call(document.querySelectorAll("" + Ce));
      g(e2).each(function(t4, e3) {
        var n3 = g(e3).data("margin-right");
        "undefined" != typeof n3 && g(e3).css("margin-right", n3).removeData("margin-right");
      });
      var n2 = g(document.body).data("padding-right");
      g(document.body).removeData("padding-right"), document.body.style.paddingRight = n2 || "";
    }, t2._getScrollbarWidth = function() {
      var t3 = document.createElement("div");
      t3.className = he, document.body.appendChild(t3);
      var e2 = t3.getBoundingClientRect().width - t3.clientWidth;
      return document.body.removeChild(t3), e2;
    }, o2._jQueryInterface = function(n2, i2) {
      return this.each(function() {
        var t3 = g(this).data(ie), e2 = l({}, se, {}, g(this).data(), {}, "object" == typeof n2 && n2 ? n2 : {});
        if (t3 || (t3 = new o2(this, e2), g(this).data(ie, t3)), "string" == typeof n2) {
          if ("undefined" == typeof t3[n2])
            throw new TypeError('No method named "' + n2 + '"');
          t3[n2](i2);
        } else
          e2.show && t3.show(i2);
      });
    }, s(o2, null, [{ key: "VERSION", get: function() {
      return "4.4.1";
    } }, { key: "Default", get: function() {
      return se;
    } }]), o2;
  }();
  g(document).on(le.CLICK_DATA_API, ve, function(t2) {
    var e2, n2 = this, i2 = _.getSelectorFromElement(this);
    i2 && (e2 = document.querySelector(i2));
    var o2 = g(e2).data(ie) ? "toggle" : l({}, g(e2).data(), {}, g(this).data());
    "A" !== this.tagName && "AREA" !== this.tagName || t2.preventDefault();
    var r2 = g(e2).one(le.SHOW, function(t3) {
      t3.isDefaultPrevented() || r2.one(le.HIDDEN, function() {
        g(n2).is(":visible") && n2.focus();
      });
    });
    Te._jQueryInterface.call(g(e2), o2, this);
  }), g.fn[ne] = Te._jQueryInterface, g.fn[ne].Constructor = Te, g.fn[ne].noConflict = function() {
    return g.fn[ne] = re, Te._jQueryInterface;
  };
  var be = ["background", "cite", "href", "itemtype", "longdesc", "poster", "src", "xlink:href"], Se = { "*": ["class", "dir", "id", "lang", "role", /^aria-[\w-]*$/i], a: ["target", "href", "title", "rel"], area: [], b: [], br: [], col: [], code: [], div: [], em: [], hr: [], h1: [], h2: [], h3: [], h4: [], h5: [], h6: [], i: [], img: ["src", "alt", "title", "width", "height"], li: [], ol: [], p: [], pre: [], s: [], small: [], span: [], sub: [], sup: [], strong: [], u: [], ul: [] }, De = /^(?:(?:https?|mailto|ftp|tel|file):|[^&:/?#]*(?:[/?#]|$))/gi, Ie = /^data:(?:image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|video\/(?:mpeg|mp4|ogg|webm)|audio\/(?:mp3|oga|ogg|opus));base64,[a-z0-9+/]+=*$/i;
  function we(t2, r2, e2) {
    if (0 === t2.length)
      return t2;
    if (e2 && "function" == typeof e2)
      return e2(t2);
    for (var n2 = new window.DOMParser().parseFromString(t2, "text/html"), s2 = Object.keys(r2), a2 = [].slice.call(n2.body.querySelectorAll("*")), i2 = function(t3) {
      var e3 = a2[t3], n3 = e3.nodeName.toLowerCase();
      if (-1 === s2.indexOf(e3.nodeName.toLowerCase()))
        return e3.parentNode.removeChild(e3), "continue";
      var i3 = [].slice.call(e3.attributes), o3 = [].concat(r2["*"] || [], r2[n3] || []);
      i3.forEach(function(t4) {
        !function(t5, e4) {
          var n4 = t5.nodeName.toLowerCase();
          if (-1 !== e4.indexOf(n4))
            return -1 === be.indexOf(n4) || Boolean(t5.nodeValue.match(De) || t5.nodeValue.match(Ie));
          for (var i4 = e4.filter(function(t6) {
            return t6 instanceof RegExp;
          }), o4 = 0, r3 = i4.length; o4 < r3; o4++)
            if (n4.match(i4[o4]))
              return true;
          return false;
        }(t4, o3) && e3.removeAttribute(t4.nodeName);
      });
    }, o2 = 0, l2 = a2.length; o2 < l2; o2++)
      i2(o2);
    return n2.body.innerHTML;
  }
  var Ae = "tooltip", Ne = "bs.tooltip", Oe = "." + Ne, ke = g.fn[Ae], Pe = "bs-tooltip", Le = new RegExp("(^|\\s)" + Pe + "\\S+", "g"), je = ["sanitize", "whiteList", "sanitizeFn"], He = { animation: "boolean", template: "string", title: "(string|element|function)", trigger: "string", delay: "(number|object)", html: "boolean", selector: "(string|boolean)", placement: "(string|function)", offset: "(number|string|function)", container: "(string|element|boolean)", fallbackPlacement: "(string|array)", boundary: "(string|element)", sanitize: "boolean", sanitizeFn: "(null|function)", whiteList: "object", popperConfig: "(null|object)" }, Re = { AUTO: "auto", TOP: "top", RIGHT: "right", BOTTOM: "bottom", LEFT: "left" }, xe = { animation: true, template: '<div class="tooltip" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>', trigger: "hover focus", title: "", delay: 0, html: false, selector: false, placement: "top", offset: 0, container: false, fallbackPlacement: "flip", boundary: "scrollParent", sanitize: true, sanitizeFn: null, whiteList: Se, popperConfig: null }, Fe = "show", Ue = "out", We = { HIDE: "hide" + Oe, HIDDEN: "hidden" + Oe, SHOW: "show" + Oe, SHOWN: "shown" + Oe, INSERTED: "inserted" + Oe, CLICK: "click" + Oe, FOCUSIN: "focusin" + Oe, FOCUSOUT: "focusout" + Oe, MOUSEENTER: "mouseenter" + Oe, MOUSELEAVE: "mouseleave" + Oe }, qe = "fade", Me = "show", Ke = ".tooltip-inner", Qe = ".arrow", Be = "hover", Ve = "focus", Ye = "click", ze = "manual", Xe = function() {
    function i2(t3, e2) {
      if ("undefined" == typeof u)
        throw new TypeError("Bootstrap's tooltips require Popper.js (https://popper.js.org/)");
      this._isEnabled = true, this._timeout = 0, this._hoverState = "", this._activeTrigger = {}, this._popper = null, this.element = t3, this.config = this._getConfig(e2), this.tip = null, this._setListeners();
    }
    var t2 = i2.prototype;
    return t2.enable = function() {
      this._isEnabled = true;
    }, t2.disable = function() {
      this._isEnabled = false;
    }, t2.toggleEnabled = function() {
      this._isEnabled = !this._isEnabled;
    }, t2.toggle = function(t3) {
      if (this._isEnabled)
        if (t3) {
          var e2 = this.constructor.DATA_KEY, n2 = g(t3.currentTarget).data(e2);
          n2 || (n2 = new this.constructor(t3.currentTarget, this._getDelegateConfig()), g(t3.currentTarget).data(e2, n2)), n2._activeTrigger.click = !n2._activeTrigger.click, n2._isWithActiveTrigger() ? n2._enter(null, n2) : n2._leave(null, n2);
        } else {
          if (g(this.getTipElement()).hasClass(Me))
            return void this._leave(null, this);
          this._enter(null, this);
        }
    }, t2.dispose = function() {
      clearTimeout(this._timeout), g.removeData(this.element, this.constructor.DATA_KEY), g(this.element).off(this.constructor.EVENT_KEY), g(this.element).closest(".modal").off("hide.bs.modal", this._hideModalHandler), this.tip && g(this.tip).remove(), this._isEnabled = null, this._timeout = null, this._hoverState = null, this._activeTrigger = null, this._popper && this._popper.destroy(), this._popper = null, this.element = null, this.config = null, this.tip = null;
    }, t2.show = function() {
      var e2 = this;
      if ("none" === g(this.element).css("display"))
        throw new Error("Please use show on visible elements");
      var t3 = g.Event(this.constructor.Event.SHOW);
      if (this.isWithContent() && this._isEnabled) {
        g(this.element).trigger(t3);
        var n2 = _.findShadowRoot(this.element), i3 = g.contains(null !== n2 ? n2 : this.element.ownerDocument.documentElement, this.element);
        if (t3.isDefaultPrevented() || !i3)
          return;
        var o2 = this.getTipElement(), r2 = _.getUID(this.constructor.NAME);
        o2.setAttribute("id", r2), this.element.setAttribute("aria-describedby", r2), this.setContent(), this.config.animation && g(o2).addClass(qe);
        var s2 = "function" == typeof this.config.placement ? this.config.placement.call(this, o2, this.element) : this.config.placement, a2 = this._getAttachment(s2);
        this.addAttachmentClass(a2);
        var l2 = this._getContainer();
        g(o2).data(this.constructor.DATA_KEY, this), g.contains(this.element.ownerDocument.documentElement, this.tip) || g(o2).appendTo(l2), g(this.element).trigger(this.constructor.Event.INSERTED), this._popper = new u(this.element, o2, this._getPopperConfig(a2)), g(o2).addClass(Me), "ontouchstart" in document.documentElement && g(document.body).children().on("mouseover", null, g.noop);
        var c2 = function() {
          e2.config.animation && e2._fixTransition();
          var t4 = e2._hoverState;
          e2._hoverState = null, g(e2.element).trigger(e2.constructor.Event.SHOWN), t4 === Ue && e2._leave(null, e2);
        };
        if (g(this.tip).hasClass(qe)) {
          var h2 = _.getTransitionDurationFromElement(this.tip);
          g(this.tip).one(_.TRANSITION_END, c2).emulateTransitionEnd(h2);
        } else
          c2();
      }
    }, t2.hide = function(t3) {
      function e2() {
        n2._hoverState !== Fe && i3.parentNode && i3.parentNode.removeChild(i3), n2._cleanTipClass(), n2.element.removeAttribute("aria-describedby"), g(n2.element).trigger(n2.constructor.Event.HIDDEN), null !== n2._popper && n2._popper.destroy(), t3 && t3();
      }
      var n2 = this, i3 = this.getTipElement(), o2 = g.Event(this.constructor.Event.HIDE);
      if (g(this.element).trigger(o2), !o2.isDefaultPrevented()) {
        if (g(i3).removeClass(Me), "ontouchstart" in document.documentElement && g(document.body).children().off("mouseover", null, g.noop), this._activeTrigger[Ye] = false, this._activeTrigger[Ve] = false, this._activeTrigger[Be] = false, g(this.tip).hasClass(qe)) {
          var r2 = _.getTransitionDurationFromElement(i3);
          g(i3).one(_.TRANSITION_END, e2).emulateTransitionEnd(r2);
        } else
          e2();
        this._hoverState = "";
      }
    }, t2.update = function() {
      null !== this._popper && this._popper.scheduleUpdate();
    }, t2.isWithContent = function() {
      return Boolean(this.getTitle());
    }, t2.addAttachmentClass = function(t3) {
      g(this.getTipElement()).addClass(Pe + "-" + t3);
    }, t2.getTipElement = function() {
      return this.tip = this.tip || g(this.config.template)[0], this.tip;
    }, t2.setContent = function() {
      var t3 = this.getTipElement();
      this.setElementContent(g(t3.querySelectorAll(Ke)), this.getTitle()), g(t3).removeClass(qe + " " + Me);
    }, t2.setElementContent = function(t3, e2) {
      "object" != typeof e2 || !e2.nodeType && !e2.jquery ? this.config.html ? (this.config.sanitize && (e2 = we(e2, this.config.whiteList, this.config.sanitizeFn)), t3.html(e2)) : t3.text(e2) : this.config.html ? g(e2).parent().is(t3) || t3.empty().append(e2) : t3.text(g(e2).text());
    }, t2.getTitle = function() {
      var t3 = this.element.getAttribute("data-original-title");
      return t3 = t3 || ("function" == typeof this.config.title ? this.config.title.call(this.element) : this.config.title);
    }, t2._getPopperConfig = function(t3) {
      var e2 = this;
      return l({}, { placement: t3, modifiers: { offset: this._getOffset(), flip: { behavior: this.config.fallbackPlacement }, arrow: { element: Qe }, preventOverflow: { boundariesElement: this.config.boundary } }, onCreate: function(t4) {
        t4.originalPlacement !== t4.placement && e2._handlePopperPlacementChange(t4);
      }, onUpdate: function(t4) {
        return e2._handlePopperPlacementChange(t4);
      } }, {}, this.config.popperConfig);
    }, t2._getOffset = function() {
      var e2 = this, t3 = {};
      return "function" == typeof this.config.offset ? t3.fn = function(t4) {
        return t4.offsets = l({}, t4.offsets, {}, e2.config.offset(t4.offsets, e2.element) || {}), t4;
      } : t3.offset = this.config.offset, t3;
    }, t2._getContainer = function() {
      return false === this.config.container ? document.body : _.isElement(this.config.container) ? g(this.config.container) : g(document).find(this.config.container);
    }, t2._getAttachment = function(t3) {
      return Re[t3.toUpperCase()];
    }, t2._setListeners = function() {
      var i3 = this;
      this.config.trigger.split(" ").forEach(function(t3) {
        if ("click" === t3)
          g(i3.element).on(i3.constructor.Event.CLICK, i3.config.selector, function(t4) {
            return i3.toggle(t4);
          });
        else if (t3 !== ze) {
          var e2 = t3 === Be ? i3.constructor.Event.MOUSEENTER : i3.constructor.Event.FOCUSIN, n2 = t3 === Be ? i3.constructor.Event.MOUSELEAVE : i3.constructor.Event.FOCUSOUT;
          g(i3.element).on(e2, i3.config.selector, function(t4) {
            return i3._enter(t4);
          }).on(n2, i3.config.selector, function(t4) {
            return i3._leave(t4);
          });
        }
      }), this._hideModalHandler = function() {
        i3.element && i3.hide();
      }, g(this.element).closest(".modal").on("hide.bs.modal", this._hideModalHandler), this.config.selector ? this.config = l({}, this.config, { trigger: "manual", selector: "" }) : this._fixTitle();
    }, t2._fixTitle = function() {
      var t3 = typeof this.element.getAttribute("data-original-title");
      !this.element.getAttribute("title") && "string" == t3 || (this.element.setAttribute("data-original-title", this.element.getAttribute("title") || ""), this.element.setAttribute("title", ""));
    }, t2._enter = function(t3, e2) {
      var n2 = this.constructor.DATA_KEY;
      (e2 = e2 || g(t3.currentTarget).data(n2)) || (e2 = new this.constructor(t3.currentTarget, this._getDelegateConfig()), g(t3.currentTarget).data(n2, e2)), t3 && (e2._activeTrigger["focusin" === t3.type ? Ve : Be] = true), g(e2.getTipElement()).hasClass(Me) || e2._hoverState === Fe ? e2._hoverState = Fe : (clearTimeout(e2._timeout), e2._hoverState = Fe, e2.config.delay && e2.config.delay.show ? e2._timeout = setTimeout(function() {
        e2._hoverState === Fe && e2.show();
      }, e2.config.delay.show) : e2.show());
    }, t2._leave = function(t3, e2) {
      var n2 = this.constructor.DATA_KEY;
      (e2 = e2 || g(t3.currentTarget).data(n2)) || (e2 = new this.constructor(t3.currentTarget, this._getDelegateConfig()), g(t3.currentTarget).data(n2, e2)), t3 && (e2._activeTrigger["focusout" === t3.type ? Ve : Be] = false), e2._isWithActiveTrigger() || (clearTimeout(e2._timeout), e2._hoverState = Ue, e2.config.delay && e2.config.delay.hide ? e2._timeout = setTimeout(function() {
        e2._hoverState === Ue && e2.hide();
      }, e2.config.delay.hide) : e2.hide());
    }, t2._isWithActiveTrigger = function() {
      for (var t3 in this._activeTrigger)
        if (this._activeTrigger[t3])
          return true;
      return false;
    }, t2._getConfig = function(t3) {
      var e2 = g(this.element).data();
      return Object.keys(e2).forEach(function(t4) {
        -1 !== je.indexOf(t4) && delete e2[t4];
      }), "number" == typeof (t3 = l({}, this.constructor.Default, {}, e2, {}, "object" == typeof t3 && t3 ? t3 : {})).delay && (t3.delay = { show: t3.delay, hide: t3.delay }), "number" == typeof t3.title && (t3.title = t3.title.toString()), "number" == typeof t3.content && (t3.content = t3.content.toString()), _.typeCheckConfig(Ae, t3, this.constructor.DefaultType), t3.sanitize && (t3.template = we(t3.template, t3.whiteList, t3.sanitizeFn)), t3;
    }, t2._getDelegateConfig = function() {
      var t3 = {};
      if (this.config)
        for (var e2 in this.config)
          this.constructor.Default[e2] !== this.config[e2] && (t3[e2] = this.config[e2]);
      return t3;
    }, t2._cleanTipClass = function() {
      var t3 = g(this.getTipElement()), e2 = t3.attr("class").match(Le);
      null !== e2 && e2.length && t3.removeClass(e2.join(""));
    }, t2._handlePopperPlacementChange = function(t3) {
      var e2 = t3.instance;
      this.tip = e2.popper, this._cleanTipClass(), this.addAttachmentClass(this._getAttachment(t3.placement));
    }, t2._fixTransition = function() {
      var t3 = this.getTipElement(), e2 = this.config.animation;
      null === t3.getAttribute("x-placement") && (g(t3).removeClass(qe), this.config.animation = false, this.hide(), this.show(), this.config.animation = e2);
    }, i2._jQueryInterface = function(n2) {
      return this.each(function() {
        var t3 = g(this).data(Ne), e2 = "object" == typeof n2 && n2;
        if ((t3 || !/dispose|hide/.test(n2)) && (t3 || (t3 = new i2(this, e2), g(this).data(Ne, t3)), "string" == typeof n2)) {
          if ("undefined" == typeof t3[n2])
            throw new TypeError('No method named "' + n2 + '"');
          t3[n2]();
        }
      });
    }, s(i2, null, [{ key: "VERSION", get: function() {
      return "4.4.1";
    } }, { key: "Default", get: function() {
      return xe;
    } }, { key: "NAME", get: function() {
      return Ae;
    } }, { key: "DATA_KEY", get: function() {
      return Ne;
    } }, { key: "Event", get: function() {
      return We;
    } }, { key: "EVENT_KEY", get: function() {
      return Oe;
    } }, { key: "DefaultType", get: function() {
      return He;
    } }]), i2;
  }();
  g.fn[Ae] = Xe._jQueryInterface, g.fn[Ae].Constructor = Xe, g.fn[Ae].noConflict = function() {
    return g.fn[Ae] = ke, Xe._jQueryInterface;
  };
  var $e = "popover", Ge = "bs.popover", Je = "." + Ge, Ze = g.fn[$e], tn = "bs-popover", en = new RegExp("(^|\\s)" + tn + "\\S+", "g"), nn = l({}, Xe.Default, { placement: "right", trigger: "click", content: "", template: '<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-header"></h3><div class="popover-body"></div></div>' }), on = l({}, Xe.DefaultType, { content: "(string|element|function)" }), rn = "fade", sn = "show", an = ".popover-header", ln = ".popover-body", cn = { HIDE: "hide" + Je, HIDDEN: "hidden" + Je, SHOW: "show" + Je, SHOWN: "shown" + Je, INSERTED: "inserted" + Je, CLICK: "click" + Je, FOCUSIN: "focusin" + Je, FOCUSOUT: "focusout" + Je, MOUSEENTER: "mouseenter" + Je, MOUSELEAVE: "mouseleave" + Je }, hn = function(t2) {
    function i2() {
      return t2.apply(this, arguments) || this;
    }
    !function(t3, e3) {
      t3.prototype = Object.create(e3.prototype), (t3.prototype.constructor = t3).__proto__ = e3;
    }(i2, t2);
    var e2 = i2.prototype;
    return e2.isWithContent = function() {
      return this.getTitle() || this._getContent();
    }, e2.addAttachmentClass = function(t3) {
      g(this.getTipElement()).addClass(tn + "-" + t3);
    }, e2.getTipElement = function() {
      return this.tip = this.tip || g(this.config.template)[0], this.tip;
    }, e2.setContent = function() {
      var t3 = g(this.getTipElement());
      this.setElementContent(t3.find(an), this.getTitle());
      var e3 = this._getContent();
      "function" == typeof e3 && (e3 = e3.call(this.element)), this.setElementContent(t3.find(ln), e3), t3.removeClass(rn + " " + sn);
    }, e2._getContent = function() {
      return this.element.getAttribute("data-content") || this.config.content;
    }, e2._cleanTipClass = function() {
      var t3 = g(this.getTipElement()), e3 = t3.attr("class").match(en);
      null !== e3 && 0 < e3.length && t3.removeClass(e3.join(""));
    }, i2._jQueryInterface = function(n2) {
      return this.each(function() {
        var t3 = g(this).data(Ge), e3 = "object" == typeof n2 ? n2 : null;
        if ((t3 || !/dispose|hide/.test(n2)) && (t3 || (t3 = new i2(this, e3), g(this).data(Ge, t3)), "string" == typeof n2)) {
          if ("undefined" == typeof t3[n2])
            throw new TypeError('No method named "' + n2 + '"');
          t3[n2]();
        }
      });
    }, s(i2, null, [{ key: "VERSION", get: function() {
      return "4.4.1";
    } }, { key: "Default", get: function() {
      return nn;
    } }, { key: "NAME", get: function() {
      return $e;
    } }, { key: "DATA_KEY", get: function() {
      return Ge;
    } }, { key: "Event", get: function() {
      return cn;
    } }, { key: "EVENT_KEY", get: function() {
      return Je;
    } }, { key: "DefaultType", get: function() {
      return on;
    } }]), i2;
  }(Xe);
  g.fn[$e] = hn._jQueryInterface, g.fn[$e].Constructor = hn, g.fn[$e].noConflict = function() {
    return g.fn[$e] = Ze, hn._jQueryInterface;
  };
  var un = "scrollspy", fn = "bs.scrollspy", dn = "." + fn, gn = g.fn[un], _n = { offset: 10, method: "auto", target: "" }, mn = { offset: "number", method: "string", target: "(string|element)" }, pn = { ACTIVATE: "activate" + dn, SCROLL: "scroll" + dn, LOAD_DATA_API: "load" + dn + ".data-api" }, vn = "dropdown-item", yn = "active", En = '[data-spy="scroll"]', Cn = ".nav, .list-group", Tn = ".nav-link", bn = ".nav-item", Sn = ".list-group-item", Dn = ".dropdown", In = ".dropdown-item", wn = ".dropdown-toggle", An = "offset", Nn = "position", On = function() {
    function n2(t3, e2) {
      var n3 = this;
      this._element = t3, this._scrollElement = "BODY" === t3.tagName ? window : t3, this._config = this._getConfig(e2), this._selector = this._config.target + " " + Tn + "," + this._config.target + " " + Sn + "," + this._config.target + " " + In, this._offsets = [], this._targets = [], this._activeTarget = null, this._scrollHeight = 0, g(this._scrollElement).on(pn.SCROLL, function(t4) {
        return n3._process(t4);
      }), this.refresh(), this._process();
    }
    var t2 = n2.prototype;
    return t2.refresh = function() {
      var e2 = this, t3 = this._scrollElement === this._scrollElement.window ? An : Nn, o2 = "auto" === this._config.method ? t3 : this._config.method, r2 = o2 === Nn ? this._getScrollTop() : 0;
      this._offsets = [], this._targets = [], this._scrollHeight = this._getScrollHeight(), [].slice.call(document.querySelectorAll(this._selector)).map(function(t4) {
        var e3, n3 = _.getSelectorFromElement(t4);
        if (n3 && (e3 = document.querySelector(n3)), e3) {
          var i2 = e3.getBoundingClientRect();
          if (i2.width || i2.height)
            return [g(e3)[o2]().top + r2, n3];
        }
        return null;
      }).filter(function(t4) {
        return t4;
      }).sort(function(t4, e3) {
        return t4[0] - e3[0];
      }).forEach(function(t4) {
        e2._offsets.push(t4[0]), e2._targets.push(t4[1]);
      });
    }, t2.dispose = function() {
      g.removeData(this._element, fn), g(this._scrollElement).off(dn), this._element = null, this._scrollElement = null, this._config = null, this._selector = null, this._offsets = null, this._targets = null, this._activeTarget = null, this._scrollHeight = null;
    }, t2._getConfig = function(t3) {
      if ("string" != typeof (t3 = l({}, _n, {}, "object" == typeof t3 && t3 ? t3 : {})).target) {
        var e2 = g(t3.target).attr("id");
        e2 || (e2 = _.getUID(un), g(t3.target).attr("id", e2)), t3.target = "#" + e2;
      }
      return _.typeCheckConfig(un, t3, mn), t3;
    }, t2._getScrollTop = function() {
      return this._scrollElement === window ? this._scrollElement.pageYOffset : this._scrollElement.scrollTop;
    }, t2._getScrollHeight = function() {
      return this._scrollElement.scrollHeight || Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
    }, t2._getOffsetHeight = function() {
      return this._scrollElement === window ? window.innerHeight : this._scrollElement.getBoundingClientRect().height;
    }, t2._process = function() {
      var t3 = this._getScrollTop() + this._config.offset, e2 = this._getScrollHeight(), n3 = this._config.offset + e2 - this._getOffsetHeight();
      if (this._scrollHeight !== e2 && this.refresh(), n3 <= t3) {
        var i2 = this._targets[this._targets.length - 1];
        this._activeTarget !== i2 && this._activate(i2);
      } else {
        if (this._activeTarget && t3 < this._offsets[0] && 0 < this._offsets[0])
          return this._activeTarget = null, void this._clear();
        for (var o2 = this._offsets.length; o2--; ) {
          this._activeTarget !== this._targets[o2] && t3 >= this._offsets[o2] && ("undefined" == typeof this._offsets[o2 + 1] || t3 < this._offsets[o2 + 1]) && this._activate(this._targets[o2]);
        }
      }
    }, t2._activate = function(e2) {
      this._activeTarget = e2, this._clear();
      var t3 = this._selector.split(",").map(function(t4) {
        return t4 + '[data-target="' + e2 + '"],' + t4 + '[href="' + e2 + '"]';
      }), n3 = g([].slice.call(document.querySelectorAll(t3.join(","))));
      n3.hasClass(vn) ? (n3.closest(Dn).find(wn).addClass(yn), n3.addClass(yn)) : (n3.addClass(yn), n3.parents(Cn).prev(Tn + ", " + Sn).addClass(yn), n3.parents(Cn).prev(bn).children(Tn).addClass(yn)), g(this._scrollElement).trigger(pn.ACTIVATE, { relatedTarget: e2 });
    }, t2._clear = function() {
      [].slice.call(document.querySelectorAll(this._selector)).filter(function(t3) {
        return t3.classList.contains(yn);
      }).forEach(function(t3) {
        return t3.classList.remove(yn);
      });
    }, n2._jQueryInterface = function(e2) {
      return this.each(function() {
        var t3 = g(this).data(fn);
        if (t3 || (t3 = new n2(this, "object" == typeof e2 && e2), g(this).data(fn, t3)), "string" == typeof e2) {
          if ("undefined" == typeof t3[e2])
            throw new TypeError('No method named "' + e2 + '"');
          t3[e2]();
        }
      });
    }, s(n2, null, [{ key: "VERSION", get: function() {
      return "4.4.1";
    } }, { key: "Default", get: function() {
      return _n;
    } }]), n2;
  }();
  g(window).on(pn.LOAD_DATA_API, function() {
    for (var t2 = [].slice.call(document.querySelectorAll(En)), e2 = t2.length; e2--; ) {
      var n2 = g(t2[e2]);
      On._jQueryInterface.call(n2, n2.data());
    }
  }), g.fn[un] = On._jQueryInterface, g.fn[un].Constructor = On, g.fn[un].noConflict = function() {
    return g.fn[un] = gn, On._jQueryInterface;
  };
  var kn = "bs.tab", Pn = "." + kn, Ln = g.fn.tab, jn = { HIDE: "hide" + Pn, HIDDEN: "hidden" + Pn, SHOW: "show" + Pn, SHOWN: "shown" + Pn, CLICK_DATA_API: "click" + Pn + ".data-api" }, Hn = "dropdown-menu", Rn = "active", xn = "disabled", Fn = "fade", Un = "show", Wn = ".dropdown", qn = ".nav, .list-group", Mn = ".active", Kn = "> li > .active", Qn = '[data-toggle="tab"], [data-toggle="pill"], [data-toggle="list"]', Bn = ".dropdown-toggle", Vn = "> .dropdown-menu .active", Yn = function() {
    function i2(t3) {
      this._element = t3;
    }
    var t2 = i2.prototype;
    return t2.show = function() {
      var n2 = this;
      if (!(this._element.parentNode && this._element.parentNode.nodeType === Node.ELEMENT_NODE && g(this._element).hasClass(Rn) || g(this._element).hasClass(xn))) {
        var t3, i3, e2 = g(this._element).closest(qn)[0], o2 = _.getSelectorFromElement(this._element);
        if (e2) {
          var r2 = "UL" === e2.nodeName || "OL" === e2.nodeName ? Kn : Mn;
          i3 = (i3 = g.makeArray(g(e2).find(r2)))[i3.length - 1];
        }
        var s2 = g.Event(jn.HIDE, { relatedTarget: this._element }), a2 = g.Event(jn.SHOW, { relatedTarget: i3 });
        if (i3 && g(i3).trigger(s2), g(this._element).trigger(a2), !a2.isDefaultPrevented() && !s2.isDefaultPrevented()) {
          o2 && (t3 = document.querySelector(o2)), this._activate(this._element, e2);
          var l2 = function() {
            var t4 = g.Event(jn.HIDDEN, { relatedTarget: n2._element }), e3 = g.Event(jn.SHOWN, { relatedTarget: i3 });
            g(i3).trigger(t4), g(n2._element).trigger(e3);
          };
          t3 ? this._activate(t3, t3.parentNode, l2) : l2();
        }
      }
    }, t2.dispose = function() {
      g.removeData(this._element, kn), this._element = null;
    }, t2._activate = function(t3, e2, n2) {
      function i3() {
        return o2._transitionComplete(t3, r2, n2);
      }
      var o2 = this, r2 = (!e2 || "UL" !== e2.nodeName && "OL" !== e2.nodeName ? g(e2).children(Mn) : g(e2).find(Kn))[0], s2 = n2 && r2 && g(r2).hasClass(Fn);
      if (r2 && s2) {
        var a2 = _.getTransitionDurationFromElement(r2);
        g(r2).removeClass(Un).one(_.TRANSITION_END, i3).emulateTransitionEnd(a2);
      } else
        i3();
    }, t2._transitionComplete = function(t3, e2, n2) {
      if (e2) {
        g(e2).removeClass(Rn);
        var i3 = g(e2.parentNode).find(Vn)[0];
        i3 && g(i3).removeClass(Rn), "tab" === e2.getAttribute("role") && e2.setAttribute("aria-selected", false);
      }
      if (g(t3).addClass(Rn), "tab" === t3.getAttribute("role") && t3.setAttribute("aria-selected", true), _.reflow(t3), t3.classList.contains(Fn) && t3.classList.add(Un), t3.parentNode && g(t3.parentNode).hasClass(Hn)) {
        var o2 = g(t3).closest(Wn)[0];
        if (o2) {
          var r2 = [].slice.call(o2.querySelectorAll(Bn));
          g(r2).addClass(Rn);
        }
        t3.setAttribute("aria-expanded", true);
      }
      n2 && n2();
    }, i2._jQueryInterface = function(n2) {
      return this.each(function() {
        var t3 = g(this), e2 = t3.data(kn);
        if (e2 || (e2 = new i2(this), t3.data(kn, e2)), "string" == typeof n2) {
          if ("undefined" == typeof e2[n2])
            throw new TypeError('No method named "' + n2 + '"');
          e2[n2]();
        }
      });
    }, s(i2, null, [{ key: "VERSION", get: function() {
      return "4.4.1";
    } }]), i2;
  }();
  g(document).on(jn.CLICK_DATA_API, Qn, function(t2) {
    t2.preventDefault(), Yn._jQueryInterface.call(g(this), "show");
  }), g.fn.tab = Yn._jQueryInterface, g.fn.tab.Constructor = Yn, g.fn.tab.noConflict = function() {
    return g.fn.tab = Ln, Yn._jQueryInterface;
  };
  var zn = "toast", Xn = "bs.toast", $n = "." + Xn, Gn = g.fn[zn], Jn = { CLICK_DISMISS: "click.dismiss" + $n, HIDE: "hide" + $n, HIDDEN: "hidden" + $n, SHOW: "show" + $n, SHOWN: "shown" + $n }, Zn = "fade", ti = "hide", ei = "show", ni = "showing", ii = { animation: "boolean", autohide: "boolean", delay: "number" }, oi = { animation: true, autohide: true, delay: 500 }, ri = '[data-dismiss="toast"]', si = function() {
    function i2(t3, e2) {
      this._element = t3, this._config = this._getConfig(e2), this._timeout = null, this._setListeners();
    }
    var t2 = i2.prototype;
    return t2.show = function() {
      var t3 = this, e2 = g.Event(Jn.SHOW);
      if (g(this._element).trigger(e2), !e2.isDefaultPrevented()) {
        this._config.animation && this._element.classList.add(Zn);
        var n2 = function() {
          t3._element.classList.remove(ni), t3._element.classList.add(ei), g(t3._element).trigger(Jn.SHOWN), t3._config.autohide && (t3._timeout = setTimeout(function() {
            t3.hide();
          }, t3._config.delay));
        };
        if (this._element.classList.remove(ti), _.reflow(this._element), this._element.classList.add(ni), this._config.animation) {
          var i3 = _.getTransitionDurationFromElement(this._element);
          g(this._element).one(_.TRANSITION_END, n2).emulateTransitionEnd(i3);
        } else
          n2();
      }
    }, t2.hide = function() {
      if (this._element.classList.contains(ei)) {
        var t3 = g.Event(Jn.HIDE);
        g(this._element).trigger(t3), t3.isDefaultPrevented() || this._close();
      }
    }, t2.dispose = function() {
      clearTimeout(this._timeout), this._timeout = null, this._element.classList.contains(ei) && this._element.classList.remove(ei), g(this._element).off(Jn.CLICK_DISMISS), g.removeData(this._element, Xn), this._element = null, this._config = null;
    }, t2._getConfig = function(t3) {
      return t3 = l({}, oi, {}, g(this._element).data(), {}, "object" == typeof t3 && t3 ? t3 : {}), _.typeCheckConfig(zn, t3, this.constructor.DefaultType), t3;
    }, t2._setListeners = function() {
      var t3 = this;
      g(this._element).on(Jn.CLICK_DISMISS, ri, function() {
        return t3.hide();
      });
    }, t2._close = function() {
      function t3() {
        e2._element.classList.add(ti), g(e2._element).trigger(Jn.HIDDEN);
      }
      var e2 = this;
      if (this._element.classList.remove(ei), this._config.animation) {
        var n2 = _.getTransitionDurationFromElement(this._element);
        g(this._element).one(_.TRANSITION_END, t3).emulateTransitionEnd(n2);
      } else
        t3();
    }, i2._jQueryInterface = function(n2) {
      return this.each(function() {
        var t3 = g(this), e2 = t3.data(Xn);
        if (e2 || (e2 = new i2(this, "object" == typeof n2 && n2), t3.data(Xn, e2)), "string" == typeof n2) {
          if ("undefined" == typeof e2[n2])
            throw new TypeError('No method named "' + n2 + '"');
          e2[n2](this);
        }
      });
    }, s(i2, null, [{ key: "VERSION", get: function() {
      return "4.4.1";
    } }, { key: "DefaultType", get: function() {
      return ii;
    } }, { key: "Default", get: function() {
      return oi;
    } }]), i2;
  }();
  g.fn[zn] = si._jQueryInterface, g.fn[zn].Constructor = si, g.fn[zn].noConflict = function() {
    return g.fn[zn] = Gn, si._jQueryInterface;
  }, t.Alert = v, t.Button = H, t.Carousel = ut, t.Collapse = wt, t.Dropdown = ee, t.Modal = Te, t.Popover = hn, t.Scrollspy = On, t.Tab = Yn, t.Toast = si, t.Tooltip = Xe, t.Util = _, Object.defineProperty(t, "__esModule", { value: true });
});
!function(e) {
  e.fn.niceSelect = function(t) {
    function s(t2) {
      t2.after(e("<div></div>").addClass("nice-select").addClass(t2.attr("class") || "").addClass(t2.attr("disabled") ? "disabled" : "").attr("tabindex", t2.attr("disabled") ? null : "0").html('<span class="current"></span><ul class="list"></ul>'));
      var s2 = t2.next(), n2 = t2.find("option"), i = t2.find("option:selected");
      s2.find(".current").html(i.data("display") || i.text()), n2.each(function(t3) {
        var n3 = e(this), i2 = n3.data("display");
        s2.find("ul").append(e("<li></li>").attr("data-value", n3.val()).attr("data-display", i2 || null).addClass("option" + (n3.is(":selected") ? " selected" : "") + (n3.is(":disabled") ? " disabled" : "")).html(n3.text()));
      });
    }
    if ("string" == typeof t)
      return "update" == t ? this.each(function() {
        var t2 = e(this), n2 = e(this).next(".nice-select"), i = n2.hasClass("open");
        n2.length && (n2.remove(), s(t2), i && t2.next().trigger("click"));
      }) : "destroy" == t ? (this.each(function() {
        var t2 = e(this), s2 = e(this).next(".nice-select");
        s2.length && (s2.remove(), t2.css("display", ""));
      }), 0 == e(".nice-select").length && e(document).off(".nice_select")) : console.log('Method "' + t + '" does not exist.'), this;
    this.hide(), this.each(function() {
      var t2 = e(this);
      t2.next().hasClass("nice-select") || s(t2);
    }), e(document).off(".nice_select"), e(document).on("click.nice_select", ".nice-select", function(t2) {
      var s2 = e(this);
      e(".nice-select").not(s2).removeClass("open"), s2.toggleClass("open"), s2.hasClass("open") ? (s2.find(".option"), s2.find(".focus").removeClass("focus"), s2.find(".selected").addClass("focus")) : s2.focus();
    }), e(document).on("click.nice_select", function(t2) {
      0 === e(t2.target).closest(".nice-select").length && e(".nice-select").removeClass("open").find(".option");
    }), e(document).on("click.nice_select", ".nice-select .option:not(.disabled)", function(t2) {
      var s2 = e(this), n2 = s2.closest(".nice-select");
      n2.find(".selected").removeClass("selected"), s2.addClass("selected");
      var i = s2.data("display") || s2.text();
      n2.find(".current").text(i), n2.prev("select").val(s2.data("value")).trigger("change");
    }), e(document).on("keydown.nice_select", ".nice-select", function(t2) {
      var s2 = e(this), n2 = e(s2.find(".focus") || s2.find(".list .option.selected"));
      if (32 == t2.keyCode || 13 == t2.keyCode)
        return s2.hasClass("open") ? n2.trigger("click") : s2.trigger("click"), false;
      if (40 == t2.keyCode) {
        if (s2.hasClass("open")) {
          var i = n2.nextAll(".option:not(.disabled)").first();
          i.length > 0 && (s2.find(".focus").removeClass("focus"), i.addClass("focus"));
        } else
          s2.trigger("click");
        return false;
      }
      if (38 == t2.keyCode) {
        if (s2.hasClass("open")) {
          var l = n2.prevAll(".option:not(.disabled)").first();
          l.length > 0 && (s2.find(".focus").removeClass("focus"), l.addClass("focus"));
        } else
          s2.trigger("click");
        return false;
      }
      if (27 == t2.keyCode)
        s2.hasClass("open") && s2.trigger("click");
      else if (9 == t2.keyCode && s2.hasClass("open"))
        return false;
    });
    var n = document.createElement("a").style;
    return n.cssText = "pointer-events:auto", "auto" !== n.pointerEvents && e("html").addClass("no-csspointerevents"), this;
  };
}(jQuery);
/*! jQuery UI - v1.12.1 - 2016-09-14
* http://jqueryui.com
* Includes: widget.js, position.js, data.js, disable-selection.js, effect.js, effects/effect-blind.js, effects/effect-bounce.js, effects/effect-clip.js, effects/effect-drop.js, effects/effect-explode.js, effects/effect-fade.js, effects/effect-fold.js, effects/effect-highlight.js, effects/effect-puff.js, effects/effect-pulsate.js, effects/effect-scale.js, effects/effect-shake.js, effects/effect-size.js, effects/effect-slide.js, effects/effect-transfer.js, focusable.js, form-reset-mixin.js, jquery-1-7.js, keycode.js, labels.js, scroll-parent.js, tabbable.js, unique-id.js, widgets/accordion.js, widgets/autocomplete.js, widgets/button.js, widgets/checkboxradio.js, widgets/controlgroup.js, widgets/datepicker.js, widgets/dialog.js, widgets/draggable.js, widgets/droppable.js, widgets/menu.js, widgets/mouse.js, widgets/progressbar.js, widgets/resizable.js, widgets/selectable.js, widgets/selectmenu.js, widgets/slider.js, widgets/sortable.js, widgets/spinner.js, widgets/tabs.js, widgets/tooltip.js
* Copyright jQuery Foundation and other contributors; Licensed MIT */
(function(t) {
  "function" == typeof define && define.amd ? define(["jquery"], t) : t(jQuery);
})(function(t) {
  function e(t2) {
    for (var e2 = t2.css("visibility"); "inherit" === e2; )
      t2 = t2.parent(), e2 = t2.css("visibility");
    return "hidden" !== e2;
  }
  function i(t2) {
    for (var e2, i2; t2.length && t2[0] !== document; ) {
      if (e2 = t2.css("position"), ("absolute" === e2 || "relative" === e2 || "fixed" === e2) && (i2 = parseInt(t2.css("zIndex"), 10), !isNaN(i2) && 0 !== i2))
        return i2;
      t2 = t2.parent();
    }
    return 0;
  }
  function s() {
    this._curInst = null, this._keyEvent = false, this._disabledInputs = [], this._datepickerShowing = false, this._inDialog = false, this._mainDivId = "ui-datepicker-div", this._inlineClass = "ui-datepicker-inline", this._appendClass = "ui-datepicker-append", this._triggerClass = "ui-datepicker-trigger", this._dialogClass = "ui-datepicker-dialog", this._disableClass = "ui-datepicker-disabled", this._unselectableClass = "ui-datepicker-unselectable", this._currentClass = "ui-datepicker-current-day", this._dayOverClass = "ui-datepicker-days-cell-over", this.regional = [], this.regional[""] = { closeText: "Done", prevText: "Prev", nextText: "Next", currentText: "Today", monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"], weekHeader: "Wk", dateFormat: "mm/dd/yy", firstDay: 0, isRTL: false, showMonthAfterYear: false, yearSuffix: "" }, this._defaults = { showOn: "focus", showAnim: "fadeIn", showOptions: {}, defaultDate: null, appendText: "", buttonText: "...", buttonImage: "", buttonImageOnly: false, hideIfNoPrevNext: false, navigationAsDateFormat: false, gotoCurrent: false, changeMonth: false, changeYear: false, yearRange: "c-10:c+10", showOtherMonths: false, selectOtherMonths: false, showWeek: false, calculateWeek: this.iso8601Week, shortYearCutoff: "+10", minDate: null, maxDate: null, duration: "fast", beforeShowDay: null, beforeShow: null, onSelect: null, onChangeMonthYear: null, onClose: null, numberOfMonths: 1, showCurrentAtPos: 0, stepMonths: 1, stepBigMonths: 12, altField: "", altFormat: "", constrainInput: true, showButtonPanel: false, autoSize: false, disabled: false }, t.extend(this._defaults, this.regional[""]), this.regional.en = t.extend(true, {}, this.regional[""]), this.regional["en-US"] = t.extend(true, {}, this.regional.en), this.dpDiv = n(t("<div id='" + this._mainDivId + "' class='ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>"));
  }
  function n(e2) {
    var i2 = "button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a";
    return e2.on("mouseout", i2, function() {
      t(this).removeClass("ui-state-hover"), -1 !== this.className.indexOf("ui-datepicker-prev") && t(this).removeClass("ui-datepicker-prev-hover"), -1 !== this.className.indexOf("ui-datepicker-next") && t(this).removeClass("ui-datepicker-next-hover");
    }).on("mouseover", i2, o);
  }
  function o() {
    t.datepicker._isDisabledDatepicker(m.inline ? m.dpDiv.parent()[0] : m.input[0]) || (t(this).parents(".ui-datepicker-calendar").find("a").removeClass("ui-state-hover"), t(this).addClass("ui-state-hover"), -1 !== this.className.indexOf("ui-datepicker-prev") && t(this).addClass("ui-datepicker-prev-hover"), -1 !== this.className.indexOf("ui-datepicker-next") && t(this).addClass("ui-datepicker-next-hover"));
  }
  function a(e2, i2) {
    t.extend(e2, i2);
    for (var s2 in i2)
      null == i2[s2] && (e2[s2] = i2[s2]);
    return e2;
  }
  function r(t2) {
    return function() {
      var e2 = this.element.val();
      t2.apply(this, arguments), this._refresh(), e2 !== this.element.val() && this._trigger("change");
    };
  }
  t.ui = t.ui || {}, t.ui.version = "1.12.1";
  var h = 0, l = Array.prototype.slice;
  t.cleanData = function(e2) {
    return function(i2) {
      var s2, n2, o2;
      for (o2 = 0; null != (n2 = i2[o2]); o2++)
        try {
          s2 = t._data(n2, "events"), s2 && s2.remove && t(n2).triggerHandler("remove");
        } catch (a2) {
        }
      e2(i2);
    };
  }(t.cleanData), t.widget = function(e2, i2, s2) {
    var n2, o2, a2, r2 = {}, h2 = e2.split(".")[0];
    e2 = e2.split(".")[1];
    var l2 = h2 + "-" + e2;
    return s2 || (s2 = i2, i2 = t.Widget), t.isArray(s2) && (s2 = t.extend.apply(null, [{}].concat(s2))), t.expr[":"][l2.toLowerCase()] = function(e3) {
      return !!t.data(e3, l2);
    }, t[h2] = t[h2] || {}, n2 = t[h2][e2], o2 = t[h2][e2] = function(t2, e3) {
      return this._createWidget ? (arguments.length && this._createWidget(t2, e3), void 0) : new o2(t2, e3);
    }, t.extend(o2, n2, { version: s2.version, _proto: t.extend({}, s2), _childConstructors: [] }), a2 = new i2(), a2.options = t.widget.extend({}, a2.options), t.each(s2, function(e3, s3) {
      return t.isFunction(s3) ? (r2[e3] = function() {
        function t2() {
          return i2.prototype[e3].apply(this, arguments);
        }
        function n3(t3) {
          return i2.prototype[e3].apply(this, t3);
        }
        return function() {
          var e4, i3 = this._super, o3 = this._superApply;
          return this._super = t2, this._superApply = n3, e4 = s3.apply(this, arguments), this._super = i3, this._superApply = o3, e4;
        };
      }(), void 0) : (r2[e3] = s3, void 0);
    }), o2.prototype = t.widget.extend(a2, { widgetEventPrefix: n2 ? a2.widgetEventPrefix || e2 : e2 }, r2, { constructor: o2, namespace: h2, widgetName: e2, widgetFullName: l2 }), n2 ? (t.each(n2._childConstructors, function(e3, i3) {
      var s3 = i3.prototype;
      t.widget(s3.namespace + "." + s3.widgetName, o2, i3._proto);
    }), delete n2._childConstructors) : i2._childConstructors.push(o2), t.widget.bridge(e2, o2), o2;
  }, t.widget.extend = function(e2) {
    for (var i2, s2, n2 = l.call(arguments, 1), o2 = 0, a2 = n2.length; a2 > o2; o2++)
      for (i2 in n2[o2])
        s2 = n2[o2][i2], n2[o2].hasOwnProperty(i2) && void 0 !== s2 && (e2[i2] = t.isPlainObject(s2) ? t.isPlainObject(e2[i2]) ? t.widget.extend({}, e2[i2], s2) : t.widget.extend({}, s2) : s2);
    return e2;
  }, t.widget.bridge = function(e2, i2) {
    var s2 = i2.prototype.widgetFullName || e2;
    t.fn[e2] = function(n2) {
      var o2 = "string" == typeof n2, a2 = l.call(arguments, 1), r2 = this;
      return o2 ? this.length || "instance" !== n2 ? this.each(function() {
        var i3, o3 = t.data(this, s2);
        return "instance" === n2 ? (r2 = o3, false) : o3 ? t.isFunction(o3[n2]) && "_" !== n2.charAt(0) ? (i3 = o3[n2].apply(o3, a2), i3 !== o3 && void 0 !== i3 ? (r2 = i3 && i3.jquery ? r2.pushStack(i3.get()) : i3, false) : void 0) : t.error("no such method '" + n2 + "' for " + e2 + " widget instance") : t.error("cannot call methods on " + e2 + " prior to initialization; attempted to call method '" + n2 + "'");
      }) : r2 = void 0 : (a2.length && (n2 = t.widget.extend.apply(null, [n2].concat(a2))), this.each(function() {
        var e3 = t.data(this, s2);
        e3 ? (e3.option(n2 || {}), e3._init && e3._init()) : t.data(this, s2, new i2(n2, this));
      })), r2;
    };
  }, t.Widget = function() {
  }, t.Widget._childConstructors = [], t.Widget.prototype = { widgetName: "widget", widgetEventPrefix: "", defaultElement: "<div>", options: { classes: {}, disabled: false, create: null }, _createWidget: function(e2, i2) {
    i2 = t(i2 || this.defaultElement || this)[0], this.element = t(i2), this.uuid = h++, this.eventNamespace = "." + this.widgetName + this.uuid, this.bindings = t(), this.hoverable = t(), this.focusable = t(), this.classesElementLookup = {}, i2 !== this && (t.data(i2, this.widgetFullName, this), this._on(true, this.element, { remove: function(t2) {
      t2.target === i2 && this.destroy();
    } }), this.document = t(i2.style ? i2.ownerDocument : i2.document || i2), this.window = t(this.document[0].defaultView || this.document[0].parentWindow)), this.options = t.widget.extend({}, this.options, this._getCreateOptions(), e2), this._create(), this.options.disabled && this._setOptionDisabled(this.options.disabled), this._trigger("create", null, this._getCreateEventData()), this._init();
  }, _getCreateOptions: function() {
    return {};
  }, _getCreateEventData: t.noop, _create: t.noop, _init: t.noop, destroy: function() {
    var e2 = this;
    this._destroy(), t.each(this.classesElementLookup, function(t2, i2) {
      e2._removeClass(i2, t2);
    }), this.element.off(this.eventNamespace).removeData(this.widgetFullName), this.widget().off(this.eventNamespace).removeAttr("aria-disabled"), this.bindings.off(this.eventNamespace);
  }, _destroy: t.noop, widget: function() {
    return this.element;
  }, option: function(e2, i2) {
    var s2, n2, o2, a2 = e2;
    if (0 === arguments.length)
      return t.widget.extend({}, this.options);
    if ("string" == typeof e2)
      if (a2 = {}, s2 = e2.split("."), e2 = s2.shift(), s2.length) {
        for (n2 = a2[e2] = t.widget.extend({}, this.options[e2]), o2 = 0; s2.length - 1 > o2; o2++)
          n2[s2[o2]] = n2[s2[o2]] || {}, n2 = n2[s2[o2]];
        if (e2 = s2.pop(), 1 === arguments.length)
          return void 0 === n2[e2] ? null : n2[e2];
        n2[e2] = i2;
      } else {
        if (1 === arguments.length)
          return void 0 === this.options[e2] ? null : this.options[e2];
        a2[e2] = i2;
      }
    return this._setOptions(a2), this;
  }, _setOptions: function(t2) {
    var e2;
    for (e2 in t2)
      this._setOption(e2, t2[e2]);
    return this;
  }, _setOption: function(t2, e2) {
    return "classes" === t2 && this._setOptionClasses(e2), this.options[t2] = e2, "disabled" === t2 && this._setOptionDisabled(e2), this;
  }, _setOptionClasses: function(e2) {
    var i2, s2, n2;
    for (i2 in e2)
      n2 = this.classesElementLookup[i2], e2[i2] !== this.options.classes[i2] && n2 && n2.length && (s2 = t(n2.get()), this._removeClass(n2, i2), s2.addClass(this._classes({ element: s2, keys: i2, classes: e2, add: true })));
  }, _setOptionDisabled: function(t2) {
    this._toggleClass(this.widget(), this.widgetFullName + "-disabled", null, !!t2), t2 && (this._removeClass(this.hoverable, null, "ui-state-hover"), this._removeClass(this.focusable, null, "ui-state-focus"));
  }, enable: function() {
    return this._setOptions({ disabled: false });
  }, disable: function() {
    return this._setOptions({ disabled: true });
  }, _classes: function(e2) {
    function i2(i3, o2) {
      var a2, r2;
      for (r2 = 0; i3.length > r2; r2++)
        a2 = n2.classesElementLookup[i3[r2]] || t(), a2 = e2.add ? t(t.unique(a2.get().concat(e2.element.get()))) : t(a2.not(e2.element).get()), n2.classesElementLookup[i3[r2]] = a2, s2.push(i3[r2]), o2 && e2.classes[i3[r2]] && s2.push(e2.classes[i3[r2]]);
    }
    var s2 = [], n2 = this;
    return e2 = t.extend({ element: this.element, classes: this.options.classes || {} }, e2), this._on(e2.element, { remove: "_untrackClassesElement" }), e2.keys && i2(e2.keys.match(/\S+/g) || [], true), e2.extra && i2(e2.extra.match(/\S+/g) || []), s2.join(" ");
  }, _untrackClassesElement: function(e2) {
    var i2 = this;
    t.each(i2.classesElementLookup, function(s2, n2) {
      -1 !== t.inArray(e2.target, n2) && (i2.classesElementLookup[s2] = t(n2.not(e2.target).get()));
    });
  }, _removeClass: function(t2, e2, i2) {
    return this._toggleClass(t2, e2, i2, false);
  }, _addClass: function(t2, e2, i2) {
    return this._toggleClass(t2, e2, i2, true);
  }, _toggleClass: function(t2, e2, i2, s2) {
    s2 = "boolean" == typeof s2 ? s2 : i2;
    var n2 = "string" == typeof t2 || null === t2, o2 = { extra: n2 ? e2 : i2, keys: n2 ? t2 : e2, element: n2 ? this.element : t2, add: s2 };
    return o2.element.toggleClass(this._classes(o2), s2), this;
  }, _on: function(e2, i2, s2) {
    var n2, o2 = this;
    "boolean" != typeof e2 && (s2 = i2, i2 = e2, e2 = false), s2 ? (i2 = n2 = t(i2), this.bindings = this.bindings.add(i2)) : (s2 = i2, i2 = this.element, n2 = this.widget()), t.each(s2, function(s3, a2) {
      function r2() {
        return e2 || o2.options.disabled !== true && !t(this).hasClass("ui-state-disabled") ? ("string" == typeof a2 ? o2[a2] : a2).apply(o2, arguments) : void 0;
      }
      "string" != typeof a2 && (r2.guid = a2.guid = a2.guid || r2.guid || t.guid++);
      var h2 = s3.match(/^([\w:-]*)\s*(.*)$/), l2 = h2[1] + o2.eventNamespace, c2 = h2[2];
      c2 ? n2.on(l2, c2, r2) : i2.on(l2, r2);
    });
  }, _off: function(e2, i2) {
    i2 = (i2 || "").split(" ").join(this.eventNamespace + " ") + this.eventNamespace, e2.off(i2).off(i2), this.bindings = t(this.bindings.not(e2).get()), this.focusable = t(this.focusable.not(e2).get()), this.hoverable = t(this.hoverable.not(e2).get());
  }, _delay: function(t2, e2) {
    function i2() {
      return ("string" == typeof t2 ? s2[t2] : t2).apply(s2, arguments);
    }
    var s2 = this;
    return setTimeout(i2, e2 || 0);
  }, _hoverable: function(e2) {
    this.hoverable = this.hoverable.add(e2), this._on(e2, { mouseenter: function(e3) {
      this._addClass(t(e3.currentTarget), null, "ui-state-hover");
    }, mouseleave: function(e3) {
      this._removeClass(t(e3.currentTarget), null, "ui-state-hover");
    } });
  }, _focusable: function(e2) {
    this.focusable = this.focusable.add(e2), this._on(e2, { focusin: function(e3) {
      this._addClass(t(e3.currentTarget), null, "ui-state-focus");
    }, focusout: function(e3) {
      this._removeClass(t(e3.currentTarget), null, "ui-state-focus");
    } });
  }, _trigger: function(e2, i2, s2) {
    var n2, o2, a2 = this.options[e2];
    if (s2 = s2 || {}, i2 = t.Event(i2), i2.type = (e2 === this.widgetEventPrefix ? e2 : this.widgetEventPrefix + e2).toLowerCase(), i2.target = this.element[0], o2 = i2.originalEvent)
      for (n2 in o2)
        n2 in i2 || (i2[n2] = o2[n2]);
    return this.element.trigger(i2, s2), !(t.isFunction(a2) && a2.apply(this.element[0], [i2].concat(s2)) === false || i2.isDefaultPrevented());
  } }, t.each({ show: "fadeIn", hide: "fadeOut" }, function(e2, i2) {
    t.Widget.prototype["_" + e2] = function(s2, n2, o2) {
      "string" == typeof n2 && (n2 = { effect: n2 });
      var a2, r2 = n2 ? n2 === true || "number" == typeof n2 ? i2 : n2.effect || i2 : e2;
      n2 = n2 || {}, "number" == typeof n2 && (n2 = { duration: n2 }), a2 = !t.isEmptyObject(n2), n2.complete = o2, n2.delay && s2.delay(n2.delay), a2 && t.effects && t.effects.effect[r2] ? s2[e2](n2) : r2 !== e2 && s2[r2] ? s2[r2](n2.duration, n2.easing, o2) : s2.queue(function(i3) {
        t(this)[e2](), o2 && o2.call(s2[0]), i3();
      });
    };
  }), t.widget, function() {
    function e2(t2, e3, i3) {
      return [parseFloat(t2[0]) * (u2.test(t2[0]) ? e3 / 100 : 1), parseFloat(t2[1]) * (u2.test(t2[1]) ? i3 / 100 : 1)];
    }
    function i2(e3, i3) {
      return parseInt(t.css(e3, i3), 10) || 0;
    }
    function s2(e3) {
      var i3 = e3[0];
      return 9 === i3.nodeType ? { width: e3.width(), height: e3.height(), offset: { top: 0, left: 0 } } : t.isWindow(i3) ? { width: e3.width(), height: e3.height(), offset: { top: e3.scrollTop(), left: e3.scrollLeft() } } : i3.preventDefault ? { width: 0, height: 0, offset: { top: i3.pageY, left: i3.pageX } } : { width: e3.outerWidth(), height: e3.outerHeight(), offset: e3.offset() };
    }
    var n2, o2 = Math.max, a2 = Math.abs, r2 = /left|center|right/, h2 = /top|center|bottom/, l2 = /[\+\-]\d+(\.[\d]+)?%?/, c2 = /^\w+/, u2 = /%$/, d2 = t.fn.position;
    t.position = { scrollbarWidth: function() {
      if (void 0 !== n2)
        return n2;
      var e3, i3, s3 = t("<div style='display:block;position:absolute;width:50px;height:50px;overflow:hidden;'><div style='height:100px;width:auto;'></div></div>"), o3 = s3.children()[0];
      return t("body").append(s3), e3 = o3.offsetWidth, s3.css("overflow", "scroll"), i3 = o3.offsetWidth, e3 === i3 && (i3 = s3[0].clientWidth), s3.remove(), n2 = e3 - i3;
    }, getScrollInfo: function(e3) {
      var i3 = e3.isWindow || e3.isDocument ? "" : e3.element.css("overflow-x"), s3 = e3.isWindow || e3.isDocument ? "" : e3.element.css("overflow-y"), n3 = "scroll" === i3 || "auto" === i3 && e3.width < e3.element[0].scrollWidth, o3 = "scroll" === s3 || "auto" === s3 && e3.height < e3.element[0].scrollHeight;
      return { width: o3 ? t.position.scrollbarWidth() : 0, height: n3 ? t.position.scrollbarWidth() : 0 };
    }, getWithinInfo: function(e3) {
      var i3 = t(e3 || window), s3 = t.isWindow(i3[0]), n3 = !!i3[0] && 9 === i3[0].nodeType, o3 = !s3 && !n3;
      return { element: i3, isWindow: s3, isDocument: n3, offset: o3 ? t(e3).offset() : { left: 0, top: 0 }, scrollLeft: i3.scrollLeft(), scrollTop: i3.scrollTop(), width: i3.outerWidth(), height: i3.outerHeight() };
    } }, t.fn.position = function(n3) {
      if (!n3 || !n3.of)
        return d2.apply(this, arguments);
      n3 = t.extend({}, n3);
      var u3, p2, f, g2, m2, _2, v2 = t(n3.of), b = t.position.getWithinInfo(n3.within), y = t.position.getScrollInfo(b), w = (n3.collision || "flip").split(" "), k = {};
      return _2 = s2(v2), v2[0].preventDefault && (n3.at = "left top"), p2 = _2.width, f = _2.height, g2 = _2.offset, m2 = t.extend({}, g2), t.each(["my", "at"], function() {
        var t2, e3, i3 = (n3[this] || "").split(" ");
        1 === i3.length && (i3 = r2.test(i3[0]) ? i3.concat(["center"]) : h2.test(i3[0]) ? ["center"].concat(i3) : ["center", "center"]), i3[0] = r2.test(i3[0]) ? i3[0] : "center", i3[1] = h2.test(i3[1]) ? i3[1] : "center", t2 = l2.exec(i3[0]), e3 = l2.exec(i3[1]), k[this] = [t2 ? t2[0] : 0, e3 ? e3[0] : 0], n3[this] = [c2.exec(i3[0])[0], c2.exec(i3[1])[0]];
      }), 1 === w.length && (w[1] = w[0]), "right" === n3.at[0] ? m2.left += p2 : "center" === n3.at[0] && (m2.left += p2 / 2), "bottom" === n3.at[1] ? m2.top += f : "center" === n3.at[1] && (m2.top += f / 2), u3 = e2(k.at, p2, f), m2.left += u3[0], m2.top += u3[1], this.each(function() {
        var s3, r3, h3 = t(this), l3 = h3.outerWidth(), c3 = h3.outerHeight(), d3 = i2(this, "marginLeft"), _3 = i2(this, "marginTop"), x = l3 + d3 + i2(this, "marginRight") + y.width, C = c3 + _3 + i2(this, "marginBottom") + y.height, D = t.extend({}, m2), I = e2(k.my, h3.outerWidth(), h3.outerHeight());
        "right" === n3.my[0] ? D.left -= l3 : "center" === n3.my[0] && (D.left -= l3 / 2), "bottom" === n3.my[1] ? D.top -= c3 : "center" === n3.my[1] && (D.top -= c3 / 2), D.left += I[0], D.top += I[1], s3 = { marginLeft: d3, marginTop: _3 }, t.each(["left", "top"], function(e3, i3) {
          t.ui.position[w[e3]] && t.ui.position[w[e3]][i3](D, { targetWidth: p2, targetHeight: f, elemWidth: l3, elemHeight: c3, collisionPosition: s3, collisionWidth: x, collisionHeight: C, offset: [u3[0] + I[0], u3[1] + I[1]], my: n3.my, at: n3.at, within: b, elem: h3 });
        }), n3.using && (r3 = function(t2) {
          var e3 = g2.left - D.left, i3 = e3 + p2 - l3, s4 = g2.top - D.top, r4 = s4 + f - c3, u4 = { target: { element: v2, left: g2.left, top: g2.top, width: p2, height: f }, element: { element: h3, left: D.left, top: D.top, width: l3, height: c3 }, horizontal: 0 > i3 ? "left" : e3 > 0 ? "right" : "center", vertical: 0 > r4 ? "top" : s4 > 0 ? "bottom" : "middle" };
          l3 > p2 && p2 > a2(e3 + i3) && (u4.horizontal = "center"), c3 > f && f > a2(s4 + r4) && (u4.vertical = "middle"), u4.important = o2(a2(e3), a2(i3)) > o2(a2(s4), a2(r4)) ? "horizontal" : "vertical", n3.using.call(this, t2, u4);
        }), h3.offset(t.extend(D, { using: r3 }));
      });
    }, t.ui.position = { fit: { left: function(t2, e3) {
      var i3, s3 = e3.within, n3 = s3.isWindow ? s3.scrollLeft : s3.offset.left, a3 = s3.width, r3 = t2.left - e3.collisionPosition.marginLeft, h3 = n3 - r3, l3 = r3 + e3.collisionWidth - a3 - n3;
      e3.collisionWidth > a3 ? h3 > 0 && 0 >= l3 ? (i3 = t2.left + h3 + e3.collisionWidth - a3 - n3, t2.left += h3 - i3) : t2.left = l3 > 0 && 0 >= h3 ? n3 : h3 > l3 ? n3 + a3 - e3.collisionWidth : n3 : h3 > 0 ? t2.left += h3 : l3 > 0 ? t2.left -= l3 : t2.left = o2(t2.left - r3, t2.left);
    }, top: function(t2, e3) {
      var i3, s3 = e3.within, n3 = s3.isWindow ? s3.scrollTop : s3.offset.top, a3 = e3.within.height, r3 = t2.top - e3.collisionPosition.marginTop, h3 = n3 - r3, l3 = r3 + e3.collisionHeight - a3 - n3;
      e3.collisionHeight > a3 ? h3 > 0 && 0 >= l3 ? (i3 = t2.top + h3 + e3.collisionHeight - a3 - n3, t2.top += h3 - i3) : t2.top = l3 > 0 && 0 >= h3 ? n3 : h3 > l3 ? n3 + a3 - e3.collisionHeight : n3 : h3 > 0 ? t2.top += h3 : l3 > 0 ? t2.top -= l3 : t2.top = o2(t2.top - r3, t2.top);
    } }, flip: { left: function(t2, e3) {
      var i3, s3, n3 = e3.within, o3 = n3.offset.left + n3.scrollLeft, r3 = n3.width, h3 = n3.isWindow ? n3.scrollLeft : n3.offset.left, l3 = t2.left - e3.collisionPosition.marginLeft, c3 = l3 - h3, u3 = l3 + e3.collisionWidth - r3 - h3, d3 = "left" === e3.my[0] ? -e3.elemWidth : "right" === e3.my[0] ? e3.elemWidth : 0, p2 = "left" === e3.at[0] ? e3.targetWidth : "right" === e3.at[0] ? -e3.targetWidth : 0, f = -2 * e3.offset[0];
      0 > c3 ? (i3 = t2.left + d3 + p2 + f + e3.collisionWidth - r3 - o3, (0 > i3 || a2(c3) > i3) && (t2.left += d3 + p2 + f)) : u3 > 0 && (s3 = t2.left - e3.collisionPosition.marginLeft + d3 + p2 + f - h3, (s3 > 0 || u3 > a2(s3)) && (t2.left += d3 + p2 + f));
    }, top: function(t2, e3) {
      var i3, s3, n3 = e3.within, o3 = n3.offset.top + n3.scrollTop, r3 = n3.height, h3 = n3.isWindow ? n3.scrollTop : n3.offset.top, l3 = t2.top - e3.collisionPosition.marginTop, c3 = l3 - h3, u3 = l3 + e3.collisionHeight - r3 - h3, d3 = "top" === e3.my[1], p2 = d3 ? -e3.elemHeight : "bottom" === e3.my[1] ? e3.elemHeight : 0, f = "top" === e3.at[1] ? e3.targetHeight : "bottom" === e3.at[1] ? -e3.targetHeight : 0, g2 = -2 * e3.offset[1];
      0 > c3 ? (s3 = t2.top + p2 + f + g2 + e3.collisionHeight - r3 - o3, (0 > s3 || a2(c3) > s3) && (t2.top += p2 + f + g2)) : u3 > 0 && (i3 = t2.top - e3.collisionPosition.marginTop + p2 + f + g2 - h3, (i3 > 0 || u3 > a2(i3)) && (t2.top += p2 + f + g2));
    } }, flipfit: { left: function() {
      t.ui.position.flip.left.apply(this, arguments), t.ui.position.fit.left.apply(this, arguments);
    }, top: function() {
      t.ui.position.flip.top.apply(this, arguments), t.ui.position.fit.top.apply(this, arguments);
    } } };
  }(), t.ui.position, t.extend(t.expr[":"], { data: t.expr.createPseudo ? t.expr.createPseudo(function(e2) {
    return function(i2) {
      return !!t.data(i2, e2);
    };
  }) : function(e2, i2, s2) {
    return !!t.data(e2, s2[3]);
  } }), t.fn.extend({ disableSelection: function() {
    var t2 = "onselectstart" in document.createElement("div") ? "selectstart" : "mousedown";
    return function() {
      return this.on(t2 + ".ui-disableSelection", function(t3) {
        t3.preventDefault();
      });
    };
  }(), enableSelection: function() {
    return this.off(".ui-disableSelection");
  } });
  var c = "ui-effects-", u = "ui-effects-style", d = "ui-effects-animated", p = t;
  t.effects = { effect: {} }, function(t2, e2) {
    function i2(t3, e3, i3) {
      var s3 = u2[e3.type] || {};
      return null == t3 ? i3 || !e3.def ? null : e3.def : (t3 = s3.floor ? ~~t3 : parseFloat(t3), isNaN(t3) ? e3.def : s3.mod ? (t3 + s3.mod) % s3.mod : 0 > t3 ? 0 : t3 > s3.max ? s3.max : t3);
    }
    function s2(i3) {
      var s3 = l2(), n3 = s3._rgba = [];
      return i3 = i3.toLowerCase(), f(h2, function(t3, o3) {
        var a3, r3 = o3.re.exec(i3), h3 = r3 && o3.parse(r3), l3 = o3.space || "rgba";
        return h3 ? (a3 = s3[l3](h3), s3[c2[l3].cache] = a3[c2[l3].cache], n3 = s3._rgba = a3._rgba, false) : e2;
      }), n3.length ? ("0,0,0,0" === n3.join() && t2.extend(n3, o2.transparent), s3) : o2[i3];
    }
    function n2(t3, e3, i3) {
      return i3 = (i3 + 1) % 1, 1 > 6 * i3 ? t3 + 6 * (e3 - t3) * i3 : 1 > 2 * i3 ? e3 : 2 > 3 * i3 ? t3 + 6 * (e3 - t3) * (2 / 3 - i3) : t3;
    }
    var o2, a2 = "backgroundColor borderBottomColor borderLeftColor borderRightColor borderTopColor color columnRuleColor outlineColor textDecorationColor textEmphasisColor", r2 = /^([\-+])=\s*(\d+\.?\d*)/, h2 = [{ re: /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/, parse: function(t3) {
      return [t3[1], t3[2], t3[3], t3[4]];
    } }, { re: /rgba?\(\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/, parse: function(t3) {
      return [2.55 * t3[1], 2.55 * t3[2], 2.55 * t3[3], t3[4]];
    } }, { re: /#([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})/, parse: function(t3) {
      return [parseInt(t3[1], 16), parseInt(t3[2], 16), parseInt(t3[3], 16)];
    } }, { re: /#([a-f0-9])([a-f0-9])([a-f0-9])/, parse: function(t3) {
      return [parseInt(t3[1] + t3[1], 16), parseInt(t3[2] + t3[2], 16), parseInt(t3[3] + t3[3], 16)];
    } }, { re: /hsla?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/, space: "hsla", parse: function(t3) {
      return [t3[1], t3[2] / 100, t3[3] / 100, t3[4]];
    } }], l2 = t2.Color = function(e3, i3, s3, n3) {
      return new t2.Color.fn.parse(e3, i3, s3, n3);
    }, c2 = { rgba: { props: { red: { idx: 0, type: "byte" }, green: { idx: 1, type: "byte" }, blue: { idx: 2, type: "byte" } } }, hsla: { props: { hue: { idx: 0, type: "degrees" }, saturation: { idx: 1, type: "percent" }, lightness: { idx: 2, type: "percent" } } } }, u2 = { "byte": { floor: true, max: 255 }, percent: { max: 1 }, degrees: { mod: 360, floor: true } }, d2 = l2.support = {}, p2 = t2("<p>")[0], f = t2.each;
    p2.style.cssText = "background-color:rgba(1,1,1,.5)", d2.rgba = p2.style.backgroundColor.indexOf("rgba") > -1, f(c2, function(t3, e3) {
      e3.cache = "_" + t3, e3.props.alpha = { idx: 3, type: "percent", def: 1 };
    }), l2.fn = t2.extend(l2.prototype, { parse: function(n3, a3, r3, h3) {
      if (n3 === e2)
        return this._rgba = [null, null, null, null], this;
      (n3.jquery || n3.nodeType) && (n3 = t2(n3).css(a3), a3 = e2);
      var u3 = this, d3 = t2.type(n3), p3 = this._rgba = [];
      return a3 !== e2 && (n3 = [n3, a3, r3, h3], d3 = "array"), "string" === d3 ? this.parse(s2(n3) || o2._default) : "array" === d3 ? (f(c2.rgba.props, function(t3, e3) {
        p3[e3.idx] = i2(n3[e3.idx], e3);
      }), this) : "object" === d3 ? (n3 instanceof l2 ? f(c2, function(t3, e3) {
        n3[e3.cache] && (u3[e3.cache] = n3[e3.cache].slice());
      }) : f(c2, function(e3, s3) {
        var o3 = s3.cache;
        f(s3.props, function(t3, e4) {
          if (!u3[o3] && s3.to) {
            if ("alpha" === t3 || null == n3[t3])
              return;
            u3[o3] = s3.to(u3._rgba);
          }
          u3[o3][e4.idx] = i2(n3[t3], e4, true);
        }), u3[o3] && 0 > t2.inArray(null, u3[o3].slice(0, 3)) && (u3[o3][3] = 1, s3.from && (u3._rgba = s3.from(u3[o3])));
      }), this) : e2;
    }, is: function(t3) {
      var i3 = l2(t3), s3 = true, n3 = this;
      return f(c2, function(t4, o3) {
        var a3, r3 = i3[o3.cache];
        return r3 && (a3 = n3[o3.cache] || o3.to && o3.to(n3._rgba) || [], f(o3.props, function(t5, i4) {
          return null != r3[i4.idx] ? s3 = r3[i4.idx] === a3[i4.idx] : e2;
        })), s3;
      }), s3;
    }, _space: function() {
      var t3 = [], e3 = this;
      return f(c2, function(i3, s3) {
        e3[s3.cache] && t3.push(i3);
      }), t3.pop();
    }, transition: function(t3, e3) {
      var s3 = l2(t3), n3 = s3._space(), o3 = c2[n3], a3 = 0 === this.alpha() ? l2("transparent") : this, r3 = a3[o3.cache] || o3.to(a3._rgba), h3 = r3.slice();
      return s3 = s3[o3.cache], f(o3.props, function(t4, n4) {
        var o4 = n4.idx, a4 = r3[o4], l3 = s3[o4], c3 = u2[n4.type] || {};
        null !== l3 && (null === a4 ? h3[o4] = l3 : (c3.mod && (l3 - a4 > c3.mod / 2 ? a4 += c3.mod : a4 - l3 > c3.mod / 2 && (a4 -= c3.mod)), h3[o4] = i2((l3 - a4) * e3 + a4, n4)));
      }), this[n3](h3);
    }, blend: function(e3) {
      if (1 === this._rgba[3])
        return this;
      var i3 = this._rgba.slice(), s3 = i3.pop(), n3 = l2(e3)._rgba;
      return l2(t2.map(i3, function(t3, e4) {
        return (1 - s3) * n3[e4] + s3 * t3;
      }));
    }, toRgbaString: function() {
      var e3 = "rgba(", i3 = t2.map(this._rgba, function(t3, e4) {
        return null == t3 ? e4 > 2 ? 1 : 0 : t3;
      });
      return 1 === i3[3] && (i3.pop(), e3 = "rgb("), e3 + i3.join() + ")";
    }, toHslaString: function() {
      var e3 = "hsla(", i3 = t2.map(this.hsla(), function(t3, e4) {
        return null == t3 && (t3 = e4 > 2 ? 1 : 0), e4 && 3 > e4 && (t3 = Math.round(100 * t3) + "%"), t3;
      });
      return 1 === i3[3] && (i3.pop(), e3 = "hsl("), e3 + i3.join() + ")";
    }, toHexString: function(e3) {
      var i3 = this._rgba.slice(), s3 = i3.pop();
      return e3 && i3.push(~~(255 * s3)), "#" + t2.map(i3, function(t3) {
        return t3 = (t3 || 0).toString(16), 1 === t3.length ? "0" + t3 : t3;
      }).join("");
    }, toString: function() {
      return 0 === this._rgba[3] ? "transparent" : this.toRgbaString();
    } }), l2.fn.parse.prototype = l2.fn, c2.hsla.to = function(t3) {
      if (null == t3[0] || null == t3[1] || null == t3[2])
        return [null, null, null, t3[3]];
      var e3, i3, s3 = t3[0] / 255, n3 = t3[1] / 255, o3 = t3[2] / 255, a3 = t3[3], r3 = Math.max(s3, n3, o3), h3 = Math.min(s3, n3, o3), l3 = r3 - h3, c3 = r3 + h3, u3 = 0.5 * c3;
      return e3 = h3 === r3 ? 0 : s3 === r3 ? 60 * (n3 - o3) / l3 + 360 : n3 === r3 ? 60 * (o3 - s3) / l3 + 120 : 60 * (s3 - n3) / l3 + 240, i3 = 0 === l3 ? 0 : 0.5 >= u3 ? l3 / c3 : l3 / (2 - c3), [Math.round(e3) % 360, i3, u3, null == a3 ? 1 : a3];
    }, c2.hsla.from = function(t3) {
      if (null == t3[0] || null == t3[1] || null == t3[2])
        return [null, null, null, t3[3]];
      var e3 = t3[0] / 360, i3 = t3[1], s3 = t3[2], o3 = t3[3], a3 = 0.5 >= s3 ? s3 * (1 + i3) : s3 + i3 - s3 * i3, r3 = 2 * s3 - a3;
      return [Math.round(255 * n2(r3, a3, e3 + 1 / 3)), Math.round(255 * n2(r3, a3, e3)), Math.round(255 * n2(r3, a3, e3 - 1 / 3)), o3];
    }, f(c2, function(s3, n3) {
      var o3 = n3.props, a3 = n3.cache, h3 = n3.to, c3 = n3.from;
      l2.fn[s3] = function(s4) {
        if (h3 && !this[a3] && (this[a3] = h3(this._rgba)), s4 === e2)
          return this[a3].slice();
        var n4, r3 = t2.type(s4), u3 = "array" === r3 || "object" === r3 ? s4 : arguments, d3 = this[a3].slice();
        return f(o3, function(t3, e3) {
          var s5 = u3["object" === r3 ? t3 : e3.idx];
          null == s5 && (s5 = d3[e3.idx]), d3[e3.idx] = i2(s5, e3);
        }), c3 ? (n4 = l2(c3(d3)), n4[a3] = d3, n4) : l2(d3);
      }, f(o3, function(e3, i3) {
        l2.fn[e3] || (l2.fn[e3] = function(n4) {
          var o4, a4 = t2.type(n4), h4 = "alpha" === e3 ? this._hsla ? "hsla" : "rgba" : s3, l3 = this[h4](), c4 = l3[i3.idx];
          return "undefined" === a4 ? c4 : ("function" === a4 && (n4 = n4.call(this, c4), a4 = t2.type(n4)), null == n4 && i3.empty ? this : ("string" === a4 && (o4 = r2.exec(n4), o4 && (n4 = c4 + parseFloat(o4[2]) * ("+" === o4[1] ? 1 : -1))), l3[i3.idx] = n4, this[h4](l3)));
        });
      });
    }), l2.hook = function(e3) {
      var i3 = e3.split(" ");
      f(i3, function(e4, i4) {
        t2.cssHooks[i4] = { set: function(e5, n3) {
          var o3, a3, r3 = "";
          if ("transparent" !== n3 && ("string" !== t2.type(n3) || (o3 = s2(n3)))) {
            if (n3 = l2(o3 || n3), !d2.rgba && 1 !== n3._rgba[3]) {
              for (a3 = "backgroundColor" === i4 ? e5.parentNode : e5; ("" === r3 || "transparent" === r3) && a3 && a3.style; )
                try {
                  r3 = t2.css(a3, "backgroundColor"), a3 = a3.parentNode;
                } catch (h3) {
                }
              n3 = n3.blend(r3 && "transparent" !== r3 ? r3 : "_default");
            }
            n3 = n3.toRgbaString();
          }
          try {
            e5.style[i4] = n3;
          } catch (h3) {
          }
        } }, t2.fx.step[i4] = function(e5) {
          e5.colorInit || (e5.start = l2(e5.elem, i4), e5.end = l2(e5.end), e5.colorInit = true), t2.cssHooks[i4].set(e5.elem, e5.start.transition(e5.end, e5.pos));
        };
      });
    }, l2.hook(a2), t2.cssHooks.borderColor = { expand: function(t3) {
      var e3 = {};
      return f(["Top", "Right", "Bottom", "Left"], function(i3, s3) {
        e3["border" + s3 + "Color"] = t3;
      }), e3;
    } }, o2 = t2.Color.names = { aqua: "#00ffff", black: "#000000", blue: "#0000ff", fuchsia: "#ff00ff", gray: "#808080", green: "#008000", lime: "#00ff00", maroon: "#800000", navy: "#000080", olive: "#808000", purple: "#800080", red: "#ff0000", silver: "#c0c0c0", teal: "#008080", white: "#ffffff", yellow: "#ffff00", transparent: [null, null, null, 0], _default: "#ffffff" };
  }(p), function() {
    function e2(e3) {
      var i3, s3, n3 = e3.ownerDocument.defaultView ? e3.ownerDocument.defaultView.getComputedStyle(e3, null) : e3.currentStyle, o2 = {};
      if (n3 && n3.length && n3[0] && n3[n3[0]])
        for (s3 = n3.length; s3--; )
          i3 = n3[s3], "string" == typeof n3[i3] && (o2[t.camelCase(i3)] = n3[i3]);
      else
        for (i3 in n3)
          "string" == typeof n3[i3] && (o2[i3] = n3[i3]);
      return o2;
    }
    function i2(e3, i3) {
      var s3, o2, a2 = {};
      for (s3 in i3)
        o2 = i3[s3], e3[s3] !== o2 && (n2[s3] || (t.fx.step[s3] || !isNaN(parseFloat(o2))) && (a2[s3] = o2));
      return a2;
    }
    var s2 = ["add", "remove", "toggle"], n2 = { border: 1, borderBottom: 1, borderColor: 1, borderLeft: 1, borderRight: 1, borderTop: 1, borderWidth: 1, margin: 1, padding: 1 };
    t.each(["borderLeftStyle", "borderRightStyle", "borderBottomStyle", "borderTopStyle"], function(e3, i3) {
      t.fx.step[i3] = function(t2) {
        ("none" !== t2.end && !t2.setAttr || 1 === t2.pos && !t2.setAttr) && (p.style(t2.elem, i3, t2.end), t2.setAttr = true);
      };
    }), t.fn.addBack || (t.fn.addBack = function(t2) {
      return this.add(null == t2 ? this.prevObject : this.prevObject.filter(t2));
    }), t.effects.animateClass = function(n3, o2, a2, r2) {
      var h2 = t.speed(o2, a2, r2);
      return this.queue(function() {
        var o3, a3 = t(this), r3 = a3.attr("class") || "", l2 = h2.children ? a3.find("*").addBack() : a3;
        l2 = l2.map(function() {
          var i3 = t(this);
          return { el: i3, start: e2(this) };
        }), o3 = function() {
          t.each(s2, function(t2, e3) {
            n3[e3] && a3[e3 + "Class"](n3[e3]);
          });
        }, o3(), l2 = l2.map(function() {
          return this.end = e2(this.el[0]), this.diff = i2(this.start, this.end), this;
        }), a3.attr("class", r3), l2 = l2.map(function() {
          var e3 = this, i3 = t.Deferred(), s3 = t.extend({}, h2, { queue: false, complete: function() {
            i3.resolve(e3);
          } });
          return this.el.animate(this.diff, s3), i3.promise();
        }), t.when.apply(t, l2.get()).done(function() {
          o3(), t.each(arguments, function() {
            var e3 = this.el;
            t.each(this.diff, function(t2) {
              e3.css(t2, "");
            });
          }), h2.complete.call(a3[0]);
        });
      });
    }, t.fn.extend({ addClass: function(e3) {
      return function(i3, s3, n3, o2) {
        return s3 ? t.effects.animateClass.call(this, { add: i3 }, s3, n3, o2) : e3.apply(this, arguments);
      };
    }(t.fn.addClass), removeClass: function(e3) {
      return function(i3, s3, n3, o2) {
        return arguments.length > 1 ? t.effects.animateClass.call(this, { remove: i3 }, s3, n3, o2) : e3.apply(this, arguments);
      };
    }(t.fn.removeClass), toggleClass: function(e3) {
      return function(i3, s3, n3, o2, a2) {
        return "boolean" == typeof s3 || void 0 === s3 ? n3 ? t.effects.animateClass.call(this, s3 ? { add: i3 } : { remove: i3 }, n3, o2, a2) : e3.apply(this, arguments) : t.effects.animateClass.call(this, { toggle: i3 }, s3, n3, o2);
      };
    }(t.fn.toggleClass), switchClass: function(e3, i3, s3, n3, o2) {
      return t.effects.animateClass.call(this, { add: i3, remove: e3 }, s3, n3, o2);
    } });
  }(), function() {
    function e2(e3, i3, s3, n2) {
      return t.isPlainObject(e3) && (i3 = e3, e3 = e3.effect), e3 = { effect: e3 }, null == i3 && (i3 = {}), t.isFunction(i3) && (n2 = i3, s3 = null, i3 = {}), ("number" == typeof i3 || t.fx.speeds[i3]) && (n2 = s3, s3 = i3, i3 = {}), t.isFunction(s3) && (n2 = s3, s3 = null), i3 && t.extend(e3, i3), s3 = s3 || i3.duration, e3.duration = t.fx.off ? 0 : "number" == typeof s3 ? s3 : s3 in t.fx.speeds ? t.fx.speeds[s3] : t.fx.speeds._default, e3.complete = n2 || i3.complete, e3;
    }
    function i2(e3) {
      return !e3 || "number" == typeof e3 || t.fx.speeds[e3] ? true : "string" != typeof e3 || t.effects.effect[e3] ? t.isFunction(e3) ? true : "object" != typeof e3 || e3.effect ? false : true : true;
    }
    function s2(t2, e3) {
      var i3 = e3.outerWidth(), s3 = e3.outerHeight(), n2 = /^rect\((-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto)\)$/, o2 = n2.exec(t2) || ["", 0, i3, s3, 0];
      return { top: parseFloat(o2[1]) || 0, right: "auto" === o2[2] ? i3 : parseFloat(o2[2]), bottom: "auto" === o2[3] ? s3 : parseFloat(o2[3]), left: parseFloat(o2[4]) || 0 };
    }
    t.expr && t.expr.filters && t.expr.filters.animated && (t.expr.filters.animated = function(e3) {
      return function(i3) {
        return !!t(i3).data(d) || e3(i3);
      };
    }(t.expr.filters.animated)), t.uiBackCompat !== false && t.extend(t.effects, { save: function(t2, e3) {
      for (var i3 = 0, s3 = e3.length; s3 > i3; i3++)
        null !== e3[i3] && t2.data(c + e3[i3], t2[0].style[e3[i3]]);
    }, restore: function(t2, e3) {
      for (var i3, s3 = 0, n2 = e3.length; n2 > s3; s3++)
        null !== e3[s3] && (i3 = t2.data(c + e3[s3]), t2.css(e3[s3], i3));
    }, setMode: function(t2, e3) {
      return "toggle" === e3 && (e3 = t2.is(":hidden") ? "show" : "hide"), e3;
    }, createWrapper: function(e3) {
      if (e3.parent().is(".ui-effects-wrapper"))
        return e3.parent();
      var i3 = { width: e3.outerWidth(true), height: e3.outerHeight(true), "float": e3.css("float") }, s3 = t("<div></div>").addClass("ui-effects-wrapper").css({ fontSize: "100%", background: "transparent", border: "none", margin: 0, padding: 0 }), n2 = { width: e3.width(), height: e3.height() }, o2 = document.activeElement;
      try {
        o2.id;
      } catch (a2) {
        o2 = document.body;
      }
      return e3.wrap(s3), (e3[0] === o2 || t.contains(e3[0], o2)) && t(o2).trigger("focus"), s3 = e3.parent(), "static" === e3.css("position") ? (s3.css({ position: "relative" }), e3.css({ position: "relative" })) : (t.extend(i3, { position: e3.css("position"), zIndex: e3.css("z-index") }), t.each(["top", "left", "bottom", "right"], function(t2, s4) {
        i3[s4] = e3.css(s4), isNaN(parseInt(i3[s4], 10)) && (i3[s4] = "auto");
      }), e3.css({ position: "relative", top: 0, left: 0, right: "auto", bottom: "auto" })), e3.css(n2), s3.css(i3).show();
    }, removeWrapper: function(e3) {
      var i3 = document.activeElement;
      return e3.parent().is(".ui-effects-wrapper") && (e3.parent().replaceWith(e3), (e3[0] === i3 || t.contains(e3[0], i3)) && t(i3).trigger("focus")), e3;
    } }), t.extend(t.effects, { version: "1.12.1", define: function(e3, i3, s3) {
      return s3 || (s3 = i3, i3 = "effect"), t.effects.effect[e3] = s3, t.effects.effect[e3].mode = i3, s3;
    }, scaledDimensions: function(t2, e3, i3) {
      if (0 === e3)
        return { height: 0, width: 0, outerHeight: 0, outerWidth: 0 };
      var s3 = "horizontal" !== i3 ? (e3 || 100) / 100 : 1, n2 = "vertical" !== i3 ? (e3 || 100) / 100 : 1;
      return { height: t2.height() * n2, width: t2.width() * s3, outerHeight: t2.outerHeight() * n2, outerWidth: t2.outerWidth() * s3 };
    }, clipToBox: function(t2) {
      return { width: t2.clip.right - t2.clip.left, height: t2.clip.bottom - t2.clip.top, left: t2.clip.left, top: t2.clip.top };
    }, unshift: function(t2, e3, i3) {
      var s3 = t2.queue();
      e3 > 1 && s3.splice.apply(s3, [1, 0].concat(s3.splice(e3, i3))), t2.dequeue();
    }, saveStyle: function(t2) {
      t2.data(u, t2[0].style.cssText);
    }, restoreStyle: function(t2) {
      t2[0].style.cssText = t2.data(u) || "", t2.removeData(u);
    }, mode: function(t2, e3) {
      var i3 = t2.is(":hidden");
      return "toggle" === e3 && (e3 = i3 ? "show" : "hide"), (i3 ? "hide" === e3 : "show" === e3) && (e3 = "none"), e3;
    }, getBaseline: function(t2, e3) {
      var i3, s3;
      switch (t2[0]) {
        case "top":
          i3 = 0;
          break;
        case "middle":
          i3 = 0.5;
          break;
        case "bottom":
          i3 = 1;
          break;
        default:
          i3 = t2[0] / e3.height;
      }
      switch (t2[1]) {
        case "left":
          s3 = 0;
          break;
        case "center":
          s3 = 0.5;
          break;
        case "right":
          s3 = 1;
          break;
        default:
          s3 = t2[1] / e3.width;
      }
      return { x: s3, y: i3 };
    }, createPlaceholder: function(e3) {
      var i3, s3 = e3.css("position"), n2 = e3.position();
      return e3.css({ marginTop: e3.css("marginTop"), marginBottom: e3.css("marginBottom"), marginLeft: e3.css("marginLeft"), marginRight: e3.css("marginRight") }).outerWidth(e3.outerWidth()).outerHeight(e3.outerHeight()), /^(static|relative)/.test(s3) && (s3 = "absolute", i3 = t("<" + e3[0].nodeName + ">").insertAfter(e3).css({ display: /^(inline|ruby)/.test(e3.css("display")) ? "inline-block" : "block", visibility: "hidden", marginTop: e3.css("marginTop"), marginBottom: e3.css("marginBottom"), marginLeft: e3.css("marginLeft"), marginRight: e3.css("marginRight"), "float": e3.css("float") }).outerWidth(e3.outerWidth()).outerHeight(e3.outerHeight()).addClass("ui-effects-placeholder"), e3.data(c + "placeholder", i3)), e3.css({ position: s3, left: n2.left, top: n2.top }), i3;
    }, removePlaceholder: function(t2) {
      var e3 = c + "placeholder", i3 = t2.data(e3);
      i3 && (i3.remove(), t2.removeData(e3));
    }, cleanUp: function(e3) {
      t.effects.restoreStyle(e3), t.effects.removePlaceholder(e3);
    }, setTransition: function(e3, i3, s3, n2) {
      return n2 = n2 || {}, t.each(i3, function(t2, i4) {
        var o2 = e3.cssUnit(i4);
        o2[0] > 0 && (n2[i4] = o2[0] * s3 + o2[1]);
      }), n2;
    } }), t.fn.extend({ effect: function() {
      function i3(e3) {
        function i4() {
          r3.removeData(d), t.effects.cleanUp(r3), "hide" === s3.mode && r3.hide(), a3();
        }
        function a3() {
          t.isFunction(h2) && h2.call(r3[0]), t.isFunction(e3) && e3();
        }
        var r3 = t(this);
        s3.mode = c2.shift(), t.uiBackCompat === false || o2 ? "none" === s3.mode ? (r3[l2](), a3()) : n2.call(r3[0], s3, i4) : (r3.is(":hidden") ? "hide" === l2 : "show" === l2) ? (r3[l2](), a3()) : n2.call(r3[0], s3, a3);
      }
      var s3 = e2.apply(this, arguments), n2 = t.effects.effect[s3.effect], o2 = n2.mode, a2 = s3.queue, r2 = a2 || "fx", h2 = s3.complete, l2 = s3.mode, c2 = [], u2 = function(e3) {
        var i4 = t(this), s4 = t.effects.mode(i4, l2) || o2;
        i4.data(d, true), c2.push(s4), o2 && ("show" === s4 || s4 === o2 && "hide" === s4) && i4.show(), o2 && "none" === s4 || t.effects.saveStyle(i4), t.isFunction(e3) && e3();
      };
      return t.fx.off || !n2 ? l2 ? this[l2](s3.duration, h2) : this.each(function() {
        h2 && h2.call(this);
      }) : a2 === false ? this.each(u2).each(i3) : this.queue(r2, u2).queue(r2, i3);
    }, show: function(t2) {
      return function(s3) {
        if (i2(s3))
          return t2.apply(this, arguments);
        var n2 = e2.apply(this, arguments);
        return n2.mode = "show", this.effect.call(this, n2);
      };
    }(t.fn.show), hide: function(t2) {
      return function(s3) {
        if (i2(s3))
          return t2.apply(this, arguments);
        var n2 = e2.apply(this, arguments);
        return n2.mode = "hide", this.effect.call(this, n2);
      };
    }(t.fn.hide), toggle: function(t2) {
      return function(s3) {
        if (i2(s3) || "boolean" == typeof s3)
          return t2.apply(this, arguments);
        var n2 = e2.apply(this, arguments);
        return n2.mode = "toggle", this.effect.call(this, n2);
      };
    }(t.fn.toggle), cssUnit: function(e3) {
      var i3 = this.css(e3), s3 = [];
      return t.each(["em", "px", "%", "pt"], function(t2, e4) {
        i3.indexOf(e4) > 0 && (s3 = [parseFloat(i3), e4]);
      }), s3;
    }, cssClip: function(t2) {
      return t2 ? this.css("clip", "rect(" + t2.top + "px " + t2.right + "px " + t2.bottom + "px " + t2.left + "px)") : s2(this.css("clip"), this);
    }, transfer: function(e3, i3) {
      var s3 = t(this), n2 = t(e3.to), o2 = "fixed" === n2.css("position"), a2 = t("body"), r2 = o2 ? a2.scrollTop() : 0, h2 = o2 ? a2.scrollLeft() : 0, l2 = n2.offset(), c2 = { top: l2.top - r2, left: l2.left - h2, height: n2.innerHeight(), width: n2.innerWidth() }, u2 = s3.offset(), d2 = t("<div class='ui-effects-transfer'></div>").appendTo("body").addClass(e3.className).css({ top: u2.top - r2, left: u2.left - h2, height: s3.innerHeight(), width: s3.innerWidth(), position: o2 ? "fixed" : "absolute" }).animate(c2, e3.duration, e3.easing, function() {
        d2.remove(), t.isFunction(i3) && i3();
      });
    } }), t.fx.step.clip = function(e3) {
      e3.clipInit || (e3.start = t(e3.elem).cssClip(), "string" == typeof e3.end && (e3.end = s2(e3.end, e3.elem)), e3.clipInit = true), t(e3.elem).cssClip({ top: e3.pos * (e3.end.top - e3.start.top) + e3.start.top, right: e3.pos * (e3.end.right - e3.start.right) + e3.start.right, bottom: e3.pos * (e3.end.bottom - e3.start.bottom) + e3.start.bottom, left: e3.pos * (e3.end.left - e3.start.left) + e3.start.left });
    };
  }(), function() {
    var e2 = {};
    t.each(["Quad", "Cubic", "Quart", "Quint", "Expo"], function(t2, i2) {
      e2[i2] = function(e3) {
        return Math.pow(e3, t2 + 2);
      };
    }), t.extend(e2, { Sine: function(t2) {
      return 1 - Math.cos(t2 * Math.PI / 2);
    }, Circ: function(t2) {
      return 1 - Math.sqrt(1 - t2 * t2);
    }, Elastic: function(t2) {
      return 0 === t2 || 1 === t2 ? t2 : -Math.pow(2, 8 * (t2 - 1)) * Math.sin((80 * (t2 - 1) - 7.5) * Math.PI / 15);
    }, Back: function(t2) {
      return t2 * t2 * (3 * t2 - 2);
    }, Bounce: function(t2) {
      for (var e3, i2 = 4; ((e3 = Math.pow(2, --i2)) - 1) / 11 > t2; )
        ;
      return 1 / Math.pow(4, 3 - i2) - 7.5625 * Math.pow((3 * e3 - 2) / 22 - t2, 2);
    } }), t.each(e2, function(e3, i2) {
      t.easing["easeIn" + e3] = i2, t.easing["easeOut" + e3] = function(t2) {
        return 1 - i2(1 - t2);
      }, t.easing["easeInOut" + e3] = function(t2) {
        return 0.5 > t2 ? i2(2 * t2) / 2 : 1 - i2(-2 * t2 + 2) / 2;
      };
    });
  }();
  t.effects;
  t.effects.define("blind", "hide", function(e2, i2) {
    var s2 = { up: ["bottom", "top"], vertical: ["bottom", "top"], down: ["top", "bottom"], left: ["right", "left"], horizontal: ["right", "left"], right: ["left", "right"] }, n2 = t(this), o2 = e2.direction || "up", a2 = n2.cssClip(), r2 = { clip: t.extend({}, a2) }, h2 = t.effects.createPlaceholder(n2);
    r2.clip[s2[o2][0]] = r2.clip[s2[o2][1]], "show" === e2.mode && (n2.cssClip(r2.clip), h2 && h2.css(t.effects.clipToBox(r2)), r2.clip = a2), h2 && h2.animate(t.effects.clipToBox(r2), e2.duration, e2.easing), n2.animate(r2, { queue: false, duration: e2.duration, easing: e2.easing, complete: i2 });
  }), t.effects.define("bounce", function(e2, i2) {
    var s2, n2, o2, a2 = t(this), r2 = e2.mode, h2 = "hide" === r2, l2 = "show" === r2, c2 = e2.direction || "up", u2 = e2.distance, d2 = e2.times || 5, p2 = 2 * d2 + (l2 || h2 ? 1 : 0), f = e2.duration / p2, g2 = e2.easing, m2 = "up" === c2 || "down" === c2 ? "top" : "left", _2 = "up" === c2 || "left" === c2, v2 = 0, b = a2.queue().length;
    for (t.effects.createPlaceholder(a2), o2 = a2.css(m2), u2 || (u2 = a2["top" === m2 ? "outerHeight" : "outerWidth"]() / 3), l2 && (n2 = { opacity: 1 }, n2[m2] = o2, a2.css("opacity", 0).css(m2, _2 ? 2 * -u2 : 2 * u2).animate(n2, f, g2)), h2 && (u2 /= Math.pow(2, d2 - 1)), n2 = {}, n2[m2] = o2; d2 > v2; v2++)
      s2 = {}, s2[m2] = (_2 ? "-=" : "+=") + u2, a2.animate(s2, f, g2).animate(n2, f, g2), u2 = h2 ? 2 * u2 : u2 / 2;
    h2 && (s2 = { opacity: 0 }, s2[m2] = (_2 ? "-=" : "+=") + u2, a2.animate(s2, f, g2)), a2.queue(i2), t.effects.unshift(a2, b, p2 + 1);
  }), t.effects.define("clip", "hide", function(e2, i2) {
    var s2, n2 = {}, o2 = t(this), a2 = e2.direction || "vertical", r2 = "both" === a2, h2 = r2 || "horizontal" === a2, l2 = r2 || "vertical" === a2;
    s2 = o2.cssClip(), n2.clip = { top: l2 ? (s2.bottom - s2.top) / 2 : s2.top, right: h2 ? (s2.right - s2.left) / 2 : s2.right, bottom: l2 ? (s2.bottom - s2.top) / 2 : s2.bottom, left: h2 ? (s2.right - s2.left) / 2 : s2.left }, t.effects.createPlaceholder(o2), "show" === e2.mode && (o2.cssClip(n2.clip), n2.clip = s2), o2.animate(n2, { queue: false, duration: e2.duration, easing: e2.easing, complete: i2 });
  }), t.effects.define("drop", "hide", function(e2, i2) {
    var s2, n2 = t(this), o2 = e2.mode, a2 = "show" === o2, r2 = e2.direction || "left", h2 = "up" === r2 || "down" === r2 ? "top" : "left", l2 = "up" === r2 || "left" === r2 ? "-=" : "+=", c2 = "+=" === l2 ? "-=" : "+=", u2 = { opacity: 0 };
    t.effects.createPlaceholder(n2), s2 = e2.distance || n2["top" === h2 ? "outerHeight" : "outerWidth"](true) / 2, u2[h2] = l2 + s2, a2 && (n2.css(u2), u2[h2] = c2 + s2, u2.opacity = 1), n2.animate(u2, { queue: false, duration: e2.duration, easing: e2.easing, complete: i2 });
  }), t.effects.define("explode", "hide", function(e2, i2) {
    function s2() {
      b.push(this), b.length === u2 * d2 && n2();
    }
    function n2() {
      p2.css({ visibility: "visible" }), t(b).remove(), i2();
    }
    var o2, a2, r2, h2, l2, c2, u2 = e2.pieces ? Math.round(Math.sqrt(e2.pieces)) : 3, d2 = u2, p2 = t(this), f = e2.mode, g2 = "show" === f, m2 = p2.show().css("visibility", "hidden").offset(), _2 = Math.ceil(p2.outerWidth() / d2), v2 = Math.ceil(p2.outerHeight() / u2), b = [];
    for (o2 = 0; u2 > o2; o2++)
      for (h2 = m2.top + o2 * v2, c2 = o2 - (u2 - 1) / 2, a2 = 0; d2 > a2; a2++)
        r2 = m2.left + a2 * _2, l2 = a2 - (d2 - 1) / 2, p2.clone().appendTo("body").wrap("<div></div>").css({ position: "absolute", visibility: "visible", left: -a2 * _2, top: -o2 * v2 }).parent().addClass("ui-effects-explode").css({ position: "absolute", overflow: "hidden", width: _2, height: v2, left: r2 + (g2 ? l2 * _2 : 0), top: h2 + (g2 ? c2 * v2 : 0), opacity: g2 ? 0 : 1 }).animate({ left: r2 + (g2 ? 0 : l2 * _2), top: h2 + (g2 ? 0 : c2 * v2), opacity: g2 ? 1 : 0 }, e2.duration || 500, e2.easing, s2);
  }), t.effects.define("fade", "toggle", function(e2, i2) {
    var s2 = "show" === e2.mode;
    t(this).css("opacity", s2 ? 0 : 1).animate({ opacity: s2 ? 1 : 0 }, { queue: false, duration: e2.duration, easing: e2.easing, complete: i2 });
  }), t.effects.define("fold", "hide", function(e2, i2) {
    var s2 = t(this), n2 = e2.mode, o2 = "show" === n2, a2 = "hide" === n2, r2 = e2.size || 15, h2 = /([0-9]+)%/.exec(r2), l2 = !!e2.horizFirst, c2 = l2 ? ["right", "bottom"] : ["bottom", "right"], u2 = e2.duration / 2, d2 = t.effects.createPlaceholder(s2), p2 = s2.cssClip(), f = { clip: t.extend({}, p2) }, g2 = { clip: t.extend({}, p2) }, m2 = [p2[c2[0]], p2[c2[1]]], _2 = s2.queue().length;
    h2 && (r2 = parseInt(h2[1], 10) / 100 * m2[a2 ? 0 : 1]), f.clip[c2[0]] = r2, g2.clip[c2[0]] = r2, g2.clip[c2[1]] = 0, o2 && (s2.cssClip(g2.clip), d2 && d2.css(t.effects.clipToBox(g2)), g2.clip = p2), s2.queue(function(i3) {
      d2 && d2.animate(t.effects.clipToBox(f), u2, e2.easing).animate(t.effects.clipToBox(g2), u2, e2.easing), i3();
    }).animate(f, u2, e2.easing).animate(g2, u2, e2.easing).queue(i2), t.effects.unshift(s2, _2, 4);
  }), t.effects.define("highlight", "show", function(e2, i2) {
    var s2 = t(this), n2 = { backgroundColor: s2.css("backgroundColor") };
    "hide" === e2.mode && (n2.opacity = 0), t.effects.saveStyle(s2), s2.css({ backgroundImage: "none", backgroundColor: e2.color || "#ffff99" }).animate(n2, { queue: false, duration: e2.duration, easing: e2.easing, complete: i2 });
  }), t.effects.define("size", function(e2, i2) {
    var s2, n2, o2, a2 = t(this), r2 = ["fontSize"], h2 = ["borderTopWidth", "borderBottomWidth", "paddingTop", "paddingBottom"], l2 = ["borderLeftWidth", "borderRightWidth", "paddingLeft", "paddingRight"], c2 = e2.mode, u2 = "effect" !== c2, d2 = e2.scale || "both", p2 = e2.origin || ["middle", "center"], f = a2.css("position"), g2 = a2.position(), m2 = t.effects.scaledDimensions(a2), _2 = e2.from || m2, v2 = e2.to || t.effects.scaledDimensions(a2, 0);
    t.effects.createPlaceholder(a2), "show" === c2 && (o2 = _2, _2 = v2, v2 = o2), n2 = { from: { y: _2.height / m2.height, x: _2.width / m2.width }, to: { y: v2.height / m2.height, x: v2.width / m2.width } }, ("box" === d2 || "both" === d2) && (n2.from.y !== n2.to.y && (_2 = t.effects.setTransition(a2, h2, n2.from.y, _2), v2 = t.effects.setTransition(a2, h2, n2.to.y, v2)), n2.from.x !== n2.to.x && (_2 = t.effects.setTransition(a2, l2, n2.from.x, _2), v2 = t.effects.setTransition(a2, l2, n2.to.x, v2))), ("content" === d2 || "both" === d2) && n2.from.y !== n2.to.y && (_2 = t.effects.setTransition(a2, r2, n2.from.y, _2), v2 = t.effects.setTransition(a2, r2, n2.to.y, v2)), p2 && (s2 = t.effects.getBaseline(p2, m2), _2.top = (m2.outerHeight - _2.outerHeight) * s2.y + g2.top, _2.left = (m2.outerWidth - _2.outerWidth) * s2.x + g2.left, v2.top = (m2.outerHeight - v2.outerHeight) * s2.y + g2.top, v2.left = (m2.outerWidth - v2.outerWidth) * s2.x + g2.left), a2.css(_2), ("content" === d2 || "both" === d2) && (h2 = h2.concat(["marginTop", "marginBottom"]).concat(r2), l2 = l2.concat(["marginLeft", "marginRight"]), a2.find("*[width]").each(function() {
      var i3 = t(this), s3 = t.effects.scaledDimensions(i3), o3 = { height: s3.height * n2.from.y, width: s3.width * n2.from.x, outerHeight: s3.outerHeight * n2.from.y, outerWidth: s3.outerWidth * n2.from.x }, a3 = { height: s3.height * n2.to.y, width: s3.width * n2.to.x, outerHeight: s3.height * n2.to.y, outerWidth: s3.width * n2.to.x };
      n2.from.y !== n2.to.y && (o3 = t.effects.setTransition(i3, h2, n2.from.y, o3), a3 = t.effects.setTransition(i3, h2, n2.to.y, a3)), n2.from.x !== n2.to.x && (o3 = t.effects.setTransition(i3, l2, n2.from.x, o3), a3 = t.effects.setTransition(i3, l2, n2.to.x, a3)), u2 && t.effects.saveStyle(i3), i3.css(o3), i3.animate(a3, e2.duration, e2.easing, function() {
        u2 && t.effects.restoreStyle(i3);
      });
    })), a2.animate(v2, { queue: false, duration: e2.duration, easing: e2.easing, complete: function() {
      var e3 = a2.offset();
      0 === v2.opacity && a2.css("opacity", _2.opacity), u2 || (a2.css("position", "static" === f ? "relative" : f).offset(e3), t.effects.saveStyle(a2)), i2();
    } });
  }), t.effects.define("scale", function(e2, i2) {
    var s2 = t(this), n2 = e2.mode, o2 = parseInt(e2.percent, 10) || (0 === parseInt(e2.percent, 10) ? 0 : "effect" !== n2 ? 0 : 100), a2 = t.extend(true, { from: t.effects.scaledDimensions(s2), to: t.effects.scaledDimensions(s2, o2, e2.direction || "both"), origin: e2.origin || ["middle", "center"] }, e2);
    e2.fade && (a2.from.opacity = 1, a2.to.opacity = 0), t.effects.effect.size.call(this, a2, i2);
  }), t.effects.define("puff", "hide", function(e2, i2) {
    var s2 = t.extend(true, {}, e2, { fade: true, percent: parseInt(e2.percent, 10) || 150 });
    t.effects.effect.scale.call(this, s2, i2);
  }), t.effects.define("pulsate", "show", function(e2, i2) {
    var s2 = t(this), n2 = e2.mode, o2 = "show" === n2, a2 = "hide" === n2, r2 = o2 || a2, h2 = 2 * (e2.times || 5) + (r2 ? 1 : 0), l2 = e2.duration / h2, c2 = 0, u2 = 1, d2 = s2.queue().length;
    for ((o2 || !s2.is(":visible")) && (s2.css("opacity", 0).show(), c2 = 1); h2 > u2; u2++)
      s2.animate({ opacity: c2 }, l2, e2.easing), c2 = 1 - c2;
    s2.animate({ opacity: c2 }, l2, e2.easing), s2.queue(i2), t.effects.unshift(s2, d2, h2 + 1);
  }), t.effects.define("shake", function(e2, i2) {
    var s2 = 1, n2 = t(this), o2 = e2.direction || "left", a2 = e2.distance || 20, r2 = e2.times || 3, h2 = 2 * r2 + 1, l2 = Math.round(e2.duration / h2), c2 = "up" === o2 || "down" === o2 ? "top" : "left", u2 = "up" === o2 || "left" === o2, d2 = {}, p2 = {}, f = {}, g2 = n2.queue().length;
    for (t.effects.createPlaceholder(n2), d2[c2] = (u2 ? "-=" : "+=") + a2, p2[c2] = (u2 ? "+=" : "-=") + 2 * a2, f[c2] = (u2 ? "-=" : "+=") + 2 * a2, n2.animate(d2, l2, e2.easing); r2 > s2; s2++)
      n2.animate(p2, l2, e2.easing).animate(f, l2, e2.easing);
    n2.animate(p2, l2, e2.easing).animate(d2, l2 / 2, e2.easing).queue(i2), t.effects.unshift(n2, g2, h2 + 1);
  }), t.effects.define("slide", "show", function(e2, i2) {
    var s2, n2, o2 = t(this), a2 = { up: ["bottom", "top"], down: ["top", "bottom"], left: ["right", "left"], right: ["left", "right"] }, r2 = e2.mode, h2 = e2.direction || "left", l2 = "up" === h2 || "down" === h2 ? "top" : "left", c2 = "up" === h2 || "left" === h2, u2 = e2.distance || o2["top" === l2 ? "outerHeight" : "outerWidth"](true), d2 = {};
    t.effects.createPlaceholder(o2), s2 = o2.cssClip(), n2 = o2.position()[l2], d2[l2] = (c2 ? -1 : 1) * u2 + n2, d2.clip = o2.cssClip(), d2.clip[a2[h2][1]] = d2.clip[a2[h2][0]], "show" === r2 && (o2.cssClip(d2.clip), o2.css(l2, d2[l2]), d2.clip = s2, d2[l2] = n2), o2.animate(d2, { queue: false, duration: e2.duration, easing: e2.easing, complete: i2 });
  });
  t.uiBackCompat !== false && t.effects.define("transfer", function(e2, i2) {
    t(this).transfer(e2, i2);
  }), t.ui.focusable = function(i2, s2) {
    var n2, o2, a2, r2, h2, l2 = i2.nodeName.toLowerCase();
    return "area" === l2 ? (n2 = i2.parentNode, o2 = n2.name, i2.href && o2 && "map" === n2.nodeName.toLowerCase() ? (a2 = t("img[usemap='#" + o2 + "']"), a2.length > 0 && a2.is(":visible")) : false) : (/^(input|select|textarea|button|object)$/.test(l2) ? (r2 = !i2.disabled, r2 && (h2 = t(i2).closest("fieldset")[0], h2 && (r2 = !h2.disabled))) : r2 = "a" === l2 ? i2.href || s2 : s2, r2 && t(i2).is(":visible") && e(t(i2)));
  }, t.extend(t.expr[":"], { focusable: function(e2) {
    return t.ui.focusable(e2, null != t.attr(e2, "tabindex"));
  } }), t.ui.focusable, t.fn.form = function() {
    return "string" == typeof this[0].form ? this.closest("form") : t(this[0].form);
  }, t.ui.formResetMixin = { _formResetHandler: function() {
    var e2 = t(this);
    setTimeout(function() {
      var i2 = e2.data("ui-form-reset-instances");
      t.each(i2, function() {
        this.refresh();
      });
    });
  }, _bindFormResetHandler: function() {
    if (this.form = this.element.form(), this.form.length) {
      var t2 = this.form.data("ui-form-reset-instances") || [];
      t2.length || this.form.on("reset.ui-form-reset", this._formResetHandler), t2.push(this), this.form.data("ui-form-reset-instances", t2);
    }
  }, _unbindFormResetHandler: function() {
    if (this.form.length) {
      var e2 = this.form.data("ui-form-reset-instances");
      e2.splice(t.inArray(this, e2), 1), e2.length ? this.form.data("ui-form-reset-instances", e2) : this.form.removeData("ui-form-reset-instances").off("reset.ui-form-reset");
    }
  } }, "1.7" === t.fn.jquery.substring(0, 3) && (t.each(["Width", "Height"], function(e2, i2) {
    function s2(e3, i3, s3, o3) {
      return t.each(n2, function() {
        i3 -= parseFloat(t.css(e3, "padding" + this)) || 0, s3 && (i3 -= parseFloat(t.css(e3, "border" + this + "Width")) || 0), o3 && (i3 -= parseFloat(t.css(e3, "margin" + this)) || 0);
      }), i3;
    }
    var n2 = "Width" === i2 ? ["Left", "Right"] : ["Top", "Bottom"], o2 = i2.toLowerCase(), a2 = { innerWidth: t.fn.innerWidth, innerHeight: t.fn.innerHeight, outerWidth: t.fn.outerWidth, outerHeight: t.fn.outerHeight };
    t.fn["inner" + i2] = function(e3) {
      return void 0 === e3 ? a2["inner" + i2].call(this) : this.each(function() {
        t(this).css(o2, s2(this, e3) + "px");
      });
    }, t.fn["outer" + i2] = function(e3, n3) {
      return "number" != typeof e3 ? a2["outer" + i2].call(this, e3) : this.each(function() {
        t(this).css(o2, s2(this, e3, true, n3) + "px");
      });
    };
  }), t.fn.addBack = function(t2) {
    return this.add(null == t2 ? this.prevObject : this.prevObject.filter(t2));
  }), t.ui.keyCode = { BACKSPACE: 8, COMMA: 188, DELETE: 46, DOWN: 40, END: 35, ENTER: 13, ESCAPE: 27, HOME: 36, LEFT: 37, PAGE_DOWN: 34, PAGE_UP: 33, PERIOD: 190, RIGHT: 39, SPACE: 32, TAB: 9, UP: 38 }, t.ui.escapeSelector = function() {
    var t2 = /([!"#$%&'()*+,.\/:;<=>?@[\]^`{|}~])/g;
    return function(e2) {
      return e2.replace(t2, "\\$1");
    };
  }(), t.fn.labels = function() {
    var e2, i2, s2, n2, o2;
    return this[0].labels && this[0].labels.length ? this.pushStack(this[0].labels) : (n2 = this.eq(0).parents("label"), s2 = this.attr("id"), s2 && (e2 = this.eq(0).parents().last(), o2 = e2.add(e2.length ? e2.siblings() : this.siblings()), i2 = "label[for='" + t.ui.escapeSelector(s2) + "']", n2 = n2.add(o2.find(i2).addBack(i2))), this.pushStack(n2));
  }, t.fn.scrollParent = function(e2) {
    var i2 = this.css("position"), s2 = "absolute" === i2, n2 = e2 ? /(auto|scroll|hidden)/ : /(auto|scroll)/, o2 = this.parents().filter(function() {
      var e3 = t(this);
      return s2 && "static" === e3.css("position") ? false : n2.test(e3.css("overflow") + e3.css("overflow-y") + e3.css("overflow-x"));
    }).eq(0);
    return "fixed" !== i2 && o2.length ? o2 : t(this[0].ownerDocument || document);
  }, t.extend(t.expr[":"], { tabbable: function(e2) {
    var i2 = t.attr(e2, "tabindex"), s2 = null != i2;
    return (!s2 || i2 >= 0) && t.ui.focusable(e2, s2);
  } }), t.fn.extend({ uniqueId: function() {
    var t2 = 0;
    return function() {
      return this.each(function() {
        this.id || (this.id = "ui-id-" + ++t2);
      });
    };
  }(), removeUniqueId: function() {
    return this.each(function() {
      /^ui-id-\d+$/.test(this.id) && t(this).removeAttr("id");
    });
  } }), t.widget("ui.accordion", { version: "1.12.1", options: { active: 0, animate: {}, classes: { "ui-accordion-header": "ui-corner-top", "ui-accordion-header-collapsed": "ui-corner-all", "ui-accordion-content": "ui-corner-bottom" }, collapsible: false, event: "click", header: "> li > :first-child, > :not(li):even", heightStyle: "auto", icons: { activeHeader: "ui-icon-triangle-1-s", header: "ui-icon-triangle-1-e" }, activate: null, beforeActivate: null }, hideProps: { borderTopWidth: "hide", borderBottomWidth: "hide", paddingTop: "hide", paddingBottom: "hide", height: "hide" }, showProps: { borderTopWidth: "show", borderBottomWidth: "show", paddingTop: "show", paddingBottom: "show", height: "show" }, _create: function() {
    var e2 = this.options;
    this.prevShow = this.prevHide = t(), this._addClass("ui-accordion", "ui-widget ui-helper-reset"), this.element.attr("role", "tablist"), e2.collapsible || e2.active !== false && null != e2.active || (e2.active = 0), this._processPanels(), 0 > e2.active && (e2.active += this.headers.length), this._refresh();
  }, _getCreateEventData: function() {
    return { header: this.active, panel: this.active.length ? this.active.next() : t() };
  }, _createIcons: function() {
    var e2, i2, s2 = this.options.icons;
    s2 && (e2 = t("<span>"), this._addClass(e2, "ui-accordion-header-icon", "ui-icon " + s2.header), e2.prependTo(this.headers), i2 = this.active.children(".ui-accordion-header-icon"), this._removeClass(i2, s2.header)._addClass(i2, null, s2.activeHeader)._addClass(this.headers, "ui-accordion-icons"));
  }, _destroyIcons: function() {
    this._removeClass(this.headers, "ui-accordion-icons"), this.headers.children(".ui-accordion-header-icon").remove();
  }, _destroy: function() {
    var t2;
    this.element.removeAttr("role"), this.headers.removeAttr("role aria-expanded aria-selected aria-controls tabIndex").removeUniqueId(), this._destroyIcons(), t2 = this.headers.next().css("display", "").removeAttr("role aria-hidden aria-labelledby").removeUniqueId(), "content" !== this.options.heightStyle && t2.css("height", "");
  }, _setOption: function(t2, e2) {
    return "active" === t2 ? (this._activate(e2), void 0) : ("event" === t2 && (this.options.event && this._off(this.headers, this.options.event), this._setupEvents(e2)), this._super(t2, e2), "collapsible" !== t2 || e2 || this.options.active !== false || this._activate(0), "icons" === t2 && (this._destroyIcons(), e2 && this._createIcons()), void 0);
  }, _setOptionDisabled: function(t2) {
    this._super(t2), this.element.attr("aria-disabled", t2), this._toggleClass(null, "ui-state-disabled", !!t2), this._toggleClass(this.headers.add(this.headers.next()), null, "ui-state-disabled", !!t2);
  }, _keydown: function(e2) {
    if (!e2.altKey && !e2.ctrlKey) {
      var i2 = t.ui.keyCode, s2 = this.headers.length, n2 = this.headers.index(e2.target), o2 = false;
      switch (e2.keyCode) {
        case i2.RIGHT:
        case i2.DOWN:
          o2 = this.headers[(n2 + 1) % s2];
          break;
        case i2.LEFT:
        case i2.UP:
          o2 = this.headers[(n2 - 1 + s2) % s2];
          break;
        case i2.SPACE:
        case i2.ENTER:
          this._eventHandler(e2);
          break;
        case i2.HOME:
          o2 = this.headers[0];
          break;
        case i2.END:
          o2 = this.headers[s2 - 1];
      }
      o2 && (t(e2.target).attr("tabIndex", -1), t(o2).attr("tabIndex", 0), t(o2).trigger("focus"), e2.preventDefault());
    }
  }, _panelKeyDown: function(e2) {
    e2.keyCode === t.ui.keyCode.UP && e2.ctrlKey && t(e2.currentTarget).prev().trigger("focus");
  }, refresh: function() {
    var e2 = this.options;
    this._processPanels(), e2.active === false && e2.collapsible === true || !this.headers.length ? (e2.active = false, this.active = t()) : e2.active === false ? this._activate(0) : this.active.length && !t.contains(this.element[0], this.active[0]) ? this.headers.length === this.headers.find(".ui-state-disabled").length ? (e2.active = false, this.active = t()) : this._activate(Math.max(0, e2.active - 1)) : e2.active = this.headers.index(this.active), this._destroyIcons(), this._refresh();
  }, _processPanels: function() {
    var t2 = this.headers, e2 = this.panels;
    this.headers = this.element.find(this.options.header), this._addClass(this.headers, "ui-accordion-header ui-accordion-header-collapsed", "ui-state-default"), this.panels = this.headers.next().filter(":not(.ui-accordion-content-active)").hide(), this._addClass(this.panels, "ui-accordion-content", "ui-helper-reset ui-widget-content"), e2 && (this._off(t2.not(this.headers)), this._off(e2.not(this.panels)));
  }, _refresh: function() {
    var e2, i2 = this.options, s2 = i2.heightStyle, n2 = this.element.parent();
    this.active = this._findActive(i2.active), this._addClass(this.active, "ui-accordion-header-active", "ui-state-active")._removeClass(this.active, "ui-accordion-header-collapsed"), this._addClass(this.active.next(), "ui-accordion-content-active"), this.active.next().show(), this.headers.attr("role", "tab").each(function() {
      var e3 = t(this), i3 = e3.uniqueId().attr("id"), s3 = e3.next(), n3 = s3.uniqueId().attr("id");
      e3.attr("aria-controls", n3), s3.attr("aria-labelledby", i3);
    }).next().attr("role", "tabpanel"), this.headers.not(this.active).attr({ "aria-selected": "false", "aria-expanded": "false", tabIndex: -1 }).next().attr({ "aria-hidden": "true" }).hide(), this.active.length ? this.active.attr({ "aria-selected": "true", "aria-expanded": "true", tabIndex: 0 }).next().attr({ "aria-hidden": "false" }) : this.headers.eq(0).attr("tabIndex", 0), this._createIcons(), this._setupEvents(i2.event), "fill" === s2 ? (e2 = n2.height(), this.element.siblings(":visible").each(function() {
      var i3 = t(this), s3 = i3.css("position");
      "absolute" !== s3 && "fixed" !== s3 && (e2 -= i3.outerHeight(true));
    }), this.headers.each(function() {
      e2 -= t(this).outerHeight(true);
    }), this.headers.next().each(function() {
      t(this).height(Math.max(0, e2 - t(this).innerHeight() + t(this).height()));
    }).css("overflow", "auto")) : "auto" === s2 && (e2 = 0, this.headers.next().each(function() {
      var i3 = t(this).is(":visible");
      i3 || t(this).show(), e2 = Math.max(e2, t(this).css("height", "").height()), i3 || t(this).hide();
    }).height(e2));
  }, _activate: function(e2) {
    var i2 = this._findActive(e2)[0];
    i2 !== this.active[0] && (i2 = i2 || this.active[0], this._eventHandler({ target: i2, currentTarget: i2, preventDefault: t.noop }));
  }, _findActive: function(e2) {
    return "number" == typeof e2 ? this.headers.eq(e2) : t();
  }, _setupEvents: function(e2) {
    var i2 = { keydown: "_keydown" };
    e2 && t.each(e2.split(" "), function(t2, e3) {
      i2[e3] = "_eventHandler";
    }), this._off(this.headers.add(this.headers.next())), this._on(this.headers, i2), this._on(this.headers.next(), { keydown: "_panelKeyDown" }), this._hoverable(this.headers), this._focusable(this.headers);
  }, _eventHandler: function(e2) {
    var i2, s2, n2 = this.options, o2 = this.active, a2 = t(e2.currentTarget), r2 = a2[0] === o2[0], h2 = r2 && n2.collapsible, l2 = h2 ? t() : a2.next(), c2 = o2.next(), u2 = { oldHeader: o2, oldPanel: c2, newHeader: h2 ? t() : a2, newPanel: l2 };
    e2.preventDefault(), r2 && !n2.collapsible || this._trigger("beforeActivate", e2, u2) === false || (n2.active = h2 ? false : this.headers.index(a2), this.active = r2 ? t() : a2, this._toggle(u2), this._removeClass(o2, "ui-accordion-header-active", "ui-state-active"), n2.icons && (i2 = o2.children(".ui-accordion-header-icon"), this._removeClass(i2, null, n2.icons.activeHeader)._addClass(i2, null, n2.icons.header)), r2 || (this._removeClass(a2, "ui-accordion-header-collapsed")._addClass(a2, "ui-accordion-header-active", "ui-state-active"), n2.icons && (s2 = a2.children(".ui-accordion-header-icon"), this._removeClass(s2, null, n2.icons.header)._addClass(s2, null, n2.icons.activeHeader)), this._addClass(a2.next(), "ui-accordion-content-active")));
  }, _toggle: function(e2) {
    var i2 = e2.newPanel, s2 = this.prevShow.length ? this.prevShow : e2.oldPanel;
    this.prevShow.add(this.prevHide).stop(true, true), this.prevShow = i2, this.prevHide = s2, this.options.animate ? this._animate(i2, s2, e2) : (s2.hide(), i2.show(), this._toggleComplete(e2)), s2.attr({ "aria-hidden": "true" }), s2.prev().attr({ "aria-selected": "false", "aria-expanded": "false" }), i2.length && s2.length ? s2.prev().attr({ tabIndex: -1, "aria-expanded": "false" }) : i2.length && this.headers.filter(function() {
      return 0 === parseInt(t(this).attr("tabIndex"), 10);
    }).attr("tabIndex", -1), i2.attr("aria-hidden", "false").prev().attr({ "aria-selected": "true", "aria-expanded": "true", tabIndex: 0 });
  }, _animate: function(t2, e2, i2) {
    var s2, n2, o2, a2 = this, r2 = 0, h2 = t2.css("box-sizing"), l2 = t2.length && (!e2.length || t2.index() < e2.index()), c2 = this.options.animate || {}, u2 = l2 && c2.down || c2, d2 = function() {
      a2._toggleComplete(i2);
    };
    return "number" == typeof u2 && (o2 = u2), "string" == typeof u2 && (n2 = u2), n2 = n2 || u2.easing || c2.easing, o2 = o2 || u2.duration || c2.duration, e2.length ? t2.length ? (s2 = t2.show().outerHeight(), e2.animate(this.hideProps, { duration: o2, easing: n2, step: function(t3, e3) {
      e3.now = Math.round(t3);
    } }), t2.hide().animate(this.showProps, { duration: o2, easing: n2, complete: d2, step: function(t3, i3) {
      i3.now = Math.round(t3), "height" !== i3.prop ? "content-box" === h2 && (r2 += i3.now) : "content" !== a2.options.heightStyle && (i3.now = Math.round(s2 - e2.outerHeight() - r2), r2 = 0);
    } }), void 0) : e2.animate(this.hideProps, o2, n2, d2) : t2.animate(this.showProps, o2, n2, d2);
  }, _toggleComplete: function(t2) {
    var e2 = t2.oldPanel, i2 = e2.prev();
    this._removeClass(e2, "ui-accordion-content-active"), this._removeClass(i2, "ui-accordion-header-active")._addClass(i2, "ui-accordion-header-collapsed"), e2.length && (e2.parent()[0].className = e2.parent()[0].className), this._trigger("activate", null, t2);
  } }), t.ui.safeActiveElement = function(t2) {
    var e2;
    try {
      e2 = t2.activeElement;
    } catch (i2) {
      e2 = t2.body;
    }
    return e2 || (e2 = t2.body), e2.nodeName || (e2 = t2.body), e2;
  }, t.widget("ui.menu", { version: "1.12.1", defaultElement: "<ul>", delay: 300, options: { icons: { submenu: "ui-icon-caret-1-e" }, items: "> *", menus: "ul", position: { my: "left top", at: "right top" }, role: "menu", blur: null, focus: null, select: null }, _create: function() {
    this.activeMenu = this.element, this.mouseHandled = false, this.element.uniqueId().attr({ role: this.options.role, tabIndex: 0 }), this._addClass("ui-menu", "ui-widget ui-widget-content"), this._on({ "mousedown .ui-menu-item": function(t2) {
      t2.preventDefault();
    }, "click .ui-menu-item": function(e2) {
      var i2 = t(e2.target), s2 = t(t.ui.safeActiveElement(this.document[0]));
      !this.mouseHandled && i2.not(".ui-state-disabled").length && (this.select(e2), e2.isPropagationStopped() || (this.mouseHandled = true), i2.has(".ui-menu").length ? this.expand(e2) : !this.element.is(":focus") && s2.closest(".ui-menu").length && (this.element.trigger("focus", [true]), this.active && 1 === this.active.parents(".ui-menu").length && clearTimeout(this.timer)));
    }, "mouseenter .ui-menu-item": function(e2) {
      if (!this.previousFilter) {
        var i2 = t(e2.target).closest(".ui-menu-item"), s2 = t(e2.currentTarget);
        i2[0] === s2[0] && (this._removeClass(s2.siblings().children(".ui-state-active"), null, "ui-state-active"), this.focus(e2, s2));
      }
    }, mouseleave: "collapseAll", "mouseleave .ui-menu": "collapseAll", focus: function(t2, e2) {
      var i2 = this.active || this.element.find(this.options.items).eq(0);
      e2 || this.focus(t2, i2);
    }, blur: function(e2) {
      this._delay(function() {
        var i2 = !t.contains(this.element[0], t.ui.safeActiveElement(this.document[0]));
        i2 && this.collapseAll(e2);
      });
    }, keydown: "_keydown" }), this.refresh(), this._on(this.document, { click: function(t2) {
      this._closeOnDocumentClick(t2) && this.collapseAll(t2), this.mouseHandled = false;
    } });
  }, _destroy: function() {
    var e2 = this.element.find(".ui-menu-item").removeAttr("role aria-disabled"), i2 = e2.children(".ui-menu-item-wrapper").removeUniqueId().removeAttr("tabIndex role aria-haspopup");
    this.element.removeAttr("aria-activedescendant").find(".ui-menu").addBack().removeAttr("role aria-labelledby aria-expanded aria-hidden aria-disabled tabIndex").removeUniqueId().show(), i2.children().each(function() {
      var e3 = t(this);
      e3.data("ui-menu-submenu-caret") && e3.remove();
    });
  }, _keydown: function(e2) {
    var i2, s2, n2, o2, a2 = true;
    switch (e2.keyCode) {
      case t.ui.keyCode.PAGE_UP:
        this.previousPage(e2);
        break;
      case t.ui.keyCode.PAGE_DOWN:
        this.nextPage(e2);
        break;
      case t.ui.keyCode.HOME:
        this._move("first", "first", e2);
        break;
      case t.ui.keyCode.END:
        this._move("last", "last", e2);
        break;
      case t.ui.keyCode.UP:
        this.previous(e2);
        break;
      case t.ui.keyCode.DOWN:
        this.next(e2);
        break;
      case t.ui.keyCode.LEFT:
        this.collapse(e2);
        break;
      case t.ui.keyCode.RIGHT:
        this.active && !this.active.is(".ui-state-disabled") && this.expand(e2);
        break;
      case t.ui.keyCode.ENTER:
      case t.ui.keyCode.SPACE:
        this._activate(e2);
        break;
      case t.ui.keyCode.ESCAPE:
        this.collapse(e2);
        break;
      default:
        a2 = false, s2 = this.previousFilter || "", o2 = false, n2 = e2.keyCode >= 96 && 105 >= e2.keyCode ? "" + (e2.keyCode - 96) : String.fromCharCode(e2.keyCode), clearTimeout(this.filterTimer), n2 === s2 ? o2 = true : n2 = s2 + n2, i2 = this._filterMenuItems(n2), i2 = o2 && -1 !== i2.index(this.active.next()) ? this.active.nextAll(".ui-menu-item") : i2, i2.length || (n2 = String.fromCharCode(e2.keyCode), i2 = this._filterMenuItems(n2)), i2.length ? (this.focus(e2, i2), this.previousFilter = n2, this.filterTimer = this._delay(function() {
          delete this.previousFilter;
        }, 1e3)) : delete this.previousFilter;
    }
    a2 && e2.preventDefault();
  }, _activate: function(t2) {
    this.active && !this.active.is(".ui-state-disabled") && (this.active.children("[aria-haspopup='true']").length ? this.expand(t2) : this.select(t2));
  }, refresh: function() {
    var e2, i2, s2, n2, o2, a2 = this, r2 = this.options.icons.submenu, h2 = this.element.find(this.options.menus);
    this._toggleClass("ui-menu-icons", null, !!this.element.find(".ui-icon").length), s2 = h2.filter(":not(.ui-menu)").hide().attr({ role: this.options.role, "aria-hidden": "true", "aria-expanded": "false" }).each(function() {
      var e3 = t(this), i3 = e3.prev(), s3 = t("<span>").data("ui-menu-submenu-caret", true);
      a2._addClass(s3, "ui-menu-icon", "ui-icon " + r2), i3.attr("aria-haspopup", "true").prepend(s3), e3.attr("aria-labelledby", i3.attr("id"));
    }), this._addClass(s2, "ui-menu", "ui-widget ui-widget-content ui-front"), e2 = h2.add(this.element), i2 = e2.find(this.options.items), i2.not(".ui-menu-item").each(function() {
      var e3 = t(this);
      a2._isDivider(e3) && a2._addClass(e3, "ui-menu-divider", "ui-widget-content");
    }), n2 = i2.not(".ui-menu-item, .ui-menu-divider"), o2 = n2.children().not(".ui-menu").uniqueId().attr({ tabIndex: -1, role: this._itemRole() }), this._addClass(n2, "ui-menu-item")._addClass(o2, "ui-menu-item-wrapper"), i2.filter(".ui-state-disabled").attr("aria-disabled", "true"), this.active && !t.contains(this.element[0], this.active[0]) && this.blur();
  }, _itemRole: function() {
    return { menu: "menuitem", listbox: "option" }[this.options.role];
  }, _setOption: function(t2, e2) {
    if ("icons" === t2) {
      var i2 = this.element.find(".ui-menu-icon");
      this._removeClass(i2, null, this.options.icons.submenu)._addClass(i2, null, e2.submenu);
    }
    this._super(t2, e2);
  }, _setOptionDisabled: function(t2) {
    this._super(t2), this.element.attr("aria-disabled", t2 + ""), this._toggleClass(null, "ui-state-disabled", !!t2);
  }, focus: function(t2, e2) {
    var i2, s2, n2;
    this.blur(t2, t2 && "focus" === t2.type), this._scrollIntoView(e2), this.active = e2.first(), s2 = this.active.children(".ui-menu-item-wrapper"), this._addClass(s2, null, "ui-state-active"), this.options.role && this.element.attr("aria-activedescendant", s2.attr("id")), n2 = this.active.parent().closest(".ui-menu-item").children(".ui-menu-item-wrapper"), this._addClass(n2, null, "ui-state-active"), t2 && "keydown" === t2.type ? this._close() : this.timer = this._delay(function() {
      this._close();
    }, this.delay), i2 = e2.children(".ui-menu"), i2.length && t2 && /^mouse/.test(t2.type) && this._startOpening(i2), this.activeMenu = e2.parent(), this._trigger("focus", t2, { item: e2 });
  }, _scrollIntoView: function(e2) {
    var i2, s2, n2, o2, a2, r2;
    this._hasScroll() && (i2 = parseFloat(t.css(this.activeMenu[0], "borderTopWidth")) || 0, s2 = parseFloat(t.css(this.activeMenu[0], "paddingTop")) || 0, n2 = e2.offset().top - this.activeMenu.offset().top - i2 - s2, o2 = this.activeMenu.scrollTop(), a2 = this.activeMenu.height(), r2 = e2.outerHeight(), 0 > n2 ? this.activeMenu.scrollTop(o2 + n2) : n2 + r2 > a2 && this.activeMenu.scrollTop(o2 + n2 - a2 + r2));
  }, blur: function(t2, e2) {
    e2 || clearTimeout(this.timer), this.active && (this._removeClass(this.active.children(".ui-menu-item-wrapper"), null, "ui-state-active"), this._trigger("blur", t2, { item: this.active }), this.active = null);
  }, _startOpening: function(t2) {
    clearTimeout(this.timer), "true" === t2.attr("aria-hidden") && (this.timer = this._delay(function() {
      this._close(), this._open(t2);
    }, this.delay));
  }, _open: function(e2) {
    var i2 = t.extend({ of: this.active }, this.options.position);
    clearTimeout(this.timer), this.element.find(".ui-menu").not(e2.parents(".ui-menu")).hide().attr("aria-hidden", "true"), e2.show().removeAttr("aria-hidden").attr("aria-expanded", "true").position(i2);
  }, collapseAll: function(e2, i2) {
    clearTimeout(this.timer), this.timer = this._delay(function() {
      var s2 = i2 ? this.element : t(e2 && e2.target).closest(this.element.find(".ui-menu"));
      s2.length || (s2 = this.element), this._close(s2), this.blur(e2), this._removeClass(s2.find(".ui-state-active"), null, "ui-state-active"), this.activeMenu = s2;
    }, this.delay);
  }, _close: function(t2) {
    t2 || (t2 = this.active ? this.active.parent() : this.element), t2.find(".ui-menu").hide().attr("aria-hidden", "true").attr("aria-expanded", "false");
  }, _closeOnDocumentClick: function(e2) {
    return !t(e2.target).closest(".ui-menu").length;
  }, _isDivider: function(t2) {
    return !/[^\-\u2014\u2013\s]/.test(t2.text());
  }, collapse: function(t2) {
    var e2 = this.active && this.active.parent().closest(".ui-menu-item", this.element);
    e2 && e2.length && (this._close(), this.focus(t2, e2));
  }, expand: function(t2) {
    var e2 = this.active && this.active.children(".ui-menu ").find(this.options.items).first();
    e2 && e2.length && (this._open(e2.parent()), this._delay(function() {
      this.focus(t2, e2);
    }));
  }, next: function(t2) {
    this._move("next", "first", t2);
  }, previous: function(t2) {
    this._move("prev", "last", t2);
  }, isFirstItem: function() {
    return this.active && !this.active.prevAll(".ui-menu-item").length;
  }, isLastItem: function() {
    return this.active && !this.active.nextAll(".ui-menu-item").length;
  }, _move: function(t2, e2, i2) {
    var s2;
    this.active && (s2 = "first" === t2 || "last" === t2 ? this.active["first" === t2 ? "prevAll" : "nextAll"](".ui-menu-item").eq(-1) : this.active[t2 + "All"](".ui-menu-item").eq(0)), s2 && s2.length && this.active || (s2 = this.activeMenu.find(this.options.items)[e2]()), this.focus(i2, s2);
  }, nextPage: function(e2) {
    var i2, s2, n2;
    return this.active ? (this.isLastItem() || (this._hasScroll() ? (s2 = this.active.offset().top, n2 = this.element.height(), this.active.nextAll(".ui-menu-item").each(function() {
      return i2 = t(this), 0 > i2.offset().top - s2 - n2;
    }), this.focus(e2, i2)) : this.focus(e2, this.activeMenu.find(this.options.items)[this.active ? "last" : "first"]())), void 0) : (this.next(e2), void 0);
  }, previousPage: function(e2) {
    var i2, s2, n2;
    return this.active ? (this.isFirstItem() || (this._hasScroll() ? (s2 = this.active.offset().top, n2 = this.element.height(), this.active.prevAll(".ui-menu-item").each(function() {
      return i2 = t(this), i2.offset().top - s2 + n2 > 0;
    }), this.focus(e2, i2)) : this.focus(e2, this.activeMenu.find(this.options.items).first())), void 0) : (this.next(e2), void 0);
  }, _hasScroll: function() {
    return this.element.outerHeight() < this.element.prop("scrollHeight");
  }, select: function(e2) {
    this.active = this.active || t(e2.target).closest(".ui-menu-item");
    var i2 = { item: this.active };
    this.active.has(".ui-menu").length || this.collapseAll(e2, true), this._trigger("select", e2, i2);
  }, _filterMenuItems: function(e2) {
    var i2 = e2.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&"), s2 = RegExp("^" + i2, "i");
    return this.activeMenu.find(this.options.items).filter(".ui-menu-item").filter(function() {
      return s2.test(t.trim(t(this).children(".ui-menu-item-wrapper").text()));
    });
  } }), t.widget("ui.autocomplete", { version: "1.12.1", defaultElement: "<input>", options: { appendTo: null, autoFocus: false, delay: 300, minLength: 1, position: { my: "left top", at: "left bottom", collision: "none" }, source: null, change: null, close: null, focus: null, open: null, response: null, search: null, select: null }, requestIndex: 0, pending: 0, _create: function() {
    var e2, i2, s2, n2 = this.element[0].nodeName.toLowerCase(), o2 = "textarea" === n2, a2 = "input" === n2;
    this.isMultiLine = o2 || !a2 && this._isContentEditable(this.element), this.valueMethod = this.element[o2 || a2 ? "val" : "text"], this.isNewMenu = true, this._addClass("ui-autocomplete-input"), this.element.attr("autocomplete", "off"), this._on(this.element, { keydown: function(n3) {
      if (this.element.prop("readOnly"))
        return e2 = true, s2 = true, i2 = true, void 0;
      e2 = false, s2 = false, i2 = false;
      var o3 = t.ui.keyCode;
      switch (n3.keyCode) {
        case o3.PAGE_UP:
          e2 = true, this._move("previousPage", n3);
          break;
        case o3.PAGE_DOWN:
          e2 = true, this._move("nextPage", n3);
          break;
        case o3.UP:
          e2 = true, this._keyEvent("previous", n3);
          break;
        case o3.DOWN:
          e2 = true, this._keyEvent("next", n3);
          break;
        case o3.ENTER:
          this.menu.active && (e2 = true, n3.preventDefault(), this.menu.select(n3));
          break;
        case o3.TAB:
          this.menu.active && this.menu.select(n3);
          break;
        case o3.ESCAPE:
          this.menu.element.is(":visible") && (this.isMultiLine || this._value(this.term), this.close(n3), n3.preventDefault());
          break;
        default:
          i2 = true, this._searchTimeout(n3);
      }
    }, keypress: function(s3) {
      if (e2)
        return e2 = false, (!this.isMultiLine || this.menu.element.is(":visible")) && s3.preventDefault(), void 0;
      if (!i2) {
        var n3 = t.ui.keyCode;
        switch (s3.keyCode) {
          case n3.PAGE_UP:
            this._move("previousPage", s3);
            break;
          case n3.PAGE_DOWN:
            this._move("nextPage", s3);
            break;
          case n3.UP:
            this._keyEvent("previous", s3);
            break;
          case n3.DOWN:
            this._keyEvent("next", s3);
        }
      }
    }, input: function(t2) {
      return s2 ? (s2 = false, t2.preventDefault(), void 0) : (this._searchTimeout(t2), void 0);
    }, focus: function() {
      this.selectedItem = null, this.previous = this._value();
    }, blur: function(t2) {
      return this.cancelBlur ? (delete this.cancelBlur, void 0) : (clearTimeout(this.searching), this.close(t2), this._change(t2), void 0);
    } }), this._initSource(), this.menu = t("<ul>").appendTo(this._appendTo()).menu({ role: null }).hide().menu("instance"), this._addClass(this.menu.element, "ui-autocomplete", "ui-front"), this._on(this.menu.element, { mousedown: function(e3) {
      e3.preventDefault(), this.cancelBlur = true, this._delay(function() {
        delete this.cancelBlur, this.element[0] !== t.ui.safeActiveElement(this.document[0]) && this.element.trigger("focus");
      });
    }, menufocus: function(e3, i3) {
      var s3, n3;
      return this.isNewMenu && (this.isNewMenu = false, e3.originalEvent && /^mouse/.test(e3.originalEvent.type)) ? (this.menu.blur(), this.document.one("mousemove", function() {
        t(e3.target).trigger(e3.originalEvent);
      }), void 0) : (n3 = i3.item.data("ui-autocomplete-item"), false !== this._trigger("focus", e3, { item: n3 }) && e3.originalEvent && /^key/.test(e3.originalEvent.type) && this._value(n3.value), s3 = i3.item.attr("aria-label") || n3.value, s3 && t.trim(s3).length && (this.liveRegion.children().hide(), t("<div>").text(s3).appendTo(this.liveRegion)), void 0);
    }, menuselect: function(e3, i3) {
      var s3 = i3.item.data("ui-autocomplete-item"), n3 = this.previous;
      this.element[0] !== t.ui.safeActiveElement(this.document[0]) && (this.element.trigger("focus"), this.previous = n3, this._delay(function() {
        this.previous = n3, this.selectedItem = s3;
      })), false !== this._trigger("select", e3, { item: s3 }) && this._value(s3.value), this.term = this._value(), this.close(e3), this.selectedItem = s3;
    } }), this.liveRegion = t("<div>", { role: "status", "aria-live": "assertive", "aria-relevant": "additions" }).appendTo(this.document[0].body), this._addClass(this.liveRegion, null, "ui-helper-hidden-accessible"), this._on(this.window, { beforeunload: function() {
      this.element.removeAttr("autocomplete");
    } });
  }, _destroy: function() {
    clearTimeout(this.searching), this.element.removeAttr("autocomplete"), this.menu.element.remove(), this.liveRegion.remove();
  }, _setOption: function(t2, e2) {
    this._super(t2, e2), "source" === t2 && this._initSource(), "appendTo" === t2 && this.menu.element.appendTo(this._appendTo()), "disabled" === t2 && e2 && this.xhr && this.xhr.abort();
  }, _isEventTargetInWidget: function(e2) {
    var i2 = this.menu.element[0];
    return e2.target === this.element[0] || e2.target === i2 || t.contains(i2, e2.target);
  }, _closeOnClickOutside: function(t2) {
    this._isEventTargetInWidget(t2) || this.close();
  }, _appendTo: function() {
    var e2 = this.options.appendTo;
    return e2 && (e2 = e2.jquery || e2.nodeType ? t(e2) : this.document.find(e2).eq(0)), e2 && e2[0] || (e2 = this.element.closest(".ui-front, dialog")), e2.length || (e2 = this.document[0].body), e2;
  }, _initSource: function() {
    var e2, i2, s2 = this;
    t.isArray(this.options.source) ? (e2 = this.options.source, this.source = function(i3, s3) {
      s3(t.ui.autocomplete.filter(e2, i3.term));
    }) : "string" == typeof this.options.source ? (i2 = this.options.source, this.source = function(e3, n2) {
      s2.xhr && s2.xhr.abort(), s2.xhr = t.ajax({ url: i2, data: e3, dataType: "json", success: function(t2) {
        n2(t2);
      }, error: function() {
        n2([]);
      } });
    }) : this.source = this.options.source;
  }, _searchTimeout: function(t2) {
    clearTimeout(this.searching), this.searching = this._delay(function() {
      var e2 = this.term === this._value(), i2 = this.menu.element.is(":visible"), s2 = t2.altKey || t2.ctrlKey || t2.metaKey || t2.shiftKey;
      (!e2 || e2 && !i2 && !s2) && (this.selectedItem = null, this.search(null, t2));
    }, this.options.delay);
  }, search: function(t2, e2) {
    return t2 = null != t2 ? t2 : this._value(), this.term = this._value(), t2.length < this.options.minLength ? this.close(e2) : this._trigger("search", e2) !== false ? this._search(t2) : void 0;
  }, _search: function(t2) {
    this.pending++, this._addClass("ui-autocomplete-loading"), this.cancelSearch = false, this.source({ term: t2 }, this._response());
  }, _response: function() {
    var e2 = ++this.requestIndex;
    return t.proxy(function(t2) {
      e2 === this.requestIndex && this.__response(t2), this.pending--, this.pending || this._removeClass("ui-autocomplete-loading");
    }, this);
  }, __response: function(t2) {
    t2 && (t2 = this._normalize(t2)), this._trigger("response", null, { content: t2 }), !this.options.disabled && t2 && t2.length && !this.cancelSearch ? (this._suggest(t2), this._trigger("open")) : this._close();
  }, close: function(t2) {
    this.cancelSearch = true, this._close(t2);
  }, _close: function(t2) {
    this._off(this.document, "mousedown"), this.menu.element.is(":visible") && (this.menu.element.hide(), this.menu.blur(), this.isNewMenu = true, this._trigger("close", t2));
  }, _change: function(t2) {
    this.previous !== this._value() && this._trigger("change", t2, { item: this.selectedItem });
  }, _normalize: function(e2) {
    return e2.length && e2[0].label && e2[0].value ? e2 : t.map(e2, function(e3) {
      return "string" == typeof e3 ? { label: e3, value: e3 } : t.extend({}, e3, { label: e3.label || e3.value, value: e3.value || e3.label });
    });
  }, _suggest: function(e2) {
    var i2 = this.menu.element.empty();
    this._renderMenu(i2, e2), this.isNewMenu = true, this.menu.refresh(), i2.show(), this._resizeMenu(), i2.position(t.extend({ of: this.element }, this.options.position)), this.options.autoFocus && this.menu.next(), this._on(this.document, { mousedown: "_closeOnClickOutside" });
  }, _resizeMenu: function() {
    var t2 = this.menu.element;
    t2.outerWidth(Math.max(t2.width("").outerWidth() + 1, this.element.outerWidth()));
  }, _renderMenu: function(e2, i2) {
    var s2 = this;
    t.each(i2, function(t2, i3) {
      s2._renderItemData(e2, i3);
    });
  }, _renderItemData: function(t2, e2) {
    return this._renderItem(t2, e2).data("ui-autocomplete-item", e2);
  }, _renderItem: function(e2, i2) {
    return t("<li>").append(t("<div>").text(i2.label)).appendTo(e2);
  }, _move: function(t2, e2) {
    return this.menu.element.is(":visible") ? this.menu.isFirstItem() && /^previous/.test(t2) || this.menu.isLastItem() && /^next/.test(t2) ? (this.isMultiLine || this._value(this.term), this.menu.blur(), void 0) : (this.menu[t2](e2), void 0) : (this.search(null, e2), void 0);
  }, widget: function() {
    return this.menu.element;
  }, _value: function() {
    return this.valueMethod.apply(this.element, arguments);
  }, _keyEvent: function(t2, e2) {
    (!this.isMultiLine || this.menu.element.is(":visible")) && (this._move(t2, e2), e2.preventDefault());
  }, _isContentEditable: function(t2) {
    if (!t2.length)
      return false;
    var e2 = t2.prop("contentEditable");
    return "inherit" === e2 ? this._isContentEditable(t2.parent()) : "true" === e2;
  } }), t.extend(t.ui.autocomplete, { escapeRegex: function(t2) {
    return t2.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
  }, filter: function(e2, i2) {
    var s2 = RegExp(t.ui.autocomplete.escapeRegex(i2), "i");
    return t.grep(e2, function(t2) {
      return s2.test(t2.label || t2.value || t2);
    });
  } }), t.widget("ui.autocomplete", t.ui.autocomplete, { options: { messages: { noResults: "No search results.", results: function(t2) {
    return t2 + (t2 > 1 ? " results are" : " result is") + " available, use up and down arrow keys to navigate.";
  } } }, __response: function(e2) {
    var i2;
    this._superApply(arguments), this.options.disabled || this.cancelSearch || (i2 = e2 && e2.length ? this.options.messages.results(e2.length) : this.options.messages.noResults, this.liveRegion.children().hide(), t("<div>").text(i2).appendTo(this.liveRegion));
  } }), t.ui.autocomplete;
  var g = /ui-corner-([a-z]){2,6}/g;
  t.widget("ui.controlgroup", { version: "1.12.1", defaultElement: "<div>", options: { direction: "horizontal", disabled: null, onlyVisible: true, items: { button: "input[type=button], input[type=submit], input[type=reset], button, a", controlgroupLabel: ".ui-controlgroup-label", checkboxradio: "input[type='checkbox'], input[type='radio']", selectmenu: "select", spinner: ".ui-spinner-input" } }, _create: function() {
    this._enhance();
  }, _enhance: function() {
    this.element.attr("role", "toolbar"), this.refresh();
  }, _destroy: function() {
    this._callChildMethod("destroy"), this.childWidgets.removeData("ui-controlgroup-data"), this.element.removeAttr("role"), this.options.items.controlgroupLabel && this.element.find(this.options.items.controlgroupLabel).find(".ui-controlgroup-label-contents").contents().unwrap();
  }, _initWidgets: function() {
    var e2 = this, i2 = [];
    t.each(this.options.items, function(s2, n2) {
      var o2, a2 = {};
      return n2 ? "controlgroupLabel" === s2 ? (o2 = e2.element.find(n2), o2.each(function() {
        var e3 = t(this);
        e3.children(".ui-controlgroup-label-contents").length || e3.contents().wrapAll("<span class='ui-controlgroup-label-contents'></span>");
      }), e2._addClass(o2, null, "ui-widget ui-widget-content ui-state-default"), i2 = i2.concat(o2.get()), void 0) : (t.fn[s2] && (a2 = e2["_" + s2 + "Options"] ? e2["_" + s2 + "Options"]("middle") : { classes: {} }, e2.element.find(n2).each(function() {
        var n3 = t(this), o3 = n3[s2]("instance"), r2 = t.widget.extend({}, a2);
        if ("button" !== s2 || !n3.parent(".ui-spinner").length) {
          o3 || (o3 = n3[s2]()[s2]("instance")), o3 && (r2.classes = e2._resolveClassesValues(r2.classes, o3)), n3[s2](r2);
          var h2 = n3[s2]("widget");
          t.data(h2[0], "ui-controlgroup-data", o3 ? o3 : n3[s2]("instance")), i2.push(h2[0]);
        }
      })), void 0) : void 0;
    }), this.childWidgets = t(t.unique(i2)), this._addClass(this.childWidgets, "ui-controlgroup-item");
  }, _callChildMethod: function(e2) {
    this.childWidgets.each(function() {
      var i2 = t(this), s2 = i2.data("ui-controlgroup-data");
      s2 && s2[e2] && s2[e2]();
    });
  }, _updateCornerClass: function(t2, e2) {
    var i2 = "ui-corner-top ui-corner-bottom ui-corner-left ui-corner-right ui-corner-all", s2 = this._buildSimpleOptions(e2, "label").classes.label;
    this._removeClass(t2, null, i2), this._addClass(t2, null, s2);
  }, _buildSimpleOptions: function(t2, e2) {
    var i2 = "vertical" === this.options.direction, s2 = { classes: {} };
    return s2.classes[e2] = { middle: "", first: "ui-corner-" + (i2 ? "top" : "left"), last: "ui-corner-" + (i2 ? "bottom" : "right"), only: "ui-corner-all" }[t2], s2;
  }, _spinnerOptions: function(t2) {
    var e2 = this._buildSimpleOptions(t2, "ui-spinner");
    return e2.classes["ui-spinner-up"] = "", e2.classes["ui-spinner-down"] = "", e2;
  }, _buttonOptions: function(t2) {
    return this._buildSimpleOptions(t2, "ui-button");
  }, _checkboxradioOptions: function(t2) {
    return this._buildSimpleOptions(t2, "ui-checkboxradio-label");
  }, _selectmenuOptions: function(t2) {
    var e2 = "vertical" === this.options.direction;
    return { width: e2 ? "auto" : false, classes: { middle: { "ui-selectmenu-button-open": "", "ui-selectmenu-button-closed": "" }, first: { "ui-selectmenu-button-open": "ui-corner-" + (e2 ? "top" : "tl"), "ui-selectmenu-button-closed": "ui-corner-" + (e2 ? "top" : "left") }, last: { "ui-selectmenu-button-open": e2 ? "" : "ui-corner-tr", "ui-selectmenu-button-closed": "ui-corner-" + (e2 ? "bottom" : "right") }, only: { "ui-selectmenu-button-open": "ui-corner-top", "ui-selectmenu-button-closed": "ui-corner-all" } }[t2] };
  }, _resolveClassesValues: function(e2, i2) {
    var s2 = {};
    return t.each(e2, function(n2) {
      var o2 = i2.options.classes[n2] || "";
      o2 = t.trim(o2.replace(g, "")), s2[n2] = (o2 + " " + e2[n2]).replace(/\s+/g, " ");
    }), s2;
  }, _setOption: function(t2, e2) {
    return "direction" === t2 && this._removeClass("ui-controlgroup-" + this.options.direction), this._super(t2, e2), "disabled" === t2 ? (this._callChildMethod(e2 ? "disable" : "enable"), void 0) : (this.refresh(), void 0);
  }, refresh: function() {
    var e2, i2 = this;
    this._addClass("ui-controlgroup ui-controlgroup-" + this.options.direction), "horizontal" === this.options.direction && this._addClass(null, "ui-helper-clearfix"), this._initWidgets(), e2 = this.childWidgets, this.options.onlyVisible && (e2 = e2.filter(":visible")), e2.length && (t.each(["first", "last"], function(t2, s2) {
      var n2 = e2[s2]().data("ui-controlgroup-data");
      if (n2 && i2["_" + n2.widgetName + "Options"]) {
        var o2 = i2["_" + n2.widgetName + "Options"](1 === e2.length ? "only" : s2);
        o2.classes = i2._resolveClassesValues(o2.classes, n2), n2.element[n2.widgetName](o2);
      } else
        i2._updateCornerClass(e2[s2](), s2);
    }), this._callChildMethod("refresh"));
  } }), t.widget("ui.checkboxradio", [t.ui.formResetMixin, { version: "1.12.1", options: { disabled: null, label: null, icon: true, classes: { "ui-checkboxradio-label": "ui-corner-all", "ui-checkboxradio-icon": "ui-corner-all" } }, _getCreateOptions: function() {
    var e2, i2, s2 = this, n2 = this._super() || {};
    return this._readType(), i2 = this.element.labels(), this.label = t(i2[i2.length - 1]), this.label.length || t.error("No label found for checkboxradio widget"), this.originalLabel = "", this.label.contents().not(this.element[0]).each(function() {
      s2.originalLabel += 3 === this.nodeType ? t(this).text() : this.outerHTML;
    }), this.originalLabel && (n2.label = this.originalLabel), e2 = this.element[0].disabled, null != e2 && (n2.disabled = e2), n2;
  }, _create: function() {
    var t2 = this.element[0].checked;
    this._bindFormResetHandler(), null == this.options.disabled && (this.options.disabled = this.element[0].disabled), this._setOption("disabled", this.options.disabled), this._addClass("ui-checkboxradio", "ui-helper-hidden-accessible"), this._addClass(this.label, "ui-checkboxradio-label", "ui-button ui-widget"), "radio" === this.type && this._addClass(this.label, "ui-checkboxradio-radio-label"), this.options.label && this.options.label !== this.originalLabel ? this._updateLabel() : this.originalLabel && (this.options.label = this.originalLabel), this._enhance(), t2 && (this._addClass(this.label, "ui-checkboxradio-checked", "ui-state-active"), this.icon && this._addClass(this.icon, null, "ui-state-hover")), this._on({ change: "_toggleClasses", focus: function() {
      this._addClass(this.label, null, "ui-state-focus ui-visual-focus");
    }, blur: function() {
      this._removeClass(this.label, null, "ui-state-focus ui-visual-focus");
    } });
  }, _readType: function() {
    var e2 = this.element[0].nodeName.toLowerCase();
    this.type = this.element[0].type, "input" === e2 && /radio|checkbox/.test(this.type) || t.error("Can't create checkboxradio on element.nodeName=" + e2 + " and element.type=" + this.type);
  }, _enhance: function() {
    this._updateIcon(this.element[0].checked);
  }, widget: function() {
    return this.label;
  }, _getRadioGroup: function() {
    var e2, i2 = this.element[0].name, s2 = "input[name='" + t.ui.escapeSelector(i2) + "']";
    return i2 ? (e2 = this.form.length ? t(this.form[0].elements).filter(s2) : t(s2).filter(function() {
      return 0 === t(this).form().length;
    }), e2.not(this.element)) : t([]);
  }, _toggleClasses: function() {
    var e2 = this.element[0].checked;
    this._toggleClass(this.label, "ui-checkboxradio-checked", "ui-state-active", e2), this.options.icon && "checkbox" === this.type && this._toggleClass(this.icon, null, "ui-icon-check ui-state-checked", e2)._toggleClass(this.icon, null, "ui-icon-blank", !e2), "radio" === this.type && this._getRadioGroup().each(function() {
      var e3 = t(this).checkboxradio("instance");
      e3 && e3._removeClass(e3.label, "ui-checkboxradio-checked", "ui-state-active");
    });
  }, _destroy: function() {
    this._unbindFormResetHandler(), this.icon && (this.icon.remove(), this.iconSpace.remove());
  }, _setOption: function(t2, e2) {
    return "label" !== t2 || e2 ? (this._super(t2, e2), "disabled" === t2 ? (this._toggleClass(this.label, null, "ui-state-disabled", e2), this.element[0].disabled = e2, void 0) : (this.refresh(), void 0)) : void 0;
  }, _updateIcon: function(e2) {
    var i2 = "ui-icon ui-icon-background ";
    this.options.icon ? (this.icon || (this.icon = t("<span>"), this.iconSpace = t("<span> </span>"), this._addClass(this.iconSpace, "ui-checkboxradio-icon-space")), "checkbox" === this.type ? (i2 += e2 ? "ui-icon-check ui-state-checked" : "ui-icon-blank", this._removeClass(this.icon, null, e2 ? "ui-icon-blank" : "ui-icon-check")) : i2 += "ui-icon-blank", this._addClass(this.icon, "ui-checkboxradio-icon", i2), e2 || this._removeClass(this.icon, null, "ui-icon-check ui-state-checked"), this.icon.prependTo(this.label).after(this.iconSpace)) : void 0 !== this.icon && (this.icon.remove(), this.iconSpace.remove(), delete this.icon);
  }, _updateLabel: function() {
    var t2 = this.label.contents().not(this.element[0]);
    this.icon && (t2 = t2.not(this.icon[0])), this.iconSpace && (t2 = t2.not(this.iconSpace[0])), t2.remove(), this.label.append(this.options.label);
  }, refresh: function() {
    var t2 = this.element[0].checked, e2 = this.element[0].disabled;
    this._updateIcon(t2), this._toggleClass(this.label, "ui-checkboxradio-checked", "ui-state-active", t2), null !== this.options.label && this._updateLabel(), e2 !== this.options.disabled && this._setOptions({ disabled: e2 });
  } }]), t.ui.checkboxradio, t.widget("ui.button", { version: "1.12.1", defaultElement: "<button>", options: { classes: { "ui-button": "ui-corner-all" }, disabled: null, icon: null, iconPosition: "beginning", label: null, showLabel: true }, _getCreateOptions: function() {
    var t2, e2 = this._super() || {};
    return this.isInput = this.element.is("input"), t2 = this.element[0].disabled, null != t2 && (e2.disabled = t2), this.originalLabel = this.isInput ? this.element.val() : this.element.html(), this.originalLabel && (e2.label = this.originalLabel), e2;
  }, _create: function() {
    !this.option.showLabel & !this.options.icon && (this.options.showLabel = true), null == this.options.disabled && (this.options.disabled = this.element[0].disabled || false), this.hasTitle = !!this.element.attr("title"), this.options.label && this.options.label !== this.originalLabel && (this.isInput ? this.element.val(this.options.label) : this.element.html(this.options.label)), this._addClass("ui-button", "ui-widget"), this._setOption("disabled", this.options.disabled), this._enhance(), this.element.is("a") && this._on({ keyup: function(e2) {
      e2.keyCode === t.ui.keyCode.SPACE && (e2.preventDefault(), this.element[0].click ? this.element[0].click() : this.element.trigger("click"));
    } });
  }, _enhance: function() {
    this.element.is("button") || this.element.attr("role", "button"), this.options.icon && (this._updateIcon("icon", this.options.icon), this._updateTooltip());
  }, _updateTooltip: function() {
    this.title = this.element.attr("title"), this.options.showLabel || this.title || this.element.attr("title", this.options.label);
  }, _updateIcon: function(e2, i2) {
    var s2 = "iconPosition" !== e2, n2 = s2 ? this.options.iconPosition : i2, o2 = "top" === n2 || "bottom" === n2;
    this.icon ? s2 && this._removeClass(this.icon, null, this.options.icon) : (this.icon = t("<span>"), this._addClass(this.icon, "ui-button-icon", "ui-icon"), this.options.showLabel || this._addClass("ui-button-icon-only")), s2 && this._addClass(this.icon, null, i2), this._attachIcon(n2), o2 ? (this._addClass(this.icon, null, "ui-widget-icon-block"), this.iconSpace && this.iconSpace.remove()) : (this.iconSpace || (this.iconSpace = t("<span> </span>"), this._addClass(this.iconSpace, "ui-button-icon-space")), this._removeClass(this.icon, null, "ui-wiget-icon-block"), this._attachIconSpace(n2));
  }, _destroy: function() {
    this.element.removeAttr("role"), this.icon && this.icon.remove(), this.iconSpace && this.iconSpace.remove(), this.hasTitle || this.element.removeAttr("title");
  }, _attachIconSpace: function(t2) {
    this.icon[/^(?:end|bottom)/.test(t2) ? "before" : "after"](this.iconSpace);
  }, _attachIcon: function(t2) {
    this.element[/^(?:end|bottom)/.test(t2) ? "append" : "prepend"](this.icon);
  }, _setOptions: function(t2) {
    var e2 = void 0 === t2.showLabel ? this.options.showLabel : t2.showLabel, i2 = void 0 === t2.icon ? this.options.icon : t2.icon;
    e2 || i2 || (t2.showLabel = true), this._super(t2);
  }, _setOption: function(t2, e2) {
    "icon" === t2 && (e2 ? this._updateIcon(t2, e2) : this.icon && (this.icon.remove(), this.iconSpace && this.iconSpace.remove())), "iconPosition" === t2 && this._updateIcon(t2, e2), "showLabel" === t2 && (this._toggleClass("ui-button-icon-only", null, !e2), this._updateTooltip()), "label" === t2 && (this.isInput ? this.element.val(e2) : (this.element.html(e2), this.icon && (this._attachIcon(this.options.iconPosition), this._attachIconSpace(this.options.iconPosition)))), this._super(t2, e2), "disabled" === t2 && (this._toggleClass(null, "ui-state-disabled", e2), this.element[0].disabled = e2, e2 && this.element.blur());
  }, refresh: function() {
    var t2 = this.element.is("input, button") ? this.element[0].disabled : this.element.hasClass("ui-button-disabled");
    t2 !== this.options.disabled && this._setOptions({ disabled: t2 }), this._updateTooltip();
  } }), t.uiBackCompat !== false && (t.widget("ui.button", t.ui.button, { options: { text: true, icons: { primary: null, secondary: null } }, _create: function() {
    this.options.showLabel && !this.options.text && (this.options.showLabel = this.options.text), !this.options.showLabel && this.options.text && (this.options.text = this.options.showLabel), this.options.icon || !this.options.icons.primary && !this.options.icons.secondary ? this.options.icon && (this.options.icons.primary = this.options.icon) : this.options.icons.primary ? this.options.icon = this.options.icons.primary : (this.options.icon = this.options.icons.secondary, this.options.iconPosition = "end"), this._super();
  }, _setOption: function(t2, e2) {
    return "text" === t2 ? (this._super("showLabel", e2), void 0) : ("showLabel" === t2 && (this.options.text = e2), "icon" === t2 && (this.options.icons.primary = e2), "icons" === t2 && (e2.primary ? (this._super("icon", e2.primary), this._super("iconPosition", "beginning")) : e2.secondary && (this._super("icon", e2.secondary), this._super("iconPosition", "end"))), this._superApply(arguments), void 0);
  } }), t.fn.button = function(e2) {
    return function() {
      return !this.length || this.length && "INPUT" !== this[0].tagName || this.length && "INPUT" === this[0].tagName && "checkbox" !== this.attr("type") && "radio" !== this.attr("type") ? e2.apply(this, arguments) : (t.ui.checkboxradio || t.error("Checkboxradio widget missing"), 0 === arguments.length ? this.checkboxradio({ icon: false }) : this.checkboxradio.apply(this, arguments));
    };
  }(t.fn.button), t.fn.buttonset = function() {
    return t.ui.controlgroup || t.error("Controlgroup widget missing"), "option" === arguments[0] && "items" === arguments[1] && arguments[2] ? this.controlgroup.apply(this, [arguments[0], "items.button", arguments[2]]) : "option" === arguments[0] && "items" === arguments[1] ? this.controlgroup.apply(this, [arguments[0], "items.button"]) : ("object" == typeof arguments[0] && arguments[0].items && (arguments[0].items = { button: arguments[0].items }), this.controlgroup.apply(this, arguments));
  }), t.ui.button, t.extend(t.ui, { datepicker: { version: "1.12.1" } });
  var m;
  t.extend(s.prototype, { markerClassName: "hasDatepicker", maxRows: 4, _widgetDatepicker: function() {
    return this.dpDiv;
  }, setDefaults: function(t2) {
    return a(this._defaults, t2 || {}), this;
  }, _attachDatepicker: function(e2, i2) {
    var s2, n2, o2;
    s2 = e2.nodeName.toLowerCase(), n2 = "div" === s2 || "span" === s2, e2.id || (this.uuid += 1, e2.id = "dp" + this.uuid), o2 = this._newInst(t(e2), n2), o2.settings = t.extend({}, i2 || {}), "input" === s2 ? this._connectDatepicker(e2, o2) : n2 && this._inlineDatepicker(e2, o2);
  }, _newInst: function(e2, i2) {
    var s2 = e2[0].id.replace(/([^A-Za-z0-9_\-])/g, "\\\\$1");
    return { id: s2, input: e2, selectedDay: 0, selectedMonth: 0, selectedYear: 0, drawMonth: 0, drawYear: 0, inline: i2, dpDiv: i2 ? n(t("<div class='" + this._inlineClass + " ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>")) : this.dpDiv };
  }, _connectDatepicker: function(e2, i2) {
    var s2 = t(e2);
    i2.append = t([]), i2.trigger = t([]), s2.hasClass(this.markerClassName) || (this._attachments(s2, i2), s2.addClass(this.markerClassName).on("keydown", this._doKeyDown).on("keypress", this._doKeyPress).on("keyup", this._doKeyUp), this._autoSize(i2), t.data(e2, "datepicker", i2), i2.settings.disabled && this._disableDatepicker(e2));
  }, _attachments: function(e2, i2) {
    var s2, n2, o2, a2 = this._get(i2, "appendText"), r2 = this._get(i2, "isRTL");
    i2.append && i2.append.remove(), a2 && (i2.append = t("<span class='" + this._appendClass + "'>" + a2 + "</span>"), e2[r2 ? "before" : "after"](i2.append)), e2.off("focus", this._showDatepicker), i2.trigger && i2.trigger.remove(), s2 = this._get(i2, "showOn"), ("focus" === s2 || "both" === s2) && e2.on("focus", this._showDatepicker), ("button" === s2 || "both" === s2) && (n2 = this._get(i2, "buttonText"), o2 = this._get(i2, "buttonImage"), i2.trigger = t(this._get(i2, "buttonImageOnly") ? t("<img/>").addClass(this._triggerClass).attr({ src: o2, alt: n2, title: n2 }) : t("<button type='button'></button>").addClass(this._triggerClass).html(o2 ? t("<img/>").attr({ src: o2, alt: n2, title: n2 }) : n2)), e2[r2 ? "before" : "after"](i2.trigger), i2.trigger.on("click", function() {
      return t.datepicker._datepickerShowing && t.datepicker._lastInput === e2[0] ? t.datepicker._hideDatepicker() : t.datepicker._datepickerShowing && t.datepicker._lastInput !== e2[0] ? (t.datepicker._hideDatepicker(), t.datepicker._showDatepicker(e2[0])) : t.datepicker._showDatepicker(e2[0]), false;
    }));
  }, _autoSize: function(t2) {
    if (this._get(t2, "autoSize") && !t2.inline) {
      var e2, i2, s2, n2, o2 = new Date(2009, 11, 20), a2 = this._get(t2, "dateFormat");
      a2.match(/[DM]/) && (e2 = function(t3) {
        for (i2 = 0, s2 = 0, n2 = 0; t3.length > n2; n2++)
          t3[n2].length > i2 && (i2 = t3[n2].length, s2 = n2);
        return s2;
      }, o2.setMonth(e2(this._get(t2, a2.match(/MM/) ? "monthNames" : "monthNamesShort"))), o2.setDate(e2(this._get(t2, a2.match(/DD/) ? "dayNames" : "dayNamesShort")) + 20 - o2.getDay())), t2.input.attr("size", this._formatDate(t2, o2).length);
    }
  }, _inlineDatepicker: function(e2, i2) {
    var s2 = t(e2);
    s2.hasClass(this.markerClassName) || (s2.addClass(this.markerClassName).append(i2.dpDiv), t.data(e2, "datepicker", i2), this._setDate(i2, this._getDefaultDate(i2), true), this._updateDatepicker(i2), this._updateAlternate(i2), i2.settings.disabled && this._disableDatepicker(e2), i2.dpDiv.css("display", "block"));
  }, _dialogDatepicker: function(e2, i2, s2, n2, o2) {
    var r2, h2, l2, c2, u2, d2 = this._dialogInst;
    return d2 || (this.uuid += 1, r2 = "dp" + this.uuid, this._dialogInput = t("<input type='text' id='" + r2 + "' style='position: absolute; top: -100px; width: 0px;'/>"), this._dialogInput.on("keydown", this._doKeyDown), t("body").append(this._dialogInput), d2 = this._dialogInst = this._newInst(this._dialogInput, false), d2.settings = {}, t.data(this._dialogInput[0], "datepicker", d2)), a(d2.settings, n2 || {}), i2 = i2 && i2.constructor === Date ? this._formatDate(d2, i2) : i2, this._dialogInput.val(i2), this._pos = o2 ? o2.length ? o2 : [o2.pageX, o2.pageY] : null, this._pos || (h2 = document.documentElement.clientWidth, l2 = document.documentElement.clientHeight, c2 = document.documentElement.scrollLeft || document.body.scrollLeft, u2 = document.documentElement.scrollTop || document.body.scrollTop, this._pos = [h2 / 2 - 100 + c2, l2 / 2 - 150 + u2]), this._dialogInput.css("left", this._pos[0] + 20 + "px").css("top", this._pos[1] + "px"), d2.settings.onSelect = s2, this._inDialog = true, this.dpDiv.addClass(this._dialogClass), this._showDatepicker(this._dialogInput[0]), t.blockUI && t.blockUI(this.dpDiv), t.data(this._dialogInput[0], "datepicker", d2), this;
  }, _destroyDatepicker: function(e2) {
    var i2, s2 = t(e2), n2 = t.data(e2, "datepicker");
    s2.hasClass(this.markerClassName) && (i2 = e2.nodeName.toLowerCase(), t.removeData(e2, "datepicker"), "input" === i2 ? (n2.append.remove(), n2.trigger.remove(), s2.removeClass(this.markerClassName).off("focus", this._showDatepicker).off("keydown", this._doKeyDown).off("keypress", this._doKeyPress).off("keyup", this._doKeyUp)) : ("div" === i2 || "span" === i2) && s2.removeClass(this.markerClassName).empty(), m === n2 && (m = null));
  }, _enableDatepicker: function(e2) {
    var i2, s2, n2 = t(e2), o2 = t.data(e2, "datepicker");
    n2.hasClass(this.markerClassName) && (i2 = e2.nodeName.toLowerCase(), "input" === i2 ? (e2.disabled = false, o2.trigger.filter("button").each(function() {
      this.disabled = false;
    }).end().filter("img").css({ opacity: "1.0", cursor: "" })) : ("div" === i2 || "span" === i2) && (s2 = n2.children("." + this._inlineClass), s2.children().removeClass("ui-state-disabled"), s2.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", false)), this._disabledInputs = t.map(this._disabledInputs, function(t2) {
      return t2 === e2 ? null : t2;
    }));
  }, _disableDatepicker: function(e2) {
    var i2, s2, n2 = t(e2), o2 = t.data(e2, "datepicker");
    n2.hasClass(this.markerClassName) && (i2 = e2.nodeName.toLowerCase(), "input" === i2 ? (e2.disabled = true, o2.trigger.filter("button").each(function() {
      this.disabled = true;
    }).end().filter("img").css({ opacity: "0.5", cursor: "default" })) : ("div" === i2 || "span" === i2) && (s2 = n2.children("." + this._inlineClass), s2.children().addClass("ui-state-disabled"), s2.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", true)), this._disabledInputs = t.map(this._disabledInputs, function(t2) {
      return t2 === e2 ? null : t2;
    }), this._disabledInputs[this._disabledInputs.length] = e2);
  }, _isDisabledDatepicker: function(t2) {
    if (!t2)
      return false;
    for (var e2 = 0; this._disabledInputs.length > e2; e2++)
      if (this._disabledInputs[e2] === t2)
        return true;
    return false;
  }, _getInst: function(e2) {
    try {
      return t.data(e2, "datepicker");
    } catch (i2) {
      throw "Missing instance data for this datepicker";
    }
  }, _optionDatepicker: function(e2, i2, s2) {
    var n2, o2, r2, h2, l2 = this._getInst(e2);
    return 2 === arguments.length && "string" == typeof i2 ? "defaults" === i2 ? t.extend({}, t.datepicker._defaults) : l2 ? "all" === i2 ? t.extend({}, l2.settings) : this._get(l2, i2) : null : (n2 = i2 || {}, "string" == typeof i2 && (n2 = {}, n2[i2] = s2), l2 && (this._curInst === l2 && this._hideDatepicker(), o2 = this._getDateDatepicker(e2, true), r2 = this._getMinMaxDate(l2, "min"), h2 = this._getMinMaxDate(l2, "max"), a(l2.settings, n2), null !== r2 && void 0 !== n2.dateFormat && void 0 === n2.minDate && (l2.settings.minDate = this._formatDate(l2, r2)), null !== h2 && void 0 !== n2.dateFormat && void 0 === n2.maxDate && (l2.settings.maxDate = this._formatDate(l2, h2)), "disabled" in n2 && (n2.disabled ? this._disableDatepicker(e2) : this._enableDatepicker(e2)), this._attachments(t(e2), l2), this._autoSize(l2), this._setDate(l2, o2), this._updateAlternate(l2), this._updateDatepicker(l2)), void 0);
  }, _changeDatepicker: function(t2, e2, i2) {
    this._optionDatepicker(t2, e2, i2);
  }, _refreshDatepicker: function(t2) {
    var e2 = this._getInst(t2);
    e2 && this._updateDatepicker(e2);
  }, _setDateDatepicker: function(t2, e2) {
    var i2 = this._getInst(t2);
    i2 && (this._setDate(i2, e2), this._updateDatepicker(i2), this._updateAlternate(i2));
  }, _getDateDatepicker: function(t2, e2) {
    var i2 = this._getInst(t2);
    return i2 && !i2.inline && this._setDateFromField(i2, e2), i2 ? this._getDate(i2) : null;
  }, _doKeyDown: function(e2) {
    var i2, s2, n2, o2 = t.datepicker._getInst(e2.target), a2 = true, r2 = o2.dpDiv.is(".ui-datepicker-rtl");
    if (o2._keyEvent = true, t.datepicker._datepickerShowing)
      switch (e2.keyCode) {
        case 9:
          t.datepicker._hideDatepicker(), a2 = false;
          break;
        case 13:
          return n2 = t("td." + t.datepicker._dayOverClass + ":not(." + t.datepicker._currentClass + ")", o2.dpDiv), n2[0] && t.datepicker._selectDay(e2.target, o2.selectedMonth, o2.selectedYear, n2[0]), i2 = t.datepicker._get(o2, "onSelect"), i2 ? (s2 = t.datepicker._formatDate(o2), i2.apply(o2.input ? o2.input[0] : null, [s2, o2])) : t.datepicker._hideDatepicker(), false;
        case 27:
          t.datepicker._hideDatepicker();
          break;
        case 33:
          t.datepicker._adjustDate(e2.target, e2.ctrlKey ? -t.datepicker._get(o2, "stepBigMonths") : -t.datepicker._get(o2, "stepMonths"), "M");
          break;
        case 34:
          t.datepicker._adjustDate(e2.target, e2.ctrlKey ? +t.datepicker._get(o2, "stepBigMonths") : +t.datepicker._get(o2, "stepMonths"), "M");
          break;
        case 35:
          (e2.ctrlKey || e2.metaKey) && t.datepicker._clearDate(e2.target), a2 = e2.ctrlKey || e2.metaKey;
          break;
        case 36:
          (e2.ctrlKey || e2.metaKey) && t.datepicker._gotoToday(e2.target), a2 = e2.ctrlKey || e2.metaKey;
          break;
        case 37:
          (e2.ctrlKey || e2.metaKey) && t.datepicker._adjustDate(e2.target, r2 ? 1 : -1, "D"), a2 = e2.ctrlKey || e2.metaKey, e2.originalEvent.altKey && t.datepicker._adjustDate(e2.target, e2.ctrlKey ? -t.datepicker._get(o2, "stepBigMonths") : -t.datepicker._get(o2, "stepMonths"), "M");
          break;
        case 38:
          (e2.ctrlKey || e2.metaKey) && t.datepicker._adjustDate(e2.target, -7, "D"), a2 = e2.ctrlKey || e2.metaKey;
          break;
        case 39:
          (e2.ctrlKey || e2.metaKey) && t.datepicker._adjustDate(e2.target, r2 ? -1 : 1, "D"), a2 = e2.ctrlKey || e2.metaKey, e2.originalEvent.altKey && t.datepicker._adjustDate(e2.target, e2.ctrlKey ? +t.datepicker._get(o2, "stepBigMonths") : +t.datepicker._get(o2, "stepMonths"), "M");
          break;
        case 40:
          (e2.ctrlKey || e2.metaKey) && t.datepicker._adjustDate(e2.target, 7, "D"), a2 = e2.ctrlKey || e2.metaKey;
          break;
        default:
          a2 = false;
      }
    else
      36 === e2.keyCode && e2.ctrlKey ? t.datepicker._showDatepicker(this) : a2 = false;
    a2 && (e2.preventDefault(), e2.stopPropagation());
  }, _doKeyPress: function(e2) {
    var i2, s2, n2 = t.datepicker._getInst(e2.target);
    return t.datepicker._get(n2, "constrainInput") ? (i2 = t.datepicker._possibleChars(t.datepicker._get(n2, "dateFormat")), s2 = String.fromCharCode(null == e2.charCode ? e2.keyCode : e2.charCode), e2.ctrlKey || e2.metaKey || " " > s2 || !i2 || i2.indexOf(s2) > -1) : void 0;
  }, _doKeyUp: function(e2) {
    var i2, s2 = t.datepicker._getInst(e2.target);
    if (s2.input.val() !== s2.lastVal)
      try {
        i2 = t.datepicker.parseDate(t.datepicker._get(s2, "dateFormat"), s2.input ? s2.input.val() : null, t.datepicker._getFormatConfig(s2)), i2 && (t.datepicker._setDateFromField(s2), t.datepicker._updateAlternate(s2), t.datepicker._updateDatepicker(s2));
      } catch (n2) {
      }
    return true;
  }, _showDatepicker: function(e2) {
    if (e2 = e2.target || e2, "input" !== e2.nodeName.toLowerCase() && (e2 = t("input", e2.parentNode)[0]), !t.datepicker._isDisabledDatepicker(e2) && t.datepicker._lastInput !== e2) {
      var s2, n2, o2, r2, h2, l2, c2;
      s2 = t.datepicker._getInst(e2), t.datepicker._curInst && t.datepicker._curInst !== s2 && (t.datepicker._curInst.dpDiv.stop(true, true), s2 && t.datepicker._datepickerShowing && t.datepicker._hideDatepicker(t.datepicker._curInst.input[0])), n2 = t.datepicker._get(s2, "beforeShow"), o2 = n2 ? n2.apply(e2, [e2, s2]) : {}, o2 !== false && (a(s2.settings, o2), s2.lastVal = null, t.datepicker._lastInput = e2, t.datepicker._setDateFromField(s2), t.datepicker._inDialog && (e2.value = ""), t.datepicker._pos || (t.datepicker._pos = t.datepicker._findPos(e2), t.datepicker._pos[1] += e2.offsetHeight), r2 = false, t(e2).parents().each(function() {
        return r2 |= "fixed" === t(this).css("position"), !r2;
      }), h2 = { left: t.datepicker._pos[0], top: t.datepicker._pos[1] }, t.datepicker._pos = null, s2.dpDiv.empty(), s2.dpDiv.css({ position: "absolute", display: "block", top: "-1000px" }), t.datepicker._updateDatepicker(s2), h2 = t.datepicker._checkOffset(s2, h2, r2), s2.dpDiv.css({ position: t.datepicker._inDialog && t.blockUI ? "static" : r2 ? "fixed" : "absolute", display: "none", left: h2.left + "px", top: h2.top + "px" }), s2.inline || (l2 = t.datepicker._get(s2, "showAnim"), c2 = t.datepicker._get(s2, "duration"), s2.dpDiv.css("z-index", i(t(e2)) + 1), t.datepicker._datepickerShowing = true, t.effects && t.effects.effect[l2] ? s2.dpDiv.show(l2, t.datepicker._get(s2, "showOptions"), c2) : s2.dpDiv[l2 || "show"](l2 ? c2 : null), t.datepicker._shouldFocusInput(s2) && s2.input.trigger("focus"), t.datepicker._curInst = s2));
    }
  }, _updateDatepicker: function(e2) {
    this.maxRows = 4, m = e2, e2.dpDiv.empty().append(this._generateHTML(e2)), this._attachHandlers(e2);
    var i2, s2 = this._getNumberOfMonths(e2), n2 = s2[1], a2 = 17, r2 = e2.dpDiv.find("." + this._dayOverClass + " a");
    r2.length > 0 && o.apply(r2.get(0)), e2.dpDiv.removeClass("ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4").width(""), n2 > 1 && e2.dpDiv.addClass("ui-datepicker-multi-" + n2).css("width", a2 * n2 + "em"), e2.dpDiv[(1 !== s2[0] || 1 !== s2[1] ? "add" : "remove") + "Class"]("ui-datepicker-multi"), e2.dpDiv[(this._get(e2, "isRTL") ? "add" : "remove") + "Class"]("ui-datepicker-rtl"), e2 === t.datepicker._curInst && t.datepicker._datepickerShowing && t.datepicker._shouldFocusInput(e2) && e2.input.trigger("focus"), e2.yearshtml && (i2 = e2.yearshtml, setTimeout(function() {
      i2 === e2.yearshtml && e2.yearshtml && e2.dpDiv.find("select.ui-datepicker-year:first").replaceWith(e2.yearshtml), i2 = e2.yearshtml = null;
    }, 0));
  }, _shouldFocusInput: function(t2) {
    return t2.input && t2.input.is(":visible") && !t2.input.is(":disabled") && !t2.input.is(":focus");
  }, _checkOffset: function(e2, i2, s2) {
    var n2 = e2.dpDiv.outerWidth(), o2 = e2.dpDiv.outerHeight(), a2 = e2.input ? e2.input.outerWidth() : 0, r2 = e2.input ? e2.input.outerHeight() : 0, h2 = document.documentElement.clientWidth + (s2 ? 0 : t(document).scrollLeft()), l2 = document.documentElement.clientHeight + (s2 ? 0 : t(document).scrollTop());
    return i2.left -= this._get(e2, "isRTL") ? n2 - a2 : 0, i2.left -= s2 && i2.left === e2.input.offset().left ? t(document).scrollLeft() : 0, i2.top -= s2 && i2.top === e2.input.offset().top + r2 ? t(document).scrollTop() : 0, i2.left -= Math.min(i2.left, i2.left + n2 > h2 && h2 > n2 ? Math.abs(i2.left + n2 - h2) : 0), i2.top -= Math.min(i2.top, i2.top + o2 > l2 && l2 > o2 ? Math.abs(o2 + r2) : 0), i2;
  }, _findPos: function(e2) {
    for (var i2, s2 = this._getInst(e2), n2 = this._get(s2, "isRTL"); e2 && ("hidden" === e2.type || 1 !== e2.nodeType || t.expr.filters.hidden(e2)); )
      e2 = e2[n2 ? "previousSibling" : "nextSibling"];
    return i2 = t(e2).offset(), [i2.left, i2.top];
  }, _hideDatepicker: function(e2) {
    var i2, s2, n2, o2, a2 = this._curInst;
    !a2 || e2 && a2 !== t.data(e2, "datepicker") || this._datepickerShowing && (i2 = this._get(a2, "showAnim"), s2 = this._get(a2, "duration"), n2 = function() {
      t.datepicker._tidyDialog(a2);
    }, t.effects && (t.effects.effect[i2] || t.effects[i2]) ? a2.dpDiv.hide(i2, t.datepicker._get(a2, "showOptions"), s2, n2) : a2.dpDiv["slideDown" === i2 ? "slideUp" : "fadeIn" === i2 ? "fadeOut" : "hide"](i2 ? s2 : null, n2), i2 || n2(), this._datepickerShowing = false, o2 = this._get(a2, "onClose"), o2 && o2.apply(a2.input ? a2.input[0] : null, [a2.input ? a2.input.val() : "", a2]), this._lastInput = null, this._inDialog && (this._dialogInput.css({ position: "absolute", left: "0", top: "-100px" }), t.blockUI && (t.unblockUI(), t("body").append(this.dpDiv))), this._inDialog = false);
  }, _tidyDialog: function(t2) {
    t2.dpDiv.removeClass(this._dialogClass).off(".ui-datepicker-calendar");
  }, _checkExternalClick: function(e2) {
    if (t.datepicker._curInst) {
      var i2 = t(e2.target), s2 = t.datepicker._getInst(i2[0]);
      (i2[0].id !== t.datepicker._mainDivId && 0 === i2.parents("#" + t.datepicker._mainDivId).length && !i2.hasClass(t.datepicker.markerClassName) && !i2.closest("." + t.datepicker._triggerClass).length && t.datepicker._datepickerShowing && (!t.datepicker._inDialog || !t.blockUI) || i2.hasClass(t.datepicker.markerClassName) && t.datepicker._curInst !== s2) && t.datepicker._hideDatepicker();
    }
  }, _adjustDate: function(e2, i2, s2) {
    var n2 = t(e2), o2 = this._getInst(n2[0]);
    this._isDisabledDatepicker(n2[0]) || (this._adjustInstDate(o2, i2 + ("M" === s2 ? this._get(o2, "showCurrentAtPos") : 0), s2), this._updateDatepicker(o2));
  }, _gotoToday: function(e2) {
    var i2, s2 = t(e2), n2 = this._getInst(s2[0]);
    this._get(n2, "gotoCurrent") && n2.currentDay ? (n2.selectedDay = n2.currentDay, n2.drawMonth = n2.selectedMonth = n2.currentMonth, n2.drawYear = n2.selectedYear = n2.currentYear) : (i2 = /* @__PURE__ */ new Date(), n2.selectedDay = i2.getDate(), n2.drawMonth = n2.selectedMonth = i2.getMonth(), n2.drawYear = n2.selectedYear = i2.getFullYear()), this._notifyChange(n2), this._adjustDate(s2);
  }, _selectMonthYear: function(e2, i2, s2) {
    var n2 = t(e2), o2 = this._getInst(n2[0]);
    o2["selected" + ("M" === s2 ? "Month" : "Year")] = o2["draw" + ("M" === s2 ? "Month" : "Year")] = parseInt(i2.options[i2.selectedIndex].value, 10), this._notifyChange(o2), this._adjustDate(n2);
  }, _selectDay: function(e2, i2, s2, n2) {
    var o2, a2 = t(e2);
    t(n2).hasClass(this._unselectableClass) || this._isDisabledDatepicker(a2[0]) || (o2 = this._getInst(a2[0]), o2.selectedDay = o2.currentDay = t("a", n2).html(), o2.selectedMonth = o2.currentMonth = i2, o2.selectedYear = o2.currentYear = s2, this._selectDate(e2, this._formatDate(o2, o2.currentDay, o2.currentMonth, o2.currentYear)));
  }, _clearDate: function(e2) {
    var i2 = t(e2);
    this._selectDate(i2, "");
  }, _selectDate: function(e2, i2) {
    var s2, n2 = t(e2), o2 = this._getInst(n2[0]);
    i2 = null != i2 ? i2 : this._formatDate(o2), o2.input && o2.input.val(i2), this._updateAlternate(o2), s2 = this._get(o2, "onSelect"), s2 ? s2.apply(o2.input ? o2.input[0] : null, [i2, o2]) : o2.input && o2.input.trigger("change"), o2.inline ? this._updateDatepicker(o2) : (this._hideDatepicker(), this._lastInput = o2.input[0], "object" != typeof o2.input[0] && o2.input.trigger("focus"), this._lastInput = null);
  }, _updateAlternate: function(e2) {
    var i2, s2, n2, o2 = this._get(e2, "altField");
    o2 && (i2 = this._get(e2, "altFormat") || this._get(e2, "dateFormat"), s2 = this._getDate(e2), n2 = this.formatDate(i2, s2, this._getFormatConfig(e2)), t(o2).val(n2));
  }, noWeekends: function(t2) {
    var e2 = t2.getDay();
    return [e2 > 0 && 6 > e2, ""];
  }, iso8601Week: function(t2) {
    var e2, i2 = new Date(t2.getTime());
    return i2.setDate(i2.getDate() + 4 - (i2.getDay() || 7)), e2 = i2.getTime(), i2.setMonth(0), i2.setDate(1), Math.floor(Math.round((e2 - i2) / 864e5) / 7) + 1;
  }, parseDate: function(e2, i2, s2) {
    if (null == e2 || null == i2)
      throw "Invalid arguments";
    if (i2 = "object" == typeof i2 ? "" + i2 : i2 + "", "" === i2)
      return null;
    var n2, o2, a2, r2, h2 = 0, l2 = (s2 ? s2.shortYearCutoff : null) || this._defaults.shortYearCutoff, c2 = "string" != typeof l2 ? l2 : (/* @__PURE__ */ new Date()).getFullYear() % 100 + parseInt(l2, 10), u2 = (s2 ? s2.dayNamesShort : null) || this._defaults.dayNamesShort, d2 = (s2 ? s2.dayNames : null) || this._defaults.dayNames, p2 = (s2 ? s2.monthNamesShort : null) || this._defaults.monthNamesShort, f = (s2 ? s2.monthNames : null) || this._defaults.monthNames, g2 = -1, m2 = -1, _2 = -1, v2 = -1, b = false, y = function(t2) {
      var i3 = e2.length > n2 + 1 && e2.charAt(n2 + 1) === t2;
      return i3 && n2++, i3;
    }, w = function(t2) {
      var e3 = y(t2), s3 = "@" === t2 ? 14 : "!" === t2 ? 20 : "y" === t2 && e3 ? 4 : "o" === t2 ? 3 : 2, n3 = "y" === t2 ? s3 : 1, o3 = RegExp("^\\d{" + n3 + "," + s3 + "}"), a3 = i2.substring(h2).match(o3);
      if (!a3)
        throw "Missing number at position " + h2;
      return h2 += a3[0].length, parseInt(a3[0], 10);
    }, k = function(e3, s3, n3) {
      var o3 = -1, a3 = t.map(y(e3) ? n3 : s3, function(t2, e4) {
        return [[e4, t2]];
      }).sort(function(t2, e4) {
        return -(t2[1].length - e4[1].length);
      });
      if (t.each(a3, function(t2, e4) {
        var s4 = e4[1];
        return i2.substr(h2, s4.length).toLowerCase() === s4.toLowerCase() ? (o3 = e4[0], h2 += s4.length, false) : void 0;
      }), -1 !== o3)
        return o3 + 1;
      throw "Unknown name at position " + h2;
    }, x = function() {
      if (i2.charAt(h2) !== e2.charAt(n2))
        throw "Unexpected literal at position " + h2;
      h2++;
    };
    for (n2 = 0; e2.length > n2; n2++)
      if (b)
        "'" !== e2.charAt(n2) || y("'") ? x() : b = false;
      else
        switch (e2.charAt(n2)) {
          case "d":
            _2 = w("d");
            break;
          case "D":
            k("D", u2, d2);
            break;
          case "o":
            v2 = w("o");
            break;
          case "m":
            m2 = w("m");
            break;
          case "M":
            m2 = k("M", p2, f);
            break;
          case "y":
            g2 = w("y");
            break;
          case "@":
            r2 = new Date(w("@")), g2 = r2.getFullYear(), m2 = r2.getMonth() + 1, _2 = r2.getDate();
            break;
          case "!":
            r2 = new Date((w("!") - this._ticksTo1970) / 1e4), g2 = r2.getFullYear(), m2 = r2.getMonth() + 1, _2 = r2.getDate();
            break;
          case "'":
            y("'") ? x() : b = true;
            break;
          default:
            x();
        }
    if (i2.length > h2 && (a2 = i2.substr(h2), !/^\s+/.test(a2)))
      throw "Extra/unparsed characters found in date: " + a2;
    if (-1 === g2 ? g2 = (/* @__PURE__ */ new Date()).getFullYear() : 100 > g2 && (g2 += (/* @__PURE__ */ new Date()).getFullYear() - (/* @__PURE__ */ new Date()).getFullYear() % 100 + (c2 >= g2 ? 0 : -100)), v2 > -1)
      for (m2 = 1, _2 = v2; ; ) {
        if (o2 = this._getDaysInMonth(g2, m2 - 1), o2 >= _2)
          break;
        m2++, _2 -= o2;
      }
    if (r2 = this._daylightSavingAdjust(new Date(g2, m2 - 1, _2)), r2.getFullYear() !== g2 || r2.getMonth() + 1 !== m2 || r2.getDate() !== _2)
      throw "Invalid date";
    return r2;
  }, ATOM: "yy-mm-dd", COOKIE: "D, dd M yy", ISO_8601: "yy-mm-dd", RFC_822: "D, d M y", RFC_850: "DD, dd-M-y", RFC_1036: "D, d M y", RFC_1123: "D, d M yy", RFC_2822: "D, d M yy", RSS: "D, d M y", TICKS: "!", TIMESTAMP: "@", W3C: "yy-mm-dd", _ticksTo1970: 1e7 * 60 * 60 * 24 * (718685 + Math.floor(492.5) - Math.floor(19.7) + Math.floor(4.925)), formatDate: function(t2, e2, i2) {
    if (!e2)
      return "";
    var s2, n2 = (i2 ? i2.dayNamesShort : null) || this._defaults.dayNamesShort, o2 = (i2 ? i2.dayNames : null) || this._defaults.dayNames, a2 = (i2 ? i2.monthNamesShort : null) || this._defaults.monthNamesShort, r2 = (i2 ? i2.monthNames : null) || this._defaults.monthNames, h2 = function(e3) {
      var i3 = t2.length > s2 + 1 && t2.charAt(s2 + 1) === e3;
      return i3 && s2++, i3;
    }, l2 = function(t3, e3, i3) {
      var s3 = "" + e3;
      if (h2(t3))
        for (; i3 > s3.length; )
          s3 = "0" + s3;
      return s3;
    }, c2 = function(t3, e3, i3, s3) {
      return h2(t3) ? s3[e3] : i3[e3];
    }, u2 = "", d2 = false;
    if (e2)
      for (s2 = 0; t2.length > s2; s2++)
        if (d2)
          "'" !== t2.charAt(s2) || h2("'") ? u2 += t2.charAt(s2) : d2 = false;
        else
          switch (t2.charAt(s2)) {
            case "d":
              u2 += l2("d", e2.getDate(), 2);
              break;
            case "D":
              u2 += c2("D", e2.getDay(), n2, o2);
              break;
            case "o":
              u2 += l2("o", Math.round((new Date(e2.getFullYear(), e2.getMonth(), e2.getDate()).getTime() - new Date(e2.getFullYear(), 0, 0).getTime()) / 864e5), 3);
              break;
            case "m":
              u2 += l2("m", e2.getMonth() + 1, 2);
              break;
            case "M":
              u2 += c2("M", e2.getMonth(), a2, r2);
              break;
            case "y":
              u2 += h2("y") ? e2.getFullYear() : (10 > e2.getFullYear() % 100 ? "0" : "") + e2.getFullYear() % 100;
              break;
            case "@":
              u2 += e2.getTime();
              break;
            case "!":
              u2 += 1e4 * e2.getTime() + this._ticksTo1970;
              break;
            case "'":
              h2("'") ? u2 += "'" : d2 = true;
              break;
            default:
              u2 += t2.charAt(s2);
          }
    return u2;
  }, _possibleChars: function(t2) {
    var e2, i2 = "", s2 = false, n2 = function(i3) {
      var s3 = t2.length > e2 + 1 && t2.charAt(e2 + 1) === i3;
      return s3 && e2++, s3;
    };
    for (e2 = 0; t2.length > e2; e2++)
      if (s2)
        "'" !== t2.charAt(e2) || n2("'") ? i2 += t2.charAt(e2) : s2 = false;
      else
        switch (t2.charAt(e2)) {
          case "d":
          case "m":
          case "y":
          case "@":
            i2 += "0123456789";
            break;
          case "D":
          case "M":
            return null;
          case "'":
            n2("'") ? i2 += "'" : s2 = true;
            break;
          default:
            i2 += t2.charAt(e2);
        }
    return i2;
  }, _get: function(t2, e2) {
    return void 0 !== t2.settings[e2] ? t2.settings[e2] : this._defaults[e2];
  }, _setDateFromField: function(t2, e2) {
    if (t2.input.val() !== t2.lastVal) {
      var i2 = this._get(t2, "dateFormat"), s2 = t2.lastVal = t2.input ? t2.input.val() : null, n2 = this._getDefaultDate(t2), o2 = n2, a2 = this._getFormatConfig(t2);
      try {
        o2 = this.parseDate(i2, s2, a2) || n2;
      } catch (r2) {
        s2 = e2 ? "" : s2;
      }
      t2.selectedDay = o2.getDate(), t2.drawMonth = t2.selectedMonth = o2.getMonth(), t2.drawYear = t2.selectedYear = o2.getFullYear(), t2.currentDay = s2 ? o2.getDate() : 0, t2.currentMonth = s2 ? o2.getMonth() : 0, t2.currentYear = s2 ? o2.getFullYear() : 0, this._adjustInstDate(t2);
    }
  }, _getDefaultDate: function(t2) {
    return this._restrictMinMax(t2, this._determineDate(t2, this._get(t2, "defaultDate"), /* @__PURE__ */ new Date()));
  }, _determineDate: function(e2, i2, s2) {
    var n2 = function(t2) {
      var e3 = /* @__PURE__ */ new Date();
      return e3.setDate(e3.getDate() + t2), e3;
    }, o2 = function(i3) {
      try {
        return t.datepicker.parseDate(t.datepicker._get(e2, "dateFormat"), i3, t.datepicker._getFormatConfig(e2));
      } catch (s3) {
      }
      for (var n3 = (i3.toLowerCase().match(/^c/) ? t.datepicker._getDate(e2) : null) || /* @__PURE__ */ new Date(), o3 = n3.getFullYear(), a3 = n3.getMonth(), r2 = n3.getDate(), h2 = /([+\-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g, l2 = h2.exec(i3); l2; ) {
        switch (l2[2] || "d") {
          case "d":
          case "D":
            r2 += parseInt(l2[1], 10);
            break;
          case "w":
          case "W":
            r2 += 7 * parseInt(l2[1], 10);
            break;
          case "m":
          case "M":
            a3 += parseInt(l2[1], 10), r2 = Math.min(r2, t.datepicker._getDaysInMonth(o3, a3));
            break;
          case "y":
          case "Y":
            o3 += parseInt(l2[1], 10), r2 = Math.min(r2, t.datepicker._getDaysInMonth(o3, a3));
        }
        l2 = h2.exec(i3);
      }
      return new Date(o3, a3, r2);
    }, a2 = null == i2 || "" === i2 ? s2 : "string" == typeof i2 ? o2(i2) : "number" == typeof i2 ? isNaN(i2) ? s2 : n2(i2) : new Date(i2.getTime());
    return a2 = a2 && "Invalid Date" == "" + a2 ? s2 : a2, a2 && (a2.setHours(0), a2.setMinutes(0), a2.setSeconds(0), a2.setMilliseconds(0)), this._daylightSavingAdjust(a2);
  }, _daylightSavingAdjust: function(t2) {
    return t2 ? (t2.setHours(t2.getHours() > 12 ? t2.getHours() + 2 : 0), t2) : null;
  }, _setDate: function(t2, e2, i2) {
    var s2 = !e2, n2 = t2.selectedMonth, o2 = t2.selectedYear, a2 = this._restrictMinMax(t2, this._determineDate(t2, e2, /* @__PURE__ */ new Date()));
    t2.selectedDay = t2.currentDay = a2.getDate(), t2.drawMonth = t2.selectedMonth = t2.currentMonth = a2.getMonth(), t2.drawYear = t2.selectedYear = t2.currentYear = a2.getFullYear(), n2 === t2.selectedMonth && o2 === t2.selectedYear || i2 || this._notifyChange(t2), this._adjustInstDate(t2), t2.input && t2.input.val(s2 ? "" : this._formatDate(t2));
  }, _getDate: function(t2) {
    var e2 = !t2.currentYear || t2.input && "" === t2.input.val() ? null : this._daylightSavingAdjust(new Date(t2.currentYear, t2.currentMonth, t2.currentDay));
    return e2;
  }, _attachHandlers: function(e2) {
    var i2 = this._get(e2, "stepMonths"), s2 = "#" + e2.id.replace(/\\\\/g, "\\");
    e2.dpDiv.find("[data-handler]").map(function() {
      var e3 = { prev: function() {
        t.datepicker._adjustDate(s2, -i2, "M");
      }, next: function() {
        t.datepicker._adjustDate(s2, +i2, "M");
      }, hide: function() {
        t.datepicker._hideDatepicker();
      }, today: function() {
        t.datepicker._gotoToday(s2);
      }, selectDay: function() {
        return t.datepicker._selectDay(s2, +this.getAttribute("data-month"), +this.getAttribute("data-year"), this), false;
      }, selectMonth: function() {
        return t.datepicker._selectMonthYear(s2, this, "M"), false;
      }, selectYear: function() {
        return t.datepicker._selectMonthYear(s2, this, "Y"), false;
      } };
      t(this).on(this.getAttribute("data-event"), e3[this.getAttribute("data-handler")]);
    });
  }, _generateHTML: function(t2) {
    var e2, i2, s2, n2, o2, a2, r2, h2, l2, c2, u2, d2, p2, f, g2, m2, _2, v2, b, y, w, k, x, C, D, I, T, P, M, S, H, z, O, A, N, W, E, F, L, R = /* @__PURE__ */ new Date(), B = this._daylightSavingAdjust(new Date(R.getFullYear(), R.getMonth(), R.getDate())), Y = this._get(t2, "isRTL"), j = this._get(t2, "showButtonPanel"), q = this._get(t2, "hideIfNoPrevNext"), K = this._get(t2, "navigationAsDateFormat"), U = this._getNumberOfMonths(t2), V = this._get(t2, "showCurrentAtPos"), $ = this._get(t2, "stepMonths"), X = 1 !== U[0] || 1 !== U[1], G = this._daylightSavingAdjust(t2.currentDay ? new Date(t2.currentYear, t2.currentMonth, t2.currentDay) : new Date(9999, 9, 9)), Q = this._getMinMaxDate(t2, "min"), J = this._getMinMaxDate(t2, "max"), Z = t2.drawMonth - V, te = t2.drawYear;
    if (0 > Z && (Z += 12, te--), J)
      for (e2 = this._daylightSavingAdjust(new Date(J.getFullYear(), J.getMonth() - U[0] * U[1] + 1, J.getDate())), e2 = Q && Q > e2 ? Q : e2; this._daylightSavingAdjust(new Date(te, Z, 1)) > e2; )
        Z--, 0 > Z && (Z = 11, te--);
    for (t2.drawMonth = Z, t2.drawYear = te, i2 = this._get(t2, "prevText"), i2 = K ? this.formatDate(i2, this._daylightSavingAdjust(new Date(te, Z - $, 1)), this._getFormatConfig(t2)) : i2, s2 = this._canAdjustMonth(t2, -1, te, Z) ? "<a class='ui-datepicker-prev ui-corner-all' data-handler='prev' data-event='click' title='" + i2 + "'><span class='ui-icon ui-icon-circle-triangle-" + (Y ? "e" : "w") + "'>" + i2 + "</span></a>" : q ? "" : "<a class='ui-datepicker-prev ui-corner-all ui-state-disabled' title='" + i2 + "'><span class='ui-icon ui-icon-circle-triangle-" + (Y ? "e" : "w") + "'>" + i2 + "</span></a>", n2 = this._get(t2, "nextText"), n2 = K ? this.formatDate(n2, this._daylightSavingAdjust(new Date(te, Z + $, 1)), this._getFormatConfig(t2)) : n2, o2 = this._canAdjustMonth(t2, 1, te, Z) ? "<a class='ui-datepicker-next ui-corner-all' data-handler='next' data-event='click' title='" + n2 + "'><span class='ui-icon ui-icon-circle-triangle-" + (Y ? "w" : "e") + "'>" + n2 + "</span></a>" : q ? "" : "<a class='ui-datepicker-next ui-corner-all ui-state-disabled' title='" + n2 + "'><span class='ui-icon ui-icon-circle-triangle-" + (Y ? "w" : "e") + "'>" + n2 + "</span></a>", a2 = this._get(t2, "currentText"), r2 = this._get(t2, "gotoCurrent") && t2.currentDay ? G : B, a2 = K ? this.formatDate(a2, r2, this._getFormatConfig(t2)) : a2, h2 = t2.inline ? "" : "<button type='button' class='ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all' data-handler='hide' data-event='click'>" + this._get(t2, "closeText") + "</button>", l2 = j ? "<div class='ui-datepicker-buttonpane ui-widget-content'>" + (Y ? h2 : "") + (this._isInRange(t2, r2) ? "<button type='button' class='ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all' data-handler='today' data-event='click'>" + a2 + "</button>" : "") + (Y ? "" : h2) + "</div>" : "", c2 = parseInt(this._get(t2, "firstDay"), 10), c2 = isNaN(c2) ? 0 : c2, u2 = this._get(t2, "showWeek"), d2 = this._get(t2, "dayNames"), p2 = this._get(t2, "dayNamesMin"), f = this._get(t2, "monthNames"), g2 = this._get(t2, "monthNamesShort"), m2 = this._get(t2, "beforeShowDay"), _2 = this._get(t2, "showOtherMonths"), v2 = this._get(t2, "selectOtherMonths"), b = this._getDefaultDate(t2), y = "", k = 0; U[0] > k; k++) {
      for (x = "", this.maxRows = 4, C = 0; U[1] > C; C++) {
        if (D = this._daylightSavingAdjust(new Date(te, Z, t2.selectedDay)), I = " ui-corner-all", T = "", X) {
          if (T += "<div class='ui-datepicker-group", U[1] > 1)
            switch (C) {
              case 0:
                T += " ui-datepicker-group-first", I = " ui-corner-" + (Y ? "right" : "left");
                break;
              case U[1] - 1:
                T += " ui-datepicker-group-last", I = " ui-corner-" + (Y ? "left" : "right");
                break;
              default:
                T += " ui-datepicker-group-middle", I = "";
            }
          T += "'>";
        }
        for (T += "<div class='ui-datepicker-header ui-widget-header ui-helper-clearfix" + I + "'>" + (/all|left/.test(I) && 0 === k ? Y ? o2 : s2 : "") + (/all|right/.test(I) && 0 === k ? Y ? s2 : o2 : "") + this._generateMonthYearHeader(t2, Z, te, Q, J, k > 0 || C > 0, f, g2) + "</div><table class='ui-datepicker-calendar'><thead><tr>", P = u2 ? "<th class='ui-datepicker-week-col'>" + this._get(t2, "weekHeader") + "</th>" : "", w = 0; 7 > w; w++)
          M = (w + c2) % 7, P += "<th scope='col'" + ((w + c2 + 6) % 7 >= 5 ? " class='ui-datepicker-week-end'" : "") + "><span title='" + d2[M] + "'>" + p2[M] + "</span></th>";
        for (T += P + "</tr></thead><tbody>", S = this._getDaysInMonth(te, Z), te === t2.selectedYear && Z === t2.selectedMonth && (t2.selectedDay = Math.min(t2.selectedDay, S)), H = (this._getFirstDayOfMonth(te, Z) - c2 + 7) % 7, z = Math.ceil((H + S) / 7), O = X ? this.maxRows > z ? this.maxRows : z : z, this.maxRows = O, A = this._daylightSavingAdjust(new Date(te, Z, 1 - H)), N = 0; O > N; N++) {
          for (T += "<tr>", W = u2 ? "<td class='ui-datepicker-week-col'>" + this._get(t2, "calculateWeek")(A) + "</td>" : "", w = 0; 7 > w; w++)
            E = m2 ? m2.apply(t2.input ? t2.input[0] : null, [A]) : [true, ""], F = A.getMonth() !== Z, L = F && !v2 || !E[0] || Q && Q > A || J && A > J, W += "<td class='" + ((w + c2 + 6) % 7 >= 5 ? " ui-datepicker-week-end" : "") + (F ? " ui-datepicker-other-month" : "") + (A.getTime() === D.getTime() && Z === t2.selectedMonth && t2._keyEvent || b.getTime() === A.getTime() && b.getTime() === D.getTime() ? " " + this._dayOverClass : "") + (L ? " " + this._unselectableClass + " ui-state-disabled" : "") + (F && !_2 ? "" : " " + E[1] + (A.getTime() === G.getTime() ? " " + this._currentClass : "") + (A.getTime() === B.getTime() ? " ui-datepicker-today" : "")) + "'" + (F && !_2 || !E[2] ? "" : " title='" + E[2].replace(/'/g, "&#39;") + "'") + (L ? "" : " data-handler='selectDay' data-event='click' data-month='" + A.getMonth() + "' data-year='" + A.getFullYear() + "'") + ">" + (F && !_2 ? "&#xa0;" : L ? "<span class='ui-state-default'>" + A.getDate() + "</span>" : "<a class='ui-state-default" + (A.getTime() === B.getTime() ? " ui-state-highlight" : "") + (A.getTime() === G.getTime() ? " ui-state-active" : "") + (F ? " ui-priority-secondary" : "") + "' href='#'>" + A.getDate() + "</a>") + "</td>", A.setDate(A.getDate() + 1), A = this._daylightSavingAdjust(A);
          T += W + "</tr>";
        }
        Z++, Z > 11 && (Z = 0, te++), T += "</tbody></table>" + (X ? "</div>" + (U[0] > 0 && C === U[1] - 1 ? "<div class='ui-datepicker-row-break'></div>" : "") : ""), x += T;
      }
      y += x;
    }
    return y += l2, t2._keyEvent = false, y;
  }, _generateMonthYearHeader: function(t2, e2, i2, s2, n2, o2, a2, r2) {
    var h2, l2, c2, u2, d2, p2, f, g2, m2 = this._get(t2, "changeMonth"), _2 = this._get(t2, "changeYear"), v2 = this._get(t2, "showMonthAfterYear"), b = "<div class='ui-datepicker-title'>", y = "";
    if (o2 || !m2)
      y += "<span class='ui-datepicker-month'>" + a2[e2] + "</span>";
    else {
      for (h2 = s2 && s2.getFullYear() === i2, l2 = n2 && n2.getFullYear() === i2, y += "<select class='ui-datepicker-month' data-handler='selectMonth' data-event='change'>", c2 = 0; 12 > c2; c2++)
        (!h2 || c2 >= s2.getMonth()) && (!l2 || n2.getMonth() >= c2) && (y += "<option value='" + c2 + "'" + (c2 === e2 ? " selected='selected'" : "") + ">" + r2[c2] + "</option>");
      y += "</select>";
    }
    if (v2 || (b += y + (!o2 && m2 && _2 ? "" : "&#xa0;")), !t2.yearshtml)
      if (t2.yearshtml = "", o2 || !_2)
        b += "<span class='ui-datepicker-year'>" + i2 + "</span>";
      else {
        for (u2 = this._get(t2, "yearRange").split(":"), d2 = (/* @__PURE__ */ new Date()).getFullYear(), p2 = function(t3) {
          var e3 = t3.match(/c[+\-].*/) ? i2 + parseInt(t3.substring(1), 10) : t3.match(/[+\-].*/) ? d2 + parseInt(t3, 10) : parseInt(t3, 10);
          return isNaN(e3) ? d2 : e3;
        }, f = p2(u2[0]), g2 = Math.max(f, p2(u2[1] || "")), f = s2 ? Math.max(f, s2.getFullYear()) : f, g2 = n2 ? Math.min(g2, n2.getFullYear()) : g2, t2.yearshtml += "<select class='ui-datepicker-year' data-handler='selectYear' data-event='change'>"; g2 >= f; f++)
          t2.yearshtml += "<option value='" + f + "'" + (f === i2 ? " selected='selected'" : "") + ">" + f + "</option>";
        t2.yearshtml += "</select>", b += t2.yearshtml, t2.yearshtml = null;
      }
    return b += this._get(t2, "yearSuffix"), v2 && (b += (!o2 && m2 && _2 ? "" : "&#xa0;") + y), b += "</div>";
  }, _adjustInstDate: function(t2, e2, i2) {
    var s2 = t2.selectedYear + ("Y" === i2 ? e2 : 0), n2 = t2.selectedMonth + ("M" === i2 ? e2 : 0), o2 = Math.min(t2.selectedDay, this._getDaysInMonth(s2, n2)) + ("D" === i2 ? e2 : 0), a2 = this._restrictMinMax(t2, this._daylightSavingAdjust(new Date(s2, n2, o2)));
    t2.selectedDay = a2.getDate(), t2.drawMonth = t2.selectedMonth = a2.getMonth(), t2.drawYear = t2.selectedYear = a2.getFullYear(), ("M" === i2 || "Y" === i2) && this._notifyChange(t2);
  }, _restrictMinMax: function(t2, e2) {
    var i2 = this._getMinMaxDate(t2, "min"), s2 = this._getMinMaxDate(t2, "max"), n2 = i2 && i2 > e2 ? i2 : e2;
    return s2 && n2 > s2 ? s2 : n2;
  }, _notifyChange: function(t2) {
    var e2 = this._get(t2, "onChangeMonthYear");
    e2 && e2.apply(t2.input ? t2.input[0] : null, [t2.selectedYear, t2.selectedMonth + 1, t2]);
  }, _getNumberOfMonths: function(t2) {
    var e2 = this._get(t2, "numberOfMonths");
    return null == e2 ? [1, 1] : "number" == typeof e2 ? [1, e2] : e2;
  }, _getMinMaxDate: function(t2, e2) {
    return this._determineDate(t2, this._get(t2, e2 + "Date"), null);
  }, _getDaysInMonth: function(t2, e2) {
    return 32 - this._daylightSavingAdjust(new Date(t2, e2, 32)).getDate();
  }, _getFirstDayOfMonth: function(t2, e2) {
    return new Date(t2, e2, 1).getDay();
  }, _canAdjustMonth: function(t2, e2, i2, s2) {
    var n2 = this._getNumberOfMonths(t2), o2 = this._daylightSavingAdjust(new Date(i2, s2 + (0 > e2 ? e2 : n2[0] * n2[1]), 1));
    return 0 > e2 && o2.setDate(this._getDaysInMonth(o2.getFullYear(), o2.getMonth())), this._isInRange(t2, o2);
  }, _isInRange: function(t2, e2) {
    var i2, s2, n2 = this._getMinMaxDate(t2, "min"), o2 = this._getMinMaxDate(t2, "max"), a2 = null, r2 = null, h2 = this._get(t2, "yearRange");
    return h2 && (i2 = h2.split(":"), s2 = (/* @__PURE__ */ new Date()).getFullYear(), a2 = parseInt(i2[0], 10), r2 = parseInt(i2[1], 10), i2[0].match(/[+\-].*/) && (a2 += s2), i2[1].match(/[+\-].*/) && (r2 += s2)), (!n2 || e2.getTime() >= n2.getTime()) && (!o2 || e2.getTime() <= o2.getTime()) && (!a2 || e2.getFullYear() >= a2) && (!r2 || r2 >= e2.getFullYear());
  }, _getFormatConfig: function(t2) {
    var e2 = this._get(t2, "shortYearCutoff");
    return e2 = "string" != typeof e2 ? e2 : (/* @__PURE__ */ new Date()).getFullYear() % 100 + parseInt(e2, 10), { shortYearCutoff: e2, dayNamesShort: this._get(t2, "dayNamesShort"), dayNames: this._get(t2, "dayNames"), monthNamesShort: this._get(t2, "monthNamesShort"), monthNames: this._get(t2, "monthNames") };
  }, _formatDate: function(t2, e2, i2, s2) {
    e2 || (t2.currentDay = t2.selectedDay, t2.currentMonth = t2.selectedMonth, t2.currentYear = t2.selectedYear);
    var n2 = e2 ? "object" == typeof e2 ? e2 : this._daylightSavingAdjust(new Date(s2, i2, e2)) : this._daylightSavingAdjust(new Date(t2.currentYear, t2.currentMonth, t2.currentDay));
    return this.formatDate(this._get(t2, "dateFormat"), n2, this._getFormatConfig(t2));
  } }), t.fn.datepicker = function(e2) {
    if (!this.length)
      return this;
    t.datepicker.initialized || (t(document).on("mousedown", t.datepicker._checkExternalClick), t.datepicker.initialized = true), 0 === t("#" + t.datepicker._mainDivId).length && t("body").append(t.datepicker.dpDiv);
    var i2 = Array.prototype.slice.call(arguments, 1);
    return "string" != typeof e2 || "isDisabled" !== e2 && "getDate" !== e2 && "widget" !== e2 ? "option" === e2 && 2 === arguments.length && "string" == typeof arguments[1] ? t.datepicker["_" + e2 + "Datepicker"].apply(t.datepicker, [this[0]].concat(i2)) : this.each(function() {
      "string" == typeof e2 ? t.datepicker["_" + e2 + "Datepicker"].apply(t.datepicker, [this].concat(i2)) : t.datepicker._attachDatepicker(this, e2);
    }) : t.datepicker["_" + e2 + "Datepicker"].apply(t.datepicker, [this[0]].concat(i2));
  }, t.datepicker = new s(), t.datepicker.initialized = false, t.datepicker.uuid = (/* @__PURE__ */ new Date()).getTime(), t.datepicker.version = "1.12.1", t.datepicker, t.ui.ie = !!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase());
  var _ = false;
  t(document).on("mouseup", function() {
    _ = false;
  }), t.widget("ui.mouse", { version: "1.12.1", options: { cancel: "input, textarea, button, select, option", distance: 1, delay: 0 }, _mouseInit: function() {
    var e2 = this;
    this.element.on("mousedown." + this.widgetName, function(t2) {
      return e2._mouseDown(t2);
    }).on("click." + this.widgetName, function(i2) {
      return true === t.data(i2.target, e2.widgetName + ".preventClickEvent") ? (t.removeData(i2.target, e2.widgetName + ".preventClickEvent"), i2.stopImmediatePropagation(), false) : void 0;
    }), this.started = false;
  }, _mouseDestroy: function() {
    this.element.off("." + this.widgetName), this._mouseMoveDelegate && this.document.off("mousemove." + this.widgetName, this._mouseMoveDelegate).off("mouseup." + this.widgetName, this._mouseUpDelegate);
  }, _mouseDown: function(e2) {
    if (!_) {
      this._mouseMoved = false, this._mouseStarted && this._mouseUp(e2), this._mouseDownEvent = e2;
      var i2 = this, s2 = 1 === e2.which, n2 = "string" == typeof this.options.cancel && e2.target.nodeName ? t(e2.target).closest(this.options.cancel).length : false;
      return s2 && !n2 && this._mouseCapture(e2) ? (this.mouseDelayMet = !this.options.delay, this.mouseDelayMet || (this._mouseDelayTimer = setTimeout(function() {
        i2.mouseDelayMet = true;
      }, this.options.delay)), this._mouseDistanceMet(e2) && this._mouseDelayMet(e2) && (this._mouseStarted = this._mouseStart(e2) !== false, !this._mouseStarted) ? (e2.preventDefault(), true) : (true === t.data(e2.target, this.widgetName + ".preventClickEvent") && t.removeData(e2.target, this.widgetName + ".preventClickEvent"), this._mouseMoveDelegate = function(t2) {
        return i2._mouseMove(t2);
      }, this._mouseUpDelegate = function(t2) {
        return i2._mouseUp(t2);
      }, this.document.on("mousemove." + this.widgetName, this._mouseMoveDelegate).on("mouseup." + this.widgetName, this._mouseUpDelegate), e2.preventDefault(), _ = true, true)) : true;
    }
  }, _mouseMove: function(e2) {
    if (this._mouseMoved) {
      if (t.ui.ie && (!document.documentMode || 9 > document.documentMode) && !e2.button)
        return this._mouseUp(e2);
      if (!e2.which) {
        if (e2.originalEvent.altKey || e2.originalEvent.ctrlKey || e2.originalEvent.metaKey || e2.originalEvent.shiftKey)
          this.ignoreMissingWhich = true;
        else if (!this.ignoreMissingWhich)
          return this._mouseUp(e2);
      }
    }
    return (e2.which || e2.button) && (this._mouseMoved = true), this._mouseStarted ? (this._mouseDrag(e2), e2.preventDefault()) : (this._mouseDistanceMet(e2) && this._mouseDelayMet(e2) && (this._mouseStarted = this._mouseStart(this._mouseDownEvent, e2) !== false, this._mouseStarted ? this._mouseDrag(e2) : this._mouseUp(e2)), !this._mouseStarted);
  }, _mouseUp: function(e2) {
    this.document.off("mousemove." + this.widgetName, this._mouseMoveDelegate).off("mouseup." + this.widgetName, this._mouseUpDelegate), this._mouseStarted && (this._mouseStarted = false, e2.target === this._mouseDownEvent.target && t.data(e2.target, this.widgetName + ".preventClickEvent", true), this._mouseStop(e2)), this._mouseDelayTimer && (clearTimeout(this._mouseDelayTimer), delete this._mouseDelayTimer), this.ignoreMissingWhich = false, _ = false, e2.preventDefault();
  }, _mouseDistanceMet: function(t2) {
    return Math.max(Math.abs(this._mouseDownEvent.pageX - t2.pageX), Math.abs(this._mouseDownEvent.pageY - t2.pageY)) >= this.options.distance;
  }, _mouseDelayMet: function() {
    return this.mouseDelayMet;
  }, _mouseStart: function() {
  }, _mouseDrag: function() {
  }, _mouseStop: function() {
  }, _mouseCapture: function() {
    return true;
  } }), t.ui.plugin = { add: function(e2, i2, s2) {
    var n2, o2 = t.ui[e2].prototype;
    for (n2 in s2)
      o2.plugins[n2] = o2.plugins[n2] || [], o2.plugins[n2].push([i2, s2[n2]]);
  }, call: function(t2, e2, i2, s2) {
    var n2, o2 = t2.plugins[e2];
    if (o2 && (s2 || t2.element[0].parentNode && 11 !== t2.element[0].parentNode.nodeType))
      for (n2 = 0; o2.length > n2; n2++)
        t2.options[o2[n2][0]] && o2[n2][1].apply(t2.element, i2);
  } }, t.ui.safeBlur = function(e2) {
    e2 && "body" !== e2.nodeName.toLowerCase() && t(e2).trigger("blur");
  }, t.widget("ui.draggable", t.ui.mouse, { version: "1.12.1", widgetEventPrefix: "drag", options: { addClasses: true, appendTo: "parent", axis: false, connectToSortable: false, containment: false, cursor: "auto", cursorAt: false, grid: false, handle: false, helper: "original", iframeFix: false, opacity: false, refreshPositions: false, revert: false, revertDuration: 500, scope: "default", scroll: true, scrollSensitivity: 20, scrollSpeed: 20, snap: false, snapMode: "both", snapTolerance: 20, stack: false, zIndex: false, drag: null, start: null, stop: null }, _create: function() {
    "original" === this.options.helper && this._setPositionRelative(), this.options.addClasses && this._addClass("ui-draggable"), this._setHandleClassName(), this._mouseInit();
  }, _setOption: function(t2, e2) {
    this._super(t2, e2), "handle" === t2 && (this._removeHandleClassName(), this._setHandleClassName());
  }, _destroy: function() {
    return (this.helper || this.element).is(".ui-draggable-dragging") ? (this.destroyOnClear = true, void 0) : (this._removeHandleClassName(), this._mouseDestroy(), void 0);
  }, _mouseCapture: function(e2) {
    var i2 = this.options;
    return this.helper || i2.disabled || t(e2.target).closest(".ui-resizable-handle").length > 0 ? false : (this.handle = this._getHandle(e2), this.handle ? (this._blurActiveElement(e2), this._blockFrames(i2.iframeFix === true ? "iframe" : i2.iframeFix), true) : false);
  }, _blockFrames: function(e2) {
    this.iframeBlocks = this.document.find(e2).map(function() {
      var e3 = t(this);
      return t("<div>").css("position", "absolute").appendTo(e3.parent()).outerWidth(e3.outerWidth()).outerHeight(e3.outerHeight()).offset(e3.offset())[0];
    });
  }, _unblockFrames: function() {
    this.iframeBlocks && (this.iframeBlocks.remove(), delete this.iframeBlocks);
  }, _blurActiveElement: function(e2) {
    var i2 = t.ui.safeActiveElement(this.document[0]), s2 = t(e2.target);
    s2.closest(i2).length || t.ui.safeBlur(i2);
  }, _mouseStart: function(e2) {
    var i2 = this.options;
    return this.helper = this._createHelper(e2), this._addClass(this.helper, "ui-draggable-dragging"), this._cacheHelperProportions(), t.ui.ddmanager && (t.ui.ddmanager.current = this), this._cacheMargins(), this.cssPosition = this.helper.css("position"), this.scrollParent = this.helper.scrollParent(true), this.offsetParent = this.helper.offsetParent(), this.hasFixedAncestor = this.helper.parents().filter(function() {
      return "fixed" === t(this).css("position");
    }).length > 0, this.positionAbs = this.element.offset(), this._refreshOffsets(e2), this.originalPosition = this.position = this._generatePosition(e2, false), this.originalPageX = e2.pageX, this.originalPageY = e2.pageY, i2.cursorAt && this._adjustOffsetFromHelper(i2.cursorAt), this._setContainment(), this._trigger("start", e2) === false ? (this._clear(), false) : (this._cacheHelperProportions(), t.ui.ddmanager && !i2.dropBehaviour && t.ui.ddmanager.prepareOffsets(this, e2), this._mouseDrag(e2, true), t.ui.ddmanager && t.ui.ddmanager.dragStart(this, e2), true);
  }, _refreshOffsets: function(t2) {
    this.offset = { top: this.positionAbs.top - this.margins.top, left: this.positionAbs.left - this.margins.left, scroll: false, parent: this._getParentOffset(), relative: this._getRelativeOffset() }, this.offset.click = { left: t2.pageX - this.offset.left, top: t2.pageY - this.offset.top };
  }, _mouseDrag: function(e2, i2) {
    if (this.hasFixedAncestor && (this.offset.parent = this._getParentOffset()), this.position = this._generatePosition(e2, true), this.positionAbs = this._convertPositionTo("absolute"), !i2) {
      var s2 = this._uiHash();
      if (this._trigger("drag", e2, s2) === false)
        return this._mouseUp(new t.Event("mouseup", e2)), false;
      this.position = s2.position;
    }
    return this.helper[0].style.left = this.position.left + "px", this.helper[0].style.top = this.position.top + "px", t.ui.ddmanager && t.ui.ddmanager.drag(this, e2), false;
  }, _mouseStop: function(e2) {
    var i2 = this, s2 = false;
    return t.ui.ddmanager && !this.options.dropBehaviour && (s2 = t.ui.ddmanager.drop(this, e2)), this.dropped && (s2 = this.dropped, this.dropped = false), "invalid" === this.options.revert && !s2 || "valid" === this.options.revert && s2 || this.options.revert === true || t.isFunction(this.options.revert) && this.options.revert.call(this.element, s2) ? t(this.helper).animate(this.originalPosition, parseInt(this.options.revertDuration, 10), function() {
      i2._trigger("stop", e2) !== false && i2._clear();
    }) : this._trigger("stop", e2) !== false && this._clear(), false;
  }, _mouseUp: function(e2) {
    return this._unblockFrames(), t.ui.ddmanager && t.ui.ddmanager.dragStop(this, e2), this.handleElement.is(e2.target) && this.element.trigger("focus"), t.ui.mouse.prototype._mouseUp.call(this, e2);
  }, cancel: function() {
    return this.helper.is(".ui-draggable-dragging") ? this._mouseUp(new t.Event("mouseup", { target: this.element[0] })) : this._clear(), this;
  }, _getHandle: function(e2) {
    return this.options.handle ? !!t(e2.target).closest(this.element.find(this.options.handle)).length : true;
  }, _setHandleClassName: function() {
    this.handleElement = this.options.handle ? this.element.find(this.options.handle) : this.element, this._addClass(this.handleElement, "ui-draggable-handle");
  }, _removeHandleClassName: function() {
    this._removeClass(this.handleElement, "ui-draggable-handle");
  }, _createHelper: function(e2) {
    var i2 = this.options, s2 = t.isFunction(i2.helper), n2 = s2 ? t(i2.helper.apply(this.element[0], [e2])) : "clone" === i2.helper ? this.element.clone().removeAttr("id") : this.element;
    return n2.parents("body").length || n2.appendTo("parent" === i2.appendTo ? this.element[0].parentNode : i2.appendTo), s2 && n2[0] === this.element[0] && this._setPositionRelative(), n2[0] === this.element[0] || /(fixed|absolute)/.test(n2.css("position")) || n2.css("position", "absolute"), n2;
  }, _setPositionRelative: function() {
    /^(?:r|a|f)/.test(this.element.css("position")) || (this.element[0].style.position = "relative");
  }, _adjustOffsetFromHelper: function(e2) {
    "string" == typeof e2 && (e2 = e2.split(" ")), t.isArray(e2) && (e2 = { left: +e2[0], top: +e2[1] || 0 }), "left" in e2 && (this.offset.click.left = e2.left + this.margins.left), "right" in e2 && (this.offset.click.left = this.helperProportions.width - e2.right + this.margins.left), "top" in e2 && (this.offset.click.top = e2.top + this.margins.top), "bottom" in e2 && (this.offset.click.top = this.helperProportions.height - e2.bottom + this.margins.top);
  }, _isRootNode: function(t2) {
    return /(html|body)/i.test(t2.tagName) || t2 === this.document[0];
  }, _getParentOffset: function() {
    var e2 = this.offsetParent.offset(), i2 = this.document[0];
    return "absolute" === this.cssPosition && this.scrollParent[0] !== i2 && t.contains(this.scrollParent[0], this.offsetParent[0]) && (e2.left += this.scrollParent.scrollLeft(), e2.top += this.scrollParent.scrollTop()), this._isRootNode(this.offsetParent[0]) && (e2 = { top: 0, left: 0 }), { top: e2.top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0), left: e2.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0) };
  }, _getRelativeOffset: function() {
    if ("relative" !== this.cssPosition)
      return { top: 0, left: 0 };
    var t2 = this.element.position(), e2 = this._isRootNode(this.scrollParent[0]);
    return { top: t2.top - (parseInt(this.helper.css("top"), 10) || 0) + (e2 ? 0 : this.scrollParent.scrollTop()), left: t2.left - (parseInt(this.helper.css("left"), 10) || 0) + (e2 ? 0 : this.scrollParent.scrollLeft()) };
  }, _cacheMargins: function() {
    this.margins = { left: parseInt(this.element.css("marginLeft"), 10) || 0, top: parseInt(this.element.css("marginTop"), 10) || 0, right: parseInt(this.element.css("marginRight"), 10) || 0, bottom: parseInt(this.element.css("marginBottom"), 10) || 0 };
  }, _cacheHelperProportions: function() {
    this.helperProportions = { width: this.helper.outerWidth(), height: this.helper.outerHeight() };
  }, _setContainment: function() {
    var e2, i2, s2, n2 = this.options, o2 = this.document[0];
    return this.relativeContainer = null, n2.containment ? "window" === n2.containment ? (this.containment = [t(window).scrollLeft() - this.offset.relative.left - this.offset.parent.left, t(window).scrollTop() - this.offset.relative.top - this.offset.parent.top, t(window).scrollLeft() + t(window).width() - this.helperProportions.width - this.margins.left, t(window).scrollTop() + (t(window).height() || o2.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top], void 0) : "document" === n2.containment ? (this.containment = [0, 0, t(o2).width() - this.helperProportions.width - this.margins.left, (t(o2).height() || o2.body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top], void 0) : n2.containment.constructor === Array ? (this.containment = n2.containment, void 0) : ("parent" === n2.containment && (n2.containment = this.helper[0].parentNode), i2 = t(n2.containment), s2 = i2[0], s2 && (e2 = /(scroll|auto)/.test(i2.css("overflow")), this.containment = [(parseInt(i2.css("borderLeftWidth"), 10) || 0) + (parseInt(i2.css("paddingLeft"), 10) || 0), (parseInt(i2.css("borderTopWidth"), 10) || 0) + (parseInt(i2.css("paddingTop"), 10) || 0), (e2 ? Math.max(s2.scrollWidth, s2.offsetWidth) : s2.offsetWidth) - (parseInt(i2.css("borderRightWidth"), 10) || 0) - (parseInt(i2.css("paddingRight"), 10) || 0) - this.helperProportions.width - this.margins.left - this.margins.right, (e2 ? Math.max(s2.scrollHeight, s2.offsetHeight) : s2.offsetHeight) - (parseInt(i2.css("borderBottomWidth"), 10) || 0) - (parseInt(i2.css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top - this.margins.bottom], this.relativeContainer = i2), void 0) : (this.containment = null, void 0);
  }, _convertPositionTo: function(t2, e2) {
    e2 || (e2 = this.position);
    var i2 = "absolute" === t2 ? 1 : -1, s2 = this._isRootNode(this.scrollParent[0]);
    return { top: e2.top + this.offset.relative.top * i2 + this.offset.parent.top * i2 - ("fixed" === this.cssPosition ? -this.offset.scroll.top : s2 ? 0 : this.offset.scroll.top) * i2, left: e2.left + this.offset.relative.left * i2 + this.offset.parent.left * i2 - ("fixed" === this.cssPosition ? -this.offset.scroll.left : s2 ? 0 : this.offset.scroll.left) * i2 };
  }, _generatePosition: function(t2, e2) {
    var i2, s2, n2, o2, a2 = this.options, r2 = this._isRootNode(this.scrollParent[0]), h2 = t2.pageX, l2 = t2.pageY;
    return r2 && this.offset.scroll || (this.offset.scroll = { top: this.scrollParent.scrollTop(), left: this.scrollParent.scrollLeft() }), e2 && (this.containment && (this.relativeContainer ? (s2 = this.relativeContainer.offset(), i2 = [this.containment[0] + s2.left, this.containment[1] + s2.top, this.containment[2] + s2.left, this.containment[3] + s2.top]) : i2 = this.containment, t2.pageX - this.offset.click.left < i2[0] && (h2 = i2[0] + this.offset.click.left), t2.pageY - this.offset.click.top < i2[1] && (l2 = i2[1] + this.offset.click.top), t2.pageX - this.offset.click.left > i2[2] && (h2 = i2[2] + this.offset.click.left), t2.pageY - this.offset.click.top > i2[3] && (l2 = i2[3] + this.offset.click.top)), a2.grid && (n2 = a2.grid[1] ? this.originalPageY + Math.round((l2 - this.originalPageY) / a2.grid[1]) * a2.grid[1] : this.originalPageY, l2 = i2 ? n2 - this.offset.click.top >= i2[1] || n2 - this.offset.click.top > i2[3] ? n2 : n2 - this.offset.click.top >= i2[1] ? n2 - a2.grid[1] : n2 + a2.grid[1] : n2, o2 = a2.grid[0] ? this.originalPageX + Math.round((h2 - this.originalPageX) / a2.grid[0]) * a2.grid[0] : this.originalPageX, h2 = i2 ? o2 - this.offset.click.left >= i2[0] || o2 - this.offset.click.left > i2[2] ? o2 : o2 - this.offset.click.left >= i2[0] ? o2 - a2.grid[0] : o2 + a2.grid[0] : o2), "y" === a2.axis && (h2 = this.originalPageX), "x" === a2.axis && (l2 = this.originalPageY)), { top: l2 - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + ("fixed" === this.cssPosition ? -this.offset.scroll.top : r2 ? 0 : this.offset.scroll.top), left: h2 - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + ("fixed" === this.cssPosition ? -this.offset.scroll.left : r2 ? 0 : this.offset.scroll.left) };
  }, _clear: function() {
    this._removeClass(this.helper, "ui-draggable-dragging"), this.helper[0] === this.element[0] || this.cancelHelperRemoval || this.helper.remove(), this.helper = null, this.cancelHelperRemoval = false, this.destroyOnClear && this.destroy();
  }, _trigger: function(e2, i2, s2) {
    return s2 = s2 || this._uiHash(), t.ui.plugin.call(this, e2, [i2, s2, this], true), /^(drag|start|stop)/.test(e2) && (this.positionAbs = this._convertPositionTo("absolute"), s2.offset = this.positionAbs), t.Widget.prototype._trigger.call(this, e2, i2, s2);
  }, plugins: {}, _uiHash: function() {
    return { helper: this.helper, position: this.position, originalPosition: this.originalPosition, offset: this.positionAbs };
  } }), t.ui.plugin.add("draggable", "connectToSortable", { start: function(e2, i2, s2) {
    var n2 = t.extend({}, i2, { item: s2.element });
    s2.sortables = [], t(s2.options.connectToSortable).each(function() {
      var i3 = t(this).sortable("instance");
      i3 && !i3.options.disabled && (s2.sortables.push(i3), i3.refreshPositions(), i3._trigger("activate", e2, n2));
    });
  }, stop: function(e2, i2, s2) {
    var n2 = t.extend({}, i2, { item: s2.element });
    s2.cancelHelperRemoval = false, t.each(s2.sortables, function() {
      var t2 = this;
      t2.isOver ? (t2.isOver = 0, s2.cancelHelperRemoval = true, t2.cancelHelperRemoval = false, t2._storedCSS = { position: t2.placeholder.css("position"), top: t2.placeholder.css("top"), left: t2.placeholder.css("left") }, t2._mouseStop(e2), t2.options.helper = t2.options._helper) : (t2.cancelHelperRemoval = true, t2._trigger("deactivate", e2, n2));
    });
  }, drag: function(e2, i2, s2) {
    t.each(s2.sortables, function() {
      var n2 = false, o2 = this;
      o2.positionAbs = s2.positionAbs, o2.helperProportions = s2.helperProportions, o2.offset.click = s2.offset.click, o2._intersectsWith(o2.containerCache) && (n2 = true, t.each(s2.sortables, function() {
        return this.positionAbs = s2.positionAbs, this.helperProportions = s2.helperProportions, this.offset.click = s2.offset.click, this !== o2 && this._intersectsWith(this.containerCache) && t.contains(o2.element[0], this.element[0]) && (n2 = false), n2;
      })), n2 ? (o2.isOver || (o2.isOver = 1, s2._parent = i2.helper.parent(), o2.currentItem = i2.helper.appendTo(o2.element).data("ui-sortable-item", true), o2.options._helper = o2.options.helper, o2.options.helper = function() {
        return i2.helper[0];
      }, e2.target = o2.currentItem[0], o2._mouseCapture(e2, true), o2._mouseStart(e2, true, true), o2.offset.click.top = s2.offset.click.top, o2.offset.click.left = s2.offset.click.left, o2.offset.parent.left -= s2.offset.parent.left - o2.offset.parent.left, o2.offset.parent.top -= s2.offset.parent.top - o2.offset.parent.top, s2._trigger("toSortable", e2), s2.dropped = o2.element, t.each(s2.sortables, function() {
        this.refreshPositions();
      }), s2.currentItem = s2.element, o2.fromOutside = s2), o2.currentItem && (o2._mouseDrag(e2), i2.position = o2.position)) : o2.isOver && (o2.isOver = 0, o2.cancelHelperRemoval = true, o2.options._revert = o2.options.revert, o2.options.revert = false, o2._trigger("out", e2, o2._uiHash(o2)), o2._mouseStop(e2, true), o2.options.revert = o2.options._revert, o2.options.helper = o2.options._helper, o2.placeholder && o2.placeholder.remove(), i2.helper.appendTo(s2._parent), s2._refreshOffsets(e2), i2.position = s2._generatePosition(e2, true), s2._trigger("fromSortable", e2), s2.dropped = false, t.each(s2.sortables, function() {
        this.refreshPositions();
      }));
    });
  } }), t.ui.plugin.add("draggable", "cursor", { start: function(e2, i2, s2) {
    var n2 = t("body"), o2 = s2.options;
    n2.css("cursor") && (o2._cursor = n2.css("cursor")), n2.css("cursor", o2.cursor);
  }, stop: function(e2, i2, s2) {
    var n2 = s2.options;
    n2._cursor && t("body").css("cursor", n2._cursor);
  } }), t.ui.plugin.add("draggable", "opacity", { start: function(e2, i2, s2) {
    var n2 = t(i2.helper), o2 = s2.options;
    n2.css("opacity") && (o2._opacity = n2.css("opacity")), n2.css("opacity", o2.opacity);
  }, stop: function(e2, i2, s2) {
    var n2 = s2.options;
    n2._opacity && t(i2.helper).css("opacity", n2._opacity);
  } }), t.ui.plugin.add("draggable", "scroll", { start: function(t2, e2, i2) {
    i2.scrollParentNotHidden || (i2.scrollParentNotHidden = i2.helper.scrollParent(false)), i2.scrollParentNotHidden[0] !== i2.document[0] && "HTML" !== i2.scrollParentNotHidden[0].tagName && (i2.overflowOffset = i2.scrollParentNotHidden.offset());
  }, drag: function(e2, i2, s2) {
    var n2 = s2.options, o2 = false, a2 = s2.scrollParentNotHidden[0], r2 = s2.document[0];
    a2 !== r2 && "HTML" !== a2.tagName ? (n2.axis && "x" === n2.axis || (s2.overflowOffset.top + a2.offsetHeight - e2.pageY < n2.scrollSensitivity ? a2.scrollTop = o2 = a2.scrollTop + n2.scrollSpeed : e2.pageY - s2.overflowOffset.top < n2.scrollSensitivity && (a2.scrollTop = o2 = a2.scrollTop - n2.scrollSpeed)), n2.axis && "y" === n2.axis || (s2.overflowOffset.left + a2.offsetWidth - e2.pageX < n2.scrollSensitivity ? a2.scrollLeft = o2 = a2.scrollLeft + n2.scrollSpeed : e2.pageX - s2.overflowOffset.left < n2.scrollSensitivity && (a2.scrollLeft = o2 = a2.scrollLeft - n2.scrollSpeed))) : (n2.axis && "x" === n2.axis || (e2.pageY - t(r2).scrollTop() < n2.scrollSensitivity ? o2 = t(r2).scrollTop(t(r2).scrollTop() - n2.scrollSpeed) : t(window).height() - (e2.pageY - t(r2).scrollTop()) < n2.scrollSensitivity && (o2 = t(r2).scrollTop(t(r2).scrollTop() + n2.scrollSpeed))), n2.axis && "y" === n2.axis || (e2.pageX - t(r2).scrollLeft() < n2.scrollSensitivity ? o2 = t(r2).scrollLeft(t(r2).scrollLeft() - n2.scrollSpeed) : t(window).width() - (e2.pageX - t(r2).scrollLeft()) < n2.scrollSensitivity && (o2 = t(r2).scrollLeft(t(r2).scrollLeft() + n2.scrollSpeed)))), o2 !== false && t.ui.ddmanager && !n2.dropBehaviour && t.ui.ddmanager.prepareOffsets(s2, e2);
  } }), t.ui.plugin.add("draggable", "snap", { start: function(e2, i2, s2) {
    var n2 = s2.options;
    s2.snapElements = [], t(n2.snap.constructor !== String ? n2.snap.items || ":data(ui-draggable)" : n2.snap).each(function() {
      var e3 = t(this), i3 = e3.offset();
      this !== s2.element[0] && s2.snapElements.push({ item: this, width: e3.outerWidth(), height: e3.outerHeight(), top: i3.top, left: i3.left });
    });
  }, drag: function(e2, i2, s2) {
    var n2, o2, a2, r2, h2, l2, c2, u2, d2, p2, f = s2.options, g2 = f.snapTolerance, m2 = i2.offset.left, _2 = m2 + s2.helperProportions.width, v2 = i2.offset.top, b = v2 + s2.helperProportions.height;
    for (d2 = s2.snapElements.length - 1; d2 >= 0; d2--)
      h2 = s2.snapElements[d2].left - s2.margins.left, l2 = h2 + s2.snapElements[d2].width, c2 = s2.snapElements[d2].top - s2.margins.top, u2 = c2 + s2.snapElements[d2].height, h2 - g2 > _2 || m2 > l2 + g2 || c2 - g2 > b || v2 > u2 + g2 || !t.contains(s2.snapElements[d2].item.ownerDocument, s2.snapElements[d2].item) ? (s2.snapElements[d2].snapping && s2.options.snap.release && s2.options.snap.release.call(s2.element, e2, t.extend(s2._uiHash(), { snapItem: s2.snapElements[d2].item })), s2.snapElements[d2].snapping = false) : ("inner" !== f.snapMode && (n2 = g2 >= Math.abs(c2 - b), o2 = g2 >= Math.abs(u2 - v2), a2 = g2 >= Math.abs(h2 - _2), r2 = g2 >= Math.abs(l2 - m2), n2 && (i2.position.top = s2._convertPositionTo("relative", { top: c2 - s2.helperProportions.height, left: 0 }).top), o2 && (i2.position.top = s2._convertPositionTo("relative", { top: u2, left: 0 }).top), a2 && (i2.position.left = s2._convertPositionTo("relative", { top: 0, left: h2 - s2.helperProportions.width }).left), r2 && (i2.position.left = s2._convertPositionTo("relative", { top: 0, left: l2 }).left)), p2 = n2 || o2 || a2 || r2, "outer" !== f.snapMode && (n2 = g2 >= Math.abs(c2 - v2), o2 = g2 >= Math.abs(u2 - b), a2 = g2 >= Math.abs(h2 - m2), r2 = g2 >= Math.abs(l2 - _2), n2 && (i2.position.top = s2._convertPositionTo("relative", { top: c2, left: 0 }).top), o2 && (i2.position.top = s2._convertPositionTo("relative", { top: u2 - s2.helperProportions.height, left: 0 }).top), a2 && (i2.position.left = s2._convertPositionTo("relative", { top: 0, left: h2 }).left), r2 && (i2.position.left = s2._convertPositionTo("relative", { top: 0, left: l2 - s2.helperProportions.width }).left)), !s2.snapElements[d2].snapping && (n2 || o2 || a2 || r2 || p2) && s2.options.snap.snap && s2.options.snap.snap.call(s2.element, e2, t.extend(s2._uiHash(), { snapItem: s2.snapElements[d2].item })), s2.snapElements[d2].snapping = n2 || o2 || a2 || r2 || p2);
  } }), t.ui.plugin.add("draggable", "stack", { start: function(e2, i2, s2) {
    var n2, o2 = s2.options, a2 = t.makeArray(t(o2.stack)).sort(function(e3, i3) {
      return (parseInt(t(e3).css("zIndex"), 10) || 0) - (parseInt(t(i3).css("zIndex"), 10) || 0);
    });
    a2.length && (n2 = parseInt(t(a2[0]).css("zIndex"), 10) || 0, t(a2).each(function(e3) {
      t(this).css("zIndex", n2 + e3);
    }), this.css("zIndex", n2 + a2.length));
  } }), t.ui.plugin.add("draggable", "zIndex", { start: function(e2, i2, s2) {
    var n2 = t(i2.helper), o2 = s2.options;
    n2.css("zIndex") && (o2._zIndex = n2.css("zIndex")), n2.css("zIndex", o2.zIndex);
  }, stop: function(e2, i2, s2) {
    var n2 = s2.options;
    n2._zIndex && t(i2.helper).css("zIndex", n2._zIndex);
  } }), t.ui.draggable, t.widget("ui.resizable", t.ui.mouse, { version: "1.12.1", widgetEventPrefix: "resize", options: { alsoResize: false, animate: false, animateDuration: "slow", animateEasing: "swing", aspectRatio: false, autoHide: false, classes: { "ui-resizable-se": "ui-icon ui-icon-gripsmall-diagonal-se" }, containment: false, ghost: false, grid: false, handles: "e,s,se", helper: false, maxHeight: null, maxWidth: null, minHeight: 10, minWidth: 10, zIndex: 90, resize: null, start: null, stop: null }, _num: function(t2) {
    return parseFloat(t2) || 0;
  }, _isNumber: function(t2) {
    return !isNaN(parseFloat(t2));
  }, _hasScroll: function(e2, i2) {
    if ("hidden" === t(e2).css("overflow"))
      return false;
    var s2 = i2 && "left" === i2 ? "scrollLeft" : "scrollTop", n2 = false;
    return e2[s2] > 0 ? true : (e2[s2] = 1, n2 = e2[s2] > 0, e2[s2] = 0, n2);
  }, _create: function() {
    var e2, i2 = this.options, s2 = this;
    this._addClass("ui-resizable"), t.extend(this, { _aspectRatio: !!i2.aspectRatio, aspectRatio: i2.aspectRatio, originalElement: this.element, _proportionallyResizeElements: [], _helper: i2.helper || i2.ghost || i2.animate ? i2.helper || "ui-resizable-helper" : null }), this.element[0].nodeName.match(/^(canvas|textarea|input|select|button|img)$/i) && (this.element.wrap(t("<div class='ui-wrapper' style='overflow: hidden;'></div>").css({ position: this.element.css("position"), width: this.element.outerWidth(), height: this.element.outerHeight(), top: this.element.css("top"), left: this.element.css("left") })), this.element = this.element.parent().data("ui-resizable", this.element.resizable("instance")), this.elementIsWrapper = true, e2 = { marginTop: this.originalElement.css("marginTop"), marginRight: this.originalElement.css("marginRight"), marginBottom: this.originalElement.css("marginBottom"), marginLeft: this.originalElement.css("marginLeft") }, this.element.css(e2), this.originalElement.css("margin", 0), this.originalResizeStyle = this.originalElement.css("resize"), this.originalElement.css("resize", "none"), this._proportionallyResizeElements.push(this.originalElement.css({ position: "static", zoom: 1, display: "block" })), this.originalElement.css(e2), this._proportionallyResize()), this._setupHandles(), i2.autoHide && t(this.element).on("mouseenter", function() {
      i2.disabled || (s2._removeClass("ui-resizable-autohide"), s2._handles.show());
    }).on("mouseleave", function() {
      i2.disabled || s2.resizing || (s2._addClass("ui-resizable-autohide"), s2._handles.hide());
    }), this._mouseInit();
  }, _destroy: function() {
    this._mouseDestroy();
    var e2, i2 = function(e3) {
      t(e3).removeData("resizable").removeData("ui-resizable").off(".resizable").find(".ui-resizable-handle").remove();
    };
    return this.elementIsWrapper && (i2(this.element), e2 = this.element, this.originalElement.css({ position: e2.css("position"), width: e2.outerWidth(), height: e2.outerHeight(), top: e2.css("top"), left: e2.css("left") }).insertAfter(e2), e2.remove()), this.originalElement.css("resize", this.originalResizeStyle), i2(this.originalElement), this;
  }, _setOption: function(t2, e2) {
    switch (this._super(t2, e2), t2) {
      case "handles":
        this._removeHandles(), this._setupHandles();
        break;
    }
  }, _setupHandles: function() {
    var e2, i2, s2, n2, o2, a2 = this.options, r2 = this;
    if (this.handles = a2.handles || (t(".ui-resizable-handle", this.element).length ? { n: ".ui-resizable-n", e: ".ui-resizable-e", s: ".ui-resizable-s", w: ".ui-resizable-w", se: ".ui-resizable-se", sw: ".ui-resizable-sw", ne: ".ui-resizable-ne", nw: ".ui-resizable-nw" } : "e,s,se"), this._handles = t(), this.handles.constructor === String)
      for ("all" === this.handles && (this.handles = "n,e,s,w,se,sw,ne,nw"), s2 = this.handles.split(","), this.handles = {}, i2 = 0; s2.length > i2; i2++)
        e2 = t.trim(s2[i2]), n2 = "ui-resizable-" + e2, o2 = t("<div>"), this._addClass(o2, "ui-resizable-handle " + n2), o2.css({ zIndex: a2.zIndex }), this.handles[e2] = ".ui-resizable-" + e2, this.element.append(o2);
    this._renderAxis = function(e3) {
      var i3, s3, n3, o3;
      e3 = e3 || this.element;
      for (i3 in this.handles)
        this.handles[i3].constructor === String ? this.handles[i3] = this.element.children(this.handles[i3]).first().show() : (this.handles[i3].jquery || this.handles[i3].nodeType) && (this.handles[i3] = t(this.handles[i3]), this._on(this.handles[i3], { mousedown: r2._mouseDown })), this.elementIsWrapper && this.originalElement[0].nodeName.match(/^(textarea|input|select|button)$/i) && (s3 = t(this.handles[i3], this.element), o3 = /sw|ne|nw|se|n|s/.test(i3) ? s3.outerHeight() : s3.outerWidth(), n3 = ["padding", /ne|nw|n/.test(i3) ? "Top" : /se|sw|s/.test(i3) ? "Bottom" : /^e$/.test(i3) ? "Right" : "Left"].join(""), e3.css(n3, o3), this._proportionallyResize()), this._handles = this._handles.add(this.handles[i3]);
    }, this._renderAxis(this.element), this._handles = this._handles.add(this.element.find(".ui-resizable-handle")), this._handles.disableSelection(), this._handles.on("mouseover", function() {
      r2.resizing || (this.className && (o2 = this.className.match(/ui-resizable-(se|sw|ne|nw|n|e|s|w)/i)), r2.axis = o2 && o2[1] ? o2[1] : "se");
    }), a2.autoHide && (this._handles.hide(), this._addClass("ui-resizable-autohide"));
  }, _removeHandles: function() {
    this._handles.remove();
  }, _mouseCapture: function(e2) {
    var i2, s2, n2 = false;
    for (i2 in this.handles)
      s2 = t(this.handles[i2])[0], (s2 === e2.target || t.contains(s2, e2.target)) && (n2 = true);
    return !this.options.disabled && n2;
  }, _mouseStart: function(e2) {
    var i2, s2, n2, o2 = this.options, a2 = this.element;
    return this.resizing = true, this._renderProxy(), i2 = this._num(this.helper.css("left")), s2 = this._num(this.helper.css("top")), o2.containment && (i2 += t(o2.containment).scrollLeft() || 0, s2 += t(o2.containment).scrollTop() || 0), this.offset = this.helper.offset(), this.position = { left: i2, top: s2 }, this.size = this._helper ? { width: this.helper.width(), height: this.helper.height() } : { width: a2.width(), height: a2.height() }, this.originalSize = this._helper ? { width: a2.outerWidth(), height: a2.outerHeight() } : { width: a2.width(), height: a2.height() }, this.sizeDiff = { width: a2.outerWidth() - a2.width(), height: a2.outerHeight() - a2.height() }, this.originalPosition = { left: i2, top: s2 }, this.originalMousePosition = { left: e2.pageX, top: e2.pageY }, this.aspectRatio = "number" == typeof o2.aspectRatio ? o2.aspectRatio : this.originalSize.width / this.originalSize.height || 1, n2 = t(".ui-resizable-" + this.axis).css("cursor"), t("body").css("cursor", "auto" === n2 ? this.axis + "-resize" : n2), this._addClass("ui-resizable-resizing"), this._propagate("start", e2), true;
  }, _mouseDrag: function(e2) {
    var i2, s2, n2 = this.originalMousePosition, o2 = this.axis, a2 = e2.pageX - n2.left || 0, r2 = e2.pageY - n2.top || 0, h2 = this._change[o2];
    return this._updatePrevProperties(), h2 ? (i2 = h2.apply(this, [e2, a2, r2]), this._updateVirtualBoundaries(e2.shiftKey), (this._aspectRatio || e2.shiftKey) && (i2 = this._updateRatio(i2, e2)), i2 = this._respectSize(i2, e2), this._updateCache(i2), this._propagate("resize", e2), s2 = this._applyChanges(), !this._helper && this._proportionallyResizeElements.length && this._proportionallyResize(), t.isEmptyObject(s2) || (this._updatePrevProperties(), this._trigger("resize", e2, this.ui()), this._applyChanges()), false) : false;
  }, _mouseStop: function(e2) {
    this.resizing = false;
    var i2, s2, n2, o2, a2, r2, h2, l2 = this.options, c2 = this;
    return this._helper && (i2 = this._proportionallyResizeElements, s2 = i2.length && /textarea/i.test(i2[0].nodeName), n2 = s2 && this._hasScroll(i2[0], "left") ? 0 : c2.sizeDiff.height, o2 = s2 ? 0 : c2.sizeDiff.width, a2 = { width: c2.helper.width() - o2, height: c2.helper.height() - n2 }, r2 = parseFloat(c2.element.css("left")) + (c2.position.left - c2.originalPosition.left) || null, h2 = parseFloat(c2.element.css("top")) + (c2.position.top - c2.originalPosition.top) || null, l2.animate || this.element.css(t.extend(a2, { top: h2, left: r2 })), c2.helper.height(c2.size.height), c2.helper.width(c2.size.width), this._helper && !l2.animate && this._proportionallyResize()), t("body").css("cursor", "auto"), this._removeClass("ui-resizable-resizing"), this._propagate("stop", e2), this._helper && this.helper.remove(), false;
  }, _updatePrevProperties: function() {
    this.prevPosition = { top: this.position.top, left: this.position.left }, this.prevSize = { width: this.size.width, height: this.size.height };
  }, _applyChanges: function() {
    var t2 = {};
    return this.position.top !== this.prevPosition.top && (t2.top = this.position.top + "px"), this.position.left !== this.prevPosition.left && (t2.left = this.position.left + "px"), this.size.width !== this.prevSize.width && (t2.width = this.size.width + "px"), this.size.height !== this.prevSize.height && (t2.height = this.size.height + "px"), this.helper.css(t2), t2;
  }, _updateVirtualBoundaries: function(t2) {
    var e2, i2, s2, n2, o2, a2 = this.options;
    o2 = { minWidth: this._isNumber(a2.minWidth) ? a2.minWidth : 0, maxWidth: this._isNumber(a2.maxWidth) ? a2.maxWidth : 1 / 0, minHeight: this._isNumber(a2.minHeight) ? a2.minHeight : 0, maxHeight: this._isNumber(a2.maxHeight) ? a2.maxHeight : 1 / 0 }, (this._aspectRatio || t2) && (e2 = o2.minHeight * this.aspectRatio, s2 = o2.minWidth / this.aspectRatio, i2 = o2.maxHeight * this.aspectRatio, n2 = o2.maxWidth / this.aspectRatio, e2 > o2.minWidth && (o2.minWidth = e2), s2 > o2.minHeight && (o2.minHeight = s2), o2.maxWidth > i2 && (o2.maxWidth = i2), o2.maxHeight > n2 && (o2.maxHeight = n2)), this._vBoundaries = o2;
  }, _updateCache: function(t2) {
    this.offset = this.helper.offset(), this._isNumber(t2.left) && (this.position.left = t2.left), this._isNumber(t2.top) && (this.position.top = t2.top), this._isNumber(t2.height) && (this.size.height = t2.height), this._isNumber(t2.width) && (this.size.width = t2.width);
  }, _updateRatio: function(t2) {
    var e2 = this.position, i2 = this.size, s2 = this.axis;
    return this._isNumber(t2.height) ? t2.width = t2.height * this.aspectRatio : this._isNumber(t2.width) && (t2.height = t2.width / this.aspectRatio), "sw" === s2 && (t2.left = e2.left + (i2.width - t2.width), t2.top = null), "nw" === s2 && (t2.top = e2.top + (i2.height - t2.height), t2.left = e2.left + (i2.width - t2.width)), t2;
  }, _respectSize: function(t2) {
    var e2 = this._vBoundaries, i2 = this.axis, s2 = this._isNumber(t2.width) && e2.maxWidth && e2.maxWidth < t2.width, n2 = this._isNumber(t2.height) && e2.maxHeight && e2.maxHeight < t2.height, o2 = this._isNumber(t2.width) && e2.minWidth && e2.minWidth > t2.width, a2 = this._isNumber(t2.height) && e2.minHeight && e2.minHeight > t2.height, r2 = this.originalPosition.left + this.originalSize.width, h2 = this.originalPosition.top + this.originalSize.height, l2 = /sw|nw|w/.test(i2), c2 = /nw|ne|n/.test(i2);
    return o2 && (t2.width = e2.minWidth), a2 && (t2.height = e2.minHeight), s2 && (t2.width = e2.maxWidth), n2 && (t2.height = e2.maxHeight), o2 && l2 && (t2.left = r2 - e2.minWidth), s2 && l2 && (t2.left = r2 - e2.maxWidth), a2 && c2 && (t2.top = h2 - e2.minHeight), n2 && c2 && (t2.top = h2 - e2.maxHeight), t2.width || t2.height || t2.left || !t2.top ? t2.width || t2.height || t2.top || !t2.left || (t2.left = null) : t2.top = null, t2;
  }, _getPaddingPlusBorderDimensions: function(t2) {
    for (var e2 = 0, i2 = [], s2 = [t2.css("borderTopWidth"), t2.css("borderRightWidth"), t2.css("borderBottomWidth"), t2.css("borderLeftWidth")], n2 = [t2.css("paddingTop"), t2.css("paddingRight"), t2.css("paddingBottom"), t2.css("paddingLeft")]; 4 > e2; e2++)
      i2[e2] = parseFloat(s2[e2]) || 0, i2[e2] += parseFloat(n2[e2]) || 0;
    return { height: i2[0] + i2[2], width: i2[1] + i2[3] };
  }, _proportionallyResize: function() {
    if (this._proportionallyResizeElements.length)
      for (var t2, e2 = 0, i2 = this.helper || this.element; this._proportionallyResizeElements.length > e2; e2++)
        t2 = this._proportionallyResizeElements[e2], this.outerDimensions || (this.outerDimensions = this._getPaddingPlusBorderDimensions(t2)), t2.css({ height: i2.height() - this.outerDimensions.height || 0, width: i2.width() - this.outerDimensions.width || 0 });
  }, _renderProxy: function() {
    var e2 = this.element, i2 = this.options;
    this.elementOffset = e2.offset(), this._helper ? (this.helper = this.helper || t("<div style='overflow:hidden;'></div>"), this._addClass(this.helper, this._helper), this.helper.css({ width: this.element.outerWidth(), height: this.element.outerHeight(), position: "absolute", left: this.elementOffset.left + "px", top: this.elementOffset.top + "px", zIndex: ++i2.zIndex }), this.helper.appendTo("body").disableSelection()) : this.helper = this.element;
  }, _change: { e: function(t2, e2) {
    return { width: this.originalSize.width + e2 };
  }, w: function(t2, e2) {
    var i2 = this.originalSize, s2 = this.originalPosition;
    return { left: s2.left + e2, width: i2.width - e2 };
  }, n: function(t2, e2, i2) {
    var s2 = this.originalSize, n2 = this.originalPosition;
    return { top: n2.top + i2, height: s2.height - i2 };
  }, s: function(t2, e2, i2) {
    return { height: this.originalSize.height + i2 };
  }, se: function(e2, i2, s2) {
    return t.extend(this._change.s.apply(this, arguments), this._change.e.apply(this, [e2, i2, s2]));
  }, sw: function(e2, i2, s2) {
    return t.extend(this._change.s.apply(this, arguments), this._change.w.apply(this, [e2, i2, s2]));
  }, ne: function(e2, i2, s2) {
    return t.extend(this._change.n.apply(this, arguments), this._change.e.apply(this, [e2, i2, s2]));
  }, nw: function(e2, i2, s2) {
    return t.extend(this._change.n.apply(this, arguments), this._change.w.apply(this, [e2, i2, s2]));
  } }, _propagate: function(e2, i2) {
    t.ui.plugin.call(this, e2, [i2, this.ui()]), "resize" !== e2 && this._trigger(e2, i2, this.ui());
  }, plugins: {}, ui: function() {
    return { originalElement: this.originalElement, element: this.element, helper: this.helper, position: this.position, size: this.size, originalSize: this.originalSize, originalPosition: this.originalPosition };
  } }), t.ui.plugin.add("resizable", "animate", { stop: function(e2) {
    var i2 = t(this).resizable("instance"), s2 = i2.options, n2 = i2._proportionallyResizeElements, o2 = n2.length && /textarea/i.test(n2[0].nodeName), a2 = o2 && i2._hasScroll(n2[0], "left") ? 0 : i2.sizeDiff.height, r2 = o2 ? 0 : i2.sizeDiff.width, h2 = { width: i2.size.width - r2, height: i2.size.height - a2 }, l2 = parseFloat(i2.element.css("left")) + (i2.position.left - i2.originalPosition.left) || null, c2 = parseFloat(i2.element.css("top")) + (i2.position.top - i2.originalPosition.top) || null;
    i2.element.animate(t.extend(h2, c2 && l2 ? { top: c2, left: l2 } : {}), { duration: s2.animateDuration, easing: s2.animateEasing, step: function() {
      var s3 = { width: parseFloat(i2.element.css("width")), height: parseFloat(i2.element.css("height")), top: parseFloat(i2.element.css("top")), left: parseFloat(i2.element.css("left")) };
      n2 && n2.length && t(n2[0]).css({ width: s3.width, height: s3.height }), i2._updateCache(s3), i2._propagate("resize", e2);
    } });
  } }), t.ui.plugin.add("resizable", "containment", { start: function() {
    var e2, i2, s2, n2, o2, a2, r2, h2 = t(this).resizable("instance"), l2 = h2.options, c2 = h2.element, u2 = l2.containment, d2 = u2 instanceof t ? u2.get(0) : /parent/.test(u2) ? c2.parent().get(0) : u2;
    d2 && (h2.containerElement = t(d2), /document/.test(u2) || u2 === document ? (h2.containerOffset = { left: 0, top: 0 }, h2.containerPosition = { left: 0, top: 0 }, h2.parentData = { element: t(document), left: 0, top: 0, width: t(document).width(), height: t(document).height() || document.body.parentNode.scrollHeight }) : (e2 = t(d2), i2 = [], t(["Top", "Right", "Left", "Bottom"]).each(function(t2, s3) {
      i2[t2] = h2._num(e2.css("padding" + s3));
    }), h2.containerOffset = e2.offset(), h2.containerPosition = e2.position(), h2.containerSize = { height: e2.innerHeight() - i2[3], width: e2.innerWidth() - i2[1] }, s2 = h2.containerOffset, n2 = h2.containerSize.height, o2 = h2.containerSize.width, a2 = h2._hasScroll(d2, "left") ? d2.scrollWidth : o2, r2 = h2._hasScroll(d2) ? d2.scrollHeight : n2, h2.parentData = { element: d2, left: s2.left, top: s2.top, width: a2, height: r2 }));
  }, resize: function(e2) {
    var i2, s2, n2, o2, a2 = t(this).resizable("instance"), r2 = a2.options, h2 = a2.containerOffset, l2 = a2.position, c2 = a2._aspectRatio || e2.shiftKey, u2 = { top: 0, left: 0 }, d2 = a2.containerElement, p2 = true;
    d2[0] !== document && /static/.test(d2.css("position")) && (u2 = h2), l2.left < (a2._helper ? h2.left : 0) && (a2.size.width = a2.size.width + (a2._helper ? a2.position.left - h2.left : a2.position.left - u2.left), c2 && (a2.size.height = a2.size.width / a2.aspectRatio, p2 = false), a2.position.left = r2.helper ? h2.left : 0), l2.top < (a2._helper ? h2.top : 0) && (a2.size.height = a2.size.height + (a2._helper ? a2.position.top - h2.top : a2.position.top), c2 && (a2.size.width = a2.size.height * a2.aspectRatio, p2 = false), a2.position.top = a2._helper ? h2.top : 0), n2 = a2.containerElement.get(0) === a2.element.parent().get(0), o2 = /relative|absolute/.test(a2.containerElement.css("position")), n2 && o2 ? (a2.offset.left = a2.parentData.left + a2.position.left, a2.offset.top = a2.parentData.top + a2.position.top) : (a2.offset.left = a2.element.offset().left, a2.offset.top = a2.element.offset().top), i2 = Math.abs(a2.sizeDiff.width + (a2._helper ? a2.offset.left - u2.left : a2.offset.left - h2.left)), s2 = Math.abs(a2.sizeDiff.height + (a2._helper ? a2.offset.top - u2.top : a2.offset.top - h2.top)), i2 + a2.size.width >= a2.parentData.width && (a2.size.width = a2.parentData.width - i2, c2 && (a2.size.height = a2.size.width / a2.aspectRatio, p2 = false)), s2 + a2.size.height >= a2.parentData.height && (a2.size.height = a2.parentData.height - s2, c2 && (a2.size.width = a2.size.height * a2.aspectRatio, p2 = false)), p2 || (a2.position.left = a2.prevPosition.left, a2.position.top = a2.prevPosition.top, a2.size.width = a2.prevSize.width, a2.size.height = a2.prevSize.height);
  }, stop: function() {
    var e2 = t(this).resizable("instance"), i2 = e2.options, s2 = e2.containerOffset, n2 = e2.containerPosition, o2 = e2.containerElement, a2 = t(e2.helper), r2 = a2.offset(), h2 = a2.outerWidth() - e2.sizeDiff.width, l2 = a2.outerHeight() - e2.sizeDiff.height;
    e2._helper && !i2.animate && /relative/.test(o2.css("position")) && t(this).css({ left: r2.left - n2.left - s2.left, width: h2, height: l2 }), e2._helper && !i2.animate && /static/.test(o2.css("position")) && t(this).css({ left: r2.left - n2.left - s2.left, width: h2, height: l2 });
  } }), t.ui.plugin.add("resizable", "alsoResize", { start: function() {
    var e2 = t(this).resizable("instance"), i2 = e2.options;
    t(i2.alsoResize).each(function() {
      var e3 = t(this);
      e3.data("ui-resizable-alsoresize", { width: parseFloat(e3.width()), height: parseFloat(e3.height()), left: parseFloat(e3.css("left")), top: parseFloat(e3.css("top")) });
    });
  }, resize: function(e2, i2) {
    var s2 = t(this).resizable("instance"), n2 = s2.options, o2 = s2.originalSize, a2 = s2.originalPosition, r2 = { height: s2.size.height - o2.height || 0, width: s2.size.width - o2.width || 0, top: s2.position.top - a2.top || 0, left: s2.position.left - a2.left || 0 };
    t(n2.alsoResize).each(function() {
      var e3 = t(this), s3 = t(this).data("ui-resizable-alsoresize"), n3 = {}, o3 = e3.parents(i2.originalElement[0]).length ? ["width", "height"] : ["width", "height", "top", "left"];
      t.each(o3, function(t2, e4) {
        var i3 = (s3[e4] || 0) + (r2[e4] || 0);
        i3 && i3 >= 0 && (n3[e4] = i3 || null);
      }), e3.css(n3);
    });
  }, stop: function() {
    t(this).removeData("ui-resizable-alsoresize");
  } }), t.ui.plugin.add("resizable", "ghost", { start: function() {
    var e2 = t(this).resizable("instance"), i2 = e2.size;
    e2.ghost = e2.originalElement.clone(), e2.ghost.css({ opacity: 0.25, display: "block", position: "relative", height: i2.height, width: i2.width, margin: 0, left: 0, top: 0 }), e2._addClass(e2.ghost, "ui-resizable-ghost"), t.uiBackCompat !== false && "string" == typeof e2.options.ghost && e2.ghost.addClass(this.options.ghost), e2.ghost.appendTo(e2.helper);
  }, resize: function() {
    var e2 = t(this).resizable("instance");
    e2.ghost && e2.ghost.css({ position: "relative", height: e2.size.height, width: e2.size.width });
  }, stop: function() {
    var e2 = t(this).resizable("instance");
    e2.ghost && e2.helper && e2.helper.get(0).removeChild(e2.ghost.get(0));
  } }), t.ui.plugin.add("resizable", "grid", { resize: function() {
    var e2, i2 = t(this).resizable("instance"), s2 = i2.options, n2 = i2.size, o2 = i2.originalSize, a2 = i2.originalPosition, r2 = i2.axis, h2 = "number" == typeof s2.grid ? [s2.grid, s2.grid] : s2.grid, l2 = h2[0] || 1, c2 = h2[1] || 1, u2 = Math.round((n2.width - o2.width) / l2) * l2, d2 = Math.round((n2.height - o2.height) / c2) * c2, p2 = o2.width + u2, f = o2.height + d2, g2 = s2.maxWidth && p2 > s2.maxWidth, m2 = s2.maxHeight && f > s2.maxHeight, _2 = s2.minWidth && s2.minWidth > p2, v2 = s2.minHeight && s2.minHeight > f;
    s2.grid = h2, _2 && (p2 += l2), v2 && (f += c2), g2 && (p2 -= l2), m2 && (f -= c2), /^(se|s|e)$/.test(r2) ? (i2.size.width = p2, i2.size.height = f) : /^(ne)$/.test(r2) ? (i2.size.width = p2, i2.size.height = f, i2.position.top = a2.top - d2) : /^(sw)$/.test(r2) ? (i2.size.width = p2, i2.size.height = f, i2.position.left = a2.left - u2) : ((0 >= f - c2 || 0 >= p2 - l2) && (e2 = i2._getPaddingPlusBorderDimensions(this)), f - c2 > 0 ? (i2.size.height = f, i2.position.top = a2.top - d2) : (f = c2 - e2.height, i2.size.height = f, i2.position.top = a2.top + o2.height - f), p2 - l2 > 0 ? (i2.size.width = p2, i2.position.left = a2.left - u2) : (p2 = l2 - e2.width, i2.size.width = p2, i2.position.left = a2.left + o2.width - p2));
  } }), t.ui.resizable, t.widget("ui.dialog", { version: "1.12.1", options: { appendTo: "body", autoOpen: true, buttons: [], classes: { "ui-dialog": "ui-corner-all", "ui-dialog-titlebar": "ui-corner-all" }, closeOnEscape: true, closeText: "Close", draggable: true, hide: null, height: "auto", maxHeight: null, maxWidth: null, minHeight: 150, minWidth: 150, modal: false, position: { my: "center", at: "center", of: window, collision: "fit", using: function(e2) {
    var i2 = t(this).css(e2).offset().top;
    0 > i2 && t(this).css("top", e2.top - i2);
  } }, resizable: true, show: null, title: null, width: 300, beforeClose: null, close: null, drag: null, dragStart: null, dragStop: null, focus: null, open: null, resize: null, resizeStart: null, resizeStop: null }, sizeRelatedOptions: { buttons: true, height: true, maxHeight: true, maxWidth: true, minHeight: true, minWidth: true, width: true }, resizableRelatedOptions: { maxHeight: true, maxWidth: true, minHeight: true, minWidth: true }, _create: function() {
    this.originalCss = { display: this.element[0].style.display, width: this.element[0].style.width, minHeight: this.element[0].style.minHeight, maxHeight: this.element[0].style.maxHeight, height: this.element[0].style.height }, this.originalPosition = { parent: this.element.parent(), index: this.element.parent().children().index(this.element) }, this.originalTitle = this.element.attr("title"), null == this.options.title && null != this.originalTitle && (this.options.title = this.originalTitle), this.options.disabled && (this.options.disabled = false), this._createWrapper(), this.element.show().removeAttr("title").appendTo(this.uiDialog), this._addClass("ui-dialog-content", "ui-widget-content"), this._createTitlebar(), this._createButtonPane(), this.options.draggable && t.fn.draggable && this._makeDraggable(), this.options.resizable && t.fn.resizable && this._makeResizable(), this._isOpen = false, this._trackFocus();
  }, _init: function() {
    this.options.autoOpen && this.open();
  }, _appendTo: function() {
    var e2 = this.options.appendTo;
    return e2 && (e2.jquery || e2.nodeType) ? t(e2) : this.document.find(e2 || "body").eq(0);
  }, _destroy: function() {
    var t2, e2 = this.originalPosition;
    this._untrackInstance(), this._destroyOverlay(), this.element.removeUniqueId().css(this.originalCss).detach(), this.uiDialog.remove(), this.originalTitle && this.element.attr("title", this.originalTitle), t2 = e2.parent.children().eq(e2.index), t2.length && t2[0] !== this.element[0] ? t2.before(this.element) : e2.parent.append(this.element);
  }, widget: function() {
    return this.uiDialog;
  }, disable: t.noop, enable: t.noop, close: function(e2) {
    var i2 = this;
    this._isOpen && this._trigger("beforeClose", e2) !== false && (this._isOpen = false, this._focusedElement = null, this._destroyOverlay(), this._untrackInstance(), this.opener.filter(":focusable").trigger("focus").length || t.ui.safeBlur(t.ui.safeActiveElement(this.document[0])), this._hide(this.uiDialog, this.options.hide, function() {
      i2._trigger("close", e2);
    }));
  }, isOpen: function() {
    return this._isOpen;
  }, moveToTop: function() {
    this._moveToTop();
  }, _moveToTop: function(e2, i2) {
    var s2 = false, n2 = this.uiDialog.siblings(".ui-front:visible").map(function() {
      return +t(this).css("z-index");
    }).get(), o2 = Math.max.apply(null, n2);
    return o2 >= +this.uiDialog.css("z-index") && (this.uiDialog.css("z-index", o2 + 1), s2 = true), s2 && !i2 && this._trigger("focus", e2), s2;
  }, open: function() {
    var e2 = this;
    return this._isOpen ? (this._moveToTop() && this._focusTabbable(), void 0) : (this._isOpen = true, this.opener = t(t.ui.safeActiveElement(this.document[0])), this._size(), this._position(), this._createOverlay(), this._moveToTop(null, true), this.overlay && this.overlay.css("z-index", this.uiDialog.css("z-index") - 1), this._show(this.uiDialog, this.options.show, function() {
      e2._focusTabbable(), e2._trigger("focus");
    }), this._makeFocusTarget(), this._trigger("open"), void 0);
  }, _focusTabbable: function() {
    var t2 = this._focusedElement;
    t2 || (t2 = this.element.find("[autofocus]")), t2.length || (t2 = this.element.find(":tabbable")), t2.length || (t2 = this.uiDialogButtonPane.find(":tabbable")), t2.length || (t2 = this.uiDialogTitlebarClose.filter(":tabbable")), t2.length || (t2 = this.uiDialog), t2.eq(0).trigger("focus");
  }, _keepFocus: function(e2) {
    function i2() {
      var e3 = t.ui.safeActiveElement(this.document[0]), i3 = this.uiDialog[0] === e3 || t.contains(this.uiDialog[0], e3);
      i3 || this._focusTabbable();
    }
    e2.preventDefault(), i2.call(this), this._delay(i2);
  }, _createWrapper: function() {
    this.uiDialog = t("<div>").hide().attr({ tabIndex: -1, role: "dialog" }).appendTo(this._appendTo()), this._addClass(this.uiDialog, "ui-dialog", "ui-widget ui-widget-content ui-front"), this._on(this.uiDialog, { keydown: function(e2) {
      if (this.options.closeOnEscape && !e2.isDefaultPrevented() && e2.keyCode && e2.keyCode === t.ui.keyCode.ESCAPE)
        return e2.preventDefault(), this.close(e2), void 0;
      if (e2.keyCode === t.ui.keyCode.TAB && !e2.isDefaultPrevented()) {
        var i2 = this.uiDialog.find(":tabbable"), s2 = i2.filter(":first"), n2 = i2.filter(":last");
        e2.target !== n2[0] && e2.target !== this.uiDialog[0] || e2.shiftKey ? e2.target !== s2[0] && e2.target !== this.uiDialog[0] || !e2.shiftKey || (this._delay(function() {
          n2.trigger("focus");
        }), e2.preventDefault()) : (this._delay(function() {
          s2.trigger("focus");
        }), e2.preventDefault());
      }
    }, mousedown: function(t2) {
      this._moveToTop(t2) && this._focusTabbable();
    } }), this.element.find("[aria-describedby]").length || this.uiDialog.attr({ "aria-describedby": this.element.uniqueId().attr("id") });
  }, _createTitlebar: function() {
    var e2;
    this.uiDialogTitlebar = t("<div>"), this._addClass(this.uiDialogTitlebar, "ui-dialog-titlebar", "ui-widget-header ui-helper-clearfix"), this._on(this.uiDialogTitlebar, { mousedown: function(e3) {
      t(e3.target).closest(".ui-dialog-titlebar-close") || this.uiDialog.trigger("focus");
    } }), this.uiDialogTitlebarClose = t("<button type='button'></button>").button({ label: t("<a>").text(this.options.closeText).html(), icon: "ui-icon-closethick", showLabel: false }).appendTo(this.uiDialogTitlebar), this._addClass(this.uiDialogTitlebarClose, "ui-dialog-titlebar-close"), this._on(this.uiDialogTitlebarClose, { click: function(t2) {
      t2.preventDefault(), this.close(t2);
    } }), e2 = t("<span>").uniqueId().prependTo(this.uiDialogTitlebar), this._addClass(e2, "ui-dialog-title"), this._title(e2), this.uiDialogTitlebar.prependTo(this.uiDialog), this.uiDialog.attr({ "aria-labelledby": e2.attr("id") });
  }, _title: function(t2) {
    this.options.title ? t2.text(this.options.title) : t2.html("&#160;");
  }, _createButtonPane: function() {
    this.uiDialogButtonPane = t("<div>"), this._addClass(this.uiDialogButtonPane, "ui-dialog-buttonpane", "ui-widget-content ui-helper-clearfix"), this.uiButtonSet = t("<div>").appendTo(this.uiDialogButtonPane), this._addClass(this.uiButtonSet, "ui-dialog-buttonset"), this._createButtons();
  }, _createButtons: function() {
    var e2 = this, i2 = this.options.buttons;
    return this.uiDialogButtonPane.remove(), this.uiButtonSet.empty(), t.isEmptyObject(i2) || t.isArray(i2) && !i2.length ? (this._removeClass(this.uiDialog, "ui-dialog-buttons"), void 0) : (t.each(i2, function(i3, s2) {
      var n2, o2;
      s2 = t.isFunction(s2) ? { click: s2, text: i3 } : s2, s2 = t.extend({ type: "button" }, s2), n2 = s2.click, o2 = { icon: s2.icon, iconPosition: s2.iconPosition, showLabel: s2.showLabel, icons: s2.icons, text: s2.text }, delete s2.click, delete s2.icon, delete s2.iconPosition, delete s2.showLabel, delete s2.icons, "boolean" == typeof s2.text && delete s2.text, t("<button></button>", s2).button(o2).appendTo(e2.uiButtonSet).on("click", function() {
        n2.apply(e2.element[0], arguments);
      });
    }), this._addClass(this.uiDialog, "ui-dialog-buttons"), this.uiDialogButtonPane.appendTo(this.uiDialog), void 0);
  }, _makeDraggable: function() {
    function e2(t2) {
      return { position: t2.position, offset: t2.offset };
    }
    var i2 = this, s2 = this.options;
    this.uiDialog.draggable({ cancel: ".ui-dialog-content, .ui-dialog-titlebar-close", handle: ".ui-dialog-titlebar", containment: "document", start: function(s3, n2) {
      i2._addClass(t(this), "ui-dialog-dragging"), i2._blockFrames(), i2._trigger("dragStart", s3, e2(n2));
    }, drag: function(t2, s3) {
      i2._trigger("drag", t2, e2(s3));
    }, stop: function(n2, o2) {
      var a2 = o2.offset.left - i2.document.scrollLeft(), r2 = o2.offset.top - i2.document.scrollTop();
      s2.position = { my: "left top", at: "left" + (a2 >= 0 ? "+" : "") + a2 + " top" + (r2 >= 0 ? "+" : "") + r2, of: i2.window }, i2._removeClass(t(this), "ui-dialog-dragging"), i2._unblockFrames(), i2._trigger("dragStop", n2, e2(o2));
    } });
  }, _makeResizable: function() {
    function e2(t2) {
      return { originalPosition: t2.originalPosition, originalSize: t2.originalSize, position: t2.position, size: t2.size };
    }
    var i2 = this, s2 = this.options, n2 = s2.resizable, o2 = this.uiDialog.css("position"), a2 = "string" == typeof n2 ? n2 : "n,e,s,w,se,sw,ne,nw";
    this.uiDialog.resizable({ cancel: ".ui-dialog-content", containment: "document", alsoResize: this.element, maxWidth: s2.maxWidth, maxHeight: s2.maxHeight, minWidth: s2.minWidth, minHeight: this._minHeight(), handles: a2, start: function(s3, n3) {
      i2._addClass(t(this), "ui-dialog-resizing"), i2._blockFrames(), i2._trigger("resizeStart", s3, e2(n3));
    }, resize: function(t2, s3) {
      i2._trigger("resize", t2, e2(s3));
    }, stop: function(n3, o3) {
      var a3 = i2.uiDialog.offset(), r2 = a3.left - i2.document.scrollLeft(), h2 = a3.top - i2.document.scrollTop();
      s2.height = i2.uiDialog.height(), s2.width = i2.uiDialog.width(), s2.position = { my: "left top", at: "left" + (r2 >= 0 ? "+" : "") + r2 + " top" + (h2 >= 0 ? "+" : "") + h2, of: i2.window }, i2._removeClass(t(this), "ui-dialog-resizing"), i2._unblockFrames(), i2._trigger("resizeStop", n3, e2(o3));
    } }).css("position", o2);
  }, _trackFocus: function() {
    this._on(this.widget(), { focusin: function(e2) {
      this._makeFocusTarget(), this._focusedElement = t(e2.target);
    } });
  }, _makeFocusTarget: function() {
    this._untrackInstance(), this._trackingInstances().unshift(this);
  }, _untrackInstance: function() {
    var e2 = this._trackingInstances(), i2 = t.inArray(this, e2);
    -1 !== i2 && e2.splice(i2, 1);
  }, _trackingInstances: function() {
    var t2 = this.document.data("ui-dialog-instances");
    return t2 || (t2 = [], this.document.data("ui-dialog-instances", t2)), t2;
  }, _minHeight: function() {
    var t2 = this.options;
    return "auto" === t2.height ? t2.minHeight : Math.min(t2.minHeight, t2.height);
  }, _position: function() {
    var t2 = this.uiDialog.is(":visible");
    t2 || this.uiDialog.show(), this.uiDialog.position(this.options.position), t2 || this.uiDialog.hide();
  }, _setOptions: function(e2) {
    var i2 = this, s2 = false, n2 = {};
    t.each(e2, function(t2, e3) {
      i2._setOption(t2, e3), t2 in i2.sizeRelatedOptions && (s2 = true), t2 in i2.resizableRelatedOptions && (n2[t2] = e3);
    }), s2 && (this._size(), this._position()), this.uiDialog.is(":data(ui-resizable)") && this.uiDialog.resizable("option", n2);
  }, _setOption: function(e2, i2) {
    var s2, n2, o2 = this.uiDialog;
    "disabled" !== e2 && (this._super(e2, i2), "appendTo" === e2 && this.uiDialog.appendTo(this._appendTo()), "buttons" === e2 && this._createButtons(), "closeText" === e2 && this.uiDialogTitlebarClose.button({ label: t("<a>").text("" + this.options.closeText).html() }), "draggable" === e2 && (s2 = o2.is(":data(ui-draggable)"), s2 && !i2 && o2.draggable("destroy"), !s2 && i2 && this._makeDraggable()), "position" === e2 && this._position(), "resizable" === e2 && (n2 = o2.is(":data(ui-resizable)"), n2 && !i2 && o2.resizable("destroy"), n2 && "string" == typeof i2 && o2.resizable("option", "handles", i2), n2 || i2 === false || this._makeResizable()), "title" === e2 && this._title(this.uiDialogTitlebar.find(".ui-dialog-title")));
  }, _size: function() {
    var t2, e2, i2, s2 = this.options;
    this.element.show().css({ width: "auto", minHeight: 0, maxHeight: "none", height: 0 }), s2.minWidth > s2.width && (s2.width = s2.minWidth), t2 = this.uiDialog.css({ height: "auto", width: s2.width }).outerHeight(), e2 = Math.max(0, s2.minHeight - t2), i2 = "number" == typeof s2.maxHeight ? Math.max(0, s2.maxHeight - t2) : "none", "auto" === s2.height ? this.element.css({ minHeight: e2, maxHeight: i2, height: "auto" }) : this.element.height(Math.max(0, s2.height - t2)), this.uiDialog.is(":data(ui-resizable)") && this.uiDialog.resizable("option", "minHeight", this._minHeight());
  }, _blockFrames: function() {
    this.iframeBlocks = this.document.find("iframe").map(function() {
      var e2 = t(this);
      return t("<div>").css({ position: "absolute", width: e2.outerWidth(), height: e2.outerHeight() }).appendTo(e2.parent()).offset(e2.offset())[0];
    });
  }, _unblockFrames: function() {
    this.iframeBlocks && (this.iframeBlocks.remove(), delete this.iframeBlocks);
  }, _allowInteraction: function(e2) {
    return t(e2.target).closest(".ui-dialog").length ? true : !!t(e2.target).closest(".ui-datepicker").length;
  }, _createOverlay: function() {
    if (this.options.modal) {
      var e2 = true;
      this._delay(function() {
        e2 = false;
      }), this.document.data("ui-dialog-overlays") || this._on(this.document, { focusin: function(t2) {
        e2 || this._allowInteraction(t2) || (t2.preventDefault(), this._trackingInstances()[0]._focusTabbable());
      } }), this.overlay = t("<div>").appendTo(this._appendTo()), this._addClass(this.overlay, null, "ui-widget-overlay ui-front"), this._on(this.overlay, { mousedown: "_keepFocus" }), this.document.data("ui-dialog-overlays", (this.document.data("ui-dialog-overlays") || 0) + 1);
    }
  }, _destroyOverlay: function() {
    if (this.options.modal && this.overlay) {
      var t2 = this.document.data("ui-dialog-overlays") - 1;
      t2 ? this.document.data("ui-dialog-overlays", t2) : (this._off(this.document, "focusin"), this.document.removeData("ui-dialog-overlays")), this.overlay.remove(), this.overlay = null;
    }
  } }), t.uiBackCompat !== false && t.widget("ui.dialog", t.ui.dialog, { options: { dialogClass: "" }, _createWrapper: function() {
    this._super(), this.uiDialog.addClass(this.options.dialogClass);
  }, _setOption: function(t2, e2) {
    "dialogClass" === t2 && this.uiDialog.removeClass(this.options.dialogClass).addClass(e2), this._superApply(arguments);
  } }), t.ui.dialog, t.widget("ui.droppable", { version: "1.12.1", widgetEventPrefix: "drop", options: { accept: "*", addClasses: true, greedy: false, scope: "default", tolerance: "intersect", activate: null, deactivate: null, drop: null, out: null, over: null }, _create: function() {
    var e2, i2 = this.options, s2 = i2.accept;
    this.isover = false, this.isout = true, this.accept = t.isFunction(s2) ? s2 : function(t2) {
      return t2.is(s2);
    }, this.proportions = function() {
      return arguments.length ? (e2 = arguments[0], void 0) : e2 ? e2 : e2 = { width: this.element[0].offsetWidth, height: this.element[0].offsetHeight };
    }, this._addToManager(i2.scope), i2.addClasses && this._addClass("ui-droppable");
  }, _addToManager: function(e2) {
    t.ui.ddmanager.droppables[e2] = t.ui.ddmanager.droppables[e2] || [], t.ui.ddmanager.droppables[e2].push(this);
  }, _splice: function(t2) {
    for (var e2 = 0; t2.length > e2; e2++)
      t2[e2] === this && t2.splice(e2, 1);
  }, _destroy: function() {
    var e2 = t.ui.ddmanager.droppables[this.options.scope];
    this._splice(e2);
  }, _setOption: function(e2, i2) {
    if ("accept" === e2)
      this.accept = t.isFunction(i2) ? i2 : function(t2) {
        return t2.is(i2);
      };
    else if ("scope" === e2) {
      var s2 = t.ui.ddmanager.droppables[this.options.scope];
      this._splice(s2), this._addToManager(i2);
    }
    this._super(e2, i2);
  }, _activate: function(e2) {
    var i2 = t.ui.ddmanager.current;
    this._addActiveClass(), i2 && this._trigger("activate", e2, this.ui(i2));
  }, _deactivate: function(e2) {
    var i2 = t.ui.ddmanager.current;
    this._removeActiveClass(), i2 && this._trigger("deactivate", e2, this.ui(i2));
  }, _over: function(e2) {
    var i2 = t.ui.ddmanager.current;
    i2 && (i2.currentItem || i2.element)[0] !== this.element[0] && this.accept.call(this.element[0], i2.currentItem || i2.element) && (this._addHoverClass(), this._trigger("over", e2, this.ui(i2)));
  }, _out: function(e2) {
    var i2 = t.ui.ddmanager.current;
    i2 && (i2.currentItem || i2.element)[0] !== this.element[0] && this.accept.call(this.element[0], i2.currentItem || i2.element) && (this._removeHoverClass(), this._trigger("out", e2, this.ui(i2)));
  }, _drop: function(e2, i2) {
    var s2 = i2 || t.ui.ddmanager.current, n2 = false;
    return s2 && (s2.currentItem || s2.element)[0] !== this.element[0] ? (this.element.find(":data(ui-droppable)").not(".ui-draggable-dragging").each(function() {
      var i3 = t(this).droppable("instance");
      return i3.options.greedy && !i3.options.disabled && i3.options.scope === s2.options.scope && i3.accept.call(i3.element[0], s2.currentItem || s2.element) && v(s2, t.extend(i3, { offset: i3.element.offset() }), i3.options.tolerance, e2) ? (n2 = true, false) : void 0;
    }), n2 ? false : this.accept.call(this.element[0], s2.currentItem || s2.element) ? (this._removeActiveClass(), this._removeHoverClass(), this._trigger("drop", e2, this.ui(s2)), this.element) : false) : false;
  }, ui: function(t2) {
    return { draggable: t2.currentItem || t2.element, helper: t2.helper, position: t2.position, offset: t2.positionAbs };
  }, _addHoverClass: function() {
    this._addClass("ui-droppable-hover");
  }, _removeHoverClass: function() {
    this._removeClass("ui-droppable-hover");
  }, _addActiveClass: function() {
    this._addClass("ui-droppable-active");
  }, _removeActiveClass: function() {
    this._removeClass("ui-droppable-active");
  } });
  var v = t.ui.intersect = function() {
    function t2(t3, e2, i2) {
      return t3 >= e2 && e2 + i2 > t3;
    }
    return function(e2, i2, s2, n2) {
      if (!i2.offset)
        return false;
      var o2 = (e2.positionAbs || e2.position.absolute).left + e2.margins.left, a2 = (e2.positionAbs || e2.position.absolute).top + e2.margins.top, r2 = o2 + e2.helperProportions.width, h2 = a2 + e2.helperProportions.height, l2 = i2.offset.left, c2 = i2.offset.top, u2 = l2 + i2.proportions().width, d2 = c2 + i2.proportions().height;
      switch (s2) {
        case "fit":
          return o2 >= l2 && u2 >= r2 && a2 >= c2 && d2 >= h2;
        case "intersect":
          return o2 + e2.helperProportions.width / 2 > l2 && u2 > r2 - e2.helperProportions.width / 2 && a2 + e2.helperProportions.height / 2 > c2 && d2 > h2 - e2.helperProportions.height / 2;
        case "pointer":
          return t2(n2.pageY, c2, i2.proportions().height) && t2(n2.pageX, l2, i2.proportions().width);
        case "touch":
          return (a2 >= c2 && d2 >= a2 || h2 >= c2 && d2 >= h2 || c2 > a2 && h2 > d2) && (o2 >= l2 && u2 >= o2 || r2 >= l2 && u2 >= r2 || l2 > o2 && r2 > u2);
        default:
          return false;
      }
    };
  }();
  t.ui.ddmanager = { current: null, droppables: { "default": [] }, prepareOffsets: function(e2, i2) {
    var s2, n2, o2 = t.ui.ddmanager.droppables[e2.options.scope] || [], a2 = i2 ? i2.type : null, r2 = (e2.currentItem || e2.element).find(":data(ui-droppable)").addBack();
    t:
      for (s2 = 0; o2.length > s2; s2++)
        if (!(o2[s2].options.disabled || e2 && !o2[s2].accept.call(o2[s2].element[0], e2.currentItem || e2.element))) {
          for (n2 = 0; r2.length > n2; n2++)
            if (r2[n2] === o2[s2].element[0]) {
              o2[s2].proportions().height = 0;
              continue t;
            }
          o2[s2].visible = "none" !== o2[s2].element.css("display"), o2[s2].visible && ("mousedown" === a2 && o2[s2]._activate.call(o2[s2], i2), o2[s2].offset = o2[s2].element.offset(), o2[s2].proportions({ width: o2[s2].element[0].offsetWidth, height: o2[s2].element[0].offsetHeight }));
        }
  }, drop: function(e2, i2) {
    var s2 = false;
    return t.each((t.ui.ddmanager.droppables[e2.options.scope] || []).slice(), function() {
      this.options && (!this.options.disabled && this.visible && v(e2, this, this.options.tolerance, i2) && (s2 = this._drop.call(this, i2) || s2), !this.options.disabled && this.visible && this.accept.call(this.element[0], e2.currentItem || e2.element) && (this.isout = true, this.isover = false, this._deactivate.call(this, i2)));
    }), s2;
  }, dragStart: function(e2, i2) {
    e2.element.parentsUntil("body").on("scroll.droppable", function() {
      e2.options.refreshPositions || t.ui.ddmanager.prepareOffsets(e2, i2);
    });
  }, drag: function(e2, i2) {
    e2.options.refreshPositions && t.ui.ddmanager.prepareOffsets(e2, i2), t.each(t.ui.ddmanager.droppables[e2.options.scope] || [], function() {
      if (!this.options.disabled && !this.greedyChild && this.visible) {
        var s2, n2, o2, a2 = v(e2, this, this.options.tolerance, i2), r2 = !a2 && this.isover ? "isout" : a2 && !this.isover ? "isover" : null;
        r2 && (this.options.greedy && (n2 = this.options.scope, o2 = this.element.parents(":data(ui-droppable)").filter(function() {
          return t(this).droppable("instance").options.scope === n2;
        }), o2.length && (s2 = t(o2[0]).droppable("instance"), s2.greedyChild = "isover" === r2)), s2 && "isover" === r2 && (s2.isover = false, s2.isout = true, s2._out.call(s2, i2)), this[r2] = true, this["isout" === r2 ? "isover" : "isout"] = false, this["isover" === r2 ? "_over" : "_out"].call(this, i2), s2 && "isout" === r2 && (s2.isout = false, s2.isover = true, s2._over.call(s2, i2)));
      }
    });
  }, dragStop: function(e2, i2) {
    e2.element.parentsUntil("body").off("scroll.droppable"), e2.options.refreshPositions || t.ui.ddmanager.prepareOffsets(e2, i2);
  } }, t.uiBackCompat !== false && t.widget("ui.droppable", t.ui.droppable, { options: { hoverClass: false, activeClass: false }, _addActiveClass: function() {
    this._super(), this.options.activeClass && this.element.addClass(this.options.activeClass);
  }, _removeActiveClass: function() {
    this._super(), this.options.activeClass && this.element.removeClass(this.options.activeClass);
  }, _addHoverClass: function() {
    this._super(), this.options.hoverClass && this.element.addClass(this.options.hoverClass);
  }, _removeHoverClass: function() {
    this._super(), this.options.hoverClass && this.element.removeClass(this.options.hoverClass);
  } }), t.ui.droppable, t.widget("ui.progressbar", { version: "1.12.1", options: { classes: { "ui-progressbar": "ui-corner-all", "ui-progressbar-value": "ui-corner-left", "ui-progressbar-complete": "ui-corner-right" }, max: 100, value: 0, change: null, complete: null }, min: 0, _create: function() {
    this.oldValue = this.options.value = this._constrainedValue(), this.element.attr({ role: "progressbar", "aria-valuemin": this.min }), this._addClass("ui-progressbar", "ui-widget ui-widget-content"), this.valueDiv = t("<div>").appendTo(this.element), this._addClass(this.valueDiv, "ui-progressbar-value", "ui-widget-header"), this._refreshValue();
  }, _destroy: function() {
    this.element.removeAttr("role aria-valuemin aria-valuemax aria-valuenow"), this.valueDiv.remove();
  }, value: function(t2) {
    return void 0 === t2 ? this.options.value : (this.options.value = this._constrainedValue(t2), this._refreshValue(), void 0);
  }, _constrainedValue: function(t2) {
    return void 0 === t2 && (t2 = this.options.value), this.indeterminate = t2 === false, "number" != typeof t2 && (t2 = 0), this.indeterminate ? false : Math.min(this.options.max, Math.max(this.min, t2));
  }, _setOptions: function(t2) {
    var e2 = t2.value;
    delete t2.value, this._super(t2), this.options.value = this._constrainedValue(e2), this._refreshValue();
  }, _setOption: function(t2, e2) {
    "max" === t2 && (e2 = Math.max(this.min, e2)), this._super(t2, e2);
  }, _setOptionDisabled: function(t2) {
    this._super(t2), this.element.attr("aria-disabled", t2), this._toggleClass(null, "ui-state-disabled", !!t2);
  }, _percentage: function() {
    return this.indeterminate ? 100 : 100 * (this.options.value - this.min) / (this.options.max - this.min);
  }, _refreshValue: function() {
    var e2 = this.options.value, i2 = this._percentage();
    this.valueDiv.toggle(this.indeterminate || e2 > this.min).width(i2.toFixed(0) + "%"), this._toggleClass(this.valueDiv, "ui-progressbar-complete", null, e2 === this.options.max)._toggleClass("ui-progressbar-indeterminate", null, this.indeterminate), this.indeterminate ? (this.element.removeAttr("aria-valuenow"), this.overlayDiv || (this.overlayDiv = t("<div>").appendTo(this.valueDiv), this._addClass(this.overlayDiv, "ui-progressbar-overlay"))) : (this.element.attr({ "aria-valuemax": this.options.max, "aria-valuenow": e2 }), this.overlayDiv && (this.overlayDiv.remove(), this.overlayDiv = null)), this.oldValue !== e2 && (this.oldValue = e2, this._trigger("change")), e2 === this.options.max && this._trigger("complete");
  } }), t.widget("ui.selectable", t.ui.mouse, { version: "1.12.1", options: { appendTo: "body", autoRefresh: true, distance: 0, filter: "*", tolerance: "touch", selected: null, selecting: null, start: null, stop: null, unselected: null, unselecting: null }, _create: function() {
    var e2 = this;
    this._addClass("ui-selectable"), this.dragged = false, this.refresh = function() {
      e2.elementPos = t(e2.element[0]).offset(), e2.selectees = t(e2.options.filter, e2.element[0]), e2._addClass(e2.selectees, "ui-selectee"), e2.selectees.each(function() {
        var i2 = t(this), s2 = i2.offset(), n2 = { left: s2.left - e2.elementPos.left, top: s2.top - e2.elementPos.top };
        t.data(this, "selectable-item", { element: this, $element: i2, left: n2.left, top: n2.top, right: n2.left + i2.outerWidth(), bottom: n2.top + i2.outerHeight(), startselected: false, selected: i2.hasClass("ui-selected"), selecting: i2.hasClass("ui-selecting"), unselecting: i2.hasClass("ui-unselecting") });
      });
    }, this.refresh(), this._mouseInit(), this.helper = t("<div>"), this._addClass(this.helper, "ui-selectable-helper");
  }, _destroy: function() {
    this.selectees.removeData("selectable-item"), this._mouseDestroy();
  }, _mouseStart: function(e2) {
    var i2 = this, s2 = this.options;
    this.opos = [e2.pageX, e2.pageY], this.elementPos = t(this.element[0]).offset(), this.options.disabled || (this.selectees = t(s2.filter, this.element[0]), this._trigger("start", e2), t(s2.appendTo).append(this.helper), this.helper.css({ left: e2.pageX, top: e2.pageY, width: 0, height: 0 }), s2.autoRefresh && this.refresh(), this.selectees.filter(".ui-selected").each(function() {
      var s3 = t.data(this, "selectable-item");
      s3.startselected = true, e2.metaKey || e2.ctrlKey || (i2._removeClass(s3.$element, "ui-selected"), s3.selected = false, i2._addClass(s3.$element, "ui-unselecting"), s3.unselecting = true, i2._trigger("unselecting", e2, { unselecting: s3.element }));
    }), t(e2.target).parents().addBack().each(function() {
      var s3, n2 = t.data(this, "selectable-item");
      return n2 ? (s3 = !e2.metaKey && !e2.ctrlKey || !n2.$element.hasClass("ui-selected"), i2._removeClass(n2.$element, s3 ? "ui-unselecting" : "ui-selected")._addClass(n2.$element, s3 ? "ui-selecting" : "ui-unselecting"), n2.unselecting = !s3, n2.selecting = s3, n2.selected = s3, s3 ? i2._trigger("selecting", e2, { selecting: n2.element }) : i2._trigger("unselecting", e2, { unselecting: n2.element }), false) : void 0;
    }));
  }, _mouseDrag: function(e2) {
    if (this.dragged = true, !this.options.disabled) {
      var i2, s2 = this, n2 = this.options, o2 = this.opos[0], a2 = this.opos[1], r2 = e2.pageX, h2 = e2.pageY;
      return o2 > r2 && (i2 = r2, r2 = o2, o2 = i2), a2 > h2 && (i2 = h2, h2 = a2, a2 = i2), this.helper.css({ left: o2, top: a2, width: r2 - o2, height: h2 - a2 }), this.selectees.each(function() {
        var i3 = t.data(this, "selectable-item"), l2 = false, c2 = {};
        i3 && i3.element !== s2.element[0] && (c2.left = i3.left + s2.elementPos.left, c2.right = i3.right + s2.elementPos.left, c2.top = i3.top + s2.elementPos.top, c2.bottom = i3.bottom + s2.elementPos.top, "touch" === n2.tolerance ? l2 = !(c2.left > r2 || o2 > c2.right || c2.top > h2 || a2 > c2.bottom) : "fit" === n2.tolerance && (l2 = c2.left > o2 && r2 > c2.right && c2.top > a2 && h2 > c2.bottom), l2 ? (i3.selected && (s2._removeClass(i3.$element, "ui-selected"), i3.selected = false), i3.unselecting && (s2._removeClass(i3.$element, "ui-unselecting"), i3.unselecting = false), i3.selecting || (s2._addClass(i3.$element, "ui-selecting"), i3.selecting = true, s2._trigger("selecting", e2, { selecting: i3.element }))) : (i3.selecting && ((e2.metaKey || e2.ctrlKey) && i3.startselected ? (s2._removeClass(i3.$element, "ui-selecting"), i3.selecting = false, s2._addClass(i3.$element, "ui-selected"), i3.selected = true) : (s2._removeClass(i3.$element, "ui-selecting"), i3.selecting = false, i3.startselected && (s2._addClass(i3.$element, "ui-unselecting"), i3.unselecting = true), s2._trigger("unselecting", e2, { unselecting: i3.element }))), i3.selected && (e2.metaKey || e2.ctrlKey || i3.startselected || (s2._removeClass(i3.$element, "ui-selected"), i3.selected = false, s2._addClass(i3.$element, "ui-unselecting"), i3.unselecting = true, s2._trigger("unselecting", e2, { unselecting: i3.element })))));
      }), false;
    }
  }, _mouseStop: function(e2) {
    var i2 = this;
    return this.dragged = false, t(".ui-unselecting", this.element[0]).each(function() {
      var s2 = t.data(this, "selectable-item");
      i2._removeClass(s2.$element, "ui-unselecting"), s2.unselecting = false, s2.startselected = false, i2._trigger("unselected", e2, { unselected: s2.element });
    }), t(".ui-selecting", this.element[0]).each(function() {
      var s2 = t.data(this, "selectable-item");
      i2._removeClass(s2.$element, "ui-selecting")._addClass(s2.$element, "ui-selected"), s2.selecting = false, s2.selected = true, s2.startselected = true, i2._trigger("selected", e2, { selected: s2.element });
    }), this._trigger("stop", e2), this.helper.remove(), false;
  } }), t.widget("ui.selectmenu", [t.ui.formResetMixin, { version: "1.12.1", defaultElement: "<select>", options: { appendTo: null, classes: { "ui-selectmenu-button-open": "ui-corner-top", "ui-selectmenu-button-closed": "ui-corner-all" }, disabled: null, icons: { button: "ui-icon-triangle-1-s" }, position: { my: "left top", at: "left bottom", collision: "none" }, width: false, change: null, close: null, focus: null, open: null, select: null }, _create: function() {
    var e2 = this.element.uniqueId().attr("id");
    this.ids = { element: e2, button: e2 + "-button", menu: e2 + "-menu" }, this._drawButton(), this._drawMenu(), this._bindFormResetHandler(), this._rendered = false, this.menuItems = t();
  }, _drawButton: function() {
    var e2, i2 = this, s2 = this._parseOption(this.element.find("option:selected"), this.element[0].selectedIndex);
    this.labels = this.element.labels().attr("for", this.ids.button), this._on(this.labels, { click: function(t2) {
      this.button.focus(), t2.preventDefault();
    } }), this.element.hide(), this.button = t("<span>", { tabindex: this.options.disabled ? -1 : 0, id: this.ids.button, role: "combobox", "aria-expanded": "false", "aria-autocomplete": "list", "aria-owns": this.ids.menu, "aria-haspopup": "true", title: this.element.attr("title") }).insertAfter(this.element), this._addClass(this.button, "ui-selectmenu-button ui-selectmenu-button-closed", "ui-button ui-widget"), e2 = t("<span>").appendTo(this.button), this._addClass(e2, "ui-selectmenu-icon", "ui-icon " + this.options.icons.button), this.buttonItem = this._renderButtonItem(s2).appendTo(this.button), this.options.width !== false && this._resizeButton(), this._on(this.button, this._buttonEvents), this.button.one("focusin", function() {
      i2._rendered || i2._refreshMenu();
    });
  }, _drawMenu: function() {
    var e2 = this;
    this.menu = t("<ul>", { "aria-hidden": "true", "aria-labelledby": this.ids.button, id: this.ids.menu }), this.menuWrap = t("<div>").append(this.menu), this._addClass(this.menuWrap, "ui-selectmenu-menu", "ui-front"), this.menuWrap.appendTo(this._appendTo()), this.menuInstance = this.menu.menu({ classes: { "ui-menu": "ui-corner-bottom" }, role: "listbox", select: function(t2, i2) {
      t2.preventDefault(), e2._setSelection(), e2._select(i2.item.data("ui-selectmenu-item"), t2);
    }, focus: function(t2, i2) {
      var s2 = i2.item.data("ui-selectmenu-item");
      null != e2.focusIndex && s2.index !== e2.focusIndex && (e2._trigger("focus", t2, { item: s2 }), e2.isOpen || e2._select(s2, t2)), e2.focusIndex = s2.index, e2.button.attr("aria-activedescendant", e2.menuItems.eq(s2.index).attr("id"));
    } }).menu("instance"), this.menuInstance._off(this.menu, "mouseleave"), this.menuInstance._closeOnDocumentClick = function() {
      return false;
    }, this.menuInstance._isDivider = function() {
      return false;
    };
  }, refresh: function() {
    this._refreshMenu(), this.buttonItem.replaceWith(this.buttonItem = this._renderButtonItem(this._getSelectedItem().data("ui-selectmenu-item") || {})), null === this.options.width && this._resizeButton();
  }, _refreshMenu: function() {
    var t2, e2 = this.element.find("option");
    this.menu.empty(), this._parseOptions(e2), this._renderMenu(this.menu, this.items), this.menuInstance.refresh(), this.menuItems = this.menu.find("li").not(".ui-selectmenu-optgroup").find(".ui-menu-item-wrapper"), this._rendered = true, e2.length && (t2 = this._getSelectedItem(), this.menuInstance.focus(null, t2), this._setAria(t2.data("ui-selectmenu-item")), this._setOption("disabled", this.element.prop("disabled")));
  }, open: function(t2) {
    this.options.disabled || (this._rendered ? (this._removeClass(this.menu.find(".ui-state-active"), null, "ui-state-active"), this.menuInstance.focus(null, this._getSelectedItem())) : this._refreshMenu(), this.menuItems.length && (this.isOpen = true, this._toggleAttr(), this._resizeMenu(), this._position(), this._on(this.document, this._documentClick), this._trigger("open", t2)));
  }, _position: function() {
    this.menuWrap.position(t.extend({ of: this.button }, this.options.position));
  }, close: function(t2) {
    this.isOpen && (this.isOpen = false, this._toggleAttr(), this.range = null, this._off(this.document), this._trigger("close", t2));
  }, widget: function() {
    return this.button;
  }, menuWidget: function() {
    return this.menu;
  }, _renderButtonItem: function(e2) {
    var i2 = t("<span>");
    return this._setText(i2, e2.label), this._addClass(i2, "ui-selectmenu-text"), i2;
  }, _renderMenu: function(e2, i2) {
    var s2 = this, n2 = "";
    t.each(i2, function(i3, o2) {
      var a2;
      o2.optgroup !== n2 && (a2 = t("<li>", { text: o2.optgroup }), s2._addClass(a2, "ui-selectmenu-optgroup", "ui-menu-divider" + (o2.element.parent("optgroup").prop("disabled") ? " ui-state-disabled" : "")), a2.appendTo(e2), n2 = o2.optgroup), s2._renderItemData(e2, o2);
    });
  }, _renderItemData: function(t2, e2) {
    return this._renderItem(t2, e2).data("ui-selectmenu-item", e2);
  }, _renderItem: function(e2, i2) {
    var s2 = t("<li>"), n2 = t("<div>", { title: i2.element.attr("title") });
    return i2.disabled && this._addClass(s2, null, "ui-state-disabled"), this._setText(n2, i2.label), s2.append(n2).appendTo(e2);
  }, _setText: function(t2, e2) {
    e2 ? t2.text(e2) : t2.html("&#160;");
  }, _move: function(t2, e2) {
    var i2, s2, n2 = ".ui-menu-item";
    this.isOpen ? i2 = this.menuItems.eq(this.focusIndex).parent("li") : (i2 = this.menuItems.eq(this.element[0].selectedIndex).parent("li"), n2 += ":not(.ui-state-disabled)"), s2 = "first" === t2 || "last" === t2 ? i2["first" === t2 ? "prevAll" : "nextAll"](n2).eq(-1) : i2[t2 + "All"](n2).eq(0), s2.length && this.menuInstance.focus(e2, s2);
  }, _getSelectedItem: function() {
    return this.menuItems.eq(this.element[0].selectedIndex).parent("li");
  }, _toggle: function(t2) {
    this[this.isOpen ? "close" : "open"](t2);
  }, _setSelection: function() {
    var t2;
    this.range && (window.getSelection ? (t2 = window.getSelection(), t2.removeAllRanges(), t2.addRange(this.range)) : this.range.select(), this.button.focus());
  }, _documentClick: { mousedown: function(e2) {
    this.isOpen && (t(e2.target).closest(".ui-selectmenu-menu, #" + t.ui.escapeSelector(this.ids.button)).length || this.close(e2));
  } }, _buttonEvents: { mousedown: function() {
    var t2;
    window.getSelection ? (t2 = window.getSelection(), t2.rangeCount && (this.range = t2.getRangeAt(0))) : this.range = document.selection.createRange();
  }, click: function(t2) {
    this._setSelection(), this._toggle(t2);
  }, keydown: function(e2) {
    var i2 = true;
    switch (e2.keyCode) {
      case t.ui.keyCode.TAB:
      case t.ui.keyCode.ESCAPE:
        this.close(e2), i2 = false;
        break;
      case t.ui.keyCode.ENTER:
        this.isOpen && this._selectFocusedItem(e2);
        break;
      case t.ui.keyCode.UP:
        e2.altKey ? this._toggle(e2) : this._move("prev", e2);
        break;
      case t.ui.keyCode.DOWN:
        e2.altKey ? this._toggle(e2) : this._move("next", e2);
        break;
      case t.ui.keyCode.SPACE:
        this.isOpen ? this._selectFocusedItem(e2) : this._toggle(e2);
        break;
      case t.ui.keyCode.LEFT:
        this._move("prev", e2);
        break;
      case t.ui.keyCode.RIGHT:
        this._move("next", e2);
        break;
      case t.ui.keyCode.HOME:
      case t.ui.keyCode.PAGE_UP:
        this._move("first", e2);
        break;
      case t.ui.keyCode.END:
      case t.ui.keyCode.PAGE_DOWN:
        this._move("last", e2);
        break;
      default:
        this.menu.trigger(e2), i2 = false;
    }
    i2 && e2.preventDefault();
  } }, _selectFocusedItem: function(t2) {
    var e2 = this.menuItems.eq(this.focusIndex).parent("li");
    e2.hasClass("ui-state-disabled") || this._select(e2.data("ui-selectmenu-item"), t2);
  }, _select: function(t2, e2) {
    var i2 = this.element[0].selectedIndex;
    this.element[0].selectedIndex = t2.index, this.buttonItem.replaceWith(this.buttonItem = this._renderButtonItem(t2)), this._setAria(t2), this._trigger("select", e2, { item: t2 }), t2.index !== i2 && this._trigger("change", e2, { item: t2 }), this.close(e2);
  }, _setAria: function(t2) {
    var e2 = this.menuItems.eq(t2.index).attr("id");
    this.button.attr({ "aria-labelledby": e2, "aria-activedescendant": e2 }), this.menu.attr("aria-activedescendant", e2);
  }, _setOption: function(t2, e2) {
    if ("icons" === t2) {
      var i2 = this.button.find("span.ui-icon");
      this._removeClass(i2, null, this.options.icons.button)._addClass(i2, null, e2.button);
    }
    this._super(t2, e2), "appendTo" === t2 && this.menuWrap.appendTo(this._appendTo()), "width" === t2 && this._resizeButton();
  }, _setOptionDisabled: function(t2) {
    this._super(t2), this.menuInstance.option("disabled", t2), this.button.attr("aria-disabled", t2), this._toggleClass(this.button, null, "ui-state-disabled", t2), this.element.prop("disabled", t2), t2 ? (this.button.attr("tabindex", -1), this.close()) : this.button.attr("tabindex", 0);
  }, _appendTo: function() {
    var e2 = this.options.appendTo;
    return e2 && (e2 = e2.jquery || e2.nodeType ? t(e2) : this.document.find(e2).eq(0)), e2 && e2[0] || (e2 = this.element.closest(".ui-front, dialog")), e2.length || (e2 = this.document[0].body), e2;
  }, _toggleAttr: function() {
    this.button.attr("aria-expanded", this.isOpen), this._removeClass(this.button, "ui-selectmenu-button-" + (this.isOpen ? "closed" : "open"))._addClass(this.button, "ui-selectmenu-button-" + (this.isOpen ? "open" : "closed"))._toggleClass(this.menuWrap, "ui-selectmenu-open", null, this.isOpen), this.menu.attr("aria-hidden", !this.isOpen);
  }, _resizeButton: function() {
    var t2 = this.options.width;
    return t2 === false ? (this.button.css("width", ""), void 0) : (null === t2 && (t2 = this.element.show().outerWidth(), this.element.hide()), this.button.outerWidth(t2), void 0);
  }, _resizeMenu: function() {
    this.menu.outerWidth(Math.max(this.button.outerWidth(), this.menu.width("").outerWidth() + 1));
  }, _getCreateOptions: function() {
    var t2 = this._super();
    return t2.disabled = this.element.prop("disabled"), t2;
  }, _parseOptions: function(e2) {
    var i2 = this, s2 = [];
    e2.each(function(e3, n2) {
      s2.push(i2._parseOption(t(n2), e3));
    }), this.items = s2;
  }, _parseOption: function(t2, e2) {
    var i2 = t2.parent("optgroup");
    return { element: t2, index: e2, value: t2.val(), label: t2.text(), optgroup: i2.attr("label") || "", disabled: i2.prop("disabled") || t2.prop("disabled") };
  }, _destroy: function() {
    this._unbindFormResetHandler(), this.menuWrap.remove(), this.button.remove(), this.element.show(), this.element.removeUniqueId(), this.labels.attr("for", this.ids.element);
  } }]), t.widget("ui.slider", t.ui.mouse, { version: "1.12.1", widgetEventPrefix: "slide", options: { animate: false, classes: { "ui-slider": "ui-corner-all", "ui-slider-handle": "ui-corner-all", "ui-slider-range": "ui-corner-all ui-widget-header" }, distance: 0, max: 100, min: 0, orientation: "horizontal", range: false, step: 1, value: 0, values: null, change: null, slide: null, start: null, stop: null }, numPages: 5, _create: function() {
    this._keySliding = false, this._mouseSliding = false, this._animateOff = true, this._handleIndex = null, this._detectOrientation(), this._mouseInit(), this._calculateNewMax(), this._addClass("ui-slider ui-slider-" + this.orientation, "ui-widget ui-widget-content"), this._refresh(), this._animateOff = false;
  }, _refresh: function() {
    this._createRange(), this._createHandles(), this._setupEvents(), this._refreshValue();
  }, _createHandles: function() {
    var e2, i2, s2 = this.options, n2 = this.element.find(".ui-slider-handle"), o2 = "<span tabindex='0'></span>", a2 = [];
    for (i2 = s2.values && s2.values.length || 1, n2.length > i2 && (n2.slice(i2).remove(), n2 = n2.slice(0, i2)), e2 = n2.length; i2 > e2; e2++)
      a2.push(o2);
    this.handles = n2.add(t(a2.join("")).appendTo(this.element)), this._addClass(this.handles, "ui-slider-handle", "ui-state-default"), this.handle = this.handles.eq(0), this.handles.each(function(e3) {
      t(this).data("ui-slider-handle-index", e3).attr("tabIndex", 0);
    });
  }, _createRange: function() {
    var e2 = this.options;
    e2.range ? (e2.range === true && (e2.values ? e2.values.length && 2 !== e2.values.length ? e2.values = [e2.values[0], e2.values[0]] : t.isArray(e2.values) && (e2.values = e2.values.slice(0)) : e2.values = [this._valueMin(), this._valueMin()]), this.range && this.range.length ? (this._removeClass(this.range, "ui-slider-range-min ui-slider-range-max"), this.range.css({ left: "", bottom: "" })) : (this.range = t("<div>").appendTo(this.element), this._addClass(this.range, "ui-slider-range")), ("min" === e2.range || "max" === e2.range) && this._addClass(this.range, "ui-slider-range-" + e2.range)) : (this.range && this.range.remove(), this.range = null);
  }, _setupEvents: function() {
    this._off(this.handles), this._on(this.handles, this._handleEvents), this._hoverable(this.handles), this._focusable(this.handles);
  }, _destroy: function() {
    this.handles.remove(), this.range && this.range.remove(), this._mouseDestroy();
  }, _mouseCapture: function(e2) {
    var i2, s2, n2, o2, a2, r2, h2, l2, c2 = this, u2 = this.options;
    return u2.disabled ? false : (this.elementSize = { width: this.element.outerWidth(), height: this.element.outerHeight() }, this.elementOffset = this.element.offset(), i2 = { x: e2.pageX, y: e2.pageY }, s2 = this._normValueFromMouse(i2), n2 = this._valueMax() - this._valueMin() + 1, this.handles.each(function(e3) {
      var i3 = Math.abs(s2 - c2.values(e3));
      (n2 > i3 || n2 === i3 && (e3 === c2._lastChangedValue || c2.values(e3) === u2.min)) && (n2 = i3, o2 = t(this), a2 = e3);
    }), r2 = this._start(e2, a2), r2 === false ? false : (this._mouseSliding = true, this._handleIndex = a2, this._addClass(o2, null, "ui-state-active"), o2.trigger("focus"), h2 = o2.offset(), l2 = !t(e2.target).parents().addBack().is(".ui-slider-handle"), this._clickOffset = l2 ? { left: 0, top: 0 } : { left: e2.pageX - h2.left - o2.width() / 2, top: e2.pageY - h2.top - o2.height() / 2 - (parseInt(o2.css("borderTopWidth"), 10) || 0) - (parseInt(o2.css("borderBottomWidth"), 10) || 0) + (parseInt(o2.css("marginTop"), 10) || 0) }, this.handles.hasClass("ui-state-hover") || this._slide(e2, a2, s2), this._animateOff = true, true));
  }, _mouseStart: function() {
    return true;
  }, _mouseDrag: function(t2) {
    var e2 = { x: t2.pageX, y: t2.pageY }, i2 = this._normValueFromMouse(e2);
    return this._slide(t2, this._handleIndex, i2), false;
  }, _mouseStop: function(t2) {
    return this._removeClass(this.handles, null, "ui-state-active"), this._mouseSliding = false, this._stop(t2, this._handleIndex), this._change(t2, this._handleIndex), this._handleIndex = null, this._clickOffset = null, this._animateOff = false, false;
  }, _detectOrientation: function() {
    this.orientation = "vertical" === this.options.orientation ? "vertical" : "horizontal";
  }, _normValueFromMouse: function(t2) {
    var e2, i2, s2, n2, o2;
    return "horizontal" === this.orientation ? (e2 = this.elementSize.width, i2 = t2.x - this.elementOffset.left - (this._clickOffset ? this._clickOffset.left : 0)) : (e2 = this.elementSize.height, i2 = t2.y - this.elementOffset.top - (this._clickOffset ? this._clickOffset.top : 0)), s2 = i2 / e2, s2 > 1 && (s2 = 1), 0 > s2 && (s2 = 0), "vertical" === this.orientation && (s2 = 1 - s2), n2 = this._valueMax() - this._valueMin(), o2 = this._valueMin() + s2 * n2, this._trimAlignValue(o2);
  }, _uiHash: function(t2, e2, i2) {
    var s2 = { handle: this.handles[t2], handleIndex: t2, value: void 0 !== e2 ? e2 : this.value() };
    return this._hasMultipleValues() && (s2.value = void 0 !== e2 ? e2 : this.values(t2), s2.values = i2 || this.values()), s2;
  }, _hasMultipleValues: function() {
    return this.options.values && this.options.values.length;
  }, _start: function(t2, e2) {
    return this._trigger("start", t2, this._uiHash(e2));
  }, _slide: function(t2, e2, i2) {
    var s2, n2, o2 = this.value(), a2 = this.values();
    this._hasMultipleValues() && (n2 = this.values(e2 ? 0 : 1), o2 = this.values(e2), 2 === this.options.values.length && this.options.range === true && (i2 = 0 === e2 ? Math.min(n2, i2) : Math.max(n2, i2)), a2[e2] = i2), i2 !== o2 && (s2 = this._trigger("slide", t2, this._uiHash(e2, i2, a2)), s2 !== false && (this._hasMultipleValues() ? this.values(e2, i2) : this.value(i2)));
  }, _stop: function(t2, e2) {
    this._trigger("stop", t2, this._uiHash(e2));
  }, _change: function(t2, e2) {
    this._keySliding || this._mouseSliding || (this._lastChangedValue = e2, this._trigger("change", t2, this._uiHash(e2)));
  }, value: function(t2) {
    return arguments.length ? (this.options.value = this._trimAlignValue(t2), this._refreshValue(), this._change(null, 0), void 0) : this._value();
  }, values: function(e2, i2) {
    var s2, n2, o2;
    if (arguments.length > 1)
      return this.options.values[e2] = this._trimAlignValue(i2), this._refreshValue(), this._change(null, e2), void 0;
    if (!arguments.length)
      return this._values();
    if (!t.isArray(arguments[0]))
      return this._hasMultipleValues() ? this._values(e2) : this.value();
    for (s2 = this.options.values, n2 = arguments[0], o2 = 0; s2.length > o2; o2 += 1)
      s2[o2] = this._trimAlignValue(n2[o2]), this._change(null, o2);
    this._refreshValue();
  }, _setOption: function(e2, i2) {
    var s2, n2 = 0;
    switch ("range" === e2 && this.options.range === true && ("min" === i2 ? (this.options.value = this._values(0), this.options.values = null) : "max" === i2 && (this.options.value = this._values(this.options.values.length - 1), this.options.values = null)), t.isArray(this.options.values) && (n2 = this.options.values.length), this._super(e2, i2), e2) {
      case "orientation":
        this._detectOrientation(), this._removeClass("ui-slider-horizontal ui-slider-vertical")._addClass("ui-slider-" + this.orientation), this._refreshValue(), this.options.range && this._refreshRange(i2), this.handles.css("horizontal" === i2 ? "bottom" : "left", "");
        break;
      case "value":
        this._animateOff = true, this._refreshValue(), this._change(null, 0), this._animateOff = false;
        break;
      case "values":
        for (this._animateOff = true, this._refreshValue(), s2 = n2 - 1; s2 >= 0; s2--)
          this._change(null, s2);
        this._animateOff = false;
        break;
      case "step":
      case "min":
      case "max":
        this._animateOff = true, this._calculateNewMax(), this._refreshValue(), this._animateOff = false;
        break;
      case "range":
        this._animateOff = true, this._refresh(), this._animateOff = false;
    }
  }, _setOptionDisabled: function(t2) {
    this._super(t2), this._toggleClass(null, "ui-state-disabled", !!t2);
  }, _value: function() {
    var t2 = this.options.value;
    return t2 = this._trimAlignValue(t2);
  }, _values: function(t2) {
    var e2, i2, s2;
    if (arguments.length)
      return e2 = this.options.values[t2], e2 = this._trimAlignValue(e2);
    if (this._hasMultipleValues()) {
      for (i2 = this.options.values.slice(), s2 = 0; i2.length > s2; s2 += 1)
        i2[s2] = this._trimAlignValue(i2[s2]);
      return i2;
    }
    return [];
  }, _trimAlignValue: function(t2) {
    if (this._valueMin() >= t2)
      return this._valueMin();
    if (t2 >= this._valueMax())
      return this._valueMax();
    var e2 = this.options.step > 0 ? this.options.step : 1, i2 = (t2 - this._valueMin()) % e2, s2 = t2 - i2;
    return 2 * Math.abs(i2) >= e2 && (s2 += i2 > 0 ? e2 : -e2), parseFloat(s2.toFixed(5));
  }, _calculateNewMax: function() {
    var t2 = this.options.max, e2 = this._valueMin(), i2 = this.options.step, s2 = Math.round((t2 - e2) / i2) * i2;
    t2 = s2 + e2, t2 > this.options.max && (t2 -= i2), this.max = parseFloat(t2.toFixed(this._precision()));
  }, _precision: function() {
    var t2 = this._precisionOf(this.options.step);
    return null !== this.options.min && (t2 = Math.max(t2, this._precisionOf(this.options.min))), t2;
  }, _precisionOf: function(t2) {
    var e2 = "" + t2, i2 = e2.indexOf(".");
    return -1 === i2 ? 0 : e2.length - i2 - 1;
  }, _valueMin: function() {
    return this.options.min;
  }, _valueMax: function() {
    return this.max;
  }, _refreshRange: function(t2) {
    "vertical" === t2 && this.range.css({ width: "", left: "" }), "horizontal" === t2 && this.range.css({ height: "", bottom: "" });
  }, _refreshValue: function() {
    var e2, i2, s2, n2, o2, a2 = this.options.range, r2 = this.options, h2 = this, l2 = this._animateOff ? false : r2.animate, c2 = {};
    this._hasMultipleValues() ? this.handles.each(function(s3) {
      i2 = 100 * ((h2.values(s3) - h2._valueMin()) / (h2._valueMax() - h2._valueMin())), c2["horizontal" === h2.orientation ? "left" : "bottom"] = i2 + "%", t(this).stop(1, 1)[l2 ? "animate" : "css"](c2, r2.animate), h2.options.range === true && ("horizontal" === h2.orientation ? (0 === s3 && h2.range.stop(1, 1)[l2 ? "animate" : "css"]({ left: i2 + "%" }, r2.animate), 1 === s3 && h2.range[l2 ? "animate" : "css"]({ width: i2 - e2 + "%" }, { queue: false, duration: r2.animate })) : (0 === s3 && h2.range.stop(1, 1)[l2 ? "animate" : "css"]({ bottom: i2 + "%" }, r2.animate), 1 === s3 && h2.range[l2 ? "animate" : "css"]({ height: i2 - e2 + "%" }, { queue: false, duration: r2.animate }))), e2 = i2;
    }) : (s2 = this.value(), n2 = this._valueMin(), o2 = this._valueMax(), i2 = o2 !== n2 ? 100 * ((s2 - n2) / (o2 - n2)) : 0, c2["horizontal" === this.orientation ? "left" : "bottom"] = i2 + "%", this.handle.stop(1, 1)[l2 ? "animate" : "css"](c2, r2.animate), "min" === a2 && "horizontal" === this.orientation && this.range.stop(1, 1)[l2 ? "animate" : "css"]({ width: i2 + "%" }, r2.animate), "max" === a2 && "horizontal" === this.orientation && this.range.stop(1, 1)[l2 ? "animate" : "css"]({ width: 100 - i2 + "%" }, r2.animate), "min" === a2 && "vertical" === this.orientation && this.range.stop(1, 1)[l2 ? "animate" : "css"]({ height: i2 + "%" }, r2.animate), "max" === a2 && "vertical" === this.orientation && this.range.stop(1, 1)[l2 ? "animate" : "css"]({ height: 100 - i2 + "%" }, r2.animate));
  }, _handleEvents: { keydown: function(e2) {
    var i2, s2, n2, o2, a2 = t(e2.target).data("ui-slider-handle-index");
    switch (e2.keyCode) {
      case t.ui.keyCode.HOME:
      case t.ui.keyCode.END:
      case t.ui.keyCode.PAGE_UP:
      case t.ui.keyCode.PAGE_DOWN:
      case t.ui.keyCode.UP:
      case t.ui.keyCode.RIGHT:
      case t.ui.keyCode.DOWN:
      case t.ui.keyCode.LEFT:
        if (e2.preventDefault(), !this._keySliding && (this._keySliding = true, this._addClass(t(e2.target), null, "ui-state-active"), i2 = this._start(e2, a2), i2 === false))
          return;
    }
    switch (o2 = this.options.step, s2 = n2 = this._hasMultipleValues() ? this.values(a2) : this.value(), e2.keyCode) {
      case t.ui.keyCode.HOME:
        n2 = this._valueMin();
        break;
      case t.ui.keyCode.END:
        n2 = this._valueMax();
        break;
      case t.ui.keyCode.PAGE_UP:
        n2 = this._trimAlignValue(s2 + (this._valueMax() - this._valueMin()) / this.numPages);
        break;
      case t.ui.keyCode.PAGE_DOWN:
        n2 = this._trimAlignValue(s2 - (this._valueMax() - this._valueMin()) / this.numPages);
        break;
      case t.ui.keyCode.UP:
      case t.ui.keyCode.RIGHT:
        if (s2 === this._valueMax())
          return;
        n2 = this._trimAlignValue(s2 + o2);
        break;
      case t.ui.keyCode.DOWN:
      case t.ui.keyCode.LEFT:
        if (s2 === this._valueMin())
          return;
        n2 = this._trimAlignValue(s2 - o2);
    }
    this._slide(e2, a2, n2);
  }, keyup: function(e2) {
    var i2 = t(e2.target).data("ui-slider-handle-index");
    this._keySliding && (this._keySliding = false, this._stop(e2, i2), this._change(e2, i2), this._removeClass(t(e2.target), null, "ui-state-active"));
  } } }), t.widget("ui.sortable", t.ui.mouse, { version: "1.12.1", widgetEventPrefix: "sort", ready: false, options: { appendTo: "parent", axis: false, connectWith: false, containment: false, cursor: "auto", cursorAt: false, dropOnEmpty: true, forcePlaceholderSize: false, forceHelperSize: false, grid: false, handle: false, helper: "original", items: "> *", opacity: false, placeholder: false, revert: false, scroll: true, scrollSensitivity: 20, scrollSpeed: 20, scope: "default", tolerance: "intersect", zIndex: 1e3, activate: null, beforeStop: null, change: null, deactivate: null, out: null, over: null, receive: null, remove: null, sort: null, start: null, stop: null, update: null }, _isOverAxis: function(t2, e2, i2) {
    return t2 >= e2 && e2 + i2 > t2;
  }, _isFloating: function(t2) {
    return /left|right/.test(t2.css("float")) || /inline|table-cell/.test(t2.css("display"));
  }, _create: function() {
    this.containerCache = {}, this._addClass("ui-sortable"), this.refresh(), this.offset = this.element.offset(), this._mouseInit(), this._setHandleClassName(), this.ready = true;
  }, _setOption: function(t2, e2) {
    this._super(t2, e2), "handle" === t2 && this._setHandleClassName();
  }, _setHandleClassName: function() {
    var e2 = this;
    this._removeClass(this.element.find(".ui-sortable-handle"), "ui-sortable-handle"), t.each(this.items, function() {
      e2._addClass(this.instance.options.handle ? this.item.find(this.instance.options.handle) : this.item, "ui-sortable-handle");
    });
  }, _destroy: function() {
    this._mouseDestroy();
    for (var t2 = this.items.length - 1; t2 >= 0; t2--)
      this.items[t2].item.removeData(this.widgetName + "-item");
    return this;
  }, _mouseCapture: function(e2, i2) {
    var s2 = null, n2 = false, o2 = this;
    return this.reverting ? false : this.options.disabled || "static" === this.options.type ? false : (this._refreshItems(e2), t(e2.target).parents().each(function() {
      return t.data(this, o2.widgetName + "-item") === o2 ? (s2 = t(this), false) : void 0;
    }), t.data(e2.target, o2.widgetName + "-item") === o2 && (s2 = t(e2.target)), s2 ? !this.options.handle || i2 || (t(this.options.handle, s2).find("*").addBack().each(function() {
      this === e2.target && (n2 = true);
    }), n2) ? (this.currentItem = s2, this._removeCurrentsFromItems(), true) : false : false);
  }, _mouseStart: function(e2, i2, s2) {
    var n2, o2, a2 = this.options;
    if (this.currentContainer = this, this.refreshPositions(), this.helper = this._createHelper(e2), this._cacheHelperProportions(), this._cacheMargins(), this.scrollParent = this.helper.scrollParent(), this.offset = this.currentItem.offset(), this.offset = { top: this.offset.top - this.margins.top, left: this.offset.left - this.margins.left }, t.extend(this.offset, { click: { left: e2.pageX - this.offset.left, top: e2.pageY - this.offset.top }, parent: this._getParentOffset(), relative: this._getRelativeOffset() }), this.helper.css("position", "absolute"), this.cssPosition = this.helper.css("position"), this.originalPosition = this._generatePosition(e2), this.originalPageX = e2.pageX, this.originalPageY = e2.pageY, a2.cursorAt && this._adjustOffsetFromHelper(a2.cursorAt), this.domPosition = { prev: this.currentItem.prev()[0], parent: this.currentItem.parent()[0] }, this.helper[0] !== this.currentItem[0] && this.currentItem.hide(), this._createPlaceholder(), a2.containment && this._setContainment(), a2.cursor && "auto" !== a2.cursor && (o2 = this.document.find("body"), this.storedCursor = o2.css("cursor"), o2.css("cursor", a2.cursor), this.storedStylesheet = t("<style>*{ cursor: " + a2.cursor + " !important; }</style>").appendTo(o2)), a2.opacity && (this.helper.css("opacity") && (this._storedOpacity = this.helper.css("opacity")), this.helper.css("opacity", a2.opacity)), a2.zIndex && (this.helper.css("zIndex") && (this._storedZIndex = this.helper.css("zIndex")), this.helper.css("zIndex", a2.zIndex)), this.scrollParent[0] !== this.document[0] && "HTML" !== this.scrollParent[0].tagName && (this.overflowOffset = this.scrollParent.offset()), this._trigger("start", e2, this._uiHash()), this._preserveHelperProportions || this._cacheHelperProportions(), !s2)
      for (n2 = this.containers.length - 1; n2 >= 0; n2--)
        this.containers[n2]._trigger("activate", e2, this._uiHash(this));
    return t.ui.ddmanager && (t.ui.ddmanager.current = this), t.ui.ddmanager && !a2.dropBehaviour && t.ui.ddmanager.prepareOffsets(this, e2), this.dragging = true, this._addClass(this.helper, "ui-sortable-helper"), this._mouseDrag(e2), true;
  }, _mouseDrag: function(e2) {
    var i2, s2, n2, o2, a2 = this.options, r2 = false;
    for (this.position = this._generatePosition(e2), this.positionAbs = this._convertPositionTo("absolute"), this.lastPositionAbs || (this.lastPositionAbs = this.positionAbs), this.options.scroll && (this.scrollParent[0] !== this.document[0] && "HTML" !== this.scrollParent[0].tagName ? (this.overflowOffset.top + this.scrollParent[0].offsetHeight - e2.pageY < a2.scrollSensitivity ? this.scrollParent[0].scrollTop = r2 = this.scrollParent[0].scrollTop + a2.scrollSpeed : e2.pageY - this.overflowOffset.top < a2.scrollSensitivity && (this.scrollParent[0].scrollTop = r2 = this.scrollParent[0].scrollTop - a2.scrollSpeed), this.overflowOffset.left + this.scrollParent[0].offsetWidth - e2.pageX < a2.scrollSensitivity ? this.scrollParent[0].scrollLeft = r2 = this.scrollParent[0].scrollLeft + a2.scrollSpeed : e2.pageX - this.overflowOffset.left < a2.scrollSensitivity && (this.scrollParent[0].scrollLeft = r2 = this.scrollParent[0].scrollLeft - a2.scrollSpeed)) : (e2.pageY - this.document.scrollTop() < a2.scrollSensitivity ? r2 = this.document.scrollTop(this.document.scrollTop() - a2.scrollSpeed) : this.window.height() - (e2.pageY - this.document.scrollTop()) < a2.scrollSensitivity && (r2 = this.document.scrollTop(this.document.scrollTop() + a2.scrollSpeed)), e2.pageX - this.document.scrollLeft() < a2.scrollSensitivity ? r2 = this.document.scrollLeft(this.document.scrollLeft() - a2.scrollSpeed) : this.window.width() - (e2.pageX - this.document.scrollLeft()) < a2.scrollSensitivity && (r2 = this.document.scrollLeft(this.document.scrollLeft() + a2.scrollSpeed))), r2 !== false && t.ui.ddmanager && !a2.dropBehaviour && t.ui.ddmanager.prepareOffsets(this, e2)), this.positionAbs = this._convertPositionTo("absolute"), this.options.axis && "y" === this.options.axis || (this.helper[0].style.left = this.position.left + "px"), this.options.axis && "x" === this.options.axis || (this.helper[0].style.top = this.position.top + "px"), i2 = this.items.length - 1; i2 >= 0; i2--)
      if (s2 = this.items[i2], n2 = s2.item[0], o2 = this._intersectsWithPointer(s2), o2 && s2.instance === this.currentContainer && n2 !== this.currentItem[0] && this.placeholder[1 === o2 ? "next" : "prev"]()[0] !== n2 && !t.contains(this.placeholder[0], n2) && ("semi-dynamic" === this.options.type ? !t.contains(this.element[0], n2) : true)) {
        if (this.direction = 1 === o2 ? "down" : "up", "pointer" !== this.options.tolerance && !this._intersectsWithSides(s2))
          break;
        this._rearrange(e2, s2), this._trigger("change", e2, this._uiHash());
        break;
      }
    return this._contactContainers(e2), t.ui.ddmanager && t.ui.ddmanager.drag(this, e2), this._trigger("sort", e2, this._uiHash()), this.lastPositionAbs = this.positionAbs, false;
  }, _mouseStop: function(e2, i2) {
    if (e2) {
      if (t.ui.ddmanager && !this.options.dropBehaviour && t.ui.ddmanager.drop(this, e2), this.options.revert) {
        var s2 = this, n2 = this.placeholder.offset(), o2 = this.options.axis, a2 = {};
        o2 && "x" !== o2 || (a2.left = n2.left - this.offset.parent.left - this.margins.left + (this.offsetParent[0] === this.document[0].body ? 0 : this.offsetParent[0].scrollLeft)), o2 && "y" !== o2 || (a2.top = n2.top - this.offset.parent.top - this.margins.top + (this.offsetParent[0] === this.document[0].body ? 0 : this.offsetParent[0].scrollTop)), this.reverting = true, t(this.helper).animate(a2, parseInt(this.options.revert, 10) || 500, function() {
          s2._clear(e2);
        });
      } else
        this._clear(e2, i2);
      return false;
    }
  }, cancel: function() {
    if (this.dragging) {
      this._mouseUp(new t.Event("mouseup", { target: null })), "original" === this.options.helper ? (this.currentItem.css(this._storedCSS), this._removeClass(this.currentItem, "ui-sortable-helper")) : this.currentItem.show();
      for (var e2 = this.containers.length - 1; e2 >= 0; e2--)
        this.containers[e2]._trigger("deactivate", null, this._uiHash(this)), this.containers[e2].containerCache.over && (this.containers[e2]._trigger("out", null, this._uiHash(this)), this.containers[e2].containerCache.over = 0);
    }
    return this.placeholder && (this.placeholder[0].parentNode && this.placeholder[0].parentNode.removeChild(this.placeholder[0]), "original" !== this.options.helper && this.helper && this.helper[0].parentNode && this.helper.remove(), t.extend(this, { helper: null, dragging: false, reverting: false, _noFinalSort: null }), this.domPosition.prev ? t(this.domPosition.prev).after(this.currentItem) : t(this.domPosition.parent).prepend(this.currentItem)), this;
  }, serialize: function(e2) {
    var i2 = this._getItemsAsjQuery(e2 && e2.connected), s2 = [];
    return e2 = e2 || {}, t(i2).each(function() {
      var i3 = (t(e2.item || this).attr(e2.attribute || "id") || "").match(e2.expression || /(.+)[\-=_](.+)/);
      i3 && s2.push((e2.key || i3[1] + "[]") + "=" + (e2.key && e2.expression ? i3[1] : i3[2]));
    }), !s2.length && e2.key && s2.push(e2.key + "="), s2.join("&");
  }, toArray: function(e2) {
    var i2 = this._getItemsAsjQuery(e2 && e2.connected), s2 = [];
    return e2 = e2 || {}, i2.each(function() {
      s2.push(t(e2.item || this).attr(e2.attribute || "id") || "");
    }), s2;
  }, _intersectsWith: function(t2) {
    var e2 = this.positionAbs.left, i2 = e2 + this.helperProportions.width, s2 = this.positionAbs.top, n2 = s2 + this.helperProportions.height, o2 = t2.left, a2 = o2 + t2.width, r2 = t2.top, h2 = r2 + t2.height, l2 = this.offset.click.top, c2 = this.offset.click.left, u2 = "x" === this.options.axis || s2 + l2 > r2 && h2 > s2 + l2, d2 = "y" === this.options.axis || e2 + c2 > o2 && a2 > e2 + c2, p2 = u2 && d2;
    return "pointer" === this.options.tolerance || this.options.forcePointerForContainers || "pointer" !== this.options.tolerance && this.helperProportions[this.floating ? "width" : "height"] > t2[this.floating ? "width" : "height"] ? p2 : e2 + this.helperProportions.width / 2 > o2 && a2 > i2 - this.helperProportions.width / 2 && s2 + this.helperProportions.height / 2 > r2 && h2 > n2 - this.helperProportions.height / 2;
  }, _intersectsWithPointer: function(t2) {
    var e2, i2, s2 = "x" === this.options.axis || this._isOverAxis(this.positionAbs.top + this.offset.click.top, t2.top, t2.height), n2 = "y" === this.options.axis || this._isOverAxis(this.positionAbs.left + this.offset.click.left, t2.left, t2.width), o2 = s2 && n2;
    return o2 ? (e2 = this._getDragVerticalDirection(), i2 = this._getDragHorizontalDirection(), this.floating ? "right" === i2 || "down" === e2 ? 2 : 1 : e2 && ("down" === e2 ? 2 : 1)) : false;
  }, _intersectsWithSides: function(t2) {
    var e2 = this._isOverAxis(this.positionAbs.top + this.offset.click.top, t2.top + t2.height / 2, t2.height), i2 = this._isOverAxis(this.positionAbs.left + this.offset.click.left, t2.left + t2.width / 2, t2.width), s2 = this._getDragVerticalDirection(), n2 = this._getDragHorizontalDirection();
    return this.floating && n2 ? "right" === n2 && i2 || "left" === n2 && !i2 : s2 && ("down" === s2 && e2 || "up" === s2 && !e2);
  }, _getDragVerticalDirection: function() {
    var t2 = this.positionAbs.top - this.lastPositionAbs.top;
    return 0 !== t2 && (t2 > 0 ? "down" : "up");
  }, _getDragHorizontalDirection: function() {
    var t2 = this.positionAbs.left - this.lastPositionAbs.left;
    return 0 !== t2 && (t2 > 0 ? "right" : "left");
  }, refresh: function(t2) {
    return this._refreshItems(t2), this._setHandleClassName(), this.refreshPositions(), this;
  }, _connectWith: function() {
    var t2 = this.options;
    return t2.connectWith.constructor === String ? [t2.connectWith] : t2.connectWith;
  }, _getItemsAsjQuery: function(e2) {
    function i2() {
      r2.push(this);
    }
    var s2, n2, o2, a2, r2 = [], h2 = [], l2 = this._connectWith();
    if (l2 && e2)
      for (s2 = l2.length - 1; s2 >= 0; s2--)
        for (o2 = t(l2[s2], this.document[0]), n2 = o2.length - 1; n2 >= 0; n2--)
          a2 = t.data(o2[n2], this.widgetFullName), a2 && a2 !== this && !a2.options.disabled && h2.push([t.isFunction(a2.options.items) ? a2.options.items.call(a2.element) : t(a2.options.items, a2.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"), a2]);
    for (h2.push([t.isFunction(this.options.items) ? this.options.items.call(this.element, null, { options: this.options, item: this.currentItem }) : t(this.options.items, this.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"), this]), s2 = h2.length - 1; s2 >= 0; s2--)
      h2[s2][0].each(i2);
    return t(r2);
  }, _removeCurrentsFromItems: function() {
    var e2 = this.currentItem.find(":data(" + this.widgetName + "-item)");
    this.items = t.grep(this.items, function(t2) {
      for (var i2 = 0; e2.length > i2; i2++)
        if (e2[i2] === t2.item[0])
          return false;
      return true;
    });
  }, _refreshItems: function(e2) {
    this.items = [], this.containers = [this];
    var i2, s2, n2, o2, a2, r2, h2, l2, c2 = this.items, u2 = [[t.isFunction(this.options.items) ? this.options.items.call(this.element[0], e2, { item: this.currentItem }) : t(this.options.items, this.element), this]], d2 = this._connectWith();
    if (d2 && this.ready)
      for (i2 = d2.length - 1; i2 >= 0; i2--)
        for (n2 = t(d2[i2], this.document[0]), s2 = n2.length - 1; s2 >= 0; s2--)
          o2 = t.data(n2[s2], this.widgetFullName), o2 && o2 !== this && !o2.options.disabled && (u2.push([t.isFunction(o2.options.items) ? o2.options.items.call(o2.element[0], e2, { item: this.currentItem }) : t(o2.options.items, o2.element), o2]), this.containers.push(o2));
    for (i2 = u2.length - 1; i2 >= 0; i2--)
      for (a2 = u2[i2][1], r2 = u2[i2][0], s2 = 0, l2 = r2.length; l2 > s2; s2++)
        h2 = t(r2[s2]), h2.data(this.widgetName + "-item", a2), c2.push({ item: h2, instance: a2, width: 0, height: 0, left: 0, top: 0 });
  }, refreshPositions: function(e2) {
    this.floating = this.items.length ? "x" === this.options.axis || this._isFloating(this.items[0].item) : false, this.offsetParent && this.helper && (this.offset.parent = this._getParentOffset());
    var i2, s2, n2, o2;
    for (i2 = this.items.length - 1; i2 >= 0; i2--)
      s2 = this.items[i2], s2.instance !== this.currentContainer && this.currentContainer && s2.item[0] !== this.currentItem[0] || (n2 = this.options.toleranceElement ? t(this.options.toleranceElement, s2.item) : s2.item, e2 || (s2.width = n2.outerWidth(), s2.height = n2.outerHeight()), o2 = n2.offset(), s2.left = o2.left, s2.top = o2.top);
    if (this.options.custom && this.options.custom.refreshContainers)
      this.options.custom.refreshContainers.call(this);
    else
      for (i2 = this.containers.length - 1; i2 >= 0; i2--)
        o2 = this.containers[i2].element.offset(), this.containers[i2].containerCache.left = o2.left, this.containers[i2].containerCache.top = o2.top, this.containers[i2].containerCache.width = this.containers[i2].element.outerWidth(), this.containers[i2].containerCache.height = this.containers[i2].element.outerHeight();
    return this;
  }, _createPlaceholder: function(e2) {
    e2 = e2 || this;
    var i2, s2 = e2.options;
    s2.placeholder && s2.placeholder.constructor !== String || (i2 = s2.placeholder, s2.placeholder = { element: function() {
      var s3 = e2.currentItem[0].nodeName.toLowerCase(), n2 = t("<" + s3 + ">", e2.document[0]);
      return e2._addClass(n2, "ui-sortable-placeholder", i2 || e2.currentItem[0].className)._removeClass(n2, "ui-sortable-helper"), "tbody" === s3 ? e2._createTrPlaceholder(e2.currentItem.find("tr").eq(0), t("<tr>", e2.document[0]).appendTo(n2)) : "tr" === s3 ? e2._createTrPlaceholder(e2.currentItem, n2) : "img" === s3 && n2.attr("src", e2.currentItem.attr("src")), i2 || n2.css("visibility", "hidden"), n2;
    }, update: function(t2, n2) {
      (!i2 || s2.forcePlaceholderSize) && (n2.height() || n2.height(e2.currentItem.innerHeight() - parseInt(e2.currentItem.css("paddingTop") || 0, 10) - parseInt(e2.currentItem.css("paddingBottom") || 0, 10)), n2.width() || n2.width(e2.currentItem.innerWidth() - parseInt(e2.currentItem.css("paddingLeft") || 0, 10) - parseInt(e2.currentItem.css("paddingRight") || 0, 10)));
    } }), e2.placeholder = t(s2.placeholder.element.call(e2.element, e2.currentItem)), e2.currentItem.after(e2.placeholder), s2.placeholder.update(e2, e2.placeholder);
  }, _createTrPlaceholder: function(e2, i2) {
    var s2 = this;
    e2.children().each(function() {
      t("<td>&#160;</td>", s2.document[0]).attr("colspan", t(this).attr("colspan") || 1).appendTo(i2);
    });
  }, _contactContainers: function(e2) {
    var i2, s2, n2, o2, a2, r2, h2, l2, c2, u2, d2 = null, p2 = null;
    for (i2 = this.containers.length - 1; i2 >= 0; i2--)
      if (!t.contains(this.currentItem[0], this.containers[i2].element[0]))
        if (this._intersectsWith(this.containers[i2].containerCache)) {
          if (d2 && t.contains(this.containers[i2].element[0], d2.element[0]))
            continue;
          d2 = this.containers[i2], p2 = i2;
        } else
          this.containers[i2].containerCache.over && (this.containers[i2]._trigger("out", e2, this._uiHash(this)), this.containers[i2].containerCache.over = 0);
    if (d2)
      if (1 === this.containers.length)
        this.containers[p2].containerCache.over || (this.containers[p2]._trigger("over", e2, this._uiHash(this)), this.containers[p2].containerCache.over = 1);
      else {
        for (n2 = 1e4, o2 = null, c2 = d2.floating || this._isFloating(this.currentItem), a2 = c2 ? "left" : "top", r2 = c2 ? "width" : "height", u2 = c2 ? "pageX" : "pageY", s2 = this.items.length - 1; s2 >= 0; s2--)
          t.contains(this.containers[p2].element[0], this.items[s2].item[0]) && this.items[s2].item[0] !== this.currentItem[0] && (h2 = this.items[s2].item.offset()[a2], l2 = false, e2[u2] - h2 > this.items[s2][r2] / 2 && (l2 = true), n2 > Math.abs(e2[u2] - h2) && (n2 = Math.abs(e2[u2] - h2), o2 = this.items[s2], this.direction = l2 ? "up" : "down"));
        if (!o2 && !this.options.dropOnEmpty)
          return;
        if (this.currentContainer === this.containers[p2])
          return this.currentContainer.containerCache.over || (this.containers[p2]._trigger("over", e2, this._uiHash()), this.currentContainer.containerCache.over = 1), void 0;
        o2 ? this._rearrange(e2, o2, null, true) : this._rearrange(e2, null, this.containers[p2].element, true), this._trigger("change", e2, this._uiHash()), this.containers[p2]._trigger("change", e2, this._uiHash(this)), this.currentContainer = this.containers[p2], this.options.placeholder.update(this.currentContainer, this.placeholder), this.containers[p2]._trigger("over", e2, this._uiHash(this)), this.containers[p2].containerCache.over = 1;
      }
  }, _createHelper: function(e2) {
    var i2 = this.options, s2 = t.isFunction(i2.helper) ? t(i2.helper.apply(this.element[0], [e2, this.currentItem])) : "clone" === i2.helper ? this.currentItem.clone() : this.currentItem;
    return s2.parents("body").length || t("parent" !== i2.appendTo ? i2.appendTo : this.currentItem[0].parentNode)[0].appendChild(s2[0]), s2[0] === this.currentItem[0] && (this._storedCSS = { width: this.currentItem[0].style.width, height: this.currentItem[0].style.height, position: this.currentItem.css("position"), top: this.currentItem.css("top"), left: this.currentItem.css("left") }), (!s2[0].style.width || i2.forceHelperSize) && s2.width(this.currentItem.width()), (!s2[0].style.height || i2.forceHelperSize) && s2.height(this.currentItem.height()), s2;
  }, _adjustOffsetFromHelper: function(e2) {
    "string" == typeof e2 && (e2 = e2.split(" ")), t.isArray(e2) && (e2 = { left: +e2[0], top: +e2[1] || 0 }), "left" in e2 && (this.offset.click.left = e2.left + this.margins.left), "right" in e2 && (this.offset.click.left = this.helperProportions.width - e2.right + this.margins.left), "top" in e2 && (this.offset.click.top = e2.top + this.margins.top), "bottom" in e2 && (this.offset.click.top = this.helperProportions.height - e2.bottom + this.margins.top);
  }, _getParentOffset: function() {
    this.offsetParent = this.helper.offsetParent();
    var e2 = this.offsetParent.offset();
    return "absolute" === this.cssPosition && this.scrollParent[0] !== this.document[0] && t.contains(this.scrollParent[0], this.offsetParent[0]) && (e2.left += this.scrollParent.scrollLeft(), e2.top += this.scrollParent.scrollTop()), (this.offsetParent[0] === this.document[0].body || this.offsetParent[0].tagName && "html" === this.offsetParent[0].tagName.toLowerCase() && t.ui.ie) && (e2 = { top: 0, left: 0 }), { top: e2.top + (parseInt(this.offsetParent.css("borderTopWidth"), 10) || 0), left: e2.left + (parseInt(this.offsetParent.css("borderLeftWidth"), 10) || 0) };
  }, _getRelativeOffset: function() {
    if ("relative" === this.cssPosition) {
      var t2 = this.currentItem.position();
      return { top: t2.top - (parseInt(this.helper.css("top"), 10) || 0) + this.scrollParent.scrollTop(), left: t2.left - (parseInt(this.helper.css("left"), 10) || 0) + this.scrollParent.scrollLeft() };
    }
    return { top: 0, left: 0 };
  }, _cacheMargins: function() {
    this.margins = { left: parseInt(this.currentItem.css("marginLeft"), 10) || 0, top: parseInt(this.currentItem.css("marginTop"), 10) || 0 };
  }, _cacheHelperProportions: function() {
    this.helperProportions = { width: this.helper.outerWidth(), height: this.helper.outerHeight() };
  }, _setContainment: function() {
    var e2, i2, s2, n2 = this.options;
    "parent" === n2.containment && (n2.containment = this.helper[0].parentNode), ("document" === n2.containment || "window" === n2.containment) && (this.containment = [0 - this.offset.relative.left - this.offset.parent.left, 0 - this.offset.relative.top - this.offset.parent.top, "document" === n2.containment ? this.document.width() : this.window.width() - this.helperProportions.width - this.margins.left, ("document" === n2.containment ? this.document.height() || document.body.parentNode.scrollHeight : this.window.height() || this.document[0].body.parentNode.scrollHeight) - this.helperProportions.height - this.margins.top]), /^(document|window|parent)$/.test(n2.containment) || (e2 = t(n2.containment)[0], i2 = t(n2.containment).offset(), s2 = "hidden" !== t(e2).css("overflow"), this.containment = [i2.left + (parseInt(t(e2).css("borderLeftWidth"), 10) || 0) + (parseInt(t(e2).css("paddingLeft"), 10) || 0) - this.margins.left, i2.top + (parseInt(t(e2).css("borderTopWidth"), 10) || 0) + (parseInt(t(e2).css("paddingTop"), 10) || 0) - this.margins.top, i2.left + (s2 ? Math.max(e2.scrollWidth, e2.offsetWidth) : e2.offsetWidth) - (parseInt(t(e2).css("borderLeftWidth"), 10) || 0) - (parseInt(t(e2).css("paddingRight"), 10) || 0) - this.helperProportions.width - this.margins.left, i2.top + (s2 ? Math.max(e2.scrollHeight, e2.offsetHeight) : e2.offsetHeight) - (parseInt(t(e2).css("borderTopWidth"), 10) || 0) - (parseInt(t(e2).css("paddingBottom"), 10) || 0) - this.helperProportions.height - this.margins.top]);
  }, _convertPositionTo: function(e2, i2) {
    i2 || (i2 = this.position);
    var s2 = "absolute" === e2 ? 1 : -1, n2 = "absolute" !== this.cssPosition || this.scrollParent[0] !== this.document[0] && t.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent, o2 = /(html|body)/i.test(n2[0].tagName);
    return { top: i2.top + this.offset.relative.top * s2 + this.offset.parent.top * s2 - ("fixed" === this.cssPosition ? -this.scrollParent.scrollTop() : o2 ? 0 : n2.scrollTop()) * s2, left: i2.left + this.offset.relative.left * s2 + this.offset.parent.left * s2 - ("fixed" === this.cssPosition ? -this.scrollParent.scrollLeft() : o2 ? 0 : n2.scrollLeft()) * s2 };
  }, _generatePosition: function(e2) {
    var i2, s2, n2 = this.options, o2 = e2.pageX, a2 = e2.pageY, r2 = "absolute" !== this.cssPosition || this.scrollParent[0] !== this.document[0] && t.contains(this.scrollParent[0], this.offsetParent[0]) ? this.scrollParent : this.offsetParent, h2 = /(html|body)/i.test(r2[0].tagName);
    return "relative" !== this.cssPosition || this.scrollParent[0] !== this.document[0] && this.scrollParent[0] !== this.offsetParent[0] || (this.offset.relative = this._getRelativeOffset()), this.originalPosition && (this.containment && (e2.pageX - this.offset.click.left < this.containment[0] && (o2 = this.containment[0] + this.offset.click.left), e2.pageY - this.offset.click.top < this.containment[1] && (a2 = this.containment[1] + this.offset.click.top), e2.pageX - this.offset.click.left > this.containment[2] && (o2 = this.containment[2] + this.offset.click.left), e2.pageY - this.offset.click.top > this.containment[3] && (a2 = this.containment[3] + this.offset.click.top)), n2.grid && (i2 = this.originalPageY + Math.round((a2 - this.originalPageY) / n2.grid[1]) * n2.grid[1], a2 = this.containment ? i2 - this.offset.click.top >= this.containment[1] && i2 - this.offset.click.top <= this.containment[3] ? i2 : i2 - this.offset.click.top >= this.containment[1] ? i2 - n2.grid[1] : i2 + n2.grid[1] : i2, s2 = this.originalPageX + Math.round((o2 - this.originalPageX) / n2.grid[0]) * n2.grid[0], o2 = this.containment ? s2 - this.offset.click.left >= this.containment[0] && s2 - this.offset.click.left <= this.containment[2] ? s2 : s2 - this.offset.click.left >= this.containment[0] ? s2 - n2.grid[0] : s2 + n2.grid[0] : s2)), { top: a2 - this.offset.click.top - this.offset.relative.top - this.offset.parent.top + ("fixed" === this.cssPosition ? -this.scrollParent.scrollTop() : h2 ? 0 : r2.scrollTop()), left: o2 - this.offset.click.left - this.offset.relative.left - this.offset.parent.left + ("fixed" === this.cssPosition ? -this.scrollParent.scrollLeft() : h2 ? 0 : r2.scrollLeft()) };
  }, _rearrange: function(t2, e2, i2, s2) {
    i2 ? i2[0].appendChild(this.placeholder[0]) : e2.item[0].parentNode.insertBefore(this.placeholder[0], "down" === this.direction ? e2.item[0] : e2.item[0].nextSibling), this.counter = this.counter ? ++this.counter : 1;
    var n2 = this.counter;
    this._delay(function() {
      n2 === this.counter && this.refreshPositions(!s2);
    });
  }, _clear: function(t2, e2) {
    function i2(t3, e3, i3) {
      return function(s3) {
        i3._trigger(t3, s3, e3._uiHash(e3));
      };
    }
    this.reverting = false;
    var s2, n2 = [];
    if (!this._noFinalSort && this.currentItem.parent().length && this.placeholder.before(this.currentItem), this._noFinalSort = null, this.helper[0] === this.currentItem[0]) {
      for (s2 in this._storedCSS)
        ("auto" === this._storedCSS[s2] || "static" === this._storedCSS[s2]) && (this._storedCSS[s2] = "");
      this.currentItem.css(this._storedCSS), this._removeClass(this.currentItem, "ui-sortable-helper");
    } else
      this.currentItem.show();
    for (this.fromOutside && !e2 && n2.push(function(t3) {
      this._trigger("receive", t3, this._uiHash(this.fromOutside));
    }), !this.fromOutside && this.domPosition.prev === this.currentItem.prev().not(".ui-sortable-helper")[0] && this.domPosition.parent === this.currentItem.parent()[0] || e2 || n2.push(function(t3) {
      this._trigger("update", t3, this._uiHash());
    }), this !== this.currentContainer && (e2 || (n2.push(function(t3) {
      this._trigger("remove", t3, this._uiHash());
    }), n2.push((function(t3) {
      return function(e3) {
        t3._trigger("receive", e3, this._uiHash(this));
      };
    }).call(this, this.currentContainer)), n2.push((function(t3) {
      return function(e3) {
        t3._trigger("update", e3, this._uiHash(this));
      };
    }).call(this, this.currentContainer)))), s2 = this.containers.length - 1; s2 >= 0; s2--)
      e2 || n2.push(i2("deactivate", this, this.containers[s2])), this.containers[s2].containerCache.over && (n2.push(i2("out", this, this.containers[s2])), this.containers[s2].containerCache.over = 0);
    if (this.storedCursor && (this.document.find("body").css("cursor", this.storedCursor), this.storedStylesheet.remove()), this._storedOpacity && this.helper.css("opacity", this._storedOpacity), this._storedZIndex && this.helper.css("zIndex", "auto" === this._storedZIndex ? "" : this._storedZIndex), this.dragging = false, e2 || this._trigger("beforeStop", t2, this._uiHash()), this.placeholder[0].parentNode.removeChild(this.placeholder[0]), this.cancelHelperRemoval || (this.helper[0] !== this.currentItem[0] && this.helper.remove(), this.helper = null), !e2) {
      for (s2 = 0; n2.length > s2; s2++)
        n2[s2].call(this, t2);
      this._trigger("stop", t2, this._uiHash());
    }
    return this.fromOutside = false, !this.cancelHelperRemoval;
  }, _trigger: function() {
    t.Widget.prototype._trigger.apply(this, arguments) === false && this.cancel();
  }, _uiHash: function(e2) {
    var i2 = e2 || this;
    return { helper: i2.helper, placeholder: i2.placeholder || t([]), position: i2.position, originalPosition: i2.originalPosition, offset: i2.positionAbs, item: i2.currentItem, sender: e2 ? e2.element : null };
  } }), t.widget("ui.spinner", { version: "1.12.1", defaultElement: "<input>", widgetEventPrefix: "spin", options: { classes: { "ui-spinner": "ui-corner-all", "ui-spinner-down": "ui-corner-br", "ui-spinner-up": "ui-corner-tr" }, culture: null, icons: { down: "ui-icon-triangle-1-s", up: "ui-icon-triangle-1-n" }, incremental: true, max: null, min: null, numberFormat: null, page: 10, step: 1, change: null, spin: null, start: null, stop: null }, _create: function() {
    this._setOption("max", this.options.max), this._setOption("min", this.options.min), this._setOption("step", this.options.step), "" !== this.value() && this._value(this.element.val(), true), this._draw(), this._on(this._events), this._refresh(), this._on(this.window, { beforeunload: function() {
      this.element.removeAttr("autocomplete");
    } });
  }, _getCreateOptions: function() {
    var e2 = this._super(), i2 = this.element;
    return t.each(["min", "max", "step"], function(t2, s2) {
      var n2 = i2.attr(s2);
      null != n2 && n2.length && (e2[s2] = n2);
    }), e2;
  }, _events: { keydown: function(t2) {
    this._start(t2) && this._keydown(t2) && t2.preventDefault();
  }, keyup: "_stop", focus: function() {
    this.previous = this.element.val();
  }, blur: function(t2) {
    return this.cancelBlur ? (delete this.cancelBlur, void 0) : (this._stop(), this._refresh(), this.previous !== this.element.val() && this._trigger("change", t2), void 0);
  }, mousewheel: function(t2, e2) {
    if (e2) {
      if (!this.spinning && !this._start(t2))
        return false;
      this._spin((e2 > 0 ? 1 : -1) * this.options.step, t2), clearTimeout(this.mousewheelTimer), this.mousewheelTimer = this._delay(function() {
        this.spinning && this._stop(t2);
      }, 100), t2.preventDefault();
    }
  }, "mousedown .ui-spinner-button": function(e2) {
    function i2() {
      var e3 = this.element[0] === t.ui.safeActiveElement(this.document[0]);
      e3 || (this.element.trigger("focus"), this.previous = s2, this._delay(function() {
        this.previous = s2;
      }));
    }
    var s2;
    s2 = this.element[0] === t.ui.safeActiveElement(this.document[0]) ? this.previous : this.element.val(), e2.preventDefault(), i2.call(this), this.cancelBlur = true, this._delay(function() {
      delete this.cancelBlur, i2.call(this);
    }), this._start(e2) !== false && this._repeat(null, t(e2.currentTarget).hasClass("ui-spinner-up") ? 1 : -1, e2);
  }, "mouseup .ui-spinner-button": "_stop", "mouseenter .ui-spinner-button": function(e2) {
    return t(e2.currentTarget).hasClass("ui-state-active") ? this._start(e2) === false ? false : (this._repeat(null, t(e2.currentTarget).hasClass("ui-spinner-up") ? 1 : -1, e2), void 0) : void 0;
  }, "mouseleave .ui-spinner-button": "_stop" }, _enhance: function() {
    this.uiSpinner = this.element.attr("autocomplete", "off").wrap("<span>").parent().append("<a></a><a></a>");
  }, _draw: function() {
    this._enhance(), this._addClass(this.uiSpinner, "ui-spinner", "ui-widget ui-widget-content"), this._addClass("ui-spinner-input"), this.element.attr("role", "spinbutton"), this.buttons = this.uiSpinner.children("a").attr("tabIndex", -1).attr("aria-hidden", true).button({ classes: { "ui-button": "" } }), this._removeClass(this.buttons, "ui-corner-all"), this._addClass(this.buttons.first(), "ui-spinner-button ui-spinner-up"), this._addClass(this.buttons.last(), "ui-spinner-button ui-spinner-down"), this.buttons.first().button({ icon: this.options.icons.up, showLabel: false }), this.buttons.last().button({ icon: this.options.icons.down, showLabel: false }), this.buttons.height() > Math.ceil(0.5 * this.uiSpinner.height()) && this.uiSpinner.height() > 0 && this.uiSpinner.height(this.uiSpinner.height());
  }, _keydown: function(e2) {
    var i2 = this.options, s2 = t.ui.keyCode;
    switch (e2.keyCode) {
      case s2.UP:
        return this._repeat(null, 1, e2), true;
      case s2.DOWN:
        return this._repeat(null, -1, e2), true;
      case s2.PAGE_UP:
        return this._repeat(null, i2.page, e2), true;
      case s2.PAGE_DOWN:
        return this._repeat(null, -i2.page, e2), true;
    }
    return false;
  }, _start: function(t2) {
    return this.spinning || this._trigger("start", t2) !== false ? (this.counter || (this.counter = 1), this.spinning = true, true) : false;
  }, _repeat: function(t2, e2, i2) {
    t2 = t2 || 500, clearTimeout(this.timer), this.timer = this._delay(function() {
      this._repeat(40, e2, i2);
    }, t2), this._spin(e2 * this.options.step, i2);
  }, _spin: function(t2, e2) {
    var i2 = this.value() || 0;
    this.counter || (this.counter = 1), i2 = this._adjustValue(i2 + t2 * this._increment(this.counter)), this.spinning && this._trigger("spin", e2, { value: i2 }) === false || (this._value(i2), this.counter++);
  }, _increment: function(e2) {
    var i2 = this.options.incremental;
    return i2 ? t.isFunction(i2) ? i2(e2) : Math.floor(e2 * e2 * e2 / 5e4 - e2 * e2 / 500 + 17 * e2 / 200 + 1) : 1;
  }, _precision: function() {
    var t2 = this._precisionOf(this.options.step);
    return null !== this.options.min && (t2 = Math.max(t2, this._precisionOf(this.options.min))), t2;
  }, _precisionOf: function(t2) {
    var e2 = "" + t2, i2 = e2.indexOf(".");
    return -1 === i2 ? 0 : e2.length - i2 - 1;
  }, _adjustValue: function(t2) {
    var e2, i2, s2 = this.options;
    return e2 = null !== s2.min ? s2.min : 0, i2 = t2 - e2, i2 = Math.round(i2 / s2.step) * s2.step, t2 = e2 + i2, t2 = parseFloat(t2.toFixed(this._precision())), null !== s2.max && t2 > s2.max ? s2.max : null !== s2.min && s2.min > t2 ? s2.min : t2;
  }, _stop: function(t2) {
    this.spinning && (clearTimeout(this.timer), clearTimeout(this.mousewheelTimer), this.counter = 0, this.spinning = false, this._trigger("stop", t2));
  }, _setOption: function(t2, e2) {
    var i2, s2, n2;
    return "culture" === t2 || "numberFormat" === t2 ? (i2 = this._parse(this.element.val()), this.options[t2] = e2, this.element.val(this._format(i2)), void 0) : (("max" === t2 || "min" === t2 || "step" === t2) && "string" == typeof e2 && (e2 = this._parse(e2)), "icons" === t2 && (s2 = this.buttons.first().find(".ui-icon"), this._removeClass(s2, null, this.options.icons.up), this._addClass(s2, null, e2.up), n2 = this.buttons.last().find(".ui-icon"), this._removeClass(n2, null, this.options.icons.down), this._addClass(n2, null, e2.down)), this._super(t2, e2), void 0);
  }, _setOptionDisabled: function(t2) {
    this._super(t2), this._toggleClass(this.uiSpinner, null, "ui-state-disabled", !!t2), this.element.prop("disabled", !!t2), this.buttons.button(t2 ? "disable" : "enable");
  }, _setOptions: r(function(t2) {
    this._super(t2);
  }), _parse: function(t2) {
    return "string" == typeof t2 && "" !== t2 && (t2 = window.Globalize && this.options.numberFormat ? Globalize.parseFloat(t2, 10, this.options.culture) : +t2), "" === t2 || isNaN(t2) ? null : t2;
  }, _format: function(t2) {
    return "" === t2 ? "" : window.Globalize && this.options.numberFormat ? Globalize.format(t2, this.options.numberFormat, this.options.culture) : t2;
  }, _refresh: function() {
    this.element.attr({ "aria-valuemin": this.options.min, "aria-valuemax": this.options.max, "aria-valuenow": this._parse(this.element.val()) });
  }, isValid: function() {
    var t2 = this.value();
    return null === t2 ? false : t2 === this._adjustValue(t2);
  }, _value: function(t2, e2) {
    var i2;
    "" !== t2 && (i2 = this._parse(t2), null !== i2 && (e2 || (i2 = this._adjustValue(i2)), t2 = this._format(i2))), this.element.val(t2), this._refresh();
  }, _destroy: function() {
    this.element.prop("disabled", false).removeAttr("autocomplete role aria-valuemin aria-valuemax aria-valuenow"), this.uiSpinner.replaceWith(this.element);
  }, stepUp: r(function(t2) {
    this._stepUp(t2);
  }), _stepUp: function(t2) {
    this._start() && (this._spin((t2 || 1) * this.options.step), this._stop());
  }, stepDown: r(function(t2) {
    this._stepDown(t2);
  }), _stepDown: function(t2) {
    this._start() && (this._spin((t2 || 1) * -this.options.step), this._stop());
  }, pageUp: r(function(t2) {
    this._stepUp((t2 || 1) * this.options.page);
  }), pageDown: r(function(t2) {
    this._stepDown((t2 || 1) * this.options.page);
  }), value: function(t2) {
    return arguments.length ? (r(this._value).call(this, t2), void 0) : this._parse(this.element.val());
  }, widget: function() {
    return this.uiSpinner;
  } }), t.uiBackCompat !== false && t.widget("ui.spinner", t.ui.spinner, { _enhance: function() {
    this.uiSpinner = this.element.attr("autocomplete", "off").wrap(this._uiSpinnerHtml()).parent().append(this._buttonHtml());
  }, _uiSpinnerHtml: function() {
    return "<span>";
  }, _buttonHtml: function() {
    return "<a></a><a></a>";
  } }), t.ui.spinner, t.widget("ui.tabs", { version: "1.12.1", delay: 300, options: { active: null, classes: { "ui-tabs": "ui-corner-all", "ui-tabs-nav": "ui-corner-all", "ui-tabs-panel": "ui-corner-bottom", "ui-tabs-tab": "ui-corner-top" }, collapsible: false, event: "click", heightStyle: "content", hide: null, show: null, activate: null, beforeActivate: null, beforeLoad: null, load: null }, _isLocal: function() {
    var t2 = /#.*$/;
    return function(e2) {
      var i2, s2;
      i2 = e2.href.replace(t2, ""), s2 = location.href.replace(t2, "");
      try {
        i2 = decodeURIComponent(i2);
      } catch (n2) {
      }
      try {
        s2 = decodeURIComponent(s2);
      } catch (n2) {
      }
      return e2.hash.length > 1 && i2 === s2;
    };
  }(), _create: function() {
    var e2 = this, i2 = this.options;
    this.running = false, this._addClass("ui-tabs", "ui-widget ui-widget-content"), this._toggleClass("ui-tabs-collapsible", null, i2.collapsible), this._processTabs(), i2.active = this._initialActive(), t.isArray(i2.disabled) && (i2.disabled = t.unique(i2.disabled.concat(t.map(this.tabs.filter(".ui-state-disabled"), function(t2) {
      return e2.tabs.index(t2);
    }))).sort()), this.active = this.options.active !== false && this.anchors.length ? this._findActive(i2.active) : t(), this._refresh(), this.active.length && this.load(i2.active);
  }, _initialActive: function() {
    var e2 = this.options.active, i2 = this.options.collapsible, s2 = location.hash.substring(1);
    return null === e2 && (s2 && this.tabs.each(function(i3, n2) {
      return t(n2).attr("aria-controls") === s2 ? (e2 = i3, false) : void 0;
    }), null === e2 && (e2 = this.tabs.index(this.tabs.filter(".ui-tabs-active"))), (null === e2 || -1 === e2) && (e2 = this.tabs.length ? 0 : false)), e2 !== false && (e2 = this.tabs.index(this.tabs.eq(e2)), -1 === e2 && (e2 = i2 ? false : 0)), !i2 && e2 === false && this.anchors.length && (e2 = 0), e2;
  }, _getCreateEventData: function() {
    return { tab: this.active, panel: this.active.length ? this._getPanelForTab(this.active) : t() };
  }, _tabKeydown: function(e2) {
    var i2 = t(t.ui.safeActiveElement(this.document[0])).closest("li"), s2 = this.tabs.index(i2), n2 = true;
    if (!this._handlePageNav(e2)) {
      switch (e2.keyCode) {
        case t.ui.keyCode.RIGHT:
        case t.ui.keyCode.DOWN:
          s2++;
          break;
        case t.ui.keyCode.UP:
        case t.ui.keyCode.LEFT:
          n2 = false, s2--;
          break;
        case t.ui.keyCode.END:
          s2 = this.anchors.length - 1;
          break;
        case t.ui.keyCode.HOME:
          s2 = 0;
          break;
        case t.ui.keyCode.SPACE:
          return e2.preventDefault(), clearTimeout(this.activating), this._activate(s2), void 0;
        case t.ui.keyCode.ENTER:
          return e2.preventDefault(), clearTimeout(this.activating), this._activate(s2 === this.options.active ? false : s2), void 0;
        default:
          return;
      }
      e2.preventDefault(), clearTimeout(this.activating), s2 = this._focusNextTab(s2, n2), e2.ctrlKey || e2.metaKey || (i2.attr("aria-selected", "false"), this.tabs.eq(s2).attr("aria-selected", "true"), this.activating = this._delay(function() {
        this.option("active", s2);
      }, this.delay));
    }
  }, _panelKeydown: function(e2) {
    this._handlePageNav(e2) || e2.ctrlKey && e2.keyCode === t.ui.keyCode.UP && (e2.preventDefault(), this.active.trigger("focus"));
  }, _handlePageNav: function(e2) {
    return e2.altKey && e2.keyCode === t.ui.keyCode.PAGE_UP ? (this._activate(this._focusNextTab(this.options.active - 1, false)), true) : e2.altKey && e2.keyCode === t.ui.keyCode.PAGE_DOWN ? (this._activate(this._focusNextTab(this.options.active + 1, true)), true) : void 0;
  }, _findNextTab: function(e2, i2) {
    function s2() {
      return e2 > n2 && (e2 = 0), 0 > e2 && (e2 = n2), e2;
    }
    for (var n2 = this.tabs.length - 1; -1 !== t.inArray(s2(), this.options.disabled); )
      e2 = i2 ? e2 + 1 : e2 - 1;
    return e2;
  }, _focusNextTab: function(t2, e2) {
    return t2 = this._findNextTab(t2, e2), this.tabs.eq(t2).trigger("focus"), t2;
  }, _setOption: function(t2, e2) {
    return "active" === t2 ? (this._activate(e2), void 0) : (this._super(t2, e2), "collapsible" === t2 && (this._toggleClass("ui-tabs-collapsible", null, e2), e2 || this.options.active !== false || this._activate(0)), "event" === t2 && this._setupEvents(e2), "heightStyle" === t2 && this._setupHeightStyle(e2), void 0);
  }, _sanitizeSelector: function(t2) {
    return t2 ? t2.replace(/[!"$%&'()*+,.\/:;<=>?@\[\]\^`{|}~]/g, "\\$&") : "";
  }, refresh: function() {
    var e2 = this.options, i2 = this.tablist.children(":has(a[href])");
    e2.disabled = t.map(i2.filter(".ui-state-disabled"), function(t2) {
      return i2.index(t2);
    }), this._processTabs(), e2.active !== false && this.anchors.length ? this.active.length && !t.contains(this.tablist[0], this.active[0]) ? this.tabs.length === e2.disabled.length ? (e2.active = false, this.active = t()) : this._activate(this._findNextTab(Math.max(0, e2.active - 1), false)) : e2.active = this.tabs.index(this.active) : (e2.active = false, this.active = t()), this._refresh();
  }, _refresh: function() {
    this._setOptionDisabled(this.options.disabled), this._setupEvents(this.options.event), this._setupHeightStyle(this.options.heightStyle), this.tabs.not(this.active).attr({ "aria-selected": "false", "aria-expanded": "false", tabIndex: -1 }), this.panels.not(this._getPanelForTab(this.active)).hide().attr({ "aria-hidden": "true" }), this.active.length ? (this.active.attr({ "aria-selected": "true", "aria-expanded": "true", tabIndex: 0 }), this._addClass(this.active, "ui-tabs-active", "ui-state-active"), this._getPanelForTab(this.active).show().attr({ "aria-hidden": "false" })) : this.tabs.eq(0).attr("tabIndex", 0);
  }, _processTabs: function() {
    var e2 = this, i2 = this.tabs, s2 = this.anchors, n2 = this.panels;
    this.tablist = this._getList().attr("role", "tablist"), this._addClass(this.tablist, "ui-tabs-nav", "ui-helper-reset ui-helper-clearfix ui-widget-header"), this.tablist.on("mousedown" + this.eventNamespace, "> li", function(e3) {
      t(this).is(".ui-state-disabled") && e3.preventDefault();
    }).on("focus" + this.eventNamespace, ".ui-tabs-anchor", function() {
      t(this).closest("li").is(".ui-state-disabled") && this.blur();
    }), this.tabs = this.tablist.find("> li:has(a[href])").attr({ role: "tab", tabIndex: -1 }), this._addClass(this.tabs, "ui-tabs-tab", "ui-state-default"), this.anchors = this.tabs.map(function() {
      return t("a", this)[0];
    }).attr({ role: "presentation", tabIndex: -1 }), this._addClass(this.anchors, "ui-tabs-anchor"), this.panels = t(), this.anchors.each(function(i3, s3) {
      var n3, o2, a2, r2 = t(s3).uniqueId().attr("id"), h2 = t(s3).closest("li"), l2 = h2.attr("aria-controls");
      e2._isLocal(s3) ? (n3 = s3.hash, a2 = n3.substring(1), o2 = e2.element.find(e2._sanitizeSelector(n3))) : (a2 = h2.attr("aria-controls") || t({}).uniqueId()[0].id, n3 = "#" + a2, o2 = e2.element.find(n3), o2.length || (o2 = e2._createPanel(a2), o2.insertAfter(e2.panels[i3 - 1] || e2.tablist)), o2.attr("aria-live", "polite")), o2.length && (e2.panels = e2.panels.add(o2)), l2 && h2.data("ui-tabs-aria-controls", l2), h2.attr({ "aria-controls": a2, "aria-labelledby": r2 }), o2.attr("aria-labelledby", r2);
    }), this.panels.attr("role", "tabpanel"), this._addClass(this.panels, "ui-tabs-panel", "ui-widget-content"), i2 && (this._off(i2.not(this.tabs)), this._off(s2.not(this.anchors)), this._off(n2.not(this.panels)));
  }, _getList: function() {
    return this.tablist || this.element.find("ol, ul").eq(0);
  }, _createPanel: function(e2) {
    return t("<div>").attr("id", e2).data("ui-tabs-destroy", true);
  }, _setOptionDisabled: function(e2) {
    var i2, s2, n2;
    for (t.isArray(e2) && (e2.length ? e2.length === this.anchors.length && (e2 = true) : e2 = false), n2 = 0; s2 = this.tabs[n2]; n2++)
      i2 = t(s2), e2 === true || -1 !== t.inArray(n2, e2) ? (i2.attr("aria-disabled", "true"), this._addClass(i2, null, "ui-state-disabled")) : (i2.removeAttr("aria-disabled"), this._removeClass(i2, null, "ui-state-disabled"));
    this.options.disabled = e2, this._toggleClass(this.widget(), this.widgetFullName + "-disabled", null, e2 === true);
  }, _setupEvents: function(e2) {
    var i2 = {};
    e2 && t.each(e2.split(" "), function(t2, e3) {
      i2[e3] = "_eventHandler";
    }), this._off(this.anchors.add(this.tabs).add(this.panels)), this._on(true, this.anchors, { click: function(t2) {
      t2.preventDefault();
    } }), this._on(this.anchors, i2), this._on(this.tabs, { keydown: "_tabKeydown" }), this._on(this.panels, { keydown: "_panelKeydown" }), this._focusable(this.tabs), this._hoverable(this.tabs);
  }, _setupHeightStyle: function(e2) {
    var i2, s2 = this.element.parent();
    "fill" === e2 ? (i2 = s2.height(), i2 -= this.element.outerHeight() - this.element.height(), this.element.siblings(":visible").each(function() {
      var e3 = t(this), s3 = e3.css("position");
      "absolute" !== s3 && "fixed" !== s3 && (i2 -= e3.outerHeight(true));
    }), this.element.children().not(this.panels).each(function() {
      i2 -= t(this).outerHeight(true);
    }), this.panels.each(function() {
      t(this).height(Math.max(0, i2 - t(this).innerHeight() + t(this).height()));
    }).css("overflow", "auto")) : "auto" === e2 && (i2 = 0, this.panels.each(function() {
      i2 = Math.max(i2, t(this).height("").height());
    }).height(i2));
  }, _eventHandler: function(e2) {
    var i2 = this.options, s2 = this.active, n2 = t(e2.currentTarget), o2 = n2.closest("li"), a2 = o2[0] === s2[0], r2 = a2 && i2.collapsible, h2 = r2 ? t() : this._getPanelForTab(o2), l2 = s2.length ? this._getPanelForTab(s2) : t(), c2 = { oldTab: s2, oldPanel: l2, newTab: r2 ? t() : o2, newPanel: h2 };
    e2.preventDefault(), o2.hasClass("ui-state-disabled") || o2.hasClass("ui-tabs-loading") || this.running || a2 && !i2.collapsible || this._trigger("beforeActivate", e2, c2) === false || (i2.active = r2 ? false : this.tabs.index(o2), this.active = a2 ? t() : o2, this.xhr && this.xhr.abort(), l2.length || h2.length || t.error("jQuery UI Tabs: Mismatching fragment identifier."), h2.length && this.load(this.tabs.index(o2), e2), this._toggle(e2, c2));
  }, _toggle: function(e2, i2) {
    function s2() {
      o2.running = false, o2._trigger("activate", e2, i2);
    }
    function n2() {
      o2._addClass(i2.newTab.closest("li"), "ui-tabs-active", "ui-state-active"), a2.length && o2.options.show ? o2._show(a2, o2.options.show, s2) : (a2.show(), s2());
    }
    var o2 = this, a2 = i2.newPanel, r2 = i2.oldPanel;
    this.running = true, r2.length && this.options.hide ? this._hide(r2, this.options.hide, function() {
      o2._removeClass(i2.oldTab.closest("li"), "ui-tabs-active", "ui-state-active"), n2();
    }) : (this._removeClass(i2.oldTab.closest("li"), "ui-tabs-active", "ui-state-active"), r2.hide(), n2()), r2.attr("aria-hidden", "true"), i2.oldTab.attr({ "aria-selected": "false", "aria-expanded": "false" }), a2.length && r2.length ? i2.oldTab.attr("tabIndex", -1) : a2.length && this.tabs.filter(function() {
      return 0 === t(this).attr("tabIndex");
    }).attr("tabIndex", -1), a2.attr("aria-hidden", "false"), i2.newTab.attr({ "aria-selected": "true", "aria-expanded": "true", tabIndex: 0 });
  }, _activate: function(e2) {
    var i2, s2 = this._findActive(e2);
    s2[0] !== this.active[0] && (s2.length || (s2 = this.active), i2 = s2.find(".ui-tabs-anchor")[0], this._eventHandler({ target: i2, currentTarget: i2, preventDefault: t.noop }));
  }, _findActive: function(e2) {
    return e2 === false ? t() : this.tabs.eq(e2);
  }, _getIndex: function(e2) {
    return "string" == typeof e2 && (e2 = this.anchors.index(this.anchors.filter("[href$='" + t.ui.escapeSelector(e2) + "']"))), e2;
  }, _destroy: function() {
    this.xhr && this.xhr.abort(), this.tablist.removeAttr("role").off(this.eventNamespace), this.anchors.removeAttr("role tabIndex").removeUniqueId(), this.tabs.add(this.panels).each(function() {
      t.data(this, "ui-tabs-destroy") ? t(this).remove() : t(this).removeAttr("role tabIndex aria-live aria-busy aria-selected aria-labelledby aria-hidden aria-expanded");
    }), this.tabs.each(function() {
      var e2 = t(this), i2 = e2.data("ui-tabs-aria-controls");
      i2 ? e2.attr("aria-controls", i2).removeData("ui-tabs-aria-controls") : e2.removeAttr("aria-controls");
    }), this.panels.show(), "content" !== this.options.heightStyle && this.panels.css("height", "");
  }, enable: function(e2) {
    var i2 = this.options.disabled;
    i2 !== false && (void 0 === e2 ? i2 = false : (e2 = this._getIndex(e2), i2 = t.isArray(i2) ? t.map(i2, function(t2) {
      return t2 !== e2 ? t2 : null;
    }) : t.map(this.tabs, function(t2, i3) {
      return i3 !== e2 ? i3 : null;
    })), this._setOptionDisabled(i2));
  }, disable: function(e2) {
    var i2 = this.options.disabled;
    if (i2 !== true) {
      if (void 0 === e2)
        i2 = true;
      else {
        if (e2 = this._getIndex(e2), -1 !== t.inArray(e2, i2))
          return;
        i2 = t.isArray(i2) ? t.merge([e2], i2).sort() : [e2];
      }
      this._setOptionDisabled(i2);
    }
  }, load: function(e2, i2) {
    e2 = this._getIndex(e2);
    var s2 = this, n2 = this.tabs.eq(e2), o2 = n2.find(".ui-tabs-anchor"), a2 = this._getPanelForTab(n2), r2 = { tab: n2, panel: a2 }, h2 = function(t2, e3) {
      "abort" === e3 && s2.panels.stop(false, true), s2._removeClass(n2, "ui-tabs-loading"), a2.removeAttr("aria-busy"), t2 === s2.xhr && delete s2.xhr;
    };
    this._isLocal(o2[0]) || (this.xhr = t.ajax(this._ajaxSettings(o2, i2, r2)), this.xhr && "canceled" !== this.xhr.statusText && (this._addClass(n2, "ui-tabs-loading"), a2.attr("aria-busy", "true"), this.xhr.done(function(t2, e3, n3) {
      setTimeout(function() {
        a2.html(t2), s2._trigger("load", i2, r2), h2(n3, e3);
      }, 1);
    }).fail(function(t2, e3) {
      setTimeout(function() {
        h2(t2, e3);
      }, 1);
    })));
  }, _ajaxSettings: function(e2, i2, s2) {
    var n2 = this;
    return { url: e2.attr("href").replace(/#.*$/, ""), beforeSend: function(e3, o2) {
      return n2._trigger("beforeLoad", i2, t.extend({ jqXHR: e3, ajaxSettings: o2 }, s2));
    } };
  }, _getPanelForTab: function(e2) {
    var i2 = t(e2).attr("aria-controls");
    return this.element.find(this._sanitizeSelector("#" + i2));
  } }), t.uiBackCompat !== false && t.widget("ui.tabs", t.ui.tabs, { _processTabs: function() {
    this._superApply(arguments), this._addClass(this.tabs, "ui-tab");
  } }), t.ui.tabs, t.widget("ui.tooltip", { version: "1.12.1", options: { classes: { "ui-tooltip": "ui-corner-all ui-widget-shadow" }, content: function() {
    var e2 = t(this).attr("title") || "";
    return t("<a>").text(e2).html();
  }, hide: true, items: "[title]:not([disabled])", position: { my: "left top+15", at: "left bottom", collision: "flipfit flip" }, show: true, track: false, close: null, open: null }, _addDescribedBy: function(e2, i2) {
    var s2 = (e2.attr("aria-describedby") || "").split(/\s+/);
    s2.push(i2), e2.data("ui-tooltip-id", i2).attr("aria-describedby", t.trim(s2.join(" ")));
  }, _removeDescribedBy: function(e2) {
    var i2 = e2.data("ui-tooltip-id"), s2 = (e2.attr("aria-describedby") || "").split(/\s+/), n2 = t.inArray(i2, s2);
    -1 !== n2 && s2.splice(n2, 1), e2.removeData("ui-tooltip-id"), s2 = t.trim(s2.join(" ")), s2 ? e2.attr("aria-describedby", s2) : e2.removeAttr("aria-describedby");
  }, _create: function() {
    this._on({ mouseover: "open", focusin: "open" }), this.tooltips = {}, this.parents = {}, this.liveRegion = t("<div>").attr({ role: "log", "aria-live": "assertive", "aria-relevant": "additions" }).appendTo(this.document[0].body), this._addClass(this.liveRegion, null, "ui-helper-hidden-accessible"), this.disabledTitles = t([]);
  }, _setOption: function(e2, i2) {
    var s2 = this;
    this._super(e2, i2), "content" === e2 && t.each(this.tooltips, function(t2, e3) {
      s2._updateContent(e3.element);
    });
  }, _setOptionDisabled: function(t2) {
    this[t2 ? "_disable" : "_enable"]();
  }, _disable: function() {
    var e2 = this;
    t.each(this.tooltips, function(i2, s2) {
      var n2 = t.Event("blur");
      n2.target = n2.currentTarget = s2.element[0], e2.close(n2, true);
    }), this.disabledTitles = this.disabledTitles.add(this.element.find(this.options.items).addBack().filter(function() {
      var e3 = t(this);
      return e3.is("[title]") ? e3.data("ui-tooltip-title", e3.attr("title")).removeAttr("title") : void 0;
    }));
  }, _enable: function() {
    this.disabledTitles.each(function() {
      var e2 = t(this);
      e2.data("ui-tooltip-title") && e2.attr("title", e2.data("ui-tooltip-title"));
    }), this.disabledTitles = t([]);
  }, open: function(e2) {
    var i2 = this, s2 = t(e2 ? e2.target : this.element).closest(this.options.items);
    s2.length && !s2.data("ui-tooltip-id") && (s2.attr("title") && s2.data("ui-tooltip-title", s2.attr("title")), s2.data("ui-tooltip-open", true), e2 && "mouseover" === e2.type && s2.parents().each(function() {
      var e3, s3 = t(this);
      s3.data("ui-tooltip-open") && (e3 = t.Event("blur"), e3.target = e3.currentTarget = this, i2.close(e3, true)), s3.attr("title") && (s3.uniqueId(), i2.parents[this.id] = { element: this, title: s3.attr("title") }, s3.attr("title", ""));
    }), this._registerCloseHandlers(e2, s2), this._updateContent(s2, e2));
  }, _updateContent: function(t2, e2) {
    var i2, s2 = this.options.content, n2 = this, o2 = e2 ? e2.type : null;
    return "string" == typeof s2 || s2.nodeType || s2.jquery ? this._open(e2, t2, s2) : (i2 = s2.call(t2[0], function(i3) {
      n2._delay(function() {
        t2.data("ui-tooltip-open") && (e2 && (e2.type = o2), this._open(e2, t2, i3));
      });
    }), i2 && this._open(e2, t2, i2), void 0);
  }, _open: function(e2, i2, s2) {
    function n2(t2) {
      l2.of = t2, a2.is(":hidden") || a2.position(l2);
    }
    var o2, a2, r2, h2, l2 = t.extend({}, this.options.position);
    if (s2) {
      if (o2 = this._find(i2))
        return o2.tooltip.find(".ui-tooltip-content").html(s2), void 0;
      i2.is("[title]") && (e2 && "mouseover" === e2.type ? i2.attr("title", "") : i2.removeAttr("title")), o2 = this._tooltip(i2), a2 = o2.tooltip, this._addDescribedBy(i2, a2.attr("id")), a2.find(".ui-tooltip-content").html(s2), this.liveRegion.children().hide(), h2 = t("<div>").html(a2.find(".ui-tooltip-content").html()), h2.removeAttr("name").find("[name]").removeAttr("name"), h2.removeAttr("id").find("[id]").removeAttr("id"), h2.appendTo(this.liveRegion), this.options.track && e2 && /^mouse/.test(e2.type) ? (this._on(this.document, { mousemove: n2 }), n2(e2)) : a2.position(t.extend({ of: i2 }, this.options.position)), a2.hide(), this._show(a2, this.options.show), this.options.track && this.options.show && this.options.show.delay && (r2 = this.delayedShow = setInterval(function() {
        a2.is(":visible") && (n2(l2.of), clearInterval(r2));
      }, t.fx.interval)), this._trigger("open", e2, { tooltip: a2 });
    }
  }, _registerCloseHandlers: function(e2, i2) {
    var s2 = { keyup: function(e3) {
      if (e3.keyCode === t.ui.keyCode.ESCAPE) {
        var s3 = t.Event(e3);
        s3.currentTarget = i2[0], this.close(s3, true);
      }
    } };
    i2[0] !== this.element[0] && (s2.remove = function() {
      this._removeTooltip(this._find(i2).tooltip);
    }), e2 && "mouseover" !== e2.type || (s2.mouseleave = "close"), e2 && "focusin" !== e2.type || (s2.focusout = "close"), this._on(true, i2, s2);
  }, close: function(e2) {
    var i2, s2 = this, n2 = t(e2 ? e2.currentTarget : this.element), o2 = this._find(n2);
    return o2 ? (i2 = o2.tooltip, o2.closing || (clearInterval(this.delayedShow), n2.data("ui-tooltip-title") && !n2.attr("title") && n2.attr("title", n2.data("ui-tooltip-title")), this._removeDescribedBy(n2), o2.hiding = true, i2.stop(true), this._hide(i2, this.options.hide, function() {
      s2._removeTooltip(t(this));
    }), n2.removeData("ui-tooltip-open"), this._off(n2, "mouseleave focusout keyup"), n2[0] !== this.element[0] && this._off(n2, "remove"), this._off(this.document, "mousemove"), e2 && "mouseleave" === e2.type && t.each(this.parents, function(e3, i3) {
      t(i3.element).attr("title", i3.title), delete s2.parents[e3];
    }), o2.closing = true, this._trigger("close", e2, { tooltip: i2 }), o2.hiding || (o2.closing = false)), void 0) : (n2.removeData("ui-tooltip-open"), void 0);
  }, _tooltip: function(e2) {
    var i2 = t("<div>").attr("role", "tooltip"), s2 = t("<div>").appendTo(i2), n2 = i2.uniqueId().attr("id");
    return this._addClass(s2, "ui-tooltip-content"), this._addClass(i2, "ui-tooltip", "ui-widget ui-widget-content"), i2.appendTo(this._appendTo(e2)), this.tooltips[n2] = { element: e2, tooltip: i2 };
  }, _find: function(t2) {
    var e2 = t2.data("ui-tooltip-id");
    return e2 ? this.tooltips[e2] : null;
  }, _removeTooltip: function(t2) {
    t2.remove(), delete this.tooltips[t2.attr("id")];
  }, _appendTo: function(t2) {
    var e2 = t2.closest(".ui-front, dialog");
    return e2.length || (e2 = this.document[0].body), e2;
  }, _destroy: function() {
    var e2 = this;
    t.each(this.tooltips, function(i2, s2) {
      var n2 = t.Event("blur"), o2 = s2.element;
      n2.target = n2.currentTarget = o2[0], e2.close(n2, true), t("#" + i2).remove(), o2.data("ui-tooltip-title") && (o2.attr("title") || o2.attr("title", o2.data("ui-tooltip-title")), o2.removeData("ui-tooltip-title"));
    }), this.liveRegion.remove();
  } }), t.uiBackCompat !== false && t.widget("ui.tooltip", t.ui.tooltip, { options: { tooltipClass: null }, _tooltip: function() {
    var t2 = this._superApply(arguments);
    return this.options.tooltipClass && t2.tooltip.addClass(this.options.tooltipClass), t2;
  } }), t.ui.tooltip;
});
(function($, document2, window2) {
  var defaults = {
    label: "MENU",
    duplicate: true,
    duration: 200,
    easingOpen: "swing",
    easingClose: "swing",
    closedSymbol: "&#9658;",
    openedSymbol: "&#9660;",
    prependTo: "body",
    appendTo: "",
    parentTag: "a",
    closeOnClick: false,
    allowParentLinks: false,
    nestedParentLinks: true,
    showChildren: false,
    removeIds: true,
    removeClasses: false,
    removeStyles: false,
    brand: "",
    animations: "jquery",
    init: function() {
    },
    beforeOpen: function() {
    },
    beforeClose: function() {
    },
    afterOpen: function() {
    },
    afterClose: function() {
    }
  }, mobileMenu = "slicknav", prefix = "slicknav", Keyboard = {
    DOWN: 40,
    ENTER: 13,
    ESCAPE: 27,
    LEFT: 37,
    RIGHT: 39,
    SPACE: 32,
    TAB: 9,
    UP: 38
  };
  function Plugin(element, options) {
    this.element = element;
    this.settings = $.extend({}, defaults, options);
    if (!this.settings.duplicate && !options.hasOwnProperty("removeIds")) {
      this.settings.removeIds = false;
    }
    this._defaults = defaults;
    this._name = mobileMenu;
    this.init();
  }
  Plugin.prototype.init = function() {
    var $this = this, menu = $(this.element), settings = this.settings, iconClass, menuBar;
    if (settings.duplicate) {
      $this.mobileNav = menu.clone();
    } else {
      $this.mobileNav = menu;
    }
    if (settings.removeIds) {
      $this.mobileNav.removeAttr("id");
      $this.mobileNav.find("*").each(function(i, e) {
        $(e).removeAttr("id");
      });
    }
    if (settings.removeClasses) {
      $this.mobileNav.removeAttr("class");
      $this.mobileNav.find("*").each(function(i, e) {
        $(e).removeAttr("class");
      });
    }
    if (settings.removeStyles) {
      $this.mobileNav.removeAttr("style");
      $this.mobileNav.find("*").each(function(i, e) {
        $(e).removeAttr("style");
      });
    }
    iconClass = prefix + "_icon";
    if (settings.label === "") {
      iconClass += " " + prefix + "_no-text";
    }
    if (settings.parentTag == "a") {
      settings.parentTag = 'a href="#"';
    }
    $this.mobileNav.attr("class", prefix + "_nav");
    menuBar = $('<div class="' + prefix + '_menu"></div>');
    if (settings.brand !== "") {
      var brand = $('<div class="' + prefix + '_brand">' + settings.brand + "</div>");
      $(menuBar).append(brand);
    }
    $this.btn = $(
      [
        "<" + settings.parentTag + ' aria-haspopup="true" role="button" tabindex="0" class="' + prefix + "_btn " + prefix + '_collapsed">',
        '<span class="' + prefix + '_menutxt">' + settings.label + "</span>",
        '<span class="' + iconClass + '">',
        '<span class="' + prefix + '_icon-bar"></span>',
        '<span class="' + prefix + '_icon-bar"></span>',
        '<span class="' + prefix + '_icon-bar"></span>',
        "</span>",
        "</" + settings.parentTag + ">"
      ].join("")
    );
    $(menuBar).append($this.btn);
    if (settings.appendTo !== "") {
      $(settings.appendTo).append(menuBar);
    } else {
      $(settings.prependTo).prepend(menuBar);
    }
    menuBar.append($this.mobileNav);
    var items = $this.mobileNav.find("li");
    $(items).each(function() {
      var item = $(this), data = {};
      data.children = item.children("ul").attr("role", "menu");
      item.data("menu", data);
      if (data.children.length > 0) {
        var a = item.contents(), containsAnchor = false, nodes = [];
        $(a).each(function() {
          if (!$(this).is("ul")) {
            nodes.push(this);
          } else {
            return false;
          }
          if ($(this).is("a")) {
            containsAnchor = true;
          }
        });
        var wrapElement = $(
          "<" + settings.parentTag + ' role="menuitem" aria-haspopup="true" tabindex="-1" class="' + prefix + '_item"/>'
        );
        if (!settings.allowParentLinks || settings.nestedParentLinks || !containsAnchor) {
          var $wrap = $(nodes).wrapAll(wrapElement).parent();
          $wrap.addClass(prefix + "_row");
        } else
          $(nodes).wrapAll('<span class="' + prefix + "_parent-link " + prefix + '_row"/>').parent();
        if (!settings.showChildren) {
          item.addClass(prefix + "_collapsed");
        } else {
          item.addClass(prefix + "_open");
        }
        item.addClass(prefix + "_parent");
        var arrowElement = $('<span class="' + prefix + '_arrow">' + (settings.showChildren ? settings.openedSymbol : settings.closedSymbol) + "</span>");
        if (settings.allowParentLinks && !settings.nestedParentLinks && containsAnchor)
          arrowElement = arrowElement.wrap(wrapElement).parent();
        $(nodes).last().after(arrowElement);
      } else if (item.children().length === 0) {
        item.addClass(prefix + "_txtnode");
      }
      item.children("a").attr("role", "menuitem").click(function(event2) {
        if (settings.closeOnClick && !$(event2.target).parent().closest("li").hasClass(prefix + "_parent")) {
          $($this.btn).click();
        }
      });
      if (settings.closeOnClick && settings.allowParentLinks) {
        item.children("a").children("a").click(function(event2) {
          $($this.btn).click();
        });
        item.find("." + prefix + "_parent-link a:not(." + prefix + "_item)").click(function(event2) {
          $($this.btn).click();
        });
      }
    });
    $(items).each(function() {
      var data = $(this).data("menu");
      if (!settings.showChildren) {
        $this._visibilityToggle(data.children, null, false, null, true);
      }
    });
    $this._visibilityToggle($this.mobileNav, null, false, "init", true);
    $this.mobileNav.attr("role", "menu");
    $(document2).mousedown(function() {
      $this._outlines(false);
    });
    $(document2).keyup(function() {
      $this._outlines(true);
    });
    $($this.btn).click(function(e) {
      e.preventDefault();
      $this._menuToggle();
    });
    $this.mobileNav.on("click", "." + prefix + "_item", function(e) {
      e.preventDefault();
      $this._itemClick($(this));
    });
    $($this.btn).keydown(function(e) {
      var ev = e || event;
      switch (ev.keyCode) {
        case Keyboard.ENTER:
        case Keyboard.SPACE:
        case Keyboard.DOWN:
          e.preventDefault();
          if (ev.keyCode !== Keyboard.DOWN || !$($this.btn).hasClass(prefix + "_open")) {
            $this._menuToggle();
          }
          $($this.btn).next().find('[role="menuitem"]').first().focus();
          break;
      }
    });
    $this.mobileNav.on("keydown", "." + prefix + "_item", function(e) {
      var ev = e || event;
      switch (ev.keyCode) {
        case Keyboard.ENTER:
          e.preventDefault();
          $this._itemClick($(e.target));
          break;
        case Keyboard.RIGHT:
          e.preventDefault();
          if ($(e.target).parent().hasClass(prefix + "_collapsed")) {
            $this._itemClick($(e.target));
          }
          $(e.target).next().find('[role="menuitem"]').first().focus();
          break;
      }
    });
    $this.mobileNav.on("keydown", '[role="menuitem"]', function(e) {
      var ev = e || event;
      switch (ev.keyCode) {
        case Keyboard.DOWN:
          e.preventDefault();
          var allItems = $(e.target).parent().parent().children().children('[role="menuitem"]:visible');
          var idx = allItems.index(e.target);
          var nextIdx = idx + 1;
          if (allItems.length <= nextIdx) {
            nextIdx = 0;
          }
          var next = allItems.eq(nextIdx);
          next.focus();
          break;
        case Keyboard.UP:
          e.preventDefault();
          var allItems = $(e.target).parent().parent().children().children('[role="menuitem"]:visible');
          var idx = allItems.index(e.target);
          var next = allItems.eq(idx - 1);
          next.focus();
          break;
        case Keyboard.LEFT:
          e.preventDefault();
          if ($(e.target).parent().parent().parent().hasClass(prefix + "_open")) {
            var parent = $(e.target).parent().parent().prev();
            parent.focus();
            $this._itemClick(parent);
          } else if ($(e.target).parent().parent().hasClass(prefix + "_nav")) {
            $this._menuToggle();
            $($this.btn).focus();
          }
          break;
        case Keyboard.ESCAPE:
          e.preventDefault();
          $this._menuToggle();
          $($this.btn).focus();
          break;
      }
    });
    if (settings.allowParentLinks && settings.nestedParentLinks) {
      $("." + prefix + "_item a").click(function(e) {
        e.stopImmediatePropagation();
      });
    }
  };
  Plugin.prototype._menuToggle = function(el) {
    var $this = this;
    var btn = $this.btn;
    var mobileNav = $this.mobileNav;
    if (btn.hasClass(prefix + "_collapsed")) {
      btn.removeClass(prefix + "_collapsed");
      btn.addClass(prefix + "_open");
    } else {
      btn.removeClass(prefix + "_open");
      btn.addClass(prefix + "_collapsed");
    }
    btn.addClass(prefix + "_animating");
    $this._visibilityToggle(mobileNav, btn.parent(), true, btn);
  };
  Plugin.prototype._itemClick = function(el) {
    var $this = this;
    var settings = $this.settings;
    var data = el.data("menu");
    if (!data) {
      data = {};
      data.arrow = el.children("." + prefix + "_arrow");
      data.ul = el.next("ul");
      data.parent = el.parent();
      if (data.parent.hasClass(prefix + "_parent-link")) {
        data.parent = el.parent().parent();
        data.ul = el.parent().next("ul");
      }
      el.data("menu", data);
    }
    if (data.parent.hasClass(prefix + "_collapsed")) {
      data.arrow.html(settings.openedSymbol);
      data.parent.removeClass(prefix + "_collapsed");
      data.parent.addClass(prefix + "_open");
      data.parent.addClass(prefix + "_animating");
      $this._visibilityToggle(data.ul, data.parent, true, el);
    } else {
      data.arrow.html(settings.closedSymbol);
      data.parent.addClass(prefix + "_collapsed");
      data.parent.removeClass(prefix + "_open");
      data.parent.addClass(prefix + "_animating");
      $this._visibilityToggle(data.ul, data.parent, true, el);
    }
  };
  Plugin.prototype._visibilityToggle = function(el, parent, animate, trigger, init) {
    var $this = this;
    var settings = $this.settings;
    var items = $this._getActionItems(el);
    var duration = 0;
    if (animate) {
      duration = settings.duration;
    }
    function afterOpen(trigger2, parent2) {
      $(trigger2).removeClass(prefix + "_animating");
      $(parent2).removeClass(prefix + "_animating");
      if (!init) {
        settings.afterOpen(trigger2);
      }
    }
    function afterClose(trigger2, parent2) {
      el.attr("aria-hidden", "true");
      items.attr("tabindex", "-1");
      $this._setVisAttr(el, true);
      el.hide();
      $(trigger2).removeClass(prefix + "_animating");
      $(parent2).removeClass(prefix + "_animating");
      if (!init) {
        settings.afterClose(trigger2);
      } else if (trigger2 == "init") {
        settings.init();
      }
    }
    if (el.hasClass(prefix + "_hidden")) {
      el.removeClass(prefix + "_hidden");
      if (!init) {
        settings.beforeOpen(trigger);
      }
      if (settings.animations === "jquery") {
        el.stop(true, true).slideDown(duration, settings.easingOpen, function() {
          afterOpen(trigger, parent);
        });
      } else if (settings.animations === "velocity") {
        el.velocity("finish").velocity("slideDown", {
          duration,
          easing: settings.easingOpen,
          complete: function() {
            afterOpen(trigger, parent);
          }
        });
      }
      el.attr("aria-hidden", "false");
      items.attr("tabindex", "0");
      $this._setVisAttr(el, false);
    } else {
      el.addClass(prefix + "_hidden");
      if (!init) {
        settings.beforeClose(trigger);
      }
      if (settings.animations === "jquery") {
        el.stop(true, true).slideUp(duration, this.settings.easingClose, function() {
          afterClose(trigger, parent);
        });
      } else if (settings.animations === "velocity") {
        el.velocity("finish").velocity("slideUp", {
          duration,
          easing: settings.easingClose,
          complete: function() {
            afterClose(trigger, parent);
          }
        });
      }
    }
  };
  Plugin.prototype._setVisAttr = function(el, hidden) {
    var $this = this;
    var nonHidden = el.children("li").children("ul").not("." + prefix + "_hidden");
    if (!hidden) {
      nonHidden.each(function() {
        var ul = $(this);
        ul.attr("aria-hidden", "false");
        var items = $this._getActionItems(ul);
        items.attr("tabindex", "0");
        $this._setVisAttr(ul, hidden);
      });
    } else {
      nonHidden.each(function() {
        var ul = $(this);
        ul.attr("aria-hidden", "true");
        var items = $this._getActionItems(ul);
        items.attr("tabindex", "-1");
        $this._setVisAttr(ul, hidden);
      });
    }
  };
  Plugin.prototype._getActionItems = function(el) {
    var data = el.data("menu");
    if (!data) {
      data = {};
      var items = el.children("li");
      var anchors = items.find("a");
      data.links = anchors.add(items.find("." + prefix + "_item"));
      el.data("menu", data);
    }
    return data.links;
  };
  Plugin.prototype._outlines = function(state) {
    if (!state) {
      $("." + prefix + "_item, ." + prefix + "_btn").css("outline", "none");
    } else {
      $("." + prefix + "_item, ." + prefix + "_btn").css("outline", "");
    }
  };
  Plugin.prototype.toggle = function() {
    var $this = this;
    $this._menuToggle();
  };
  Plugin.prototype.open = function() {
    var $this = this;
    if ($this.btn.hasClass(prefix + "_collapsed")) {
      $this._menuToggle();
    }
  };
  Plugin.prototype.close = function() {
    var $this = this;
    if ($this.btn.hasClass(prefix + "_open")) {
      $this._menuToggle();
    }
  };
  $.fn[mobileMenu] = function(options) {
    var args = arguments;
    if (options === void 0 || typeof options === "object") {
      return this.each(function() {
        if (!$.data(this, "plugin_" + mobileMenu)) {
          $.data(this, "plugin_" + mobileMenu, new Plugin(this, options));
        }
      });
    } else if (typeof options === "string" && options[0] !== "_" && options !== "init") {
      var returns;
      this.each(function() {
        var instance = $.data(this, "plugin_" + mobileMenu);
        if (instance instanceof Plugin && typeof instance[options] === "function") {
          returns = instance[options].apply(instance, Array.prototype.slice.call(args, 1));
        }
      });
      return returns !== void 0 ? returns : this;
    }
  };
})(jQuery, document);
!function(a, b, c, d) {
  function e(b2, c2) {
    this.settings = null, this.options = a.extend({}, e.Defaults, c2), this.$element = a(b2), this._handlers = {}, this._plugins = {}, this._supress = {}, this._current = null, this._speed = null, this._coordinates = [], this._breakpoint = null, this._width = null, this._items = [], this._clones = [], this._mergers = [], this._widths = [], this._invalidated = {}, this._pipe = [], this._drag = { time: null, target: null, pointer: null, stage: { start: null, current: null }, direction: null }, this._states = { current: {}, tags: { initializing: ["busy"], animating: ["busy"], dragging: ["interacting"] } }, a.each(["onResize", "onThrottledResize"], a.proxy(function(b3, c3) {
      this._handlers[c3] = a.proxy(this[c3], this);
    }, this)), a.each(e.Plugins, a.proxy(function(a2, b3) {
      this._plugins[a2.charAt(0).toLowerCase() + a2.slice(1)] = new b3(this);
    }, this)), a.each(e.Workers, a.proxy(function(b3, c3) {
      this._pipe.push({ filter: c3.filter, run: a.proxy(c3.run, this) });
    }, this)), this.setup(), this.initialize();
  }
  e.Defaults = { items: 3, loop: false, center: false, rewind: false, checkVisibility: true, mouseDrag: true, touchDrag: true, pullDrag: true, freeDrag: false, margin: 0, stagePadding: 0, merge: false, mergeFit: true, autoWidth: false, startPosition: 0, rtl: false, smartSpeed: 250, fluidSpeed: false, dragEndSpeed: false, responsive: {}, responsiveRefreshRate: 200, responsiveBaseElement: b, fallbackEasing: "swing", slideTransition: "", info: false, nestedItemSelector: false, itemElement: "div", stageElement: "div", refreshClass: "owl-refresh", loadedClass: "owl-loaded", loadingClass: "owl-loading", rtlClass: "owl-rtl", responsiveClass: "owl-responsive", dragClass: "owl-drag", itemClass: "owl-item", stageClass: "owl-stage", stageOuterClass: "owl-stage-outer", grabClass: "owl-grab" }, e.Width = { Default: "default", Inner: "inner", Outer: "outer" }, e.Type = { Event: "event", State: "state" }, e.Plugins = {}, e.Workers = [{ filter: ["width", "settings"], run: function() {
    this._width = this.$element.width();
  } }, { filter: ["width", "items", "settings"], run: function(a2) {
    a2.current = this._items && this._items[this.relative(this._current)];
  } }, { filter: ["items", "settings"], run: function() {
    this.$stage.children(".cloned").remove();
  } }, { filter: ["width", "items", "settings"], run: function(a2) {
    var b2 = this.settings.margin || "", c2 = !this.settings.autoWidth, d2 = this.settings.rtl, e2 = { width: "auto", "margin-left": d2 ? b2 : "", "margin-right": d2 ? "" : b2 };
    !c2 && this.$stage.children().css(e2), a2.css = e2;
  } }, { filter: ["width", "items", "settings"], run: function(a2) {
    var b2 = (this.width() / this.settings.items).toFixed(3) - this.settings.margin, c2 = null, d2 = this._items.length, e2 = !this.settings.autoWidth, f = [];
    for (a2.items = { merge: false, width: b2 }; d2--; )
      c2 = this._mergers[d2], c2 = this.settings.mergeFit && Math.min(c2, this.settings.items) || c2, a2.items.merge = c2 > 1 || a2.items.merge, f[d2] = e2 ? b2 * c2 : this._items[d2].width();
    this._widths = f;
  } }, { filter: ["items", "settings"], run: function() {
    var b2 = [], c2 = this._items, d2 = this.settings, e2 = Math.max(2 * d2.items, 4), f = 2 * Math.ceil(c2.length / 2), g = d2.loop && c2.length ? d2.rewind ? e2 : Math.max(e2, f) : 0, h = "", i = "";
    for (g /= 2; g > 0; )
      b2.push(this.normalize(b2.length / 2, true)), h += c2[b2[b2.length - 1]][0].outerHTML, b2.push(this.normalize(c2.length - 1 - (b2.length - 1) / 2, true)), i = c2[b2[b2.length - 1]][0].outerHTML + i, g -= 1;
    this._clones = b2, a(h).addClass("cloned").appendTo(this.$stage), a(i).addClass("cloned").prependTo(this.$stage);
  } }, { filter: ["width", "items", "settings"], run: function() {
    for (var a2 = this.settings.rtl ? 1 : -1, b2 = this._clones.length + this._items.length, c2 = -1, d2 = 0, e2 = 0, f = []; ++c2 < b2; )
      d2 = f[c2 - 1] || 0, e2 = this._widths[this.relative(c2)] + this.settings.margin, f.push(d2 + e2 * a2);
    this._coordinates = f;
  } }, { filter: ["width", "items", "settings"], run: function() {
    var a2 = this.settings.stagePadding, b2 = this._coordinates, c2 = { width: Math.ceil(Math.abs(b2[b2.length - 1])) + 2 * a2, "padding-left": a2 || "", "padding-right": a2 || "" };
    this.$stage.css(c2);
  } }, { filter: ["width", "items", "settings"], run: function(a2) {
    var b2 = this._coordinates.length, c2 = !this.settings.autoWidth, d2 = this.$stage.children();
    if (c2 && a2.items.merge)
      for (; b2--; )
        a2.css.width = this._widths[this.relative(b2)], d2.eq(b2).css(a2.css);
    else
      c2 && (a2.css.width = a2.items.width, d2.css(a2.css));
  } }, { filter: ["items"], run: function() {
    this._coordinates.length < 1 && this.$stage.removeAttr("style");
  } }, { filter: ["width", "items", "settings"], run: function(a2) {
    a2.current = a2.current ? this.$stage.children().index(a2.current) : 0, a2.current = Math.max(this.minimum(), Math.min(this.maximum(), a2.current)), this.reset(a2.current);
  } }, { filter: ["position"], run: function() {
    this.animate(this.coordinates(this._current));
  } }, { filter: ["width", "position", "items", "settings"], run: function() {
    var a2, b2, c2, d2, e2 = this.settings.rtl ? 1 : -1, f = 2 * this.settings.stagePadding, g = this.coordinates(this.current()) + f, h = g + this.width() * e2, i = [];
    for (c2 = 0, d2 = this._coordinates.length; c2 < d2; c2++)
      a2 = this._coordinates[c2 - 1] || 0, b2 = Math.abs(this._coordinates[c2]) + f * e2, (this.op(a2, "<=", g) && this.op(a2, ">", h) || this.op(b2, "<", g) && this.op(b2, ">", h)) && i.push(c2);
    this.$stage.children(".active").removeClass("active"), this.$stage.children(":eq(" + i.join("), :eq(") + ")").addClass("active"), this.$stage.children(".center").removeClass("center"), this.settings.center && this.$stage.children().eq(this.current()).addClass("center");
  } }], e.prototype.initializeStage = function() {
    this.$stage = this.$element.find("." + this.settings.stageClass), this.$stage.length || (this.$element.addClass(this.options.loadingClass), this.$stage = a("<" + this.settings.stageElement + ">", { class: this.settings.stageClass }).wrap(a("<div/>", { class: this.settings.stageOuterClass })), this.$element.append(this.$stage.parent()));
  }, e.prototype.initializeItems = function() {
    var b2 = this.$element.find(".owl-item");
    if (b2.length)
      return this._items = b2.get().map(function(b3) {
        return a(b3);
      }), this._mergers = this._items.map(function() {
        return 1;
      }), void this.refresh();
    this.replace(this.$element.children().not(this.$stage.parent())), this.isVisible() ? this.refresh() : this.invalidate("width"), this.$element.removeClass(this.options.loadingClass).addClass(this.options.loadedClass);
  }, e.prototype.initialize = function() {
    if (this.enter("initializing"), this.trigger("initialize"), this.$element.toggleClass(this.settings.rtlClass, this.settings.rtl), this.settings.autoWidth && !this.is("pre-loading")) {
      var a2, b2, c2;
      a2 = this.$element.find("img"), b2 = this.settings.nestedItemSelector ? "." + this.settings.nestedItemSelector : d, c2 = this.$element.children(b2).width(), a2.length && c2 <= 0 && this.preloadAutoWidthImages(a2);
    }
    this.initializeStage(), this.initializeItems(), this.registerEventHandlers(), this.leave("initializing"), this.trigger("initialized");
  }, e.prototype.isVisible = function() {
    return !this.settings.checkVisibility || this.$element.is(":visible");
  }, e.prototype.setup = function() {
    var b2 = this.viewport(), c2 = this.options.responsive, d2 = -1, e2 = null;
    c2 ? (a.each(c2, function(a2) {
      a2 <= b2 && a2 > d2 && (d2 = Number(a2));
    }), e2 = a.extend({}, this.options, c2[d2]), "function" == typeof e2.stagePadding && (e2.stagePadding = e2.stagePadding()), delete e2.responsive, e2.responsiveClass && this.$element.attr("class", this.$element.attr("class").replace(new RegExp("(" + this.options.responsiveClass + "-)\\S+\\s", "g"), "$1" + d2))) : e2 = a.extend({}, this.options), this.trigger("change", { property: { name: "settings", value: e2 } }), this._breakpoint = d2, this.settings = e2, this.invalidate("settings"), this.trigger("changed", { property: { name: "settings", value: this.settings } });
  }, e.prototype.optionsLogic = function() {
    this.settings.autoWidth && (this.settings.stagePadding = false, this.settings.merge = false);
  }, e.prototype.prepare = function(b2) {
    var c2 = this.trigger("prepare", { content: b2 });
    return c2.data || (c2.data = a("<" + this.settings.itemElement + "/>").addClass(this.options.itemClass).append(b2)), this.trigger("prepared", { content: c2.data }), c2.data;
  }, e.prototype.update = function() {
    for (var b2 = 0, c2 = this._pipe.length, d2 = a.proxy(function(a2) {
      return this[a2];
    }, this._invalidated), e2 = {}; b2 < c2; )
      (this._invalidated.all || a.grep(this._pipe[b2].filter, d2).length > 0) && this._pipe[b2].run(e2), b2++;
    this._invalidated = {}, !this.is("valid") && this.enter("valid");
  }, e.prototype.width = function(a2) {
    switch (a2 = a2 || e.Width.Default) {
      case e.Width.Inner:
      case e.Width.Outer:
        return this._width;
      default:
        return this._width - 2 * this.settings.stagePadding + this.settings.margin;
    }
  }, e.prototype.refresh = function() {
    this.enter("refreshing"), this.trigger("refresh"), this.setup(), this.optionsLogic(), this.$element.addClass(this.options.refreshClass), this.update(), this.$element.removeClass(this.options.refreshClass), this.leave("refreshing"), this.trigger("refreshed");
  }, e.prototype.onThrottledResize = function() {
    b.clearTimeout(this.resizeTimer), this.resizeTimer = b.setTimeout(this._handlers.onResize, this.settings.responsiveRefreshRate);
  }, e.prototype.onResize = function() {
    return !!this._items.length && (this._width !== this.$element.width() && (!!this.isVisible() && (this.enter("resizing"), this.trigger("resize").isDefaultPrevented() ? (this.leave("resizing"), false) : (this.invalidate("width"), this.refresh(), this.leave("resizing"), void this.trigger("resized")))));
  }, e.prototype.registerEventHandlers = function() {
    a.support.transition && this.$stage.on(a.support.transition.end + ".owl.core", a.proxy(this.onTransitionEnd, this)), false !== this.settings.responsive && this.on(b, "resize", this._handlers.onThrottledResize), this.settings.mouseDrag && (this.$element.addClass(this.options.dragClass), this.$stage.on("mousedown.owl.core", a.proxy(this.onDragStart, this)), this.$stage.on("dragstart.owl.core selectstart.owl.core", function() {
      return false;
    })), this.settings.touchDrag && (this.$stage.on("touchstart.owl.core", a.proxy(this.onDragStart, this)), this.$stage.on("touchcancel.owl.core", a.proxy(this.onDragEnd, this)));
  }, e.prototype.onDragStart = function(b2) {
    var d2 = null;
    3 !== b2.which && (a.support.transform ? (d2 = this.$stage.css("transform").replace(/.*\(|\)| /g, "").split(","), d2 = { x: d2[16 === d2.length ? 12 : 4], y: d2[16 === d2.length ? 13 : 5] }) : (d2 = this.$stage.position(), d2 = { x: this.settings.rtl ? d2.left + this.$stage.width() - this.width() + this.settings.margin : d2.left, y: d2.top }), this.is("animating") && (a.support.transform ? this.animate(d2.x) : this.$stage.stop(), this.invalidate("position")), this.$element.toggleClass(this.options.grabClass, "mousedown" === b2.type), this.speed(0), this._drag.time = (/* @__PURE__ */ new Date()).getTime(), this._drag.target = a(b2.target), this._drag.stage.start = d2, this._drag.stage.current = d2, this._drag.pointer = this.pointer(b2), a(c).on("mouseup.owl.core touchend.owl.core", a.proxy(this.onDragEnd, this)), a(c).one("mousemove.owl.core touchmove.owl.core", a.proxy(function(b3) {
      var d3 = this.difference(this._drag.pointer, this.pointer(b3));
      a(c).on("mousemove.owl.core touchmove.owl.core", a.proxy(this.onDragMove, this)), Math.abs(d3.x) < Math.abs(d3.y) && this.is("valid") || (b3.preventDefault(), this.enter("dragging"), this.trigger("drag"));
    }, this)));
  }, e.prototype.onDragMove = function(a2) {
    var b2 = null, c2 = null, d2 = null, e2 = this.difference(this._drag.pointer, this.pointer(a2)), f = this.difference(this._drag.stage.start, e2);
    this.is("dragging") && (a2.preventDefault(), this.settings.loop ? (b2 = this.coordinates(this.minimum()), c2 = this.coordinates(this.maximum() + 1) - b2, f.x = ((f.x - b2) % c2 + c2) % c2 + b2) : (b2 = this.settings.rtl ? this.coordinates(this.maximum()) : this.coordinates(this.minimum()), c2 = this.settings.rtl ? this.coordinates(this.minimum()) : this.coordinates(this.maximum()), d2 = this.settings.pullDrag ? -1 * e2.x / 5 : 0, f.x = Math.max(Math.min(f.x, b2 + d2), c2 + d2)), this._drag.stage.current = f, this.animate(f.x));
  }, e.prototype.onDragEnd = function(b2) {
    var d2 = this.difference(this._drag.pointer, this.pointer(b2)), e2 = this._drag.stage.current, f = d2.x > 0 ^ this.settings.rtl ? "left" : "right";
    a(c).off(".owl.core"), this.$element.removeClass(this.options.grabClass), (0 !== d2.x && this.is("dragging") || !this.is("valid")) && (this.speed(this.settings.dragEndSpeed || this.settings.smartSpeed), this.current(this.closest(e2.x, 0 !== d2.x ? f : this._drag.direction)), this.invalidate("position"), this.update(), this._drag.direction = f, (Math.abs(d2.x) > 3 || (/* @__PURE__ */ new Date()).getTime() - this._drag.time > 300) && this._drag.target.one("click.owl.core", function() {
      return false;
    })), this.is("dragging") && (this.leave("dragging"), this.trigger("dragged"));
  }, e.prototype.closest = function(b2, c2) {
    var e2 = -1, f = 30, g = this.width(), h = this.coordinates();
    return this.settings.freeDrag || a.each(h, a.proxy(function(a2, i) {
      return "left" === c2 && b2 > i - f && b2 < i + f ? e2 = a2 : "right" === c2 && b2 > i - g - f && b2 < i - g + f ? e2 = a2 + 1 : this.op(b2, "<", i) && this.op(b2, ">", h[a2 + 1] !== d ? h[a2 + 1] : i - g) && (e2 = "left" === c2 ? a2 + 1 : a2), -1 === e2;
    }, this)), this.settings.loop || (this.op(b2, ">", h[this.minimum()]) ? e2 = b2 = this.minimum() : this.op(b2, "<", h[this.maximum()]) && (e2 = b2 = this.maximum())), e2;
  }, e.prototype.animate = function(b2) {
    var c2 = this.speed() > 0;
    this.is("animating") && this.onTransitionEnd(), c2 && (this.enter("animating"), this.trigger("translate")), a.support.transform3d && a.support.transition ? this.$stage.css({ transform: "translate3d(" + b2 + "px,0px,0px)", transition: this.speed() / 1e3 + "s" + (this.settings.slideTransition ? " " + this.settings.slideTransition : "") }) : c2 ? this.$stage.animate({ left: b2 + "px" }, this.speed(), this.settings.fallbackEasing, a.proxy(this.onTransitionEnd, this)) : this.$stage.css({ left: b2 + "px" });
  }, e.prototype.is = function(a2) {
    return this._states.current[a2] && this._states.current[a2] > 0;
  }, e.prototype.current = function(a2) {
    if (a2 === d)
      return this._current;
    if (0 === this._items.length)
      return d;
    if (a2 = this.normalize(a2), this._current !== a2) {
      var b2 = this.trigger("change", { property: { name: "position", value: a2 } });
      b2.data !== d && (a2 = this.normalize(b2.data)), this._current = a2, this.invalidate("position"), this.trigger("changed", { property: { name: "position", value: this._current } });
    }
    return this._current;
  }, e.prototype.invalidate = function(b2) {
    return "string" === a.type(b2) && (this._invalidated[b2] = true, this.is("valid") && this.leave("valid")), a.map(this._invalidated, function(a2, b3) {
      return b3;
    });
  }, e.prototype.reset = function(a2) {
    (a2 = this.normalize(a2)) !== d && (this._speed = 0, this._current = a2, this.suppress(["translate", "translated"]), this.animate(this.coordinates(a2)), this.release(["translate", "translated"]));
  }, e.prototype.normalize = function(a2, b2) {
    var c2 = this._items.length, e2 = b2 ? 0 : this._clones.length;
    return !this.isNumeric(a2) || c2 < 1 ? a2 = d : (a2 < 0 || a2 >= c2 + e2) && (a2 = ((a2 - e2 / 2) % c2 + c2) % c2 + e2 / 2), a2;
  }, e.prototype.relative = function(a2) {
    return a2 -= this._clones.length / 2, this.normalize(a2, true);
  }, e.prototype.maximum = function(a2) {
    var b2, c2, d2, e2 = this.settings, f = this._coordinates.length;
    if (e2.loop)
      f = this._clones.length / 2 + this._items.length - 1;
    else if (e2.autoWidth || e2.merge) {
      if (b2 = this._items.length)
        for (c2 = this._items[--b2].width(), d2 = this.$element.width(); b2-- && !((c2 += this._items[b2].width() + this.settings.margin) > d2); )
          ;
      f = b2 + 1;
    } else
      f = e2.center ? this._items.length - 1 : this._items.length - e2.items;
    return a2 && (f -= this._clones.length / 2), Math.max(f, 0);
  }, e.prototype.minimum = function(a2) {
    return a2 ? 0 : this._clones.length / 2;
  }, e.prototype.items = function(a2) {
    return a2 === d ? this._items.slice() : (a2 = this.normalize(a2, true), this._items[a2]);
  }, e.prototype.mergers = function(a2) {
    return a2 === d ? this._mergers.slice() : (a2 = this.normalize(a2, true), this._mergers[a2]);
  }, e.prototype.clones = function(b2) {
    var c2 = this._clones.length / 2, e2 = c2 + this._items.length, f = function(a2) {
      return a2 % 2 == 0 ? e2 + a2 / 2 : c2 - (a2 + 1) / 2;
    };
    return b2 === d ? a.map(this._clones, function(a2, b3) {
      return f(b3);
    }) : a.map(this._clones, function(a2, c3) {
      return a2 === b2 ? f(c3) : null;
    });
  }, e.prototype.speed = function(a2) {
    return a2 !== d && (this._speed = a2), this._speed;
  }, e.prototype.coordinates = function(b2) {
    var c2, e2 = 1, f = b2 - 1;
    return b2 === d ? a.map(this._coordinates, a.proxy(function(a2, b3) {
      return this.coordinates(b3);
    }, this)) : (this.settings.center ? (this.settings.rtl && (e2 = -1, f = b2 + 1), c2 = this._coordinates[b2], c2 += (this.width() - c2 + (this._coordinates[f] || 0)) / 2 * e2) : c2 = this._coordinates[f] || 0, c2 = Math.ceil(c2));
  }, e.prototype.duration = function(a2, b2, c2) {
    return 0 === c2 ? 0 : Math.min(Math.max(Math.abs(b2 - a2), 1), 6) * Math.abs(c2 || this.settings.smartSpeed);
  }, e.prototype.to = function(a2, b2) {
    var c2 = this.current(), d2 = null, e2 = a2 - this.relative(c2), f = (e2 > 0) - (e2 < 0), g = this._items.length, h = this.minimum(), i = this.maximum();
    this.settings.loop ? (!this.settings.rewind && Math.abs(e2) > g / 2 && (e2 += -1 * f * g), a2 = c2 + e2, (d2 = ((a2 - h) % g + g) % g + h) !== a2 && d2 - e2 <= i && d2 - e2 > 0 && (c2 = d2 - e2, a2 = d2, this.reset(c2))) : this.settings.rewind ? (i += 1, a2 = (a2 % i + i) % i) : a2 = Math.max(h, Math.min(i, a2)), this.speed(this.duration(c2, a2, b2)), this.current(a2), this.isVisible() && this.update();
  }, e.prototype.next = function(a2) {
    a2 = a2 || false, this.to(this.relative(this.current()) + 1, a2);
  }, e.prototype.prev = function(a2) {
    a2 = a2 || false, this.to(this.relative(this.current()) - 1, a2);
  }, e.prototype.onTransitionEnd = function(a2) {
    if (a2 !== d && (a2.stopPropagation(), (a2.target || a2.srcElement || a2.originalTarget) !== this.$stage.get(0)))
      return false;
    this.leave("animating"), this.trigger("translated");
  }, e.prototype.viewport = function() {
    var d2;
    return this.options.responsiveBaseElement !== b ? d2 = a(this.options.responsiveBaseElement).width() : b.innerWidth ? d2 = b.innerWidth : c.documentElement && c.documentElement.clientWidth ? d2 = c.documentElement.clientWidth : console.warn("Can not detect viewport width."), d2;
  }, e.prototype.replace = function(b2) {
    this.$stage.empty(), this._items = [], b2 && (b2 = b2 instanceof jQuery ? b2 : a(b2)), this.settings.nestedItemSelector && (b2 = b2.find("." + this.settings.nestedItemSelector)), b2.filter(function() {
      return 1 === this.nodeType;
    }).each(a.proxy(function(a2, b3) {
      b3 = this.prepare(b3), this.$stage.append(b3), this._items.push(b3), this._mergers.push(1 * b3.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1);
    }, this)), this.reset(this.isNumeric(this.settings.startPosition) ? this.settings.startPosition : 0), this.invalidate("items");
  }, e.prototype.add = function(b2, c2) {
    var e2 = this.relative(this._current);
    c2 = c2 === d ? this._items.length : this.normalize(c2, true), b2 = b2 instanceof jQuery ? b2 : a(b2), this.trigger("add", { content: b2, position: c2 }), b2 = this.prepare(b2), 0 === this._items.length || c2 === this._items.length ? (0 === this._items.length && this.$stage.append(b2), 0 !== this._items.length && this._items[c2 - 1].after(b2), this._items.push(b2), this._mergers.push(1 * b2.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1)) : (this._items[c2].before(b2), this._items.splice(c2, 0, b2), this._mergers.splice(c2, 0, 1 * b2.find("[data-merge]").addBack("[data-merge]").attr("data-merge") || 1)), this._items[e2] && this.reset(this._items[e2].index()), this.invalidate("items"), this.trigger("added", { content: b2, position: c2 });
  }, e.prototype.remove = function(a2) {
    (a2 = this.normalize(a2, true)) !== d && (this.trigger("remove", { content: this._items[a2], position: a2 }), this._items[a2].remove(), this._items.splice(a2, 1), this._mergers.splice(a2, 1), this.invalidate("items"), this.trigger("removed", { content: null, position: a2 }));
  }, e.prototype.preloadAutoWidthImages = function(b2) {
    b2.each(a.proxy(function(b3, c2) {
      this.enter("pre-loading"), c2 = a(c2), a(new Image()).one("load", a.proxy(function(a2) {
        c2.attr("src", a2.target.src), c2.css("opacity", 1), this.leave("pre-loading"), !this.is("pre-loading") && !this.is("initializing") && this.refresh();
      }, this)).attr("src", c2.attr("src") || c2.attr("data-src") || c2.attr("data-src-retina"));
    }, this));
  }, e.prototype.destroy = function() {
    this.$element.off(".owl.core"), this.$stage.off(".owl.core"), a(c).off(".owl.core"), false !== this.settings.responsive && (b.clearTimeout(this.resizeTimer), this.off(b, "resize", this._handlers.onThrottledResize));
    for (var d2 in this._plugins)
      this._plugins[d2].destroy();
    this.$stage.children(".cloned").remove(), this.$stage.unwrap(), this.$stage.children().contents().unwrap(), this.$stage.children().unwrap(), this.$stage.remove(), this.$element.removeClass(this.options.refreshClass).removeClass(this.options.loadingClass).removeClass(this.options.loadedClass).removeClass(this.options.rtlClass).removeClass(this.options.dragClass).removeClass(this.options.grabClass).attr("class", this.$element.attr("class").replace(new RegExp(this.options.responsiveClass + "-\\S+\\s", "g"), "")).removeData("owl.carousel");
  }, e.prototype.op = function(a2, b2, c2) {
    var d2 = this.settings.rtl;
    switch (b2) {
      case "<":
        return d2 ? a2 > c2 : a2 < c2;
      case ">":
        return d2 ? a2 < c2 : a2 > c2;
      case ">=":
        return d2 ? a2 <= c2 : a2 >= c2;
      case "<=":
        return d2 ? a2 >= c2 : a2 <= c2;
    }
  }, e.prototype.on = function(a2, b2, c2, d2) {
    a2.addEventListener ? a2.addEventListener(b2, c2, d2) : a2.attachEvent && a2.attachEvent("on" + b2, c2);
  }, e.prototype.off = function(a2, b2, c2, d2) {
    a2.removeEventListener ? a2.removeEventListener(b2, c2, d2) : a2.detachEvent && a2.detachEvent("on" + b2, c2);
  }, e.prototype.trigger = function(b2, c2, d2, f, g) {
    var h = { item: { count: this._items.length, index: this.current() } }, i = a.camelCase(a.grep(["on", b2, d2], function(a2) {
      return a2;
    }).join("-").toLowerCase()), j = a.Event([b2, "owl", d2 || "carousel"].join(".").toLowerCase(), a.extend({ relatedTarget: this }, h, c2));
    return this._supress[b2] || (a.each(this._plugins, function(a2, b3) {
      b3.onTrigger && b3.onTrigger(j);
    }), this.register({ type: e.Type.Event, name: b2 }), this.$element.trigger(j), this.settings && "function" == typeof this.settings[i] && this.settings[i].call(this, j)), j;
  }, e.prototype.enter = function(b2) {
    a.each([b2].concat(this._states.tags[b2] || []), a.proxy(function(a2, b3) {
      this._states.current[b3] === d && (this._states.current[b3] = 0), this._states.current[b3]++;
    }, this));
  }, e.prototype.leave = function(b2) {
    a.each([b2].concat(this._states.tags[b2] || []), a.proxy(function(a2, b3) {
      this._states.current[b3]--;
    }, this));
  }, e.prototype.register = function(b2) {
    if (b2.type === e.Type.Event) {
      if (a.event.special[b2.name] || (a.event.special[b2.name] = {}), !a.event.special[b2.name].owl) {
        var c2 = a.event.special[b2.name]._default;
        a.event.special[b2.name]._default = function(a2) {
          return !c2 || !c2.apply || a2.namespace && -1 !== a2.namespace.indexOf("owl") ? a2.namespace && a2.namespace.indexOf("owl") > -1 : c2.apply(this, arguments);
        }, a.event.special[b2.name].owl = true;
      }
    } else
      b2.type === e.Type.State && (this._states.tags[b2.name] ? this._states.tags[b2.name] = this._states.tags[b2.name].concat(b2.tags) : this._states.tags[b2.name] = b2.tags, this._states.tags[b2.name] = a.grep(this._states.tags[b2.name], a.proxy(function(c3, d2) {
        return a.inArray(c3, this._states.tags[b2.name]) === d2;
      }, this)));
  }, e.prototype.suppress = function(b2) {
    a.each(b2, a.proxy(function(a2, b3) {
      this._supress[b3] = true;
    }, this));
  }, e.prototype.release = function(b2) {
    a.each(b2, a.proxy(function(a2, b3) {
      delete this._supress[b3];
    }, this));
  }, e.prototype.pointer = function(a2) {
    var c2 = { x: null, y: null };
    return a2 = a2.originalEvent || a2 || b.event, a2 = a2.touches && a2.touches.length ? a2.touches[0] : a2.changedTouches && a2.changedTouches.length ? a2.changedTouches[0] : a2, a2.pageX ? (c2.x = a2.pageX, c2.y = a2.pageY) : (c2.x = a2.clientX, c2.y = a2.clientY), c2;
  }, e.prototype.isNumeric = function(a2) {
    return !isNaN(parseFloat(a2));
  }, e.prototype.difference = function(a2, b2) {
    return { x: a2.x - b2.x, y: a2.y - b2.y };
  }, a.fn.owlCarousel = function(b2) {
    var c2 = Array.prototype.slice.call(arguments, 1);
    return this.each(function() {
      var d2 = a(this), f = d2.data("owl.carousel");
      f || (f = new e(this, "object" == typeof b2 && b2), d2.data("owl.carousel", f), a.each(["next", "prev", "to", "destroy", "refresh", "replace", "add", "remove"], function(b3, c3) {
        f.register({ type: e.Type.Event, name: c3 }), f.$element.on(c3 + ".owl.carousel.core", a.proxy(function(a2) {
          a2.namespace && a2.relatedTarget !== this && (this.suppress([c3]), f[c3].apply(this, [].slice.call(arguments, 1)), this.release([c3]));
        }, f));
      })), "string" == typeof b2 && "_" !== b2.charAt(0) && f[b2].apply(f, c2);
    });
  }, a.fn.owlCarousel.Constructor = e;
}(window.Zepto || window.jQuery, window, document), function(a, b, c, d) {
  var e = function(b2) {
    this._core = b2, this._interval = null, this._visible = null, this._handlers = { "initialized.owl.carousel": a.proxy(function(a2) {
      a2.namespace && this._core.settings.autoRefresh && this.watch();
    }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this._core.$element.on(this._handlers);
  };
  e.Defaults = { autoRefresh: true, autoRefreshInterval: 500 }, e.prototype.watch = function() {
    this._interval || (this._visible = this._core.isVisible(), this._interval = b.setInterval(a.proxy(this.refresh, this), this._core.settings.autoRefreshInterval));
  }, e.prototype.refresh = function() {
    this._core.isVisible() !== this._visible && (this._visible = !this._visible, this._core.$element.toggleClass("owl-hidden", !this._visible), this._visible && this._core.invalidate("width") && this._core.refresh());
  }, e.prototype.destroy = function() {
    var a2, c2;
    b.clearInterval(this._interval);
    for (a2 in this._handlers)
      this._core.$element.off(a2, this._handlers[a2]);
    for (c2 in Object.getOwnPropertyNames(this))
      "function" != typeof this[c2] && (this[c2] = null);
  }, a.fn.owlCarousel.Constructor.Plugins.AutoRefresh = e;
}(window.Zepto || window.jQuery, window), function(a, b, c, d) {
  var e = function(b2) {
    this._core = b2, this._loaded = [], this._handlers = { "initialized.owl.carousel change.owl.carousel resized.owl.carousel": a.proxy(function(b3) {
      if (b3.namespace && this._core.settings && this._core.settings.lazyLoad && (b3.property && "position" == b3.property.name || "initialized" == b3.type)) {
        var c2 = this._core.settings, e2 = c2.center && Math.ceil(c2.items / 2) || c2.items, f = c2.center && -1 * e2 || 0, g = (b3.property && b3.property.value !== d ? b3.property.value : this._core.current()) + f, h = this._core.clones().length, i = a.proxy(function(a2, b4) {
          this.load(b4);
        }, this);
        for (c2.lazyLoadEager > 0 && (e2 += c2.lazyLoadEager, c2.loop && (g -= c2.lazyLoadEager, e2++)); f++ < e2; )
          this.load(h / 2 + this._core.relative(g)), h && a.each(this._core.clones(this._core.relative(g)), i), g++;
      }
    }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this._core.$element.on(this._handlers);
  };
  e.Defaults = { lazyLoad: false, lazyLoadEager: 0 }, e.prototype.load = function(c2) {
    var d2 = this._core.$stage.children().eq(c2), e2 = d2 && d2.find(".owl-lazy");
    !e2 || a.inArray(d2.get(0), this._loaded) > -1 || (e2.each(a.proxy(function(c3, d3) {
      var e3, f = a(d3), g = b.devicePixelRatio > 1 && f.attr("data-src-retina") || f.attr("data-src") || f.attr("data-srcset");
      this._core.trigger("load", { element: f, url: g }, "lazy"), f.is("img") ? f.one("load.owl.lazy", a.proxy(function() {
        f.css("opacity", 1), this._core.trigger("loaded", { element: f, url: g }, "lazy");
      }, this)).attr("src", g) : f.is("source") ? f.one("load.owl.lazy", a.proxy(function() {
        this._core.trigger("loaded", { element: f, url: g }, "lazy");
      }, this)).attr("srcset", g) : (e3 = new Image(), e3.onload = a.proxy(function() {
        f.css({ "background-image": 'url("' + g + '")', opacity: "1" }), this._core.trigger("loaded", { element: f, url: g }, "lazy");
      }, this), e3.src = g);
    }, this)), this._loaded.push(d2.get(0)));
  }, e.prototype.destroy = function() {
    var a2, b2;
    for (a2 in this.handlers)
      this._core.$element.off(a2, this.handlers[a2]);
    for (b2 in Object.getOwnPropertyNames(this))
      "function" != typeof this[b2] && (this[b2] = null);
  }, a.fn.owlCarousel.Constructor.Plugins.Lazy = e;
}(window.Zepto || window.jQuery, window), function(a, b, c, d) {
  var e = function(c2) {
    this._core = c2, this._previousHeight = null, this._handlers = { "initialized.owl.carousel refreshed.owl.carousel": a.proxy(function(a2) {
      a2.namespace && this._core.settings.autoHeight && this.update();
    }, this), "changed.owl.carousel": a.proxy(function(a2) {
      a2.namespace && this._core.settings.autoHeight && "position" === a2.property.name && this.update();
    }, this), "loaded.owl.lazy": a.proxy(function(a2) {
      a2.namespace && this._core.settings.autoHeight && a2.element.closest("." + this._core.settings.itemClass).index() === this._core.current() && this.update();
    }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this._core.$element.on(this._handlers), this._intervalId = null;
    var d2 = this;
    a(b).on("load", function() {
      d2._core.settings.autoHeight && d2.update();
    }), a(b).resize(function() {
      d2._core.settings.autoHeight && (null != d2._intervalId && clearTimeout(d2._intervalId), d2._intervalId = setTimeout(function() {
        d2.update();
      }, 250));
    });
  };
  e.Defaults = { autoHeight: false, autoHeightClass: "owl-height" }, e.prototype.update = function() {
    var b2 = this._core._current, c2 = b2 + this._core.settings.items, d2 = this._core.settings.lazyLoad, e2 = this._core.$stage.children().toArray().slice(b2, c2), f = [], g = 0;
    a.each(e2, function(b3, c3) {
      f.push(a(c3).height());
    }), g = Math.max.apply(null, f), g <= 1 && d2 && this._previousHeight && (g = this._previousHeight), this._previousHeight = g, this._core.$stage.parent().height(g).addClass(this._core.settings.autoHeightClass);
  }, e.prototype.destroy = function() {
    var a2, b2;
    for (a2 in this._handlers)
      this._core.$element.off(a2, this._handlers[a2]);
    for (b2 in Object.getOwnPropertyNames(this))
      "function" != typeof this[b2] && (this[b2] = null);
  }, a.fn.owlCarousel.Constructor.Plugins.AutoHeight = e;
}(window.Zepto || window.jQuery, window), function(a, b, c, d) {
  var e = function(b2) {
    this._core = b2, this._videos = {}, this._playing = null, this._handlers = { "initialized.owl.carousel": a.proxy(function(a2) {
      a2.namespace && this._core.register({ type: "state", name: "playing", tags: ["interacting"] });
    }, this), "resize.owl.carousel": a.proxy(function(a2) {
      a2.namespace && this._core.settings.video && this.isInFullScreen() && a2.preventDefault();
    }, this), "refreshed.owl.carousel": a.proxy(function(a2) {
      a2.namespace && this._core.is("resizing") && this._core.$stage.find(".cloned .owl-video-frame").remove();
    }, this), "changed.owl.carousel": a.proxy(function(a2) {
      a2.namespace && "position" === a2.property.name && this._playing && this.stop();
    }, this), "prepared.owl.carousel": a.proxy(function(b3) {
      if (b3.namespace) {
        var c2 = a(b3.content).find(".owl-video");
        c2.length && (c2.css("display", "none"), this.fetch(c2, a(b3.content)));
      }
    }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this._core.$element.on(this._handlers), this._core.$element.on("click.owl.video", ".owl-video-play-icon", a.proxy(function(a2) {
      this.play(a2);
    }, this));
  };
  e.Defaults = { video: false, videoHeight: false, videoWidth: false }, e.prototype.fetch = function(a2, b2) {
    var c2 = function() {
      return a2.attr("data-vimeo-id") ? "vimeo" : a2.attr("data-vzaar-id") ? "vzaar" : "youtube";
    }(), d2 = a2.attr("data-vimeo-id") || a2.attr("data-youtube-id") || a2.attr("data-vzaar-id"), e2 = a2.attr("data-width") || this._core.settings.videoWidth, f = a2.attr("data-height") || this._core.settings.videoHeight, g = a2.attr("href");
    if (!g)
      throw new Error("Missing video URL.");
    if (d2 = g.match(/(http:|https:|)\/\/(player.|www.|app.)?(vimeo\.com|youtu(be\.com|\.be|be\.googleapis\.com|be\-nocookie\.com)|vzaar\.com)\/(video\/|videos\/|embed\/|channels\/.+\/|groups\/.+\/|watch\?v=|v\/)?([A-Za-z0-9._%-]*)(\&\S+)?/), d2[3].indexOf("youtu") > -1)
      c2 = "youtube";
    else if (d2[3].indexOf("vimeo") > -1)
      c2 = "vimeo";
    else {
      if (!(d2[3].indexOf("vzaar") > -1))
        throw new Error("Video URL not supported.");
      c2 = "vzaar";
    }
    d2 = d2[6], this._videos[g] = { type: c2, id: d2, width: e2, height: f }, b2.attr("data-video", g), this.thumbnail(a2, this._videos[g]);
  }, e.prototype.thumbnail = function(b2, c2) {
    var d2, e2, f, g = c2.width && c2.height ? "width:" + c2.width + "px;height:" + c2.height + "px;" : "", h = b2.find("img"), i = "src", j = "", k = this._core.settings, l = function(c3) {
      e2 = '<div class="owl-video-play-icon"></div>', d2 = k.lazyLoad ? a("<div/>", { class: "owl-video-tn " + j, srcType: c3 }) : a("<div/>", { class: "owl-video-tn", style: "opacity:1;background-image:url(" + c3 + ")" }), b2.after(d2), b2.after(e2);
    };
    if (b2.wrap(a("<div/>", { class: "owl-video-wrapper", style: g })), this._core.settings.lazyLoad && (i = "data-src", j = "owl-lazy"), h.length)
      return l(h.attr(i)), h.remove(), false;
    "youtube" === c2.type ? (f = "//img.youtube.com/vi/" + c2.id + "/hqdefault.jpg", l(f)) : "vimeo" === c2.type ? a.ajax({ type: "GET", url: "//vimeo.com/api/v2/video/" + c2.id + ".json", jsonp: "callback", dataType: "jsonp", success: function(a2) {
      f = a2[0].thumbnail_large, l(f);
    } }) : "vzaar" === c2.type && a.ajax({ type: "GET", url: "//vzaar.com/api/videos/" + c2.id + ".json", jsonp: "callback", dataType: "jsonp", success: function(a2) {
      f = a2.framegrab_url, l(f);
    } });
  }, e.prototype.stop = function() {
    this._core.trigger("stop", null, "video"), this._playing.find(".owl-video-frame").remove(), this._playing.removeClass("owl-video-playing"), this._playing = null, this._core.leave("playing"), this._core.trigger("stopped", null, "video");
  }, e.prototype.play = function(b2) {
    var c2, d2 = a(b2.target), e2 = d2.closest("." + this._core.settings.itemClass), f = this._videos[e2.attr("data-video")], g = f.width || "100%", h = f.height || this._core.$stage.height();
    this._playing || (this._core.enter("playing"), this._core.trigger("play", null, "video"), e2 = this._core.items(this._core.relative(e2.index())), this._core.reset(e2.index()), c2 = a('<iframe frameborder="0" allowfullscreen mozallowfullscreen webkitAllowFullScreen ></iframe>'), c2.attr("height", h), c2.attr("width", g), "youtube" === f.type ? c2.attr("src", "//www.youtube.com/embed/" + f.id + "?autoplay=1&rel=0&v=" + f.id) : "vimeo" === f.type ? c2.attr("src", "//player.vimeo.com/video/" + f.id + "?autoplay=1") : "vzaar" === f.type && c2.attr("src", "//view.vzaar.com/" + f.id + "/player?autoplay=true"), a(c2).wrap('<div class="owl-video-frame" />').insertAfter(e2.find(".owl-video")), this._playing = e2.addClass("owl-video-playing"));
  }, e.prototype.isInFullScreen = function() {
    var b2 = c.fullscreenElement || c.mozFullScreenElement || c.webkitFullscreenElement;
    return b2 && a(b2).parent().hasClass("owl-video-frame");
  }, e.prototype.destroy = function() {
    var a2, b2;
    this._core.$element.off("click.owl.video");
    for (a2 in this._handlers)
      this._core.$element.off(a2, this._handlers[a2]);
    for (b2 in Object.getOwnPropertyNames(this))
      "function" != typeof this[b2] && (this[b2] = null);
  }, a.fn.owlCarousel.Constructor.Plugins.Video = e;
}(window.Zepto || window.jQuery, window, document), function(a, b, c, d) {
  var e = function(b2) {
    this.core = b2, this.core.options = a.extend({}, e.Defaults, this.core.options), this.swapping = true, this.previous = d, this.next = d, this.handlers = { "change.owl.carousel": a.proxy(function(a2) {
      a2.namespace && "position" == a2.property.name && (this.previous = this.core.current(), this.next = a2.property.value);
    }, this), "drag.owl.carousel dragged.owl.carousel translated.owl.carousel": a.proxy(function(a2) {
      a2.namespace && (this.swapping = "translated" == a2.type);
    }, this), "translate.owl.carousel": a.proxy(function(a2) {
      a2.namespace && this.swapping && (this.core.options.animateOut || this.core.options.animateIn) && this.swap();
    }, this) }, this.core.$element.on(this.handlers);
  };
  e.Defaults = {
    animateOut: false,
    animateIn: false
  }, e.prototype.swap = function() {
    if (1 === this.core.settings.items && a.support.animation && a.support.transition) {
      this.core.speed(0);
      var b2, c2 = a.proxy(this.clear, this), d2 = this.core.$stage.children().eq(this.previous), e2 = this.core.$stage.children().eq(this.next), f = this.core.settings.animateIn, g = this.core.settings.animateOut;
      this.core.current() !== this.previous && (g && (b2 = this.core.coordinates(this.previous) - this.core.coordinates(this.next), d2.one(a.support.animation.end, c2).css({ left: b2 + "px" }).addClass("animated owl-animated-out").addClass(g)), f && e2.one(a.support.animation.end, c2).addClass("animated owl-animated-in").addClass(f));
    }
  }, e.prototype.clear = function(b2) {
    a(b2.target).css({ left: "" }).removeClass("animated owl-animated-out owl-animated-in").removeClass(this.core.settings.animateIn).removeClass(this.core.settings.animateOut), this.core.onTransitionEnd();
  }, e.prototype.destroy = function() {
    var a2, b2;
    for (a2 in this.handlers)
      this.core.$element.off(a2, this.handlers[a2]);
    for (b2 in Object.getOwnPropertyNames(this))
      "function" != typeof this[b2] && (this[b2] = null);
  }, a.fn.owlCarousel.Constructor.Plugins.Animate = e;
}(window.Zepto || window.jQuery), function(a, b, c, d) {
  var e = function(b2) {
    this._core = b2, this._call = null, this._time = 0, this._timeout = 0, this._paused = true, this._handlers = { "changed.owl.carousel": a.proxy(function(a2) {
      a2.namespace && "settings" === a2.property.name ? this._core.settings.autoplay ? this.play() : this.stop() : a2.namespace && "position" === a2.property.name && this._paused && (this._time = 0);
    }, this), "initialized.owl.carousel": a.proxy(function(a2) {
      a2.namespace && this._core.settings.autoplay && this.play();
    }, this), "play.owl.autoplay": a.proxy(function(a2, b3, c2) {
      a2.namespace && this.play(b3, c2);
    }, this), "stop.owl.autoplay": a.proxy(function(a2) {
      a2.namespace && this.stop();
    }, this), "mouseover.owl.autoplay": a.proxy(function() {
      this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.pause();
    }, this), "mouseleave.owl.autoplay": a.proxy(function() {
      this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.play();
    }, this), "touchstart.owl.core": a.proxy(function() {
      this._core.settings.autoplayHoverPause && this._core.is("rotating") && this.pause();
    }, this), "touchend.owl.core": a.proxy(function() {
      this._core.settings.autoplayHoverPause && this.play();
    }, this) }, this._core.$element.on(this._handlers), this._core.options = a.extend({}, e.Defaults, this._core.options);
  };
  e.Defaults = { autoplay: false, autoplayTimeout: 5e3, autoplayHoverPause: false, autoplaySpeed: false }, e.prototype._next = function(d2) {
    this._call = b.setTimeout(a.proxy(this._next, this, d2), this._timeout * (Math.round(this.read() / this._timeout) + 1) - this.read()), this._core.is("interacting") || c.hidden || this._core.next(d2 || this._core.settings.autoplaySpeed);
  }, e.prototype.read = function() {
    return (/* @__PURE__ */ new Date()).getTime() - this._time;
  }, e.prototype.play = function(c2, d2) {
    var e2;
    this._core.is("rotating") || this._core.enter("rotating"), c2 = c2 || this._core.settings.autoplayTimeout, e2 = Math.min(this._time % (this._timeout || c2), c2), this._paused ? (this._time = this.read(), this._paused = false) : b.clearTimeout(this._call), this._time += this.read() % c2 - e2, this._timeout = c2, this._call = b.setTimeout(a.proxy(this._next, this, d2), c2 - e2);
  }, e.prototype.stop = function() {
    this._core.is("rotating") && (this._time = 0, this._paused = true, b.clearTimeout(this._call), this._core.leave("rotating"));
  }, e.prototype.pause = function() {
    this._core.is("rotating") && !this._paused && (this._time = this.read(), this._paused = true, b.clearTimeout(this._call));
  }, e.prototype.destroy = function() {
    var a2, b2;
    this.stop();
    for (a2 in this._handlers)
      this._core.$element.off(a2, this._handlers[a2]);
    for (b2 in Object.getOwnPropertyNames(this))
      "function" != typeof this[b2] && (this[b2] = null);
  }, a.fn.owlCarousel.Constructor.Plugins.autoplay = e;
}(window.Zepto || window.jQuery, window, document), function(a, b, c, d) {
  var e = function(b2) {
    this._core = b2, this._initialized = false, this._pages = [], this._controls = {}, this._templates = [], this.$element = this._core.$element, this._overrides = { next: this._core.next, prev: this._core.prev, to: this._core.to }, this._handlers = { "prepared.owl.carousel": a.proxy(function(b3) {
      b3.namespace && this._core.settings.dotsData && this._templates.push('<div class="' + this._core.settings.dotClass + '">' + a(b3.content).find("[data-dot]").addBack("[data-dot]").attr("data-dot") + "</div>");
    }, this), "added.owl.carousel": a.proxy(function(a2) {
      a2.namespace && this._core.settings.dotsData && this._templates.splice(a2.position, 0, this._templates.pop());
    }, this), "remove.owl.carousel": a.proxy(function(a2) {
      a2.namespace && this._core.settings.dotsData && this._templates.splice(a2.position, 1);
    }, this), "changed.owl.carousel": a.proxy(function(a2) {
      a2.namespace && "position" == a2.property.name && this.draw();
    }, this), "initialized.owl.carousel": a.proxy(function(a2) {
      a2.namespace && !this._initialized && (this._core.trigger("initialize", null, "navigation"), this.initialize(), this.update(), this.draw(), this._initialized = true, this._core.trigger("initialized", null, "navigation"));
    }, this), "refreshed.owl.carousel": a.proxy(function(a2) {
      a2.namespace && this._initialized && (this._core.trigger("refresh", null, "navigation"), this.update(), this.draw(), this._core.trigger("refreshed", null, "navigation"));
    }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this.$element.on(this._handlers);
  };
  e.Defaults = { nav: false, navText: ['<span aria-label="Previous">&#x2039;</span>', '<span aria-label="Next">&#x203a;</span>'], navSpeed: false, navElement: 'button type="button" role="presentation"', navContainer: false, navContainerClass: "owl-nav", navClass: ["owl-prev", "owl-next"], slideBy: 1, dotClass: "owl-dot", dotsClass: "owl-dots", dots: true, dotsEach: false, dotsData: false, dotsSpeed: false, dotsContainer: false }, e.prototype.initialize = function() {
    var b2, c2 = this._core.settings;
    this._controls.$relative = (c2.navContainer ? a(c2.navContainer) : a("<div>").addClass(c2.navContainerClass).appendTo(this.$element)).addClass("disabled"), this._controls.$previous = a("<" + c2.navElement + ">").addClass(c2.navClass[0]).html(c2.navText[0]).prependTo(this._controls.$relative).on("click", a.proxy(function(a2) {
      this.prev(c2.navSpeed);
    }, this)), this._controls.$next = a("<" + c2.navElement + ">").addClass(c2.navClass[1]).html(c2.navText[1]).appendTo(this._controls.$relative).on("click", a.proxy(function(a2) {
      this.next(c2.navSpeed);
    }, this)), c2.dotsData || (this._templates = [a('<button role="button">').addClass(c2.dotClass).append(a("<span>")).prop("outerHTML")]), this._controls.$absolute = (c2.dotsContainer ? a(c2.dotsContainer) : a("<div>").addClass(c2.dotsClass).appendTo(this.$element)).addClass("disabled"), this._controls.$absolute.on("click", "button", a.proxy(function(b3) {
      var d2 = a(b3.target).parent().is(this._controls.$absolute) ? a(b3.target).index() : a(b3.target).parent().index();
      b3.preventDefault(), this.to(d2, c2.dotsSpeed);
    }, this));
    for (b2 in this._overrides)
      this._core[b2] = a.proxy(this[b2], this);
  }, e.prototype.destroy = function() {
    var a2, b2, c2, d2, e2;
    e2 = this._core.settings;
    for (a2 in this._handlers)
      this.$element.off(a2, this._handlers[a2]);
    for (b2 in this._controls)
      "$relative" === b2 && e2.navContainer ? this._controls[b2].html("") : this._controls[b2].remove();
    for (d2 in this.overides)
      this._core[d2] = this._overrides[d2];
    for (c2 in Object.getOwnPropertyNames(this))
      "function" != typeof this[c2] && (this[c2] = null);
  }, e.prototype.update = function() {
    var a2, b2, d2 = this._core.clones().length / 2, e2 = d2 + this._core.items().length, f = this._core.maximum(true), g = this._core.settings, h = g.center || g.autoWidth || g.dotsData ? 1 : g.dotsEach || g.items;
    if ("page" !== g.slideBy && (g.slideBy = Math.min(g.slideBy, g.items)), g.dots || "page" == g.slideBy)
      for (this._pages = [], a2 = d2, b2 = 0, 0; a2 < e2; a2++) {
        if (b2 >= h || 0 === b2) {
          if (this._pages.push({ start: Math.min(f, a2 - d2), end: a2 - d2 + h - 1 }), Math.min(f, a2 - d2) === f)
            break;
          b2 = 0;
        }
        b2 += this._core.mergers(this._core.relative(a2));
      }
  }, e.prototype.draw = function() {
    var b2, c2 = this._core.settings, d2 = this._core.items().length <= c2.items, e2 = this._core.relative(this._core.current()), f = c2.loop || c2.rewind;
    this._controls.$relative.toggleClass("disabled", !c2.nav || d2), c2.nav && (this._controls.$previous.toggleClass("disabled", !f && e2 <= this._core.minimum(true)), this._controls.$next.toggleClass("disabled", !f && e2 >= this._core.maximum(true))), this._controls.$absolute.toggleClass("disabled", !c2.dots || d2), c2.dots && (b2 = this._pages.length - this._controls.$absolute.children().length, c2.dotsData && 0 !== b2 ? this._controls.$absolute.html(this._templates.join("")) : b2 > 0 ? this._controls.$absolute.append(new Array(b2 + 1).join(this._templates[0])) : b2 < 0 && this._controls.$absolute.children().slice(b2).remove(), this._controls.$absolute.find(".active").removeClass("active"), this._controls.$absolute.children().eq(a.inArray(this.current(), this._pages)).addClass("active"));
  }, e.prototype.onTrigger = function(b2) {
    var c2 = this._core.settings;
    b2.page = { index: a.inArray(this.current(), this._pages), count: this._pages.length, size: c2 && (c2.center || c2.autoWidth || c2.dotsData ? 1 : c2.dotsEach || c2.items) };
  }, e.prototype.current = function() {
    var b2 = this._core.relative(this._core.current());
    return a.grep(this._pages, a.proxy(function(a2, c2) {
      return a2.start <= b2 && a2.end >= b2;
    }, this)).pop();
  }, e.prototype.getPosition = function(b2) {
    var c2, d2, e2 = this._core.settings;
    return "page" == e2.slideBy ? (c2 = a.inArray(this.current(), this._pages), d2 = this._pages.length, b2 ? ++c2 : --c2, c2 = this._pages[(c2 % d2 + d2) % d2].start) : (c2 = this._core.relative(this._core.current()), d2 = this._core.items().length, b2 ? c2 += e2.slideBy : c2 -= e2.slideBy), c2;
  }, e.prototype.next = function(b2) {
    a.proxy(this._overrides.to, this._core)(this.getPosition(true), b2);
  }, e.prototype.prev = function(b2) {
    a.proxy(this._overrides.to, this._core)(this.getPosition(false), b2);
  }, e.prototype.to = function(b2, c2, d2) {
    var e2;
    !d2 && this._pages.length ? (e2 = this._pages.length, a.proxy(this._overrides.to, this._core)(this._pages[(b2 % e2 + e2) % e2].start, c2)) : a.proxy(this._overrides.to, this._core)(b2, c2);
  }, a.fn.owlCarousel.Constructor.Plugins.Navigation = e;
}(window.Zepto || window.jQuery), function(a, b, c, d) {
  var e = function(c2) {
    this._core = c2, this._hashes = {}, this.$element = this._core.$element, this._handlers = { "initialized.owl.carousel": a.proxy(function(c3) {
      c3.namespace && "URLHash" === this._core.settings.startPosition && a(b).trigger("hashchange.owl.navigation");
    }, this), "prepared.owl.carousel": a.proxy(function(b2) {
      if (b2.namespace) {
        var c3 = a(b2.content).find("[data-hash]").addBack("[data-hash]").attr("data-hash");
        if (!c3)
          return;
        this._hashes[c3] = b2.content;
      }
    }, this), "changed.owl.carousel": a.proxy(function(c3) {
      if (c3.namespace && "position" === c3.property.name) {
        var d2 = this._core.items(this._core.relative(this._core.current())), e2 = a.map(this._hashes, function(a2, b2) {
          return a2 === d2 ? b2 : null;
        }).join();
        if (!e2 || b.location.hash.slice(1) === e2)
          return;
        b.location.hash = e2;
      }
    }, this) }, this._core.options = a.extend({}, e.Defaults, this._core.options), this.$element.on(this._handlers), a(b).on("hashchange.owl.navigation", a.proxy(function(a2) {
      var c3 = b.location.hash.substring(1), e2 = this._core.$stage.children(), f = this._hashes[c3] && e2.index(this._hashes[c3]);
      f !== d && f !== this._core.current() && this._core.to(this._core.relative(f), false, true);
    }, this));
  };
  e.Defaults = { URLhashListener: false }, e.prototype.destroy = function() {
    var c2, d2;
    a(b).off("hashchange.owl.navigation");
    for (c2 in this._handlers)
      this._core.$element.off(c2, this._handlers[c2]);
    for (d2 in Object.getOwnPropertyNames(this))
      "function" != typeof this[d2] && (this[d2] = null);
  }, a.fn.owlCarousel.Constructor.Plugins.Hash = e;
}(window.Zepto || window.jQuery, window), function(a, b, c, d) {
  function e(b2, c2) {
    var e2 = false, f2 = b2.charAt(0).toUpperCase() + b2.slice(1);
    return a.each((b2 + " " + h.join(f2 + " ") + f2).split(" "), function(a2, b3) {
      if (g[b3] !== d)
        return e2 = !c2 || b3, false;
    }), e2;
  }
  function f(a2) {
    return e(a2, true);
  }
  var g = a("<support>").get(0).style, h = "Webkit Moz O ms".split(" "), i = { transition: { end: { WebkitTransition: "webkitTransitionEnd", MozTransition: "transitionend", OTransition: "oTransitionEnd", transition: "transitionend" } }, animation: { end: { WebkitAnimation: "webkitAnimationEnd", MozAnimation: "animationend", OAnimation: "oAnimationEnd", animation: "animationend" } } }, j = { csstransforms: function() {
    return !!e("transform");
  }, csstransforms3d: function() {
    return !!e("perspective");
  }, csstransitions: function() {
    return !!e("transition");
  }, cssanimations: function() {
    return !!e("animation");
  } };
  j.csstransitions() && (a.support.transition = new String(f("transition")), a.support.transition.end = i.transition.end[a.support.transition]), j.cssanimations() && (a.support.animation = new String(f("animation")), a.support.animation.end = i.animation.end[a.support.animation]), j.csstransforms() && (a.support.transform = new String(f("transform")), a.support.transform3d = j.csstransforms3d());
}(window.Zepto || window.jQuery);
const Heroto_vue_vue_type_style_index_0_lang = "";
const _sfc_main$4 = {
  __name: "Heroto",
  __ssrInlineRender: true,
  setup(__props) {
    onMounted(() => {
      initTemplateJs();
      new WOW().init();
    });
    onUpdated(() => {
      initTemplateJs();
    });
    const initTemplateJs = () => {
      (function($) {
        $(window).on("load", function() {
          $(".loader").fadeOut();
          $("#preloder").delay(200).fadeOut("slow");
        });
        $(".set-bg").each(function() {
          var bg = $(this).data("setbg");
          $(this).css("background-image", "url(" + bg + ")");
        });
        $(".canvas__open").on("click", function() {
          $(".offcanvas-menu-wrapper").addClass("active");
          $(".offcanvas-menu-overlay").addClass("active");
        });
        $(".offcanvas-menu-overlay").on("click", function() {
          $(".offcanvas-menu-wrapper").removeClass("active");
          $(".offcanvas-menu-overlay").removeClass("active");
        });
        $(".menu__class").slicknav({
          appendTo: "#mobile-menu-wrap",
          allowParentLinks: true
        });
        $(".gallery__slider").owlCarousel({
          loop: true,
          margin: 10,
          items: 4,
          dots: false,
          smartSpeed: 1200,
          autoHeight: false,
          autoplay: true,
          responsive: {
            992: {
              items: 4
            },
            768: {
              items: 3
            },
            576: {
              items: 2
            },
            0: {
              items: 1
            }
          }
        });
        $(".room__pic__slider").owlCarousel({
          loop: true,
          margin: 0,
          items: 1,
          dots: false,
          nav: true,
          navText: ["<i class='arrow_carrot-left'></i>", "<i class='arrow_carrot-right'></i>"],
          smartSpeed: 1200,
          autoHeight: false,
          autoplay: false
        });
        $(".room__details__pic__slider").owlCarousel({
          loop: true,
          margin: 10,
          items: 2,
          dots: false,
          nav: true,
          navText: ["<i class='arrow_carrot-left'></i>", "<i class='arrow_carrot-right'></i>"],
          autoHeight: false,
          autoplay: false,
          mouseDrag: false,
          responsive: {
            576: {
              items: 2
            },
            0: {
              items: 1
            }
          }
        });
        console.log("test");
        var testimonialSlider = $(".testimonial__slider");
        testimonialSlider.owlCarousel({
          loop: true,
          margin: 30,
          items: 1,
          dots: true,
          nav: true,
          navText: ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],
          smartSpeed: 1200,
          autoHeight: false,
          autoplay: true,
          mouseDrag: false,
          onInitialized: function(e) {
            var a = this.items().length;
            $("#snh-1").html("<span>01</span><span>0" + a + "</span>");
            var presentage = Math.round(100 / a);
            $(".slider__progress span").css("width", presentage + "%");
          }
        }).on("changed.owl.carousel", function(e) {
          var b = --e.item.index, a = e.item.count;
          $("#snh-1").html("<span> 0" + (1 > b ? b + a : b > a ? b - a : b) + "</span><span>0" + a + "</span>");
          var current = e.page.index + 1;
          var presentage = Math.round(100 / e.page.count * current);
          $(".slider__progress span").css("width", presentage + "%");
        });
        $(".logo__carousel").owlCarousel({
          loop: true,
          margin: 100,
          items: 5,
          dots: false,
          smartSpeed: 1200,
          autoHeight: false,
          autoplay: false,
          responsive: {
            992: {
              items: 5
            },
            768: {
              items: 3
            },
            320: {
              items: 2
            },
            0: {
              items: 1
            }
          }
        });
        $("select").niceSelect();
        var today = /* @__PURE__ */ new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1;
        var yyyy = today.getFullYear();
        if (dd < 10) {
          dd = "0" + dd;
        }
        var mS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        var month;
        for (let i = 0; i <= 12; i++) {
          if (mm == mS.indexOf(mS[i])) {
            month = mS[i - 1];
          }
        }
        var today = dd + " " + month + " " + yyyy;
        $(".check__in").val(today);
        $(".check__out").val(today);
        $(".datepicker_pop").datepicker({
          dateFormat: "dd M yy",
          minDate: 0
        });
      })(jQuery);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/Heroto.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const Navbar_vue_vue_type_style_index_0_lang = "";
const _sfc_main$3 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(_attrs)}><div class="offcanvas-menu-overlay"></div><div class="offcanvas-menu-wrapper"><div class="offcanvas__logo"><a href="./index.html"><img src="img/logo.png" alt=""></a></div><div id="mobile-menu-wrap"></div><div class="offcanvas__btn__widget"><a href="#">Book Now <span class="arrow_right"></span></a></div><div class="offcanvas__widget"><ul><li><span class="icon_pin_alt"></span> Magadi road,</li><li><span class="icon_phone"></span> (123) 456-78-910</li></ul></div><div class="offcanvas__language"><img src="img/lan.png" alt=""><span>English</span><i class="fa fa-angle-down"></i><ul><li>English</li><li>Bangla</li></ul></div><div class="offcanvas__auth"><ul><li><a href="#">Login</a></li><li><a href="#">Register</a></li></ul></div></div><header class="header"><div style="${ssrRenderStyle({ "background-color": "black" })}" class="header__top fixed-top"><div class="container"><div class="row"><div class="col-lg-8"><ul class="header__top__widget wow animate__pulse"><li style="${ssrRenderStyle({ "color": "white" })}"><span class="icon_pin_alt"></span>Magadi Road, Ongata Rongai, Nairobi</li><li style="${ssrRenderStyle({ "color": "white" })}"><span class="icon_phone"></span> +254 723 160 888 </li><li style="${ssrRenderStyle({ "color": "white" })}"><span class="icon_mail"></span> info@maasailodge.com</li></ul></div><div class="col-lg-4"><div class="header__top__right"><div class="header__top__auth"><ul><li class="primary-color wow animate__pulse"><a href="https://www.facebook.com/MaasaiLodgeKenya" target="_blank"><i class="fab fa-facebook primary-color fa-lg"></i></a></li><li class="primary-color wow animate__pulse"><a href="https://www.instagram.com/masailodgeofficial/" target="_blank"><i class="fab fa-instagram primary-color fa-lg"></i></a></li><li class="primary-color wow animate__pulse"><a href="https://twitter.com/maasailodge" target="_blank"><i class="fab fa-twitter primary-color fa-lg"></i></a></li><li class="primary-color wow animate__pulse"><a href="https://www.tripadvisor.com/Hotel_Review-g294207-d1787285-Reviews-Masai_Lodge-Nairobi.html" target="_blank"><i class="fa fa-tripadvisor primary-color fa-lg"></i></a></li></ul></div></div></div></div></div></div><div style="${ssrRenderStyle({ "background-color": "white", "margin-top": "40px" })}" class="header__nav__option"><div class="container"><div class="row"><div class="col-lg-2"><div class="header__logo"><a href="./index.html"><img src="img/log.png" alt=""></a></div></div><div class="col-lg-10" style="${ssrRenderStyle({ "margin-top": "12px" })}"><div class="header__nav"><nav class="header__menu"><ul class="menu__class"><li class="active"><a href="./index.html">Home</a></li><li><a style="${ssrRenderStyle({ "color": "black" })}" href="./rooms.html">Rooms</a></li><li><a style="${ssrRenderStyle({ "color": "black" })}" href="./about.html">Our Services</a></li><li><a style="${ssrRenderStyle({ "color": "black" })}" href="./about.html">About Us</a></li><li><a style="${ssrRenderStyle({ "color": "black" })}" href="./contact.html">Contact Us</a></li><li><a style="${ssrRenderStyle({ "color": "black" })}" href="./blog.html">Media</a></li></ul></nav><div class="header__nav__widget"><a href="#">Book Now <span class="arrow_right"></span></a></div></div></div></div><div class="canvas__open"><span class="fa fa-bars"></span></div></div></div></header></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Heroto/Navbar.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const Navbar = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$1]]);
const _imports_0 = "/build/assets/try-7ab60075.png";
const _imports_1 = "/build/assets/accom-27e4ff30.jpg";
const _imports_2 = "/build/assets/conf-bc10e377.jpg";
const _imports_3 = "/build/assets/bar-fcf9fc90.jpg";
const _imports_4 = "/build/assets/test-49dd0caf.jpg";
const Landing_vue_vue_type_style_index_0_scoped_6ef898fc_lang = "";
const _sfc_main$2 = {
  __name: "Landing",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-6ef898fc><section class="hero spad set-bg" data-setbg="../../../heroto/img/maasai/3.jpg" data-v-6ef898fc><div class="container" data-v-6ef898fc><div id="carouselExampleControls" class="carousel slide" data-ride="carousel" data-v-6ef898fc><div class="carousel-inner" data-v-6ef898fc><div class="row carousel-item active" data-v-6ef898fc><div class="col-lg-12" data-v-6ef898fc><div class="hero__text" data-v-6ef898fc><h5 class="wow slideInLeft" data-wow-duration="2s" data-v-6ef898fc>Maasai Lodge</h5><h2 class="wow slideInRight" data-wow-duration="2s" data-v-6ef898fc>Discover tranquility where nature is your retreat</h2></div></div></div><div class="row carousel-item" data-v-6ef898fc><div class="col-lg-12" data-v-6ef898fc><div class="hero__text" data-v-6ef898fc><h5 class="wow slideInRight" data-wow-duration="2s" data-v-6ef898fc>Maasai Lodge</h5><h2 class="wow slideInLeft" data-wow-duration="2s" data-v-6ef898fc>Experience the service you will not find anywhere else</h2></div></div></div><div class="row carousel-item" data-v-6ef898fc><div class="col-lg-12" data-v-6ef898fc><div class="hero__text" data-v-6ef898fc><h5 class="wow slideInLeft" data-wow-duration="2s" data-v-6ef898fc>Maasai Lodge</h5><h2 class="wow slideInRight" data-wow-duration="2s" data-v-6ef898fc>Your stay turns into more than a vacation</h2></div></div></div></div><a class="carousel-control-prev wow slideInLeft" data-wow-offset="10" data-wow-iteration="1" data-wow-duration="3s" href="#carouselExampleControls" role="button" data-slide="prev" data-v-6ef898fc><span style="${ssrRenderStyle({ "color": "black !important" })}" class="carousel-control-prev-icon" aria-hidden="true" data-v-6ef898fc></span><span class="sr-only" data-v-6ef898fc>Previous</span></a><a class="carousel-control-next wow slideInRight" data-wow-offset="10" data-wow-iteration="1" data-wow-duration="3s" href="#carouselExampleControls" role="button" data-slide="next" data-v-6ef898fc><span class="carousel-control-next-icon" aria-hidden="true" data-v-6ef898fc></span><span class="sr-only" data-v-6ef898fc>Next</span></a></div></div></section><section class="home-about" data-v-6ef898fc><div class="container" data-v-6ef898fc><div class="row" data-v-6ef898fc><div class="col-lg-6" data-v-6ef898fc><div class="home__about__text" data-v-6ef898fc><div class="section-title" data-v-6ef898fc><h5 data-v-6ef898fc>WE LET NATURE SPEAK FOR US</h5><h1 data-v-6ef898fc>Maasai Lodge</h1></div><div class="wow slideInLeft" data-wow-duration="2s" data-v-6ef898fc><p class="first-para" data-v-6ef898fc> We let nature speak for us with breathtaking views of the Nairobi national park. Masai lodge offers warm hospitality and is located at the banks of Mbagathi river overlooking the national park. </p><p class="last-para" data-v-6ef898fc> With over 40 years of peerless hospitality excellence in the wilderness, our main aim is to provide you with renowned personalized services in our beautiful facility. </p></div></div></div><div class="col-lg-6 wow animate__bounce" data-wow-offset="10" data-v-6ef898fc><div class="home__about__pic" data-v-6ef898fc><img${ssrRenderAttr("src", _imports_0)} alt="" data-v-6ef898fc></div></div></div></div></section><section class="services spad" data-v-6ef898fc><div class="container" data-v-6ef898fc><div class="row" data-v-6ef898fc><div class="col-lg-4 col-md-4 col-sm-6 wow animate__backInLeft" data-wow-duration="1s" data-v-6ef898fc><div class="services__item" data-v-6ef898fc><img${ssrRenderAttr("src", _imports_1)} alt="" data-v-6ef898fc><h4 data-v-6ef898fc>Accomodation</h4><p data-v-6ef898fc>Comprised of single and double rooms, all the 14 manyatta shaped rooms are strategically designed to face the Nairobi national park. This will give you a unique experience.</p></div></div><div class="col-lg-4 col-md-4 col-sm-6 wow animate__backInRight" data-wow-duration="2s" data-v-6ef898fc><div class="services__item" data-v-6ef898fc><img${ssrRenderAttr("src", _imports_2)} alt="" data-v-6ef898fc><h4 data-v-6ef898fc>Conference Facilities</h4><p data-v-6ef898fc>Away for the busy life of the city and with our professionally competent team, we offer the most serene environment for all levels of proffessional meetings covering your needs.</p></div></div><div class="col-lg-4 col-md-4 col-sm-6 wow animate__rubberBand" data-wow-duration="2.5s" data-v-6ef898fc><div class="services__item" data-v-6ef898fc><img${ssrRenderAttr("src", _imports_3)} alt="" data-v-6ef898fc><h4 data-v-6ef898fc>Bar &amp; Restaurant</h4><p data-v-6ef898fc>Our restaurant &amp; bar offers impeccable services giving you an opportunity to indulge in both local, international cuisines as you enjoy your favourite drink.</p></div></div></div></div></section><section class="home-room spad" data-v-6ef898fc><div class="container" data-v-6ef898fc><div class="row" data-v-6ef898fc><div class="col-lg-12" data-v-6ef898fc><div class="section-title" data-v-6ef898fc><h5 class="wow animate__fadeInDown" data-wow-duration="2s" data-v-6ef898fc>OUR ROOMS</h5><h2 class="wow animate__bounceInDown" data-wow-duration="3s" data-v-6ef898fc>Explore Our Hotel</h2></div></div></div></div><div class="container-fluid" data-v-6ef898fc><div class="row" data-v-6ef898fc><div class="col-lg-4 col-md-6 col-sm-6 p-0 wow animate__flipInX" data-wow-duration="3s" data-v-6ef898fc><div class="home__room__item set-bg" data-setbg="../../../heroto/img/maasai/parks.jpg" data-v-6ef898fc><div class="home__room__title" data-v-6ef898fc><h4 data-v-6ef898fc>Park View Rooms</h4><h2 data-v-6ef898fc><sup data-v-6ef898fc>KES</sup> 10,000<span style="${ssrRenderStyle({ "color": "white" })}" data-v-6ef898fc>/night</span></h2></div><a href="#" data-v-6ef898fc>View Details</a></div></div><div class="col-lg-4 col-md-6 col-sm-6 p-0 wow animate__flip" data-wow-duration="3s" data-v-6ef898fc><div class="home__room__item set-bg" data-setbg="../../../heroto/img/maasai/garden.jpg" data-v-6ef898fc><div class="home__room__title" data-v-6ef898fc><h4 data-v-6ef898fc>Garden View Rooms</h4><h2 data-v-6ef898fc><sup data-v-6ef898fc>KES</sup> 10,000<span style="${ssrRenderStyle({ "color": "white" })}" data-v-6ef898fc>/night</span></h2></div><a href="#" data-v-6ef898fc>View Details</a></div></div><div class="col-lg-4 col-md-6 col-sm-6 p-0 wow animate__flipInX" data-wow-duration="3s" data-v-6ef898fc><div class="home__room__item set-bg" data-setbg="../../../heroto/img/maasai/st.jpg" data-v-6ef898fc><div class="home__room__title" data-v-6ef898fc><h4 data-v-6ef898fc>Standard Triple Rooms</h4><h2 data-v-6ef898fc><sup data-v-6ef898fc>KES</sup> 12,300<span style="${ssrRenderStyle({ "color": "white" })}" data-v-6ef898fc>/night</span></h2></div><a href="#" data-v-6ef898fc>View Details</a></div></div></div></div><div class="container" data-v-6ef898fc><div class="home__explore" data-v-6ef898fc><div class="row" data-v-6ef898fc><div class="col-lg-9 col-md-8" data-v-6ef898fc><h3 data-v-6ef898fc>Unwind in Comfort: Where Every Stay is a Journey to Relaxation and Luxury</h3></div><div class="col-lg-3 col-md-4 text-center" data-v-6ef898fc><a href="#" class="primary-btn" data-v-6ef898fc>Book a reservation</a></div></div></div></div></section><section class="testimonial spad" data-v-6ef898fc><div class="container" data-v-6ef898fc><div class="row" data-v-6ef898fc><div class="col-lg-5 wow animate__lightSpeedInLeft" data-wow-duration="1s" data-v-6ef898fc><div class="testimonial__pic" data-v-6ef898fc><img${ssrRenderAttr("src", _imports_4)} alt="" data-v-6ef898fc></div></div><div class="col-lg-7" data-v-6ef898fc><div class="testimonial__text" data-v-6ef898fc><div class="section-title" data-v-6ef898fc><h5 wow slideInLeft data-v-6ef898fc>Testimonials</h5><h2 wow slideInRight data-v-6ef898fc>What do customers say about us?</h2></div><div class="testimonial__slider__content" data-v-6ef898fc><div class="testimonial__slider owl-carousel" data-v-6ef898fc><div class="testimonial__item wow animate__shakeX" data-v-6ef898fc><h5 data-v-6ef898fc>Detailed Review:</h5><div class="rating" data-v-6ef898fc><i class="fa fa-star" data-v-6ef898fc></i><i class="fa fa-star" data-v-6ef898fc></i><i class="fa fa-star" data-v-6ef898fc></i><i class="fa fa-star" data-v-6ef898fc></i><i class="fa fa-star-o" data-v-6ef898fc></i></div><p data-v-6ef898fc>Great place to relax and unwind with family. Good pool ample grounds. Best waiter ( Mr. Simon) very professional and friendly great guest centred service.</p><div class="testimonial__author" data-v-6ef898fc><div class="row" data-v-6ef898fc><div class="col-lg-6 col-md-6" data-v-6ef898fc><div class="testimonial__author__title" data-v-6ef898fc><h5 data-v-6ef898fc>Dorcas Marshall</h5><span data-v-6ef898fc>Nairobi, Kenya</span></div></div></div></div></div><div class="testimonial__item wow animate__shakeX" data-v-6ef898fc><h5 data-v-6ef898fc>Detailed Review:</h5><div class="rating" data-v-6ef898fc><i class="fa fa-star" data-v-6ef898fc></i><i class="fa fa-star" data-v-6ef898fc></i><i class="fa fa-star" data-v-6ef898fc></i><i class="fa fa-star" data-v-6ef898fc></i><i class="fa fa-star-o" data-v-6ef898fc></i></div><p data-v-6ef898fc>Beauty beyond measure, serenity with touch, background music accentuated by running waterfall, in the wild edge of Nairobi National Park, Masai Lodge is a rare grandeur. A must visit for those interested in seeing in it&#39;s simple nature, Nairobi&#39;s best kept secret.</p><div class="testimonial__author" data-v-6ef898fc><div class="row" data-v-6ef898fc><div class="col-lg-6 col-md-6" data-v-6ef898fc><div class="testimonial__author__title" data-v-6ef898fc><h5 data-v-6ef898fc>Bulle Jarso</h5><span data-v-6ef898fc>Nairobi, Kenya</span></div></div></div></div></div><div class="testimonial__item wow animate__shakeX" data-v-6ef898fc><h5 data-v-6ef898fc>Detailed Review:</h5><div class="rating" data-v-6ef898fc><i class="fa fa-star" data-v-6ef898fc></i><i class="fa fa-star" data-v-6ef898fc></i><i class="fa fa-star" data-v-6ef898fc></i><i class="fa fa-star" data-v-6ef898fc></i><i class="fa fa-star-o" data-v-6ef898fc></i></div><p data-v-6ef898fc>A very peaceful place perfectly lodged at the edge of Nairobi National park. If you&#39;re looking for tranquility, this is the place. The staff are very friendly and the food tastes great. If you&#39;re planning to spend a night, carry some warm clothes cuz it gets very cold in the evening.</p><div class="testimonial__author" data-v-6ef898fc><div class="row" data-v-6ef898fc><div class="col-lg-6 col-md-6" data-v-6ef898fc><div class="testimonial__author__title" data-v-6ef898fc><h5 data-v-6ef898fc>Id-Mwarabu</h5><span data-v-6ef898fc>Local Guide</span></div></div></div></div></div></div><div class="slide-num" id="snh-1" data-v-6ef898fc></div><div class="slider__progress" data-v-6ef898fc><span data-v-6ef898fc></span></div></div></div></div></div></div></section><div class="chooseus spad set-bg" data-setbg="heroto/img/maasai/wine.jpg" data-v-6ef898fc><div class="container" data-v-6ef898fc><div class="row d-flex justify-content-center" data-v-6ef898fc><div class="col-lg-8 text-center" data-v-6ef898fc><div class="chooseus__text" data-v-6ef898fc><div class="section-title" data-v-6ef898fc><h5 class="wow animate__backInUp" data-wow-duration="1s" data-v-6ef898fc>WHY CHOOSE US</h5><h2 class="wow animate__tada" data-v-6ef898fc>Get the tailored deals for bookings</h2></div><a href="#" class="primary-btn" data-v-6ef898fc>Write to us <i class="fas fa-paper-plane" data-v-6ef898fc></i></a></div></div></div></div></div><section class="gallery spad" data-v-6ef898fc><div class="gallery__text" data-v-6ef898fc><div class="container" data-v-6ef898fc><div class="row" data-v-6ef898fc><div class="col-lg-6 col-md-6 col-sm-6" data-v-6ef898fc><div class="section-title" data-v-6ef898fc><h5 class="wow animate__lightSpeedInRight" data-wow-duration="1s" data-v-6ef898fc>OUR GALLERY</h5><h2 class="wow animate__lightSpeedInLeft" data-wow-duration="0.5s" data-v-6ef898fc>Capturing Elegance in Every Frame</h2></div></div><div class="col-lg-6 col-md-6 col-sm-6" data-v-6ef898fc><div class="gallery__title" data-v-6ef898fc><a href="#" class="mt-5 primary-btn wow animate__rubberBand" data-wow-duration="1s" data-v-6ef898fc>View Gallery <span class="arrow_right" data-v-6ef898fc></span></a></div></div></div></div></div><div class="gallery__slider owl-carousel" data-v-6ef898fc><div class="gallery__item small__item set-bg" data-setbg="heroto/img/maasai/slider/1.jpg" data-v-6ef898fc></div><div class="gallery__item set-bg" data-setbg="heroto/img/maasai/slider/2.jpg" data-v-6ef898fc></div><div class="gallery__item set-bg" data-setbg="heroto/img/maasai/slider/3.jpg" data-v-6ef898fc></div><div class="gallery__item set-bg" data-setbg="heroto/img/maasai/slider/9.jpg" data-v-6ef898fc></div><div class="gallery__item set-bg" data-setbg="heroto/img/maasai/slider/5.jpg" data-v-6ef898fc></div><div class="gallery__item set-bg" data-setbg="heroto/img/maasai/slider/6.jpg" data-v-6ef898fc></div><div class="gallery__item set-bg" data-setbg="heroto/img/maasai/slider/10.jpg" data-v-6ef898fc></div><div class="gallery__item set-bg" data-setbg="heroto/img/maasai/slider/7.jpg" data-v-6ef898fc></div><div class="gallery__item set-bg" data-setbg="heroto/img/maasai/slider/8.jpg" data-v-6ef898fc></div><div class="gallery__item set-bg" data-setbg="heroto/img/maasai/slider/11.jpg" data-v-6ef898fc></div></div></section><section class="latest-blog spad" data-v-6ef898fc><div class="container" data-v-6ef898fc><div class="row" data-v-6ef898fc><div class="col-lg-12" data-v-6ef898fc><div class="section-title" data-v-6ef898fc><h5 class="wow animate__backInLeft" data-v-6ef898fc>NEWS &amp; EVENT</h5><h2 class="wow animate__backInUp" data-v-6ef898fc>From Our Blog</h2></div></div></div><div class="row" data-v-6ef898fc><div class="wow animate__bounce col-lg-3 p-0 order-lg-1 col-md-6 order-md-1" data-v-6ef898fc><div class="latest__blog__pic set-bg" data-setbg="https://www.congosafaristours.com/wp-content/uploads/2021/05/Nairobi-National-Park-1.jpg" data-v-6ef898fc></div></div><div class="wow animate__lightSpeedInRight col-lg-3 p-0 order-lg-2 col-md-6 order-md-2" data-v-6ef898fc><div class="latest__blog__text" data-v-6ef898fc><div class="label" data-v-6ef898fc>Tour</div><h5 data-v-6ef898fc>The Nairobi National Park</h5><p data-v-6ef898fc><i class="fa fa-clock-o" data-v-6ef898fc></i> 15th August, 2023</p><a href="#" data-v-6ef898fc>Read More</a></div></div><div class="wow animate__bounce col-lg-3 p-0 order-lg-3 col-md-6 order-md-4" data-v-6ef898fc><div class="latest__blog__pic set-bg" data-setbg="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFBcVFRUYGBcZGiIcGxoaGiIdHxwcIRwaHCAiHSIjICwlIyIoIBwcJDUlKS0vMjIyHCM4PTgxPCwxMi8BCwsLDw4PHRERHTEoIyg0MTcxMzM6MTExMzExMTExMTMxMTExMTEzMTExMTMxMzExMTExMTExMTExMTExMTExMf/AABEIALcBEwMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAAEBQIDBgABB//EAD8QAAIBAwMCBAQEBAUDAwUBAAECEQADIQQSMUFRBSJhcRMygZGhscHRBiNC8BRScuHxFTOCYpKiJENjstIW/8QAGgEAAwEBAQEAAAAAAAAAAAAAAgMEAQAFBv/EAC8RAAICAgIBAgMHBAMAAAAAAAABAhEDIRIxQSJRBBNhMkJxgZGh8BRSsdEjcsH/2gAMAwEAAhEDEQA/AASiSfiCSVks0zMdhH/FU3Ne4KXLaEMcTM7swSMyOuBP0pwdWLeGBcsYUkCRPSY46fSKS3HB23Cj+TAkHbkkg+/2qFSVca1+36EilFao81OvEm3sK3JI3NPGDhRyfv6ULY1ly44tou4EFQB/UfmIEGI8syf0qrUaYvclTmeBziM8U1010WiYXbJgGAduZI9AczHpVsVStdjo8WrPL4VbbrbuDOTJAIPbk9ar8O8R229lzzAcE9PfHHPWhtbbl4SD0wSRzPX7QO1MtJpjbtwFKzG4kwWz9ozWZdJeQraPLniJkQAAREg/pPPrVuu8VZBJcj1J/OhNToh8MiAh3hiRkhTI8xHfpNVroCzMxhlOFXnjsOZrOMH2go7KreuN1+sCApJPHt6mmyuLTKSGwO+MnH7/AHq/SaK3btqWRt+7EZOKY6ayrFnZoB8pVuM5+9ZklFp60OUKQLcS5cYtCqADBnn3x3oB7J3Q5ncOPSn164BuCE+vAA+woNNOpuM7uGXsdykH8Qe2KHG0uzYRinsFGi2oBMCelQ8O07B93MBj2IwfuKJ/xBYESDtjAMLjsYzVGp17BiylZOCNvQ4kZpsILmjpPH15D94W1auG3vKltsMAZJ7Hk0s8T1IYoqWbibyILRDEZ5BP6VNNWxtoIUwTEeUg84zBPvAqnUeIsEVJnzSR2Azzx/eK3Kmnro5yi01ZHTOlu2Wu297SQZAx6jFTPiDDZKqFjsoxOMivLuvVlVCLbv6sAP8Ayg0A9hhbBYp82ALgLDJnAMxjk1KoxfYibT6IfxFquseeJBWOOvv9RS7S6ktH8sc4/c+lWXLpcbsdwvWJM+vSmHhG7yjKGQdwGYPeSMeonjNPjqKXsClbNVbubdG5aFnACmSMwI+1K9Xo3uru2lQEB5+bp+GJpk1otFtyq+YQOjQCYPvRWosW1UvBIAG5fyg0SS0PgmzMsqWkCi2bjN1CiF/1CQT9KN0GmW0kXivxGB2iRCzjB7x60SEDOr20fZHBA+nGBmiWQKLhd/NB/mTtnHyjPI9KTlyxi1EKwCxr7cC3uUjuZAzjywP771Ra3q5hQg6bTMjuSc/8mr9M6BgAu7jJ5PrM85/GmahAdxXaI4PNFJOh8FYC+r2uuAwYgk56DoBgZA+1ONRbG1Ru55nIjk1Te06lpQb4HtHsZP70u1WouEqDHJEccwPpxS1CSZslasp1bncbZjd3BxBiO3bivH0zhIChu/moB79s3CSDumIkwI7zIpzeuuEVRBgZPaSB1inxUeVI5QqNgej0wG5NsMT0OduDHP4R96nrNUgAQkA4MAHcQBgCDHfFCXWctDJucMfMrAKBxkjJj0+9LEc79pQOWdjBAkBYg5PUz3NTTw8cjd6JskdWtFmt8TuMZt22RV/qhTyMHBkH70FoNW9x2dz1yVYLkcY61R4hau/EjFrdgLyB/wCUckU2/h/w63atkXE3/EJ85iIET3z9qZJxhHrYmOOQh1Wqfe3mPPc11bf/AKfpB/U//tH6muof6rH7MH5U/cLfw5NgbbsJHzN/W3TrxP8Aeat1Fy21orcO8MPlH7dDH2oDVO/w1wEgTgHjEcjB+sfalVi9dJB2woO6MKO3J4waij8MprlKXT/wJpVaJ6/asfASC2CFlmiOxz7mh9FcDLBBJglSFMj36c17q9KzpcDSVVsBTIjJmc8UH4aj2zy0cYAwOmD1n2xVsLUe9+AB4llVWDLGRnIjjAyR+H+zXxB0uIbZABAGScxiDPX6dqywvPbDlgwOPmnPmg47Ub4aHW4Lgb4gyxUtGQMDGdwnqII96zLi5RTk+vIx7VNii/qgGYtcGfLuJ+bPBxEcU58MufEtt8MzcXPlIg4EASM4PT1oTSWrenuOxYNvfKwpwWBggGByegwR9Gyaq2zB7ZBMnaBwcR8qyBHbnNDJtUl14OUnGqFmp1d0naRMgEEDBH996M8IZlViIAmWAaNx9QZznn2qOv0nnBTyuZMiB1M+v/A71G1pRgEcAyZGY+tUacaZbDlJWF6jWW3BAByPYzxmcfhSjV6s5UCD1giPw4mo6p4EKhk/5eBHc0JfknpIEekxRYYKxcpWtBaXt1sicjA+tT0dhrnlTLExzHrGY7UDph5TPUg/amGk1JtqLkKXDAieOvP09aqxRVu+ieTdquy7W6S5atgXF2tPEjj3GKSo+91Sdizlp4HrWi8S1r3rXxHgEY8oMYI7kilbadQgZjmJbriuz0qoH1O7CbDLatBPLctfE3XAoYHbEjzR8vXj3qI8EFwu4ZLdo/LubIHQAwZg/ajpC29pwbgAkjbAMSQOpj+qjNMFACu/xWWY3wpKhhiOBgeteVycW+PbH17mYvaG5Z1Vu0LgYlQQ6ZgH9Y7Hr0rYhhcG0mJWRAxE85zSNNPcu3Ga5Ihv5KMIgcDjj9arN9rYZi0kEquJ46R0z7UalaW039A4pJaCLFi2rEm40CQFuf5vw4/WnWmlg03CTgEhQB6dc+9Yy4uoujFtiR5ixER2mfqK0Pg1wtbBLAOMXBGTGM4zXZJSguSYcJOKqh5ozb3MBJJjJG3gRA/PGKU+K3RullZkAkHpIxn061L+IJtqrsxxgruzPSMDpSTT+IXTtZF8gMOTxHaOmKRjjzufdmyl4CWvh9ijy3AxGyCQQcgjt9av8a1zWbTFWm4B5R6x2yMdutWo6I2ShuMsiT5yIxOO1KtSR8S2XIkuJnoDGR6CqozSbix0Nrs2Xhr3DatG4iksBvAxBjoJPX1qjVWB5tqDyHy7oM/b9aYaZmKlSRCmJjJwCOtUtB2woI3MSR0IGPxqqONcbOlPdCJNChJuXE+o4zg4/wBqLv6S4bdy2iDYRCw0iPqBEehoi/qdgZuIMkY4jrVeg8Q+Ku+38rsZHaMZnpjIAqT4q8bUomQyNKgTw3whYKneigQREiTxBgz96F//AM/tvSHJBXvEd4I6E5+tG6k/CHxDeIXqFlgTnsojr9qEv6y2B5XJ3cHMfQEYpayylboLTB18N3/92GInaIBj6j2px8W2pCJcLMsA2wvAPJEjjPPpQh06NtlzJzgicfjTDSWVUkxLQSTHNdJJblux0YewTY8Jt7RFsEczjM5rq7/EWTmEM/6f3rys/pn7ibXuZ9tYz7ggmQZg4IHQAjB+lKQHcNuG0n5Z4MdBEQRjpRHxLiBSCXiVClo546mRPp0FDNeuXAq/LcBPlJknExisxyUVar+fQ8eMvYhvONrAsBmCAenf+81O2HADPKQZ9Sc4xx6+3WqNTvWS3ytO7zEgSRIMQDU9NdLW/h7SSpgETBnIJ7fb0xRXq6vf7GPe0EjVC4NrH5pGQRDKJ29/t96FZLlrdcBJ3kQDJCqDEmOxEA9po/S2xbW58QgmQPICpA3Azu7j6mDUdTqioVQZEFAVyFziZzmYnjmjwT9NJfr9QscvCJOEuANdiSOVE5A59B1z3qtrrWSAhlRyoEZIx79M0SLyqhUBhgACIzPXpEZwKot3LsFl2yCFaT5oyRiMjMfSt4Sq+l7DYxt/Qt0TlrhDgLu69Nx7DMGmmo0KlDB2nbwe/X06UALiblMeYDOTBP0wINS1uoY7mLsBglQRt6yZwxj0in4XGmmWRmkklozvw1Z/+5AX5VE5z69assgI/nVuZzn79Kp8T+GtxQMdVkEY9zH517qFBbdIZSBBGQen6UUdC80VFXYXeCuYQ+pPMCrL8LaUR8zCPQQf9qV6ZxLdJIUj78Y+tFa0JttgcgmQViMY656/erIL0WTKXKSGmmSbPJIkyJwB7ftQovbiSiAAYB3ZPeRULUfDB2j5jxyeDmqVS2ouF2UbVJ2mJP8AyO1Bmi5RQXcmgq/qXIRw222vlyZMgSdozPbA/Kj9NeN1/ibZVSeT+nJ9qR63XpqLdoC3c3loTaR7ckZMjrTHQ6VkkurrOJLAD7zz6V4+ZvjvTGSuqHY1nmO0c5z0jA/PihtbeQzbKfMQT0Mgz74of4igQcHvumDx7RSrUEfE3E5Hcz9aT8PiqaatIBKmh+vjFtQmTgR3B9P9q80via3MWlHzwywAxEZKj9ZmgLNtTbZztYGQd4EA8kqSfmiPvTbQLaVAAdpAJVyFWcDAKwOT36U/4l1DStjpTdaKPEtMrp8QtelSsjymD29PQnPp1oFtPcX4lzeHQEebdMT0cEAk/wB5p7ndhGCxMNMEj1nnrNL9fo/iOWuNtP8AQBAEzMxEMPsaHDNqK/8AQVKxPqNOHi4XG5TtgGR6ETGPpUbWpaPhk7iIgsJM+kdOnFaC14daVWgnJGIxHBB9Imrn0tvaWRbflIG0rJgCRnkj9qOeaMn0xsHctFngmpT4cG55twDqWEqeQIOY9qaoxfzRtABx3n2NZix4b8QsHQKoyIjIP0mfrSnUaX4BLWyQDxB/X8KoxfFNLi0UTwJ+pM0PjeqNzfa2H4awWIgSTwP+aCex5AsgCMJMGCe0cc9RXlhAV3uwAjMnkmOQOlWLp7d508zeXjHC89+tBmyOctrQMYKK0OfDdL/LKTzzzx0j/mqdd4KvzQIAIEzie0Gr9HaNsQC21fz9un1oi7qIGYO7gHpU6juwtLsQabRtbuAuclSFAyQfx7daY3LgRUglmwSDmehk8VC9Z3XDkR05gDqJ/fvRf/TrYWQ0bhj061k4t9hKbVMW3bqgmFX6/wDFdVy+GW/X6sa6nX+I35q+n6GXu6raCVUOvOXjaOhWAZPpP71U3iCxuKc4BPQA5/vtSjTahcQrAAAYjPU8iBmeKNZ948jGQJAMA/eOJ7mlygopL+bPnONaDk1CFdyqSCYMwVP+qZBHqR0+tRa/tYY2zICjpwcCeDmqn1jONvxM+08d/X1Heg9Jf3MWaDsGBE+5njAgfWsg2rvo1Lex3rH2lB5mzkZ6iB5SYiexqvXXmfapAVSQdogR3BPeaGus4csoLTmeimPLzmOD35qK3Yfz7WbaSQTuiY6cx6UUJKLr2/wbB0GanUuF2bSSxy8CPbnvU9A4VXUtDTBI2yYzGQRz0rhqVKwABwQFhYzzOD0qq+84BG4dGGduY8x61vzKXF6vz/sKM2lxI6fSfzB/MlScncARnIMTnIx/zU3ti2xa9clc7QFhj94/KoeHqTcIJECJyJzMf2DXvjOluXBbRGBIzDHPAE4E9AM+nvXcmpU3X+hnzHypgfimut3WgiBHlO4k9MRNUKgS2uxtwPHl4M/XvQCWYP8AMLFpgBRuM9cgxTTVXFRBBAYnyqBkLBlue4q/HG2q6HTfpPEktMjaMboxuxOMg9PtUvELh3KCenQz3H6V1u0s8EHEY5kDpmKl4ri6QW3esd1z9jj6VY66E47uwvw62rW2G+O04E55xQF7TB2RSo3MwExOBg/T6Vfo7hKlBwSASZx3MUVoLmy8DAfZJEGRPHcGPMD14pOV/wDHKuzWpc7rQTqdKlp1baG82BHlQwIjr0+k0VcR2CynXEevHtROm1i3SWaCAdphfL1Mlp5wftV+lvKxncTiSIxPSDn1rwud1a2g4zafQivaG4rkXCFBM8E8Z9OKXanStnYPiYJIkEgT1z2rQeI6D4jSrCQeTInr0xHqYpd4ro0t2rYCeY8knrGQelPhNJre2a5oHsaoPcJCqoMZUYGOn9madXbquoiIBwCefaf0isXachQCCuSJ6Dr9ac6e/IVYUkdQM4HXFNzRelFmyly6NJpVB3gsCYBAjrAED0qjUKGxuiBkf3+lL7Vy5HkIA+kgc8GrdQ7OiMuc5/WpYRk27MigvTLuld5UDmOtXN4kFMBgemcce2aT6ncsFAMrLEt9/YUm02p6wAfrVKinofCSNm/iqeaVmcExH50u8RdLsA+WMCKz2p1zEDPk4Y5jv96hdumBIIBI557ijUEjZZHZpNFaRzD/ACJjI6/Sm+n+HbkoIED6x071nfCNa1yFIXaDy0j2zTfWpAydpiYWIjuB1+9dOA2Ew25flCdxE4MZ6xVTuLagSZM/1SaF02qX4dzZJCJLTzJ4/KrteV+Fa3GGKyVGZOD29aVJSq1/GMfBas9S/tMjjtj8K9t+IKWIHGePz7UlVyg83lgnygyYjr1paNW+6A3JP9MgDsfT61zg5aTETk5GwYj/ADA/eurNXNddkxEdK6upirRln05UbZlTnB+n94q7S6gW9qmHAk5jr68ihr10QDg5gnnaPX8ea5ipASdwkwcyvuImD+FUSV6ZGlaphWp1KgnaBkQBM5Of959Kt03yzuJIPK//AC6Tx9cUBoXNtijKVPRp6e8HyyZ7VdZusjMXJBJ5AAB9o/MULS6Mkq0M9S67NyTnlQSIIHI6cfce1A6d1wCGLnJIz7R7Z+hoW9qQBtLMqk/Kp+3SDRQYgApu3ROBkERP4dBWqFoyMXWg7T37gwxHYSPoQD+hj60fbeQQ6wxyDMExjH71nNFqg1yWKgQRujr0P39Ooo6ygDqVEgjBJiCBOM8xmD96Tlx0teQJquxsddaBMBgYAPaRzn++aktxCQzsQTwGJx9OR1oTT6hBLbSCYE5HpMHn8aCuaj4hIJY3JAUD+rMGTjjuKXDC9U3sCFthz3lt7tplZLnoFyJK9we2aS6nUszi4R8zGSMwoOIHt0oyVeFbKjduI8xZhAkHGB+9WXNIBbS58QBgxJB4A2ArAjqQRmRNelGoLj58/iWRdR2EoGeQj7vPtAG0TwQcA4j1oLXvNxtpOXbkD9Iox/honkuK55AI6wR1HHX/AIpXIkZH396oSp6MxS5K2NNAh2ud5kAGIGfw9qqOq23FjcfN5sLBXJP5T9DV3hShg8uoGJJPA6kDr2+tDLLs13uxMATAJA6dIn7GlZG47CtcmGXfKxtqf6pCiSDPH9nip6e9etXCw8x4g5CgfWolRcRSSqsBsYHBJE7cn0oN/EFs7WdsD5VHPPX096jnhvI0unv+MZCL78Gq04LguPLuzyB5f1nOKWeNHeMHKkeUk9+nei/BPFGueb4ZWcCRE/fMU8Fq3cEXLaEjqBmtj8PT00E8fJWYZbTuRP2x39TTXUWvhhWkkx3Gc+3tTw+FILm7cSvVWE+mJ5+tBeL6a3IYOQAIKnPpicUnMpxmrQp6ewC8zMmAY6y0DH0NV6PVH4Y3/LJkDGPelXiOvuIvlx26yKE8Mcsjy2RmD+VMx40k7C0jQeJ3GdMYBEjv7Vnk0rwxGMZJOAPWmaO7DJkEQF9fehzZJOJHHEkff96KMOKpGw7ostm3ctmyxdUXzrtiSREzz0mM9q9awgCQSc5ZuT2jPapaS0vxF9Wg4xkRV7213sxYyokE8K44xgfSicEo2g2DJ4wqXCseQGYBnzRzMTFFL4l8RmJJgL9QPSli6VLrTJAMmD/m+3HpRKWYUgEzED71umg4psYeFX0WYHnYEkdT2HEUat27c2qUEkNMRuUng+3Skil7QJAO8iJPNW+CXbltzvad8CIxkiZ+lBkblEyUZO0loafAt/EUs8mNrKMqT0ljENg8UFY0xLMSDEkg7pPPfiabeF6Ybdtwqu24Rtgcdgeee880ZrSnlCtBz/ZjtSVLi+IUMMm78Ge/wTHg/hXU7tOoAG/j1rqZv2N+WfLr89QI75Bz0JH95qVmzJ5I7yTC/apBjM5g5MHrkRNSuaV8QxgZMSRnIB4+4mqZpqVLoiTIXSycGQDyDuHOSM9u1df1BgEDyySJ6fj9qgisjSGBk8Rg/bv6VBL72zBUHYTKkdCIOZk4PWgdXs1RTdshdckjB5EGPrkxHrNH+RbYYtLtxtbAHOR+9Bau2sYO4M39JB4E9Cen2j7VsoAiDMkAgcjoY5rGjpRD21LQLnllTJGPMJ5xwYwa6zr1IMggAkpn5R79T2496W6i7vMxAHpEVyXISMT9fx6VkkmgPlqtj06rJUqD0G3IwOgJwZz+tW6jU7SlskC45AcjhFI4nmfWqhFvThr4DOQRbXghTwW9unag9Ft2q27hl3GcjkCPb9qaocFfl9fQHhxVse6HUm0CpIJW6RIiCCvfiDIPvRt7TKd6iYCiAwyNrTHqIb0pQD534MqGxHIJ4jBwoP6UaNTHygbpZdzGRDCQAeKXCN2bjtyBrlvai8zAxPJzVS8cfj70Z4pqd9uwMk7SScCfN+kc0Agx6+/pVa0h8FQ48Hfb8Ux/9s4n1jP3orw+1aZCty4bW3aFCQd5LmWYwZADfak+kZgSB2JOegNXuHIBUcQsep/GPOKRllJ+m6BklbZ1/Urbt33fzoTAHA3T5SPpH4UL/DegDBtXfyQCbSESDGJg884H17Uq8TLXLo06mQCS0egzn/So+9anU6oIlsqoCOgjbOOBtiMQI65zWOMpwpPr/AcK8ja1qpUE87ZarvD9SWHNItPrR55wQYzTn+H9MzgKoEtnJ6e/SnOFSSj0OjL07D314XBz+NBa1luLIn1ExjvR+otm0QLjIkzAkGY7QaDutbP9fNVPCpwpsmnK3pGT8asLO1CCSO/HvS7TOwO2YAMkQMmtPrfCrdxH/wAKzvqFJd7TeUm2ME2xw0H161i0uEvlTH2OP1qPJDhpmXfZq7WpnBAMcf3FXG/A8oKj2+/40o0WqAQH5ZHufrVz+JKIEyIyZ5qV90ugXqWgm1qFncM98ftQmsuuTBSAPTr/ALirVe2ODg9KLS/aUk7iDgQwx6Rn9KPmuhykAaa1GWkeswKYG4oG4sYIkRxSfTo1zezNMHEHEEjoD2mjL91flWI4HTHFPhGO/YNSGGlbdJgmfvRx0TFWlQDzJGQB2pJpdU1s8ShxjBHbNPPD9USPMx2x5SYI+080icVv6Da4xRRo9MyuwLEm55vaB0+gpqnhynkz1yeftSzUsd/lYyD2ifY02sXwFkmJOMGY7mOldHhxqX5Dr1cQu0ltQBtGPQftXtLzrSMDawHBzn711H8jH/d+4u37Hy+1cgSSR7dPeiPgOygrDZkREGYk9uK8QWgn/cJcj5QuM9P95rxNPcljujunGewkRP4UeRpeSFqj19K4uI1wjaDgjIgMoMx0z05pno9Pa+PdUqpDKGQk55IMTOD1HPtSLUaovtUkhgABHAiZx1Mx1rrepdLgeGE8NkdjM9vWp4tv7XYUG06ZcdKFvFN21AGKbj8pngnr196BvbiTswJjasgsP80dqv16ks8tu827eOpI49o71f4H4Wl1trlxCmQDEZHMqY5NG2krC0xchnpEESeM+9O9NpFt2/jXBE/9tD8xPf8A3q/W+FJZUsrhkBldwkEgdTImTAxigb157p3uCBtEA4kf+npj9KbBKMVJ/kLckS01y403CWYzmckCeq9auteHstkXpGw3ChHDAiSG9QMD60T4ffRLOpLMu4wgQxJLQSwxyP0oCxfcIQJKhjIMmAwAmOJOa6b8vdiZN2MrmnCuGQ+UpHPJmDg5zPHGaXvqWDptU7oAj1jZ+f5VD/GEJJyJwR0x260RevIXtNb8xUhmdZBA3bsjptJ5yCI9q7FCUk5Ja8/iMxvjJIlqbfwyttv6dxJMzJ7/AKVy7TP7elEeOWGW67Rgkf0iJOeY4/eqQQRMJxPGf/1pjeilxolYBAb5vovoIz0zTcKoSRtLLB9QolvpkrSsGSICxnI+ncd6K8X1oXTuR2MfVoH4IKVKPJ2Jn7C7+Fbau+ovOwBCkIJjcTyF7mIx61oksC2y6fb8XAcYgqvHUZMg8Uk/h/w9fhWG829nLEHI2rOQB/pA+1Otfq2F/dtyqr2HlLGTyQYE070x4uPlbAXLk76EN+9tvcELcYESOhPqJ719G/wxsaM3J/mXFlRHyr0+prMeKaFbl3TwFG64on0ZgT9efvX0fxvTC5bI6AY+nApj0xq3o+PNbuM+4zMQozgegoLUu9vNx9nYdfwzFNP4k1TW5S3g9W6/T96xF5mZiWJJnrU0rerGXRsvBv4gtW3Rix3qcN0Hv6f30o/xXw60Xu3rSFkc/EHIHmGY/wDKcGsFb0xDqGxMH6V9mvapVtWXwB8MD2+9bkU5YmvahE+9GD1WnufDDASDMACIj2rzQ+GXbh8qBQseaCZPUT6Vs31gIMKWkdIg9jUV8TCDaE2z0AyfqMTUajNKgfUjHXdFcVlVrRBn/KYn3iKk99H3LcUkqcwMTPWtZfui4JKeZe4Bn2FVMyqP+2qh4ztxx1peWbglaM512gDw+1bRAQh2nOeB25zXuuRW8wT0kR/ZqN9gN0NxyTIUD07z7V47K6A27nptB2kt3/5pUJSTUm+/xNTrYPbcEEHPtTXwjSCAY2qRycnnoKTaBn3uLnTE43YPtWh0Osd2KoigADaZ6U74jPxriP8Am3olqIDMWMgRg0RZd3INsz0IxgjpVu5SCCFaVzuI9yPwqnT6wAhEhSZAC8GepmlL4q49bX6BLLxI+Yf0/wDxPXPavKLtq8cr1/q9a6s/rF9Df6iR8g1jbbkjg00ta3awOw7YjAMEdM9x60q1zAjAMAn8P+aM0V8bVndEdOJ7ke1eo13QjwRVyXZlA6E9RmZ9O9XatEVQQgBVxJA/AjEDND27wDtBJBGFPQz60z8Vsslk/EcSwXYAPnyQSCegj0qWVqaMrYptXZOwA7GuznkjEA+gFaTwC7cS5d1DqgQqUhhhjgAgTmI9ppV4ZZRbguuV27i0eYjII2g/KT6g0drHN+NpVbQwoLGWgcwqkx0nvVkMcYr5mTrwvdnS9gDxjUPeIiAhkADrFU2bybQrHGCJMbTHvxz7flRoSpVg04mT2E4A55zNNfA/AbmrcW7e0FfnY4VVBgHAmcjoZpWSbk7bMbrQLdCgwQIIViRnoRIj2qFtmW4sEdcqRmJ+5zTj+Iv4Vu6bZce4jWWKp8RZ8mP6lIB7kRPHeq9fpPh3ltsWxneqAEkoCpCknykg9elbJXYu762KHTygkeUk4ns3QUVYv/Bt3AjxuG0SASVbcHExjG3HpU9PZlLvlkqSZkSMD9+lEa7w4Qu2cyRPtJ9+PxoIZuEqQVq0mXJ4gbtsb2fdPRBEepketefEI5uLEf1Ln7bvShNNadCAGUdeB0+01eyM8kkgHqVIzPHzU1tPRVzT2Xaay1zi4VQSWaOO3UHnpQv8R3It/D3l7jXAPlgbR5cZwZWI7GitHpRgvchAZjMmONw6iQKEvXfi662WGVId44kDdPMcgYnM+tC5xqkJk/UafTBLbIoXy2rQUxMyxAJj2UmPWrNDbt3N7yoDXDAjG1fLGe8E/WgLgIS7dFxdpJjafMCo2iQZgkg4z83NEXLQtW9hbeLahi4BGY7THoaB5Ip0wOUWxXc1AtH4kttt6hckzKK4BI7QQRFb7xv+IltgEEGeI7d6+d3/AA28bHm8y/DmFyZclm3DnFKNP4mTaVHbKYE9qe8lxpD8b3bNh4lasa2Wtv8ACudjwfftmsf4h4BetGXAgcEZmqbfiDqSVp9Y1Tm1Nw7gwnY3A/3jrQQu9hy4voV2LO62LjY+HAz1JLEqPaJ+tbDwPXi75WPA2DggwATg+/PpXz7VaswEwFHAGBnr7+tbn+DHA0ytkks85A6wOnp+FMy5LhX4E8lQwL2wRCOS2J28e45AoizpehBiekE47mKgusXfAyOOpEe4nNH6a4vyhTzzPfr/ALVLFb7Br6kE8P25UmOxpT4h4W7XCEuxxKmWj6SAZ+lNTq5kebHGDSzXa0KN0jPUj8OcV2adpR8nWI38KvqW2XFYbSQT5WMcgrkA++KAS29jdvCstzqCGgj2OKZMCzBha2ls7pMfSen0qu74WARMrOZGQZpCUum0NjG0C+CM92+OcA+Y8Y79a0GicfEId4WSN0AT/eM1Z4NYCyoTiq9T4WxO93WJO0SPpIjvUGTMp5Gpa1oC1eyGo1XxLn8tpzjy4B6/SetEeHaZo33CFO7b03RmIxHNAWrhtsfkYsMwcAx1PPNaOyoNvzDdnDbcfnS80+CUV0a6s8+GTmOfUD9K6ll/VJuMLiej4+kiuoOLM5fU+f65fL0/YmcV54TqdoYEBumeM9aYPomu7gBtyIwcSf760rWybV5rbe0/SRX0kbpS8GwdovCD4qi4VaYM5EZzMijjYfUsJuE27e4fE2wCCeFk5POYEVK34ObjoZYILYJY8DJwDAnMiDn3qet1W/8AkWiFABJOAABzRYsSrnPpGXXQJ4v4mMW7Y8iiCJMEDvmnfhert27QuGGdVlVYEASD0I28dRzWd8KtjDuQFVgxHVpxA6DHWmf/AFEDSOgcEqWRR1Kng59CKR8Rlc3S0tfkc0uiv/EJcDXDbS3buMZW2duw8SBxBjpgduaK/hLxUWLlyCSpABK8mD/T39qTazaioqxuCicZ9556xH51b4WqrdtgnDeUnAiePyyaHhzu/Jjjps1P8S+OpfVragwXWZxiYEfcGhPGU/l2pUBraqCQ07wDAicyCT9+tAeJ+HlCV2yZYqwzI5BxzxHpBq/W66LOybTfEBKmdzKIWeMKdw5oeMot8d292L49NFOjJ3vbJKS2+SvcbSCuMYFT1Oo320M+dQAMmDAgzntjpQH+LPxd5lzAMlueDyCe9Utq4BG4RkkROScc13y1ytBxi27Ybp3ls8RwJxn/AG9aOuvDZKbQOA8/ht4ikQcQTKzHQjt2q6zcPcHy55n8vanuF+RtDG3DQAQJBnPQj6etU+An4mpuvIljtBaIAmSe2Ao+9C6rVFVJxIQ9zzgcj1ojwBItIkiLtzzT/SAYP1gGhcd2DPWx5qVtkLYttuXfl8CYG4/TdFEalCQtsmfiOFIBEFFJYmfUCPrQF6+nxnNuFXbtAUQJYzmePlBiphDdu7TcC/DSA08Mxx9gOnep546uSJmh7a3SfKNqgAkkcZxXzXx7TfDvOFjaWJEcQTits3kbarbujLyOMHisT/ELH4rA+ke0V2GTcmm/A7HO3Q4/hRVZXO1S24Az0UjJHerfG02TtwKU+BK6+ZSPMYIOI7GfvxTnx5IQEkSee5jr7esCq4r119Bl7MbfOa+k/wAP2f8A6FFidykiPUn7HNfN7i5jk/rX1fwABLCpuU7BkSAVMAZBM49qVn5JelWDkbrQktIVC7ZUbSYJ83MSx9opjoNWZG4r2XIOemQfrmvdRrPK5ADJmdsZkf3xWf0nnI+GrDoZPl75yc/SlRae5ICO/tD7V+JFHKRDkEjjI6RkUFa8YXdtuICrZnOT1X0oS0lz4j/EYgIvlAzgZJg9Pb9KaaQC5/MGwSoAgAEk9OxNTZMi2nv6r9jr/tVnuvui3NtJCtnEGB27irzbuXLakvEdP6mEYgAUb4Xoi25js2gQu4AkEHn07U71GqIUbLe8GPlAEEdj69qklncapWxseVJmF1R1CQAHUSGLRMx0x3q++tx7YK4V/mIY4k+1PnN7abgRWUZKlob/AGjtNLE1jf8AbO1WEsAxxHQN60yalJc0loKfV0Jn0pt3l2mNxAM8E/rNO/8Aq4Q7XdiflPQjpheIxQepU3LobO23yTgqYkCOufzpe+luG5vbYufmnJPsOaZDGpxXNJsS6rsZfDQ5lc+prqHLxjehgDqO3+npxXUPyo+37szgwDQeIF0uuwVQkYk4J6CScYBpK1ltVqBs7Dc3QDuabaHSbw68sxEsQO3U15rL1vSobdv5jknqTX0UIcoq9R7GyaR2t1jIi6e2QWmBAj/3STn1pFav7HYhQXA2AHksSRMZyOnGYqehuIxZ7hnB579Ks8G0fnFx/lM7JzuMx+tT/EZr/wCq6BXptsKXS/DjcxgwBAyeCeRj86G1ulXei7tquAWJHETMcTiIA5o+7bbeA2VUzJOCe0daB+Nudrw4QiF5BH9UdMCo1K9oBSd2Ml8GVVzv3ESAwz6TyCe8cdKhc06WmDByLqgXFB4wQcR7EROZo3VeIyCwUIogDaTkbfU+3FI9ZqwwRVZiOu8ZHsZzQY5zbVmRnJjDxfXuxclY24VgSBt7gHkGTPalem3HaAhM4wJDRz+H5VNXItoSN0SNpEiOk47zV2g1tyxBUtbZuMZCnMrPQ1T5bfuMfQtZuFHB/PvRKMBmAZgZj9amLEMVcgEEwcZzP61WoELmSSaZCKCS0GJqIBwuABkfsBNerdg8DAmY7kUDcMqT3b96uuOBO3mIM/Sj4oLie+JKWTESRMdQAc/Sj/Atu+2rDCoxmO42jj3NLEtmRJ5XjNM/CN+y6bebkBAMzE5M9M/2KGlZzS6J6bSgKHJyznaOODtk8TiDU7WoO03FkF3J+WcDE88QJ+tD6Oyz3FtAqpY7QzGQDETPb2pvqNLbs3Ft27zOEWGP9O7jy57TPNco8l7IS1fp8kLF655jESMvmefwrvDrNvU/Ha5bQk4Q7eNoAkAZ5yYNQ8XvhUeG8x5BIM8QRwZ9IqfgVoW0kyWgQIGO/pzS44uE2x2LGlLYCmnNu5tdVMETPBHIPFT/AIz1gdrUDBSQMTE8GOxBo3xVFMXN0n5W4naeMDsfzrJeNXD8Qg9hVlpRs2SptIo0NwLeRzwpDfbI/Gte/wDEVsXBcRGub2IYOVkyOB6HvSH+HtKrh94kGB+fFMPjJbuG2lu0oHJjIjrLEkmhin2vJi0g7X2S9tWB+HJiOyxx61b4DoLaPv3Fm7sYA6TzBNG6W4zMtwXAbcYUKIB49qu1DFtiqJbIMCOhx+szXmfHwyY0l4d7JM0pVSZLXbCdxUkxE8SM/el1vSpt2jyqDIjB3Uz09q5cOwsFHeJq1/CGiUKsAcTiR2z615cZKOnKhEHJOy741pLfVv6eRLYnc0Gla+N3G2sFCqI3EHyyPUdY/Oi38HYxsYndlrYInAzBFEK5QbEtQoEgOIlcSSOC0jmKJZIKWlbf5Fy+K+gLf1bsishjdJIGMH8/rSV0W2GuP8wPlnt69wDWrtqjJua0CxHzAcj27DiqNdpLLW0IXzW8qvc+s8nPWm489R4R99mZJ8l6WJPFXa4BtG6VkuoO1vU+36UANtu2rxuuN1K7io6Ymfzou61x2YMdtoZJKE/QGlXjGrIfZa+SBEZParscfTQqK+6Gf9X0vXTqx6nYRJ69O9dSX45OWOTz/LH7V1P4xC4odXb401soCZ7nn2+lZXXfELS4Oe/qKd+GK1+4LjAEA4U8e/3qj+KLZFxjHUD8B+9XZppxqPSGpNbYitcMtP3skW7cQuDkCOg5j9az1l4YGtHqNThZfPOOBI6V5+RN1Rk71QFeckTIj+8H9690lxQmwqZycf1E9DGfwoTUMS22IBOQPSmakJaZy43HEfMR2Jx2n1oZVS0bJa/EDs6ltoUk7Qcjg+39iqijDawMEkn2/YVVeVt/B3e0fWOnSmekW2d6u20QAOpPJ9Bn1nit0jKrYCdRtJ28ewP1+8mvE1TM0tLERBJmI45+lGavSqBbKySwMiMCCIg9ZEmhbloyOhMg9PX9KeMSCdUhJLOZ3ANAx8w5ke1VBAGWeAJz0PNQdGMDqT+HAq7ZLGT+H07USpG9HvwxsEERODioFSd4Hp2q5VIAA2/VZ6xjsakwJDmB2wo71ujT1doKk5MdxHX6VXZuEBQGI3MCY5xJ9+1St25KHMTGMfpios0u3lggY9uk/QUEuwfwLnZWwbnJkqBMkCRn1MfjVmnUzwBPAnM/WqbCI1w7c4GM5nJ9O3NNvD0/pMY/pOcH1jHtNL5da2I5NMXPf+I9tnSCCZnsD+U0+IVRuIlTiZiJpatkk3Lkbk3FZxwOfxM4q9NbHkCqR6j8jT4xVW+ynHsa2rNtgwdDBEAq0DI61lPEPDGZo6php5OcfhWj0GoI7leSojeveJwRXeJRv+KMjCsSIkdCQDyDj606KvtmtMz38OeFvcuXLYlSFnrAM9Y6R1oh7BR2b4Y2nB2w4MH6z9KaadgrM2crtJTkrMigH07WrguW2DKTJUiYnoy+lG48WgPA80zqdI222QRPlUzHqOojn6V54VqluAWy+1yJMwJ6c9/SopCJ8Qv5XG07FjzEcbfr0ofX+EKLNq7aIVgoDycnuRPWe/6UWfDHJBRkrEuKl2aBEFrbJuEg5jt0x2r1dQW3KDucnMgqY9pEe9Zz+EtezXLlv4jt1UHnH9/hTm14oymNm5xIlh0n8Y4r5f4n4SWOfpVrwyacOD0HaIXFMMqyOjYwR/mioajVXEEm2pj/ANW6PUcVVpbnxdpZjuJ6GI7D+xXnium+GpLsSOGUGQM49TUsUnP1JWcmcniFuSSsmI8pKn6waB1/jLOjLG0CI/zMYicfnS666MdySoJ7Y/59qlfSdoyIGDyIHce9XY4QjK2dy8M9t6lW2xc8oB8nBnr3n2NAeIWrVxFPU/LsEn1k4z71G3pbm62WyN32xnmJjmo624m4I5AtycoAZHeQSRkcYq2KTqg4rehFdtkEiePU/vXUYXt9EQe5JrqbaG8mPvAPOFIAUzGOAAOnvSv+JrZN24OcbvsK6uqn7iH5PBlTRrXpUSTxXV1IODLVxAztkQu1R68muvXP5QnMsRPpFdXVyGfdZK7rC1tOBsgrjPMfYdqvvXkdTK5kbiCcsJJxx6V7XUuMVf6iUvUj0NATbzuBDQJHKx7Z/CqNU5Yg9Q2R6kx+tdXUx9heT0nziegJ+309qlaO4GYHTge/Qe1dXUXg2RZYJ3AYwByB+x71Wt3aGjvHTr7iurq3yzPLJLfEoevpjr/pom2waWYz5mkHkgY5HHFdXUE/Bj7RBVwr8C4T/wCJBIAxyIAqt12qWPTiO/Ga6uro/wCxUOmFeHPB+GeI8wxIJHIPufxqWshHQtJU4MRNeV1bi8h4u2GvqbNxT8MPbdeGmQw4yIwc80Oti6QylyQckT+NdXVSh4RpWlQeo8re1D/GFm9LLuUnzZ5XtXV1UfdQkcpr7YdrLibTjcpiCAY7dQetEeOakWrQsbZDAKHxP/qJ9esjma9rqN9MBGFBexedVYgkYZcSCAR1xWp/hzxl3U74JXGR6dxzXldXlfFfYcfqDl+yObV92G5YHbAkfhQF7Ss5855OSev2OK6urylFWyZvRadiKoAEbpOOD6TUn1iwRECOQB9K6uoWjvADqHDEEgAAzIAmfrND3LNlvmUiRO0GAcjzYXnuOs9K6uqnCdjbs6z4RpmUN8F8/wD5B/8AyK6urqrDtn//2Q==" data-v-6ef898fc></div></div><div class="wow animate__lightSpeedInRight col-lg-3 p-0 order-lg-4 col-md-6 order-md-3" data-v-6ef898fc><div class="latest__blog__text" data-v-6ef898fc><div class="label" data-v-6ef898fc>Restaurant</div><h5 data-v-6ef898fc>The Kitengela Glass Bridge</h5><p data-v-6ef898fc><i class="fa fa-clock-o" data-v-6ef898fc></i> 18th August, 2023</p><a href="#" data-v-6ef898fc>Read More</a></div></div><div class="wow animate__bounce col-lg-3 p-0 order-lg-6 col-md-6 order-md-5" data-v-6ef898fc><div class="latest__blog__pic latest__blog__pic__last__row set-bg" data-setbg="https://images.squarespace-cdn.com/content/v1/5bc06d4a797f742708fa9b93/1573551192823-U3QJV6J9E6FFVA88YVGU/DSM-20190811-IMG_0491.jpg" data-v-6ef898fc></div></div><div class="wow animate__lightSpeedInLeft col-lg-3 p-0 order-lg-5 col-md-6 order-md-6" data-v-6ef898fc><div class="latest__blog__text" data-v-6ef898fc><div class="label" data-v-6ef898fc>Travel</div><h5 data-v-6ef898fc>Mbagathi River</h5><p data-v-6ef898fc><i class="fa fa-clock-o" data-v-6ef898fc></i> 20th August, 2023</p><a href="#" data-v-6ef898fc>Read More</a></div></div><div class="wow animate__bounce col-lg-3 p-0 order-lg-8 col-md-6 order-md-8" data-v-6ef898fc><div class="latest__blog__pic latest__blog__pic__last__row set-bg" data-setbg="https://pbs.twimg.com/media/DuRx3G5X4AE3oSG.jpg:large" data-v-6ef898fc></div></div><div class="wow animate__lightSpeedInLeft col-lg-3 p-0 order-lg-7 col-md-6 order-md-7" data-v-6ef898fc><div class="latest__blog__text" data-v-6ef898fc><div class="label" data-v-6ef898fc>Travel</div><h5 data-v-6ef898fc>Mugumo Tree</h5><p data-v-6ef898fc><i class="fa fa-clock-o" data-v-6ef898fc></i> 22th August, 2023</p><a href="#" data-v-6ef898fc>Read More</a></div></div></div></div></section></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Heroto/Landing.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const Landing = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-6ef898fc"]]);
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<div${ssrRenderAttrs(mergeProps({
    class: "footer set-bg",
    "data-setbg": "img/footer-bg.jpg"
  }, _attrs))}><div class="container"><div class="footer__content"><div class="row"><div class="col-lg-3 col-md-6 col-sm-6"><div class="footer__about"><div class="footer__logo"><a href="#"><img src="img/log.png" alt=""></a></div><ul><h4 class="wow animate__lightSpeedInLeft" data-wow-duration="1s">+254 723 160 888</h4><h4 class="wow animate__lightSpeedInLeft" data-wow-duration="1.5s">info@maasailodge.com</h4><h4 class="wow animate__lightSpeedInLeft" data-wow-duration="2s">Magadi Road, Ongata Rongai</h4></ul></div></div><div class="col-lg-3 offset-lg-1 col-md-5 offset-md-1 col-sm-6"><div class="footer__widget"><h4>Quick Link</h4><ul><li><a href="#">Home</a></li><li><a href="#">Booking</a></li><li><a href="#">About Us</a></li><li><a href="#">Review</a></li><li><a href="#">Contact</a></li></ul><ul><li><a href="#">Services</a></li><li><a href="#">Our Room</a></li><li><a href="#">Restaurants</a></li><li><a href="#">Payments</a></li><li><a href="#">Events</a></li></ul></div></div><div class="col-lg-5 col-md-8 col-sm-12"><div class="footer__newslatter"><h4>Subscribe our newlatester</h4><form action="#" class="wow animate__rubberBand" data-wow-duration="1s"><input type="text" placeholder="Your E-mail Address"><button type="submit">Subscribe</button></form><div class="footer__newslatter__find"><h5>Find Us:</h5><div class="footer__newslatter__find__links"><a href="#"><i class="fa fa-tripadvisor wow animate__lightSpeedIn" data-wow-duration="1.5s"></i></a><a href="#"><i class="fab fa-facebook wow animate__lightSpeedInRight" data-wow-duration="2s"></i></a><a href="#"><i class="fab fa-twitter wow animate__lightSpeedInRight" data-wow-duration="2.5s"></i></a><a href="#"><i class="fab fa-instagram wow animate__lightSpeedInRight" data-wow-duration="3s"></i></a></div></div></div></div></div></div><div class="footer__copyright"><div class="row"><div class="col-lg-7 col-md-7"><div class="footer__copyright__text"><p>Copyright ©  All rights reserved | Developed by <a href="https://colorlib.com" target="_blank" class="wow animate__rubberBand">Michael Saiba</a></p></div></div><div class="col-lg-5 col-md-5"><ul class="footer__copyright__links"><li><a href="#">Terms Of Use</a></li><li><a href="#">Privacy Policy</a></li></ul></div></div></div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Heroto/Footer.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const Foota = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = {
  __name: "Home",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Home" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(Navbar, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(Landing, null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(Foota, null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(Navbar),
              createVNode(Landing),
              createVNode(Foota)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Home.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
